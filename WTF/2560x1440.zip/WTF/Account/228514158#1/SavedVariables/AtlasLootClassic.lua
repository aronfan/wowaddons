
AtlasLootClassicDB = {
	["global"] = {
		["__addonrevision"] = 1050001,
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
			["minimap"] = {
				["minimapPos"] = 189.796629774518,
			},
			["GUI"] = {
				["point"] = {
					nil, -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					134.555435180664, -- [4]
					41.5555267333984, -- [5]
				},
				["selected"] = {
					nil, -- [1]
					"DireMaulWest", -- [2]
					6, -- [3]
					1, -- [4]
					0, -- [5]
				},
			},
		},
		["玛丽苏本苏 - 龙牙"] = {
			["GUI"] = {
				["point"] = {
					nil, -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					126.844528198242, -- [4]
					-40.622184753418, -- [5]
				},
				["selected"] = {
					"AtlasLootClassic_Crafting", -- [1]
					"Enchanting", -- [2]
					4, -- [3]
					1, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 199.953046523251,
			},
		},
		["潇潇 - 龙牙"] = {
			["GUI"] = {
				["point"] = {
					nil, -- [1]
					nil, -- [2]
					"CENTER", -- [3]
					140.000122070313, -- [4]
					101.999992370605, -- [5]
				},
				["selected"] = {
					"AtlasLootClassic_Collections", -- [1]
					"Darkmoon", -- [2]
					nil, -- [3]
					2, -- [4]
					0, -- [5]
				},
			},
			["minimap"] = {
				["minimapPos"] = 190.753836235418,
			},
		},
	},
}
