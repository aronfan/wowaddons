
boomTimeSv = {
	["instance_timer_sv"] = {
		["locked"] = true,
		["on"] = true,
		["pos"] = {
			"BOTTOM", -- [1]
			nil, -- [2]
			"BOTTOM", -- [3]
			-314.311248779297, -- [4]
			2.48915648460388, -- [5]
		},
	},
	["target_warn_sv"] = {
		["Player-4920-022A2037"] = {
			["on"] = true,
			["locked"] = false,
		},
		["Player-4920-01D0BF72"] = {
			["on"] = true,
			["locked"] = false,
		},
		["Player-4920-01D0A6FB"] = {
			["on"] = true,
			["locked"] = false,
		},
	},
}
