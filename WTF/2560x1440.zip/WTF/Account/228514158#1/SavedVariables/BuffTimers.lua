
BuffTimersOptions = {
	["seconds"] = true,
}
