
BugGrabberDB = {
	["session"] = 320,
	["lastSanitation"] = 3,
	["errors"] = {
	},
}
