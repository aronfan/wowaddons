
BugGrabberDB = {
	["session"] = 174,
	["lastSanitation"] = 3,
	["errors"] = {
	},
}
