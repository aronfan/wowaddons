
BugGrabberDB = {
	["lastSanitation"] = 3,
	["session"] = 103,
	["errors"] = {
	},
}
