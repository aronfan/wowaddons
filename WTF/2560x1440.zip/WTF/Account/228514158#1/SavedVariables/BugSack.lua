
BugSackDB = {
	["fontSize"] = "GameFontHighlight",
	["auto"] = false,
	["soundMedia"] = "BugSack: Fatality",
	["mute"] = false,
	["chatframe"] = false,
}
BugSackLDBIconDB = {
	["minimapPos"] = 166.206867219963,
}
