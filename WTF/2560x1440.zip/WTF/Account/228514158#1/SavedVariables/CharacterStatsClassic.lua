
CharacterStatsClassicDB = {
	["useBlizzardBlockValue"] = false,
}
