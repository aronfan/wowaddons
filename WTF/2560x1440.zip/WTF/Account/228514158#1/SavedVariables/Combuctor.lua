
Combuctor_Sets = {
	["tackleColor"] = {
	},
	["leatherColor"] = {
	},
	["engineerColor"] = {
	},
	["herbColor"] = {
	},
	["inscribeColor"] = {
	},
	["soulColor"] = {
	},
	["quiverColor"] = {
	},
	["reagentColor"] = {
	},
	["gemColor"] = {
	},
	["enchantColor"] = {
	},
	["keyColor"] = {
	},
	["normalColor"] = {
	},
	["profiles"] = {
	},
	["mineColor"] = {
	},
	["version"] = "8.3.2",
	["global"] = {
		["inventory"] = {
			["rules"] = {
				"all/normal", -- [1]
				"all/trade", -- [2]
				"all/reagent", -- [3]
				"all/keys", -- [4]
				"all/quiver", -- [5]
				"equip/armor", -- [6]
				"equip/weapon", -- [7]
				"equip/trinket", -- [8]
				"use/consume", -- [9]
				"use/enhance", -- [10]
				"trade/goods", -- [11]
				"trade/gem", -- [12]
				"trade/glyph", -- [13]
				"trade/recipe", -- [14]
				"all/souls", -- [15]
				"equip/ammo", -- [16]
			},
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
				[-2] = true,
			},
			["color"] = {
			},
			["hiddenRules"] = {
				["misc"] = true,
				["trade"] = true,
				["equip"] = true,
				["all"] = true,
				["quest"] = true,
				["use"] = true,
			},
			["width"] = 318.419677734375,
			["y"] = -78.6657473717214,
			["x"] = -204.641641582806,
			["borderColor"] = {
			},
			["height"] = 544.296020507813,
		},
		["vault"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
		["guild"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["borderColor"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["hiddenBags"] = {
			},
		},
		["bank"] = {
			["rules"] = {
				"all/normal", -- [1]
				"all/trade", -- [2]
				"all/reagent", -- [3]
				"all/keys", -- [4]
				"all/quiver", -- [5]
				"equip/armor", -- [6]
				"equip/weapon", -- [7]
				"equip/trinket", -- [8]
				"use/consume", -- [9]
				"use/enhance", -- [10]
				"trade/goods", -- [11]
				"trade/gem", -- [12]
				"trade/glyph", -- [13]
				"trade/recipe", -- [14]
				"all/souls", -- [15]
				"equip/ammo", -- [16]
			},
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
				["misc"] = true,
				["trade"] = true,
				["equip"] = true,
				["all"] = true,
				["quest"] = true,
				["use"] = true,
			},
			["width"] = 532.050415039063,
			["y"] = -149.802221981096,
			["x"] = -729.591836895306,
			["borderColor"] = {
			},
			["height"] = 498.420074462891,
			["showBags"] = true,
		},
	},
	["fridgeColor"] = {
	},
}
