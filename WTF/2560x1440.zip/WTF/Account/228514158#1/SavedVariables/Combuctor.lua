
Combuctor_Sets = {
	["tackleColor"] = {
	},
	["leatherColor"] = {
	},
	["engineerColor"] = {
	},
	["herbColor"] = {
	},
	["inscribeColor"] = {
	},
	["soulColor"] = {
	},
	["quiverColor"] = {
	},
	["reagentColor"] = {
	},
	["gemColor"] = {
	},
	["enchantColor"] = {
	},
	["keyColor"] = {
	},
	["normalColor"] = {
	},
	["profiles"] = {
	},
	["mineColor"] = {
	},
	["version"] = "8.3.2",
	["global"] = {
		["inventory"] = {
			["rules"] = {
				"all/normal", -- [1]
				"all/trade", -- [2]
				"all/reagent", -- [3]
				"all/keys", -- [4]
				"all/quiver", -- [5]
				"equip/armor", -- [6]
				"equip/weapon", -- [7]
				"equip/trinket", -- [8]
				"use/consume", -- [9]
				"use/enhance", -- [10]
				"trade/goods", -- [11]
				"trade/gem", -- [12]
				"trade/glyph", -- [13]
				"trade/recipe", -- [14]
				"all/souls", -- [15]
				"equip/ammo", -- [16]
			},
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
				["misc"] = true,
				["trade"] = true,
				["equip"] = true,
				["all"] = true,
				["quest"] = true,
				["use"] = true,
			},
			["width"] = 337.382629394531,
			["y"] = -222.468603817034,
			["x"] = 0.00020412031858541,
			["borderColor"] = {
			},
			["height"] = 501.629638671875,
		},
		["vault"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
		["guild"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["borderColor"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["hiddenBags"] = {
			},
		},
		["bank"] = {
			["rules"] = {
				"all/normal", -- [1]
				"all/trade", -- [2]
				"all/reagent", -- [3]
				"all/keys", -- [4]
				"all/quiver", -- [5]
				"equip/armor", -- [6]
				"equip/weapon", -- [7]
				"equip/trinket", -- [8]
				"use/consume", -- [9]
				"use/enhance", -- [10]
				"trade/goods", -- [11]
				"trade/gem", -- [12]
				"trade/glyph", -- [13]
				"trade/recipe", -- [14]
				"all/souls", -- [15]
				"equip/ammo", -- [16]
			},
			["point"] = "TOPLEFT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
				["misc"] = true,
				["trade"] = true,
				["equip"] = true,
				["all"] = true,
				["quest"] = true,
				["use"] = true,
			},
			["width"] = 554.173400878906,
			["y"] = -149.802771297503,
			["x"] = 659.148620605469,
			["borderColor"] = {
			},
			["height"] = 586.913269042969,
			["showBags"] = true,
		},
	},
	["fridgeColor"] = {
	},
}
