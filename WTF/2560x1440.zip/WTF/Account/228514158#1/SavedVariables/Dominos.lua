
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["char"] = {
				["花姐 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["潇潇 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["玛丽苏本苏 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
			},
			["global"] = {
				["version"] = 2,
			},
		},
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
	},
	["global"] = {
		["configVersion"] = 1,
		["addonVersion"] = "8.3.1",
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
			["linkedOpacity"] = true,
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["anchor"] = "3BR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["shadowdance"] = 6,
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["page2"] = 1,
							["shadowform"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 31,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["anchor"] = "1TL",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["display"] = {
						["border"] = true,
						["icon"] = false,
						["time"] = true,
					},
					["padH"] = 1,
					["y"] = 149,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["point"] = "TOP",
					["lockMode"] = true,
					["padW"] = 2,
					["spacing"] = 1,
					["numButtons"] = 20,
					["texture"] = "blizzard",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 0,
					["font"] = "Friz Quadrata TT",
					["padH"] = 2,
					["alwaysShowText"] = true,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 0,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "3TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -225,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = "3TL",
					["showInOverrideUI"] = false,
					["y"] = 120,
				},
			},
			["minimap"] = {
				["hide"] = true,
			},
			["showgrid"] = true,
		},
		["玛丽苏本苏 - 龙牙"] = {
			["linkedOpacity"] = true,
			["minimap"] = {
				["hide"] = true,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 40,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "3BR",
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["page2"] = 1,
							["shadowform"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["padH"] = 2,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 31,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 80,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "1TL",
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["padH"] = 2,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 360,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 149,
					["font"] = "Friz Quadrata TT",
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["icon"] = false,
						["border"] = true,
					},
					["padW"] = 1,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["font"] = "Friz Quadrata TT",
					["point"] = "TOP",
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["numButtons"] = 20,
					["lockMode"] = true,
					["hidden"] = true,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["y"] = 0,
					["spacing"] = 1,
					["padH"] = 2,
					["columns"] = 20,
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -225,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = "3TL",
					["showInOverrideUI"] = false,
					["y"] = 120,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "3TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["showgrid"] = true,
		},
		["潇潇 - 龙牙"] = {
			["showgrid"] = true,
			["minimap"] = {
				["hide"] = true,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 40,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["page2"] = 1,
							["shadowform"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["anchor"] = "3BR",
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 31,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 80,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["anchor"] = "1TL",
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["padH"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["y"] = 360,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 149,
					["font"] = "Friz Quadrata TT",
					["padH"] = 1,
					["display"] = {
						["time"] = true,
						["icon"] = false,
						["border"] = true,
					},
					["padW"] = 1,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["point"] = "TOP",
					["numButtons"] = 20,
					["lockMode"] = true,
					["x"] = 0,
					["padH"] = 2,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = 0,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["showInOverrideUI"] = false,
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "3TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["linkedOpacity"] = true,
		},
	},
}
