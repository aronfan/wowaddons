
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["char"] = {
				["花姐 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["潇潇 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["玛丽苏本苏 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
			},
			["global"] = {
				["version"] = 2,
			},
		},
	},
	["global"] = {
		["configVersion"] = 1,
		["addonVersion"] = "8.3.1",
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
			["showgrid"] = true,
			["minimap"] = {
				["hide"] = true,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 40,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["page2"] = 1,
							["shadowform"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["shadowdance"] = 6,
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["anchor"] = "3BR",
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 80,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 31,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 80,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["anchor"] = "1TL",
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["padH"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 360,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["display"] = {
						["icon"] = false,
						["time"] = true,
						["border"] = true,
					},
					["padH"] = 1,
					["y"] = 149,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["point"] = "TOP",
					["numButtons"] = 20,
					["font"] = "Friz Quadrata TT",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padH"] = 2,
					["padW"] = 2,
					["x"] = 0,
					["y"] = 0,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["lockMode"] = true,
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -225,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = "3TL",
					["showInOverrideUI"] = false,
					["y"] = 120,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "3TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["linkedOpacity"] = true,
		},
		["玛丽苏本苏 - 龙牙"] = {
			["showgrid"] = true,
			["minimap"] = {
				["hide"] = true,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 40,
					["anchor"] = "3BR",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["page2"] = 1,
							["shadowform"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 31,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 80,
					["anchor"] = "1TL",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["MAGE"] = {
						},
						["ROGUE"] = {
						},
						["PRIEST"] = {
						},
					},
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 149,
					["font"] = "Friz Quadrata TT",
					["padH"] = 1,
					["display"] = {
						["icon"] = false,
						["border"] = true,
						["time"] = true,
					},
					["padW"] = 1,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["x"] = 0,
					["point"] = "TOP",
					["padH"] = 2,
					["alwaysShowText"] = true,
					["lockMode"] = true,
					["hidden"] = true,
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = 0,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["columns"] = 20,
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "3TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -225,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = "3TL",
					["showInOverrideUI"] = false,
					["y"] = 120,
				},
			},
			["linkedOpacity"] = true,
		},
		["潇潇 - 龙牙"] = {
			["linkedOpacity"] = true,
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "3BR",
					["pages"] = {
						["MAGE"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["PRIEST"] = {
							["page2"] = 1,
							["shadowform"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 31,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "1TL",
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["padH"] = 2,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["pages"] = {
						["MAGE"] = {
						},
						["PRIEST"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 149,
					["font"] = "Friz Quadrata TT",
					["padH"] = 1,
					["display"] = {
						["icon"] = false,
						["border"] = true,
						["time"] = true,
					},
					["padW"] = 1,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["lockMode"] = true,
					["point"] = "TOP",
					["showInOverrideUI"] = false,
					["alwaysShowText"] = true,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = 0,
					["spacing"] = 1,
					["padH"] = 2,
					["x"] = 0,
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "3TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
			},
			["minimap"] = {
				["hide"] = true,
			},
			["showgrid"] = true,
		},
	},
}
