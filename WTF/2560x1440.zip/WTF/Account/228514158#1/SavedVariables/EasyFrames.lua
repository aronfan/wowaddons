
EasyFramesDB = {
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["潇潇 - 龙牙"] = "Default",
		["玛丽苏本苏 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["target"] = {
				["healthBarFontFamily"] = "默认",
				["targetNameFontSize"] = 14,
				["showNameInsideFrame"] = true,
				["healthBarFontStyle"] = "NONE",
				["showTargetCastbar"] = true,
			},
			["player"] = {
				["showNameInsideFrame"] = true,
				["portrait"] = "1",
				["playerNameFontSize"] = 14,
			},
			["general"] = {
				["classColored"] = false,
				["barTexture"] = "Flat",
			},
		},
		["花姐 - 龙牙"] = {
			["player"] = {
				["portrait"] = "1",
				["playerNameFontSize"] = 14,
				["showGroupIndicator"] = false,
				["showNameInsideFrame"] = true,
			},
			["general"] = {
				["classColored"] = false,
				["barTexture"] = "Flat",
			},
			["target"] = {
				["showNameInsideFrame"] = true,
				["targetNameFontSize"] = 14,
				["showTargetCastbar"] = true,
			},
		},
	},
}
