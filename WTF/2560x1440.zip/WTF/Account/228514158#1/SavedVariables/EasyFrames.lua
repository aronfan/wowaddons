
EasyFramesDB = {
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["潇潇 - 龙牙"] = "Default",
		["玛丽苏本苏 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["player"] = {
				["portrait"] = "1",
				["playerNameFontSize"] = 14,
				["showGroupIndicator"] = false,
				["showNameInsideFrame"] = true,
			},
			["general"] = {
				["classColored"] = false,
				["barTexture"] = "Flat",
			},
			["target"] = {
				["healthBarFontFamily"] = "默认",
				["targetNameFontSize"] = 14,
				["showTargetCastbar"] = true,
				["showNameInsideFrame"] = true,
				["healthBarFontStyle"] = "NONE",
			},
		},
		["花姐 - 龙牙"] = {
			["target"] = {
				["showNameInsideFrame"] = true,
				["showTargetCastbar"] = true,
				["targetNameFontSize"] = 14,
			},
			["player"] = {
				["showNameInsideFrame"] = true,
				["showGroupIndicator"] = false,
				["portrait"] = "1",
				["playerNameFontSize"] = 14,
			},
			["general"] = {
				["classColored"] = false,
				["barTexture"] = "Flat",
			},
		},
	},
}
