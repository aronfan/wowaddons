
NugCastDB = {
	["castColor"] = {
		0.917647058823529, -- [1]
		1, -- [2]
		0.0235294117647059, -- [3]
	},
	["timeFont"] = "默认",
	["anchors"] = {
		["target"] = {
			["y"] = 100,
		},
	},
	["barTexture"] = "Flat",
	["nameplateCastbars"] = false,
	["spellFont"] = "默认",
}
