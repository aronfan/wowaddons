
NugEnergyDB = {
	["lowColor"] = {
		0.552941176470588, -- [1]
		0.12156862745098, -- [2]
		0.243137254901961, -- [3]
	},
	["fontName"] = "默认",
	["y"] = -117.333282470703,
	["x"] = -100.977600097656,
	["maxColor"] = {
		0.513725490196078, -- [1]
	},
	["height"] = 24,
	["textureName"] = "Flat",
	["isVertical"] = true,
	["width"] = 60,
	["twChangeColor"] = false,
	["hideText"] = true,
	["enableColorByPowerType"] = true,
}
