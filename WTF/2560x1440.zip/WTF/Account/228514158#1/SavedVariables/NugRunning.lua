
NRunDB_Global = {
	["nptextureName"] = "Flat",
	["anchors"] = {
		["main"] = {
			["y"] = -95.2890396118164,
			["x"] = 265.955627441406,
		},
	},
	["charspec"] = {
	},
	["textureName"] = "Flat",
}
NugRunningConfigCustom = {
	["MAGE"] = {
	},
	["ROGUE"] = {
	},
	["PRIEST"] = {
	},
}
