
Postal3ClassicDB = {
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"潇潇|龙牙|Horde|60|MAGE", -- [1]
				"玛丽苏本苏|龙牙|Horde|60|PRIEST", -- [2]
				"花姐|龙牙|Horde|60|ROGUE", -- [3]
			},
		},
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"潇潇|龙牙|Horde", -- [1]
					"玛丽苏本苏|龙牙|Horde", -- [2]
					"龙哥|龙牙|Horde", -- [3]
					"夏雨|龙牙|Horde", -- [4]
					"啪啪|龙牙|Horde", -- [5]
					"小辣椒机长二|龙牙|Horde", -- [6]
					"火抗梯|龙牙|Horde", -- [7]
				},
			},
		},
		["玛丽苏本苏 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"花姐|龙牙|Horde", -- [1]
					"潇潇|龙牙|Horde", -- [2]
					"龙哥|龙牙|Horde", -- [3]
					"啪啪|龙牙|Horde", -- [4]
				},
			},
		},
		["潇潇 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"玛丽苏本苏|龙牙|Horde", -- [1]
					"龙哥|龙牙|Horde", -- [2]
					"花姐|龙牙|Horde", -- [3]
					"啪啪|龙牙|Horde", -- [4]
				},
			},
		},
	},
}
