
Postal3ClassicDB = {
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
	},
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"潇潇|龙牙|Horde|51|MAGE", -- [1]
				"玛丽苏本苏|龙牙|Horde|60|PRIEST", -- [2]
				"花姐|龙牙|Horde|60|ROGUE", -- [3]
			},
		},
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"龙哥|龙牙|Horde", -- [1]
					"玛丽苏本苏|龙牙|Horde", -- [2]
					"夏雨|龙牙|Horde", -- [3]
					"啪啪|龙牙|Horde", -- [4]
					"小辣椒机长二|龙牙|Horde", -- [5]
					"潇潇|龙牙|Horde", -- [6]
					"火抗梯|龙牙|Horde", -- [7]
				},
			},
		},
		["玛丽苏本苏 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"龙哥|龙牙|Horde", -- [1]
					"啪啪|龙牙|Horde", -- [2]
					"花姐|龙牙|Horde", -- [3]
				},
			},
		},
		["潇潇 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"花姐|龙牙|Horde", -- [1]
					"龙哥|龙牙|Horde", -- [2]
					"玛丽苏本苏|龙牙|Horde", -- [3]
					"啪啪|龙牙|Horde", -- [4]
				},
			},
		},
	},
}
