
Postal3ClassicDB = {
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"潇潇|龙牙|Horde|51|MAGE", -- [1]
				"玛丽苏本苏|龙牙|Horde|60|PRIEST", -- [2]
				"花姐|龙牙|Horde|60|ROGUE", -- [3]
			},
		},
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"龙哥|龙牙|Horde", -- [1]
					"小辣椒机长二|龙牙|Horde", -- [2]
					"玛丽苏本苏|龙牙|Horde", -- [3]
					"潇潇|龙牙|Horde", -- [4]
					"火抗梯|龙牙|Horde", -- [5]
					"啪啪|龙牙|Horde", -- [6]
				},
			},
		},
		["玛丽苏本苏 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"龙哥|龙牙|Horde", -- [1]
					"啪啪|龙牙|Horde", -- [2]
					"花姐|龙牙|Horde", -- [3]
				},
			},
		},
		["潇潇 - 龙牙"] = {
			["BlackBook"] = {
				["recent"] = {
					"玛丽苏本苏|龙牙|Horde", -- [1]
					"啪啪|龙牙|Horde", -- [2]
					"花姐|龙牙|Horde", -- [3]
					"龙哥|龙牙|Horde", -- [4]
				},
			},
		},
	},
}
