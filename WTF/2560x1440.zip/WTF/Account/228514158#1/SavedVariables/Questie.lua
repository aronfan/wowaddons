
QuestieConfig = {
	["char"] = {
		["花姐 - 龙牙"] = {
			["AutoUntrackedQuests"] = {
			},
			["complete"] = {
				[6601] = true,
				[8] = true,
				[2460] = true,
				[381] = true,
				[3096] = true,
				[405] = true,
				[5401] = true,
				[7498] = true,
				[4768] = true,
				[445] = true,
				[5405] = true,
				[1098] = true,
				[358] = true,
				[8141] = true,
				[4903] = true,
				[7761] = true,
				[382] = true,
				[398] = true,
				[6622] = true,
				[5481] = true,
				[8867] = true,
				[4974] = true,
				[8870] = true,
				[8871] = true,
				[3901] = true,
				[8873] = true,
				[8874] = true,
				[8875] = true,
				[2378] = true,
				[6566] = true,
				[6567] = true,
				[2379] = true,
				[6568] = true,
				[4981] = true,
				[6569] = true,
				[367] = true,
				[6570] = true,
				[375] = true,
				[2381] = true,
				[264] = true,
				[2382] = true,
				[6321] = true,
				[1898] = true,
				[6322] = true,
				[6323] = true,
				[1978] = true,
				[8648] = true,
				[2480] = true,
				[1899] = true,
				[8872] = true,
				[8652] = true,
				[8645] = true,
				[8233] = true,
				[6582] = true,
				[5503] = true,
				[6583] = true,
				[8142] = true,
				[6584] = true,
				[360] = true,
				[364] = true,
				[6395] = true,
				[8072] = true,
				[376] = true,
				[380] = true,
				[8063] = true,
				[7848] = true,
				[7491] = true,
				[7490] = true,
				[6681] = true,
				[404] = true,
				[6602] = true,
				[1886] = true,
				[6585] = true,
				[4941] = true,
				[590] = true,
				[1013] = true,
				[359] = true,
				[363] = true,
				[1998] = true,
				[2479] = true,
				[368] = true,
				[1885] = true,
				[6324] = true,
				[383] = true,
				[1014] = true,
				[5482] = true,
				[2458] = true,
				[3902] = true,
				[2478] = true,
			},
			["TrackerHiddenQuests"] = {
			},
			["journey"] = {
				{
					["Timestamp"] = 1588253131,
					["Party"] = {
						{
							["Class"] = "法师",
							["Name"] = "汉卿",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "法师",
							["Name"] = "翊仔",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "牧师",
							["Name"] = "狂暴小绵羊",
							["Level"] = 57,
						}, -- [3]
						{
							["Class"] = "法师",
							["Name"] = "牛儿桥",
							["Level"] = 50,
						}, -- [4]
					},
					["Event"] = "Level",
					["NewLevel"] = 59,
				}, -- [1]
				{
					["Timestamp"] = 1588257771,
					["Event"] = "Level",
					["NewLevel"] = 60,
				}, -- [2]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588387333,
					["Quest"] = 4081,
					["Level"] = 60,
				}, -- [3]
				{
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1588387345,
					["Quest"] = 5212,
					["Level"] = 60,
				}, -- [4]
				{
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1588387348,
					["Quest"] = 5251,
					["Level"] = 60,
				}, -- [5]
				{
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1588387353,
					["Quest"] = 5093,
					["Level"] = 60,
				}, -- [6]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588387367,
					["Quest"] = 3906,
					["Level"] = 60,
				}, -- [7]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588387378,
					["Quest"] = 4134,
					["Level"] = 60,
				}, -- [8]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588387386,
					["Quest"] = 4768,
					["Level"] = 60,
				}, -- [9]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588387529,
					["Quest"] = 3821,
					["Level"] = 60,
				}, -- [10]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588387537,
					["Quest"] = 4061,
					["Level"] = 60,
				}, -- [11]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588387907,
					["Quest"] = 7848,
					["Level"] = 60,
				}, -- [12]
				{
					["Party"] = {
						{
							["Class"] = "潜行者",
							["Name"] = "龙哥",
							["Level"] = 60,
						}, -- [1]
					},
					["Timestamp"] = 1588389501,
					["Quest"] = 7848,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [13]
				{
					["Level"] = 60,
					["Quest"] = 5211,
					["Timestamp"] = 1588406780,
					["SubType"] = "Abandon",
					["Event"] = "Quest",
				}, -- [14]
				{
					["Timestamp"] = 1588414533,
					["Quest"] = 4981,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Complete",
				}, -- [15]
				{
					["Timestamp"] = 1588414535,
					["Quest"] = 4982,
					["Level"] = 60,
					["Event"] = "Quest",
					["SubType"] = "Accept",
				}, -- [16]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "残花丶",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "战士",
							["Name"] = "亻弗",
							["Level"] = 56,
						}, -- [2]
						{
							["Class"] = "猎人",
							["Name"] = "羽落星辰",
							["Level"] = 58,
						}, -- [3]
						{
							["Class"] = "萨满祭司",
							["Name"] = "影蛮",
							["Level"] = 55,
						}, -- [4]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 7761,
					["Timestamp"] = 1588473245,
				}, -- [17]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "残花丶",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "萨满祭司",
							["Name"] = "超级小土豆",
							["Level"] = 60,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 60,
					["Quest"] = 4903,
					["Timestamp"] = 1588479714,
				}, -- [18]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "残花丶",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "萨满祭司",
							["Name"] = "超级小土豆",
							["Level"] = 60,
						}, -- [2]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 4941,
					["Timestamp"] = 1588479717,
				}, -- [19]
				{
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 60,
					["Quest"] = 4941,
					["Timestamp"] = 1588479863,
				}, -- [20]
				{
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 4974,
					["Timestamp"] = 1588479866,
				}, -- [21]
				{
					["Party"] = {
						{
							["Class"] = "法师",
							["Name"] = "紫冰",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "战士",
							["Name"] = "残花丶",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "牧师",
							["Name"] = "捡到一快钱",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "战士",
							["Name"] = "来战吧哇呀呀",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "猎人",
							["Name"] = "狩猎者一老龙",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "德鲁伊",
							["Name"] = "功德无量",
							["Level"] = 60,
						}, -- [6]
						{
							["Class"] = "法师",
							["Name"] = "一块钱开门",
							["Level"] = 59,
						}, -- [7]
						{
							["Class"] = "法师",
							["Name"] = "天地大师兄丶",
							["Level"] = 60,
						}, -- [8]
						{
							["Class"] = "牧师",
							["Name"] = "燃烧的蔡文姬",
							["Level"] = 60,
						}, -- [9]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588489092,
					["Quest"] = 7761,
					["Level"] = 60,
				}, -- [22]
				{
					["Party"] = {
						{
							["Class"] = "牧师",
							["Name"] = "捡到一快钱",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "猎人",
							["Name"] = "狩猎者一老龙",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "一块钱开门",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "燃烧的蔡文姬",
							["Level"] = 60,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588489193,
					["Quest"] = 4974,
					["Level"] = 60,
				}, -- [23]
				{
					["Party"] = {
						{
							["Class"] = "牧师",
							["Name"] = "捡到一快钱",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "猎人",
							["Name"] = "狩猎者一老龙",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "一块钱开门",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "燃烧的蔡文姬",
							["Level"] = 60,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588489196,
					["Quest"] = 6566,
					["Level"] = 60,
				}, -- [24]
				{
					["Party"] = {
						{
							["Class"] = "牧师",
							["Name"] = "捡到一快钱",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "猎人",
							["Name"] = "狩猎者一老龙",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "一块钱开门",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "燃烧的蔡文姬",
							["Level"] = 60,
						}, -- [4]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588489225,
					["Quest"] = 6566,
					["Level"] = 60,
				}, -- [25]
				{
					["Party"] = {
						{
							["Class"] = "牧师",
							["Name"] = "捡到一快钱",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "猎人",
							["Name"] = "狩猎者一老龙",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "一块钱开门",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "燃烧的蔡文姬",
							["Level"] = 60,
						}, -- [4]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588489228,
					["Quest"] = 6567,
					["Level"] = 60,
				}, -- [26]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "残花丶",
							["Level"] = 60,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588490166,
					["Quest"] = 6567,
					["Level"] = 60,
				}, -- [27]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "残花丶",
							["Level"] = 60,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588490169,
					["Quest"] = 6568,
					["Level"] = 60,
				}, -- [28]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "蚩尤摸摸达",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "法师",
							["Name"] = "勾魄无常",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "牧师",
							["Name"] = "无名无常",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "法师",
							["Name"] = "破魂无常",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "法师",
							["Name"] = "裂魄无常",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "猎人",
							["Name"] = "先生晚上好",
							["Level"] = 59,
						}, -- [6]
						{
							["Class"] = "潜行者",
							["Name"] = "我吃柠檬乄",
							["Level"] = 60,
						}, -- [7]
						{
							["Class"] = "法师",
							["Name"] = "不让大伙了",
							["Level"] = 60,
						}, -- [8]
						{
							["Class"] = "战士",
							["Name"] = "超级宇宙无敌",
							["Level"] = 60,
						}, -- [9]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588490635,
					["Quest"] = 6568,
					["Level"] = 60,
				}, -- [29]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "蚩尤摸摸达",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "法师",
							["Name"] = "勾魄无常",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "牧师",
							["Name"] = "无名无常",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "法师",
							["Name"] = "破魂无常",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "法师",
							["Name"] = "裂魄无常",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "猎人",
							["Name"] = "先生晚上好",
							["Level"] = 59,
						}, -- [6]
						{
							["Class"] = "潜行者",
							["Name"] = "我吃柠檬乄",
							["Level"] = 60,
						}, -- [7]
						{
							["Class"] = "法师",
							["Name"] = "不让大伙了",
							["Level"] = 60,
						}, -- [8]
						{
							["Class"] = "战士",
							["Name"] = "超级宇宙无敌",
							["Level"] = 60,
						}, -- [9]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588490637,
					["Quest"] = 6569,
					["Level"] = 60,
				}, -- [30]
				{
					["Party"] = {
						{
							["Class"] = "法师",
							["Name"] = "心漠",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "潜行者",
							["Name"] = "莲城羊杂汤",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "潜行者",
							["Name"] = "卡拉蒙多",
							["Level"] = 59,
						}, -- [3]
						{
							["Class"] = "猎人",
							["Name"] = "叶莲娜",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "战士",
							["Name"] = "一步到位",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "德鲁伊",
							["Name"] = "德丶易忘形",
							["Level"] = 60,
						}, -- [6]
						{
							["Class"] = "战士",
							["Name"] = "布霖的小弟",
							["Level"] = 60,
						}, -- [7]
						{
							["Class"] = "牧师",
							["Name"] = "布霖",
							["Level"] = 60,
						}, -- [8]
						{
							["Class"] = "战士",
							["Name"] = "残花丶",
							["Level"] = 60,
						}, -- [9]
						{
							["Class"] = "法师",
							["Name"] = "习惯有你",
							["Level"] = 60,
						}, -- [10]
						{
							["Class"] = "法师",
							["Name"] = "我彳艮普通",
							["Level"] = 60,
						}, -- [11]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588505604,
					["Quest"] = 4768,
					["Level"] = 60,
				}, -- [31]
				{
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 8063,
					["Timestamp"] = 1588517981,
				}, -- [32]
				{
					["Event"] = "Quest",
					["SubType"] = "Abandon",
					["Level"] = 60,
					["Quest"] = 8063,
					["Timestamp"] = 1588518032,
				}, -- [33]
				{
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 60,
					["Quest"] = 6569,
					["Timestamp"] = 1588518493,
				}, -- [34]
				{
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 6570,
					["Timestamp"] = 1588518497,
				}, -- [35]
				{
					["Event"] = "Quest",
					["SubType"] = "Complete",
					["Level"] = 60,
					["Quest"] = 6570,
					["Timestamp"] = 1588518691,
				}, -- [36]
				{
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 6582,
					["Timestamp"] = 1588518694,
				}, -- [37]
				{
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 6583,
					["Timestamp"] = 1588518697,
				}, -- [38]
				{
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 6584,
					["Timestamp"] = 1588518700,
				}, -- [39]
				{
					["Party"] = {
						{
							["Class"] = "法师",
							["Name"] = "安娜的法神",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "德鲁伊",
							["Name"] = "Annas",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "笨猪婷婷",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "牧神南瓜",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "术士",
							["Name"] = "圣光喂了狗",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "牧师",
							["Name"] = "雪神洛洛",
							["Level"] = 60,
						}, -- [6]
						{
							["Class"] = "法师",
							["Name"] = "安娜的投影法",
							["Level"] = 60,
						}, -- [7]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588522167,
					["Quest"] = 6582,
					["Level"] = 60,
				}, -- [40]
				{
					["Party"] = {
						{
							["Class"] = "法师",
							["Name"] = "安娜的法神",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "德鲁伊",
							["Name"] = "Annas",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "笨猪婷婷",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "牧神南瓜",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "术士",
							["Name"] = "圣光喂了狗",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "牧师",
							["Name"] = "雪神洛洛",
							["Level"] = 60,
						}, -- [6]
						{
							["Class"] = "法师",
							["Name"] = "安娜的投影法",
							["Level"] = 60,
						}, -- [7]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588522170,
					["Quest"] = 6583,
					["Level"] = 60,
				}, -- [41]
				{
					["Party"] = {
						{
							["Class"] = "法师",
							["Name"] = "安娜的法神",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "德鲁伊",
							["Name"] = "Annas",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "笨猪婷婷",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "牧神南瓜",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "术士",
							["Name"] = "圣光喂了狗",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "牧师",
							["Name"] = "雪神洛洛",
							["Level"] = 60,
						}, -- [6]
						{
							["Class"] = "法师",
							["Name"] = "安娜的投影法",
							["Level"] = 60,
						}, -- [7]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588522172,
					["Quest"] = 6584,
					["Level"] = 60,
				}, -- [42]
				{
					["Party"] = {
						{
							["Class"] = "法师",
							["Name"] = "安娜的法神",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "德鲁伊",
							["Name"] = "Annas",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "笨猪婷婷",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "牧师",
							["Name"] = "牧神南瓜",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "术士",
							["Name"] = "圣光喂了狗",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "牧师",
							["Name"] = "雪神洛洛",
							["Level"] = 60,
						}, -- [6]
						{
							["Class"] = "法师",
							["Name"] = "安娜的投影法",
							["Level"] = 60,
						}, -- [7]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588522174,
					["Quest"] = 6585,
					["Level"] = 60,
				}, -- [43]
				{
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588523409,
					["Quest"] = 6585,
					["Level"] = 60,
				}, -- [44]
				{
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588523413,
					["Quest"] = 6601,
					["Level"] = 60,
				}, -- [45]
				{
					["Party"] = {
						{
							["Class"] = "潜行者",
							["Name"] = "龙哥",
							["Level"] = 60,
						}, -- [1]
					},
					["SubType"] = "Complete",
					["Event"] = "Quest",
					["Timestamp"] = 1588523700,
					["Quest"] = 6601,
					["Level"] = 60,
				}, -- [46]
				{
					["Party"] = {
						{
							["Class"] = "潜行者",
							["Name"] = "龙哥",
							["Level"] = 60,
						}, -- [1]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588523705,
					["Quest"] = 6602,
					["Level"] = 60,
				}, -- [47]
				{
					["Party"] = {
						{
							["Class"] = "战士",
							["Name"] = "蚩尤摸摸达",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "法师",
							["Name"] = "破魂无常",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "法师",
							["Name"] = "勾魄无常",
							["Level"] = 60,
						}, -- [3]
						{
							["Class"] = "法师",
							["Name"] = "裂魄无常",
							["Level"] = 60,
						}, -- [4]
						{
							["Class"] = "牧师",
							["Name"] = "无名无常",
							["Level"] = 60,
						}, -- [5]
						{
							["Class"] = "萨满祭司",
							["Name"] = "托尔",
							["Level"] = 59,
						}, -- [6]
						{
							["Class"] = "战士",
							["Name"] = "玫瑰灰",
							["Level"] = 60,
						}, -- [7]
						{
							["Class"] = "潜行者",
							["Name"] = "毛骗贼煌",
							["Level"] = 60,
						}, -- [8]
					},
					["SubType"] = "Accept",
					["Event"] = "Quest",
					["Timestamp"] = 1588585206,
					["Quest"] = 5160,
					["Level"] = 60,
				}, -- [48]
				{
					["Level"] = 60,
					["Quest"] = 6602,
					["Timestamp"] = 1588590709,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [49]
				{
					["Party"] = {
						{
							["Class"] = "德鲁伊",
							["Name"] = "熊心壮痣",
							["Level"] = 60,
						}, -- [1]
						{
							["Class"] = "法师",
							["Name"] = "夏雨",
							["Level"] = 60,
						}, -- [2]
						{
							["Class"] = "猎人",
							["Name"] = "啪啪",
							["Level"] = 60,
						}, -- [3]
					},
					["Event"] = "Quest",
					["SubType"] = "Accept",
					["Level"] = 60,
					["Quest"] = 5382,
					["Timestamp"] = 1588775088,
				}, -- [50]
				{
					["SubType"] = "Abandon",
					["Event"] = "Quest",
					["Timestamp"] = 1589006470,
					["Quest"] = 1999,
					["Level"] = 60,
				}, -- [51]
				{
					["Level"] = 60,
					["Quest"] = 8072,
					["Timestamp"] = 1589466855,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [52]
				{
					["Level"] = 60,
					["Quest"] = 8072,
					["Timestamp"] = 1589466860,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [53]
				{
					["Level"] = 60,
					["Quest"] = 8063,
					["Timestamp"] = 1589466864,
					["SubType"] = "Accept",
					["Event"] = "Quest",
				}, -- [54]
				{
					["Level"] = 60,
					["Quest"] = 8063,
					["Timestamp"] = 1589466868,
					["SubType"] = "Complete",
					["Event"] = "Quest",
				}, -- [55]
			},
			["TrackerHiddenObjectives"] = {
			},
			["TrackedQuests"] = {
				[4903] = true,
				[6583] = true,
			},
			["collapsedQuests"] = {
			},
		},
		["玛丽苏本苏 - 龙牙"] = {
			["TrackerHiddenQuests"] = {
			},
			["TrackerHiddenObjectives"] = {
			},
			["AutoUntrackedQuests"] = {
			},
			["collapsedQuests"] = {
			},
			["TrackedQuests"] = {
			},
			["complete"] = {
				[365] = true,
				[8] = true,
				[5650] = true,
				[381] = true,
				[5651] = true,
				[7621] = true,
				[405] = true,
				[7877] = true,
				[5401] = true,
				[4134] = true,
				[5341] = true,
				[5405] = true,
				[5660] = true,
				[5661] = true,
				[5662] = true,
				[7504] = true,
				[354] = true,
				[358] = true,
				[362] = true,
				[4903] = true,
				[374] = true,
				[1014] = true,
				[3802] = true,
				[398] = true,
				[6622] = true,
				[6623] = true,
				[3042] = true,
				[5481] = true,
				[426] = true,
				[4974] = true,
				[8870] = true,
				[8871] = true,
				[3901] = true,
				[8873] = true,
				[8874] = true,
				[8875] = true,
				[3902] = true,
				[6566] = true,
				[4081] = true,
				[6567] = true,
				[5482] = true,
				[355] = true,
				[3982] = true,
				[8883] = true,
				[367] = true,
				[6570] = true,
				[375] = true,
				[382] = true,
				[383] = true,
				[7461] = true,
				[7761] = true,
				[4001] = true,
				[3906] = true,
				[5504] = true,
				[407] = true,
				[4002] = true,
				[3907] = true,
				[2203] = true,
				[2865] = true,
				[427] = true,
				[5507] = true,
				[7848] = true,
				[4724] = true,
				[4004] = true,
				[2258] = true,
				[2202] = true,
				[3801] = true,
				[370] = true,
				[368] = true,
				[6582] = true,
				[5503] = true,
				[6583] = true,
				[2768] = true,
				[6584] = true,
				[5663] = true,
				[6585] = true,
				[6395] = true,
				[376] = true,
				[5761] = true,
				[380] = true,
				[2770] = true,
				[3981] = true,
				[5382] = true,
				[6569] = true,
				[363] = true,
				[404] = true,
				[7201] = true,
				[5658] = true,
				[5659] = true,
				[4941] = true,
				[5513] = true,
				[8677] = true,
				[364] = true,
				[5679] = true,
				[5515] = true,
				[6568] = true,
				[6602] = true,
				[4003] = true,
				[5644] = true,
				[7622] = true,
				[2521] = true,
				[6601] = true,
				[5646] = true,
				[8867] = true,
				[8872] = true,
			},
		},
		["潇潇 - 龙牙"] = {
			["TrackerHiddenQuests"] = {
			},
			["TrackerHiddenObjectives"] = {
			},
			["AutoUntrackedQuests"] = {
			},
			["collapsedQuests"] = {
			},
			["TrackedQuests"] = {
			},
			["complete"] = {
				[357] = true,
				[3221] = true,
				[492] = true,
				[369] = true,
				[8] = true,
				[381] = true,
				[405] = true,
				[409] = true,
				[7814] = true,
				[421] = true,
				[425] = true,
				[429] = true,
				[437] = true,
				[441] = true,
				[445] = true,
				[449] = true,
				[5723] = true,
				[5724] = true,
				[1098] = true,
				[477] = true,
				[481] = true,
				[358] = true,
				[362] = true,
				[366] = true,
				[370] = true,
				[374] = true,
				[1014] = true,
				[398] = true,
				[422] = true,
				[426] = true,
				[430] = true,
				[438] = true,
				[3901] = true,
				[450] = true,
				[1959] = true,
				[478] = true,
				[482] = true,
				[359] = true,
				[363] = true,
				[367] = true,
				[371] = true,
				[375] = true,
				[1881] = true,
				[383] = true,
				[264] = true,
				[407] = true,
				[411] = true,
				[6322] = true,
				[423] = true,
				[427] = true,
				[435] = true,
				[439] = true,
				[447] = true,
				[1884] = true,
				[382] = true,
				[356] = true,
				[360] = true,
				[364] = true,
				[368] = true,
				[372] = true,
				[376] = true,
				[380] = true,
				[365] = true,
				[355] = true,
				[354] = true,
				[1013] = true,
				[1359] = true,
				[404] = true,
				[408] = true,
				[5482] = true,
				[1882] = true,
				[590] = true,
				[424] = true,
				[428] = true,
				[1960] = true,
				[3098] = true,
				[440] = true,
				[3902] = true,
				[5481] = true,
				[452] = true,
				[5722] = true,
				[5725] = true,
				[5761] = true,
				[6321] = true,
				[6323] = true,
				[6324] = true,
				[6395] = true,
			},
		},
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "Default",
		["玛丽苏本苏 - 龙牙"] = "Default",
		["潇潇 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["minimap"] = {
				["hide"] = true,
			},
		},
	},
}
