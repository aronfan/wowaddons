
SpyDB = {
	["kosData"] = {
		["龙牙"] = {
			["Horde"] = {
				["潇潇"] = {
				},
				["花姐"] = {
				},
				["玛丽苏本苏"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["龙牙"] = {
			["Horde"] = {
			},
		},
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 818.000122070313,
					["x"] = 1640.44458007813,
					["w"] = 159.999954223633,
					["h"] = 51.0000076293945,
				},
			},
			["Colors"] = {
				["Alert"] = {
					["Stealth Text"] = {
						["a"] = 1,
					},
					["Name Text"] = {
						["a"] = 1,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["HideSpy"] = true,
			["AppendUnitNameCheck"] = true,
			["AppendUnitKoSCheck"] = true,
			["MainWindowVis"] = false,
		},
		["潇潇 - 龙牙"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 779.500061035156,
					["x"] = 1634.44470214844,
					["w"] = 159.999954223633,
					["h"] = 147.000045776367,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
			["MainWindowVis"] = false,
			["HideSpy"] = true,
		},
		["玛丽苏本苏 - 龙牙"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 740.500061035156,
					["h"] = 34.9999504089356,
					["w"] = 160.000015258789,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
			["MainWindowVis"] = false,
			["HideSpy"] = true,
		},
	},
}
