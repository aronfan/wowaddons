
WowLua_DB = {
	["currentPage"] = 1,
	["fontSize"] = 14,
	["pages"] = {
		{
			["name"] = "Questie",
			["content"] = "local name, title, _, _, reason = GetAddOnInfo(\"Questie\")\nif reason == \"MISSING\" then\n   _, title = GetAddOnInfo(\"Questie\")\nend\nlocal major, minor, patch, commit = string.match(title,\n\"(%d+)%p(%d+)%p(%d+)\")\nprint(title)\nprint(major, minor, patch)",
		}, -- [1]
	},
	["untitled"] = 2,
}
