
felFruiTimerDB = {
	["auto"] = 1,
}
