
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 65,
					["_ActorTable"] = {
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 436.005269,
							["damage_from"] = {
								["亡者农药"] = true,
								["弑丶晓宇"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 1014,
								["亡者农药"] = 436,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1450.005269,
							["last_event"] = 1590924709,
							["fight_component"] = true,
							["total"] = 1450.005269,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "高端法爷",
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 436,
										["targets"] = {
											["潇潇"] = 602,
											["亡者农药"] = 436,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1038,
										["n_min"] = 285,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1038,
										["c_max"] = 0,
										["id"] = "魔爆术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 64,
									},
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 385,
										["targets"] = {
											["潇潇"] = 385,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 385,
										["n_min"] = 385,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 385,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 1,
										["a_dmg"] = 385,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 27,
										["targets"] = {
											["潇潇"] = 27,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 27,
										["n_min"] = 27,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 27,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1023.005269,
							["end_time"] = 1590924714,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590924704,
							["serial"] = "Player-4920-01D6EAA0",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 149.00127,
							["damage_from"] = {
								["高端法爷"] = true,
							},
							["targets"] = {
								["高端法爷"] = 149,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 149.00127,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 149.00127,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1590924714,
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 149,
										["targets"] = {
											["高端法爷"] = 149,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 149,
										["n_min"] = 149,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 149,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "魔爆术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 1,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 64,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1014.00127,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590924708,
							["on_hold"] = false,
							["start_time"] = 1590924706,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 171.004209,
							["damage_from"] = {
								["高端法爷"] = true,
							},
							["targets"] = {
								["高端法爷"] = 171,
							},
							["pets"] = {
							},
							["damage_taken"] = 436.004209,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 171.004209,
							["last_event"] = 1590924705,
							["dps_started"] = false,
							["total"] = 171.004209,
							["delay"] = 0,
							["classe"] = "MAGE",
							["nome"] = "亡者农药",
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 171,
										["targets"] = {
											["高端法爷"] = 171,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 171,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 171,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590924714,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1590924705,
							["serial"] = "Player-4920-01DA4323",
							["on_hold"] = false,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 65,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MAGE",
							["totalover"] = 0.006096,
							["total_without_pet"] = 371.006096,
							["total"] = 371.006096,
							["targets_absorbs"] = {
								["潇潇"] = 371,
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-022A2037",
							["totalabsorb"] = 371.006096,
							["last_hps"] = 0,
							["targets"] = {
								["潇潇"] = 371,
							},
							["totalover_without_pet"] = 0.006096,
							["healing_taken"] = 371.006096,
							["fight_component"] = true,
							["end_time"] = 1590924714,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 371,
										["targets_overheal"] = {
										},
										["n_max"] = 371,
										["targets"] = {
											["潇潇"] = 371,
										},
										["n_min"] = 371,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 371,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 371,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 371,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1590924706,
							["totaldenied"] = 0.006096,
							["start_time"] = 1590924706,
							["delay"] = 0,
							["spec"] = 64,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 436.002419,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["亡者农药"] = 436,
							},
							["total"] = 436.002419,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["亡者农药"] = true,
							},
							["healing_taken"] = 436.002419,
							["totalover"] = 0.002419,
							["total_without_pet"] = 436.002419,
							["totalover_without_pet"] = 0.002419,
							["totaldenied"] = 0.002419,
							["fight_component"] = true,
							["end_time"] = 1590924714,
							["classe"] = "MAGE",
							["heal_enemy_amt"] = 0,
							["nome"] = "亡者农药",
							["targets_absorbs"] = {
								["亡者农药"] = 436,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 436,
										["targets_overheal"] = {
										},
										["n_max"] = 436,
										["targets"] = {
											["亡者农药"] = 436,
										},
										["n_min"] = 436,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 436,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["亡者农药"] = 436,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 436,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["custom"] = 0,
							["last_event"] = 1590924709,
							["on_hold"] = false,
							["start_time"] = 1590924709,
							["serial"] = "Player-4920-01DA4323",
							["delay"] = 0,
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 65,
					["_ActorTable"] = {
						{
							["received"] = 710.001457,
							["resource"] = 0.001457,
							["targets"] = {
								["高端法爷"] = 710,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["passiveover"] = 0.001457,
							["fight_component"] = true,
							["total"] = 710.001457,
							["nome"] = "高端法爷",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 710,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["高端法爷"] = 710,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["totalover"] = 0.001457,
							["last_event"] = 1590924708,
							["alternatepower"] = 0.001457,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D6EAA0",
							["flag_original"] = 66888,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 65,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["activedamt"] = -1,
										["id"] = "暴风雪",
										["targets"] = {
										},
										["actived_at"] = 1590924705,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 46,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪现术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪现术",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 0,
							["nome"] = "亡者农药",
							["grupo"] = true,
							["spell_cast"] = {
								["闪现术"] = 1,
								["冰锥术"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1590924714,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01DA4323",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["nome"] = "我瞿李媚",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["last_event"] = 1590924714,
							["tipo"] = 4,
							["buff_uptime"] = 50,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "耐力",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "呀啊啊啊啊",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA138E",
							["buff_uptime_targets"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 1300,
							["fight_component"] = true,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["nome"] = "潇潇",
							["buff_uptime"] = 32,
							["pets"] = {
							},
							["spell_cast"] = {
								["魔爆术"] = 3,
								["寒冰护体"] = 1,
							},
							["classe"] = "MAGE",
							["last_event"] = 1590924714,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "力量",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [3]
						{
							["flag_original"] = 66888,
							["last_event"] = 0,
							["nome"] = "高端法爷",
							["enemy"] = true,
							["pets"] = {
							},
							["classe"] = "UNGROUPPLAYER",
							["tipo"] = 4,
							["spell_cast"] = {
								["魔爆术"] = 1,
								["冰锥术"] = 1,
								["冰霜新星"] = 1,
							},
							["serial"] = "Player-4920-01D6EAA0",
							["fight_component"] = true,
						}, -- [4]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 65,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["tempo_start"] = 1590924704,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					1769.991111, -- [1]
					806.997749, -- [2]
					{
						0, -- [1]
						[0] = 710,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					320, -- [1]
					807, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "19:31:55",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "高端法爷",
				["TotalElapsedCombatTime"] = 805871.174,
				["CombatEndedAt"] = 805871.174,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["潇潇"] = 149.00127,
							["亡者农药"] = 171.004209,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 371.006096,
							["亡者农药"] = 436.002419,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 805871.441,
				["combat_id"] = 65,
				["data_inicio"] = "19:31:45",
				["overall_added"] = true,
				["frags"] = {
					["高端法爷"] = 1,
				},
				["combat_counter"] = 96,
				["contra"] = "高端法爷",
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 805861.433,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 64,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 344.006209,
							["damage_from"] = {
							},
							["targets"] = {
								["高端法爷"] = 1202,
								["要水收钱"] = 472,
							},
							["pets"] = {
							},
							["damage_taken"] = 0.006209,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1674.006209,
							["last_event"] = 1590924701,
							["dps_started"] = false,
							["total"] = 1674.006209,
							["delay"] = 0,
							["classe"] = "MAGE",
							["nome"] = "我瞿李媚",
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 172,
										["targets"] = {
											["高端法爷"] = 1202,
											["要水收钱"] = 472,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1674,
										["n_min"] = 129,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 1674,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 129,
										["c_min"] = 0,
										["r_amt"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590924704,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1590924695,
							["serial"] = "Player-4920-01DA138E",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 542.004508,
							["damage_from"] = {
								["魔导师"] = true,
								["我瞿李媚"] = true,
								["亡者农药"] = true,
								["弑丶晓宇"] = true,
								["冬郭"] = true,
							},
							["targets"] = {
								["魔导师"] = 225,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 225.004508,
							["last_event"] = 1590924704,
							["fight_component"] = true,
							["total"] = 225.004508,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "高端法爷",
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 225,
										["targets"] = {
											["魔导师"] = 225,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 225,
										["n_min"] = 225,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 225,
										["c_max"] = 0,
										["id"] = "魔爆术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 4134.004508,
							["end_time"] = 1590924698,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590924697,
							["serial"] = "Player-4920-01D6EAA0",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 1352,
							["totalabsorbed"] = 282.002961,
							["damage_from"] = {
								["冬郭"] = true,
								["我瞿李媚"] = true,
								["弑丶晓宇"] = true,
							},
							["targets"] = {
								["魔导师"] = 282,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 282.002961,
							["last_event"] = 1590924697,
							["fight_component"] = true,
							["total"] = 282.002961,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "要水收钱",
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 282,
										["targets"] = {
											["魔导师"] = 282,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 282,
										["n_min"] = 282,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 282,
										["c_max"] = 0,
										["id"] = "魔爆术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 2963.002961,
							["end_time"] = 1590924698,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590924697,
							["serial"] = "Player-4920-01D6E9FD",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 344.001936,
							["damage_from"] = {
							},
							["targets"] = {
								["高端法爷"] = 1029,
							},
							["pets"] = {
							},
							["damage_taken"] = 0.001936,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1029.001936,
							["last_event"] = 1590924704,
							["dps_started"] = false,
							["total"] = 1029.001936,
							["delay"] = 0,
							["classe"] = "MAGE",
							["nome"] = "亡者农药",
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 172,
										["targets"] = {
											["高端法爷"] = 1029,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1029,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1029,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590924704,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1590924699,
							["serial"] = "Player-4920-01DA4323",
							["on_hold"] = false,
						}, -- [4]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005477,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 1590924704,
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["高端法爷"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005477,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 0.005477,
							["classe"] = "MAGE",
							["damage_taken"] = 0.005477,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["end_time"] = 1590924704,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590924704,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 64,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 64,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 64,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["nome"] = "亡者农药",
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 1590924698,
							["buff_uptime"] = 12,
							["tipo"] = 4,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["暴风雪"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA4323",
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime"] = 0,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["activedamt"] = -1,
										["id"] = "暴风雪",
										["targets"] = {
										},
										["actived_at"] = 1590924698,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "我瞿李媚",
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 15,
							["last_event"] = 1590924698,
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "耐力",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "呀啊啊啊啊",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA138E",
							["classe"] = "MAGE",
						}, -- [2]
						{
							["flag_original"] = 1300,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 12,
							["classe"] = "MAGE",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "力量",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["last_event"] = 1590924698,
						}, -- [3]
						{
							["flag_original"] = 66888,
							["last_event"] = 0,
							["nome"] = "高端法爷",
							["enemy"] = true,
							["pets"] = {
							},
							["classe"] = "UNGROUPPLAYER",
							["tipo"] = 4,
							["spell_cast"] = {
								["魔爆术"] = 1,
							},
							["serial"] = "Player-4920-01D6EAA0",
							["fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 1352,
							["last_event"] = 0,
							["nome"] = "要水收钱",
							["enemy"] = true,
							["pets"] = {
							},
							["classe"] = "UNGROUPPLAYER",
							["tipo"] = 4,
							["spell_cast"] = {
								["魔爆术"] = 1,
							},
							["serial"] = "Player-4920-01D6E9FD",
							["fight_component"] = true,
						}, -- [5]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 64,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 805861,
				["tempo_start"] = 1590924695,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 95,
				["totals"] = {
					3209.990966, -- [1]
					-0.011256000000003, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					2703, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "19:31:39",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "高端法爷",
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["我瞿李媚"] = 988.006209,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 805854.963,
				["combat_id"] = 64,
				["overall_added"] = true,
				["player_last_events"] = {
				},
				["spells_cast_timeline"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["data_inicio"] = "19:31:36",
				["CombatSkillCache"] = {
				},
				["contra"] = "高端法爷",
				["start_time"] = 805851.96,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 63,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 407.008755,
							["damage_from"] = {
								["要水收钱"] = true,
							},
							["targets"] = {
								["小俊俊"] = 439,
								["高端法爷"] = 407,
								["猫影貂蝉"] = 410,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 1256.008755,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1256.008755,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1590924660,
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 439,
										["targets"] = {
											["小俊俊"] = 439,
											["猫影貂蝉"] = 410,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 849,
										["n_min"] = 410,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 849,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 407,
										["targets"] = {
											["高端法爷"] = 407,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 407,
										["n_min"] = 407,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 407,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 177.008755,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590924655,
							["on_hold"] = false,
							["start_time"] = 1590924653,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1352,
							["totalabsorbed"] = 0.007572,
							["damage_from"] = {
								["魔导师"] = true,
								["潇潇"] = true,
								["我吥猜"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007572,
							["last_event"] = 0,
							["fight_component"] = true,
							["total"] = 0.007572,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "小俊俊",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1849.007572,
							["end_time"] = 1590924660,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590924660,
							["serial"] = "Player-4920-025FF372",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 1352,
							["totalabsorbed"] = 0.001111,
							["damage_from"] = {
								["魔导师"] = true,
								["潇潇"] = true,
								["我吥猜"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001111,
							["last_event"] = 0,
							["fight_component"] = true,
							["total"] = 0.001111,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "猫影貂蝉",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1373.001111,
							["end_time"] = 1590924660,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590924660,
							["serial"] = "Player-4920-01DB6C85",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1352,
							["totalabsorbed"] = 263.007932,
							["damage_from"] = {
								["冬郭"] = true,
								["潇潇"] = true,
								["我吥猜"] = true,
							},
							["targets"] = {
								["Oldd"] = 1225,
								["可爱的憨憨"] = 175,
								["冬邪"] = 943,
								["冬郭"] = 1113,
								["无心法"] = 875,
								["青青美羊羊"] = 175,
								["接托管 <弑丶晓宇>"] = 746,
								["青青喜羊羊"] = 350,
								["哎嘿灬"] = 1095,
								["青青沸羊羊"] = 175,
								["弑丶晓宇"] = 350,
								["魔导师"] = 169,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7391.007932,
							["tipo"] = 1,
							["fight_component"] = true,
							["end_time"] = 1590924695,
							["delay"] = 0,
							["total"] = 7391.007932,
							["nome"] = "高端法爷",
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 175,
										["targets"] = {
											["Oldd"] = 1225,
											["可爱的憨憨"] = 175,
											["冬邪"] = 943,
											["冬郭"] = 1113,
											["无心法"] = 875,
											["青青美羊羊"] = 175,
											["接托管 <弑丶晓宇>"] = 746,
											["青青喜羊羊"] = 350,
											["哎嘿灬"] = 1095,
											["青青沸羊羊"] = 175,
											["弑丶晓宇"] = 350,
											["魔导师"] = 169,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 7391,
										["n_min"] = 86,
										["g_dmg"] = 0,
										["counter"] = 48,
										["total"] = 7391,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 1391,
										["c_min"] = 0,
										["r_amt"] = 13,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 48,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1523.007932,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590924693,
							["on_hold"] = false,
							["start_time"] = 1590924660,
							["serial"] = "Player-4920-01D6EAA0",
							["dps_started"] = false,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 172.005874,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["damage_taken"] = 0.005874,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005874,
							["last_event"] = 1590924695,
							["dps_started"] = false,
							["total"] = 0.005874,
							["delay"] = 0,
							["classe"] = "MAGE",
							["nome"] = "我瞿李媚",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590924695,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1590924695,
							["serial"] = "Player-4920-01DA138E",
							["on_hold"] = false,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 63,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 63,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 63,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["nome"] = "亡者农药",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["last_event"] = 1590924660,
							["tipo"] = 4,
							["buff_uptime"] = 21,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA4323",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["要水收钱"] = 1,
										},
										["interrompeu_oque"] = {
											["暴风雪"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "耐力",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "呀啊啊啊啊",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["暴风雪"] = 1,
							},
							["nome"] = "我瞿李媚",
							["interrupt_targets"] = {
								["要水收钱"] = 1,
							},
							["grupo"] = true,
							["buff_uptime"] = 28,
							["last_event"] = 1590924693,
							["interrupt"] = 1.002885,
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01DA138E",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["activedamt"] = -2,
										["id"] = "冰锥术",
										["targets"] = {
										},
										["actived_at"] = 1590924653,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "力量",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 0,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1590924660,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 35,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 63,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 805839.163,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					8646.940318, -- [1]
					-0.007585, -- [2]
					{
						0, -- [1]
						[0] = -0.0320990000000734,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0.99647,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["潇潇"] = {
						{
							true, -- [1]
							"暴风雪", -- [2]
							177, -- [3]
							1590924682.475, -- [4]
							2010, -- [5]
							"要水收钱", -- [6]
							nil, -- [7]
							16, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "19:31:00",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "小俊俊",
				["TotalElapsedCombatTime"] = 5.68900000001304,
				["CombatEndedAt"] = 805844.852,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["潇潇"] = 1256.008755,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 805816.712,
				["combat_id"] = 63,
				["combat_counter"] = 94,
				["tempo_start"] = 1590924653,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["totals_grupo"] = {
					1256, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "19:30:53",
				["start_time"] = 805809.707,
				["contra"] = "小俊俊",
				["frags"] = {
					["猫影貂蝉"] = 1,
				},
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 62,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005328,
							["damage_from"] = {
							},
							["targets"] = {
								["要水收钱"] = 463,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 463.005328,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 463.005328,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1590924648,
							["spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 62,
										["targets"] = {
											["要水收钱"] = 62,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 62,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 62,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 401,
										["targets"] = {
											["要水收钱"] = 401,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 401,
										["n_min"] = 401,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 401,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.005328,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590924642,
							["on_hold"] = false,
							["start_time"] = 1590924638,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.007534,
							["damage_from"] = {
								["魔导师"] = true,
								["潇潇"] = true,
								["我吥猜"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007534,
							["last_event"] = 0,
							["fight_component"] = true,
							["total"] = 0.007534,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "要水收钱",
							["spells"] = {
								["_ActorTable"] = {
									["闪现术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "闪现术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1294.007534,
							["end_time"] = 1590924648,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590924648,
							["serial"] = "Player-4920-01D6E9FD",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 62,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 62,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 62,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["nome"] = "亡者农药",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["last_event"] = 1590924648,
							["tipo"] = 4,
							["buff_uptime"] = 40,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA4323",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["nome"] = "我瞿李媚",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["last_event"] = 1590924648,
							["tipo"] = 4,
							["buff_uptime"] = 48,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "耐力",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "呀啊啊啊啊",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA138E",
							["buff_uptime_targets"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "力量",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 2,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰箭"] = 1,
								["冰锥术"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1590924648,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 50,
						}, -- [3]
						{
							["flag_original"] = 66888,
							["last_event"] = 0,
							["nome"] = "要水收钱",
							["enemy"] = true,
							["pets"] = {
							},
							["classe"] = "UNGROUPPLAYER",
							["tipo"] = 4,
							["spell_cast"] = {
								["闪现术"] = 1,
							},
							["serial"] = "Player-4920-01D6E9FD",
							["fight_component"] = true,
						}, -- [4]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 62,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 805809.707,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					462.981213000001, -- [1]
					-0.005616, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = -0.00545799999999996,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "19:30:48",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "要水收钱",
				["TotalElapsedCombatTime"] = 805804.35,
				["CombatEndedAt"] = 805804.35,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["潇潇"] = 463.005328,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 805804.734,
				["combat_id"] = 62,
				["combat_counter"] = 93,
				["tempo_start"] = 1590924638,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["totals_grupo"] = {
					463, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "19:30:38",
				["start_time"] = 805794.726,
				["contra"] = "要水收钱",
				["frags"] = {
				},
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 51,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001229,
							["damage_from"] = {
								["缝补憎恶"] = true,
								["弗雷斯特恩"] = true,
							},
							["targets"] = {
								["骷髅狂战士"] = 5595,
								["被撕裂的死尸"] = 13111,
								["恶疫食尸鬼"] = 3126,
								["缝补憎恶"] = 1559,
								["被毁坏的死尸"] = 14212,
								["石翼石像鬼"] = 1846,
								["骷髅守护者"] = 3339,
							},
							["delay"] = 1590922662,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 125,
										["targets"] = {
											["骷髅狂战士"] = 5595,
											["被撕裂的死尸"] = 12625,
											["恶疫食尸鬼"] = 3062,
											["缝补憎恶"] = 1499,
											["被毁坏的死尸"] = 13658,
											["石翼石像鬼"] = 1720,
											["骷髅守护者"] = 3281,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 41440,
										["n_min"] = 32,
										["g_dmg"] = 0,
										["counter"] = 342,
										["total"] = 41440,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 2573,
										["c_min"] = 0,
										["r_amt"] = 31,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 342,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰冻"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["缝补憎恶"] = 0,
											["弗雷斯特恩"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "冰冻",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 64,
										["targets"] = {
											["石翼石像鬼"] = 126,
											["被撕裂的死尸"] = 486,
											["恶疫食尸鬼"] = 64,
											["弗雷斯特恩"] = 0,
											["被毁坏的死尸"] = 554,
											["缝补憎恶"] = 60,
											["骷髅守护者"] = 58,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1348,
										["n_min"] = 58,
										["g_dmg"] = 0,
										["counter"] = 23,
										["total"] = 1348,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 22,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 42788.001229,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 42788.001229,
							["damage_taken"] = 3731.001229,
							["nome"] = "潇潇",
							["boss_fight_component"] = true,
							["spec"] = 64,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1590922697,
							["custom"] = 0,
							["last_event"] = 1590922662,
							["on_hold"] = false,
							["start_time"] = 1590922677,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00473,
							["damage_from"] = {
								["潇潇"] = true,
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
								"破碎的死尸 <被毁坏的死尸>", -- [1]
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00473,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.00473,
							["classe"] = "UNKNOW",
							["damage_taken"] = 71124.00473,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["召唤破碎的死尸"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "召唤破碎的死尸",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 10,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "被毁坏的死尸",
							["last_dps"] = 0,
							["end_time"] = 1590922697,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590922697,
							["serial"] = "Creature-0-4999-329-27480-10381-0002538B60",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002521,
							["damage_from"] = {
								["潇潇"] = true,
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002521,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.002521,
							["classe"] = "UNKNOW",
							["damage_taken"] = 61764.002521,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["nome"] = "被撕裂的死尸",
							["last_dps"] = 0,
							["end_time"] = 1590922697,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590922697,
							["serial"] = "Creature-0-4999-329-27480-10382-0008D38B5F",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 856.007634,
							["damage_from"] = {
								["潇潇"] = true,
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
								["我瞿李媚"] = 94,
								["亡者农药"] = 960,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1054.007634,
							["delay"] = 1590922684,
							["monster"] = true,
							["end_time"] = 1590922697,
							["nome"] = "骷髅守护者",
							["damage_taken"] = 30481.007634,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["奥术箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 70,
										["targets"] = {
											["亡者农药"] = 70,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 70,
										["n_min"] = 70,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 70,
										["c_max"] = 0,
										["id"] = "奥术箭",
										["r_dmg"] = 70,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 105,
										["targets"] = {
											["我瞿李媚"] = 94,
											["亡者农药"] = 303,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 397,
										["n_min"] = 94,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 397,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["暗影箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 139,
										["targets"] = {
											["亡者农药"] = 587,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 587,
										["n_min"] = 66,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 587,
										["c_max"] = 0,
										["id"] = "暗影箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["n_amt"] = 6,
										["m_amt"] = 0,
										["successful_casted"] = 7,
										["b_dmg"] = 0,
										["RESIST"] = 1,
										["a_amt"] = 1,
										["a_dmg"] = 123,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 1054.007634,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590922946,
							["on_hold"] = false,
							["start_time"] = 1590922678,
							["serial"] = "Creature-0-4999-329-27480-10390-0010538B5F",
							["dps_started"] = false,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00334,
							["damage_from"] = {
								["潇潇"] = true,
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00334,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.00334,
							["classe"] = "UNKNOW",
							["damage_taken"] = 26651.00334,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["nome"] = "骷髅狂战士",
							["last_dps"] = 0,
							["end_time"] = 1590922697,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590922697,
							["serial"] = "Creature-0-4999-329-27480-10391-000F538B5F",
							["dps_started"] = false,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00199,
							["damage_from"] = {
								["潇潇"] = true,
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00199,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.00199,
							["classe"] = "UNKNOW",
							["damage_taken"] = 23867.00199,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["狂怒"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "狂怒",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "恶疫食尸鬼",
							["last_dps"] = 0,
							["end_time"] = 1590922697,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590922697,
							["serial"] = "Creature-0-4999-329-27480-10405-000A538B5F",
							["dps_started"] = false,
						}, -- [6]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00114,
							["damage_from"] = {
								["骷髅守护者"] = true,
							},
							["targets"] = {
								["石翼石像鬼"] = 6662,
								["被撕裂的死尸"] = 24325,
								["恶疫食尸鬼"] = 11213,
								["破碎的死尸 <被毁坏的死尸>"] = 1889,
								["缝补憎恶"] = 7729,
								["被毁坏的死尸"] = 27850,
								["骷髅狂战士"] = 8817,
								["骷髅守护者"] = 14239,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["nome"] = "我瞿李媚",
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 5932,
							},
							["total_without_pet"] = 102724.00114,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 102724.00114,
							["on_hold"] = false,
							["damage_taken"] = 94.00114,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["c_amt"] = 10,
										["b_amt"] = 0,
										["c_dmg"] = 607,
										["g_amt"] = 0,
										["n_max"] = 31,
										["targets"] = {
											["骷髅狂战士"] = 358,
											["被撕裂的死尸"] = 271,
											["恶疫食尸鬼"] = 216,
											["缝补憎恶"] = 57,
											["被毁坏的死尸"] = 120,
											["石翼石像鬼"] = 64,
											["骷髅守护者"] = 62,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 541,
										["n_min"] = 29,
										["g_dmg"] = 0,
										["counter"] = 28,
										["total"] = 1148,
										["c_max"] = 66,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 57,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 180,
										["targets"] = {
											["石翼石像鬼"] = 6598,
											["被撕裂的死尸"] = 24054,
											["恶疫食尸鬼"] = 10997,
											["破碎的死尸 <被毁坏的死尸>"] = 1889,
											["缝补憎恶"] = 4043,
											["被毁坏的死尸"] = 27730,
											["骷髅狂战士"] = 8459,
											["骷髅守护者"] = 13669,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 97439,
										["n_min"] = 41,
										["g_dmg"] = 0,
										["counter"] = 547,
										["total"] = 97439,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 547,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1491,
										["g_amt"] = 0,
										["n_max"] = 756,
										["targets"] = {
											["缝补憎恶"] = 2981,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1490,
										["n_min"] = 734,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2981,
										["c_max"] = 1491,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 1491,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 648,
										["targets"] = {
											["缝补憎恶"] = 648,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 648,
										["n_min"] = 648,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 648,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 508,
										["targets"] = {
											["骷髅守护者"] = 508,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 508,
										["n_min"] = 508,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 508,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590922945,
							["friendlyfire"] = {
							},
							["start_time"] = 1590922627,
							["serial"] = "Player-4920-01DA138E",
							["end_time"] = 1590922946,
						}, -- [7]
						{
							["flag_original"] = 8776,
							["totalabsorbed"] = 0.008854,
							["damage_from"] = {
								["亡者农药"] = true,
								["我瞿李媚"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008854,
							["last_event"] = 0,
							["dps_started"] = false,
							["total"] = 0.008854,
							["delay"] = 0,
							["nome"] = "石翼石像鬼",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 16454.008854,
							["end_time"] = 1590922697,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590922697,
							["serial"] = "Creature-0-4999-329-27480-10408-0000538D65",
							["classe"] = "PET",
						}, -- [8]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003214,
							["damage_from"] = {
								["骷髅守护者"] = true,
							},
							["targets"] = {
								["骷髅狂战士"] = 12239,
								["被撕裂的死尸"] = 24328,
								["恶疫食尸鬼"] = 9528,
								["破碎的死尸 <被毁坏的死尸>"] = 1545,
								["缝补憎恶"] = 7857,
								["被毁坏的死尸"] = 29062,
								["石翼石像鬼"] = 7946,
								["骷髅守护者"] = 12903,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["nome"] = "亡者农药",
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 5703,
							},
							["total_without_pet"] = 105408.003214,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 105408.003214,
							["on_hold"] = false,
							["damage_taken"] = 960.003214,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 180,
										["targets"] = {
											["骷髅狂战士"] = 12239,
											["被撕裂的死尸"] = 24328,
											["恶疫食尸鬼"] = 9528,
											["破碎的死尸 <被毁坏的死尸>"] = 1545,
											["缝补憎恶"] = 5756,
											["被毁坏的死尸"] = 29062,
											["石翼石像鬼"] = 7886,
											["骷髅守护者"] = 12903,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 103247,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 580,
										["total"] = 103247,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 580,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 763,
										["targets"] = {
											["缝补憎恶"] = 1512,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1512,
										["n_min"] = 749,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1512,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 31,
										["targets"] = {
											["石翼石像鬼"] = 60,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 60,
										["n_min"] = 29,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 60,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 589,
										["targets"] = {
											["缝补憎恶"] = 589,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 589,
										["n_min"] = 589,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 589,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590922946,
							["friendlyfire"] = {
							},
							["start_time"] = 1590922627,
							["serial"] = "Player-4920-01DA4323",
							["end_time"] = 1590922946,
						}, -- [9]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006829,
							["damage_from"] = {
								["亡者农药"] = true,
								["我瞿李媚"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 873,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 873.006829,
							["delay"] = 1590922643,
							["monster"] = true,
							["end_time"] = 1590922697,
							["nome"] = "缝补憎恶",
							["damage_taken"] = 17145.006829,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["击退"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 873,
										["targets"] = {
											["潇潇"] = 873,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 873,
										["n_min"] = 873,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 873,
										["c_max"] = 0,
										["id"] = "击退",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 1,
										["a_dmg"] = 873,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 873.006829,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590922643,
							["on_hold"] = false,
							["start_time"] = 1590922696,
							["serial"] = "Creature-0-4999-329-27480-10414-0000538B5E",
							["dps_started"] = false,
						}, -- [10]
						{
							["flag_original"] = 68136,
							["totalabsorbed"] = 528.006289,
							["damage_from"] = {
							},
							["targets"] = {
								["潇潇"] = 2858,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2858.006289,
							["last_event"] = 1590922662,
							["dps_started"] = false,
							["total"] = 2858.006289,
							["delay"] = 1590922662,
							["nome"] = "弗雷斯特恩",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 704,
										["g_amt"] = 0,
										["n_max"] = 602,
										["targets"] = {
											["潇潇"] = 2351,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1647,
										["n_min"] = 517,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 2351,
										["c_max"] = 704,
										["c_min"] = 704,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 704,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 1,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["IMMUNE"] = 4,
									},
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 507,
										["targets"] = {
											["潇潇"] = 507,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 507,
										["n_min"] = 507,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 507,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.006289,
							["end_time"] = 1590922697,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590922677,
							["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
							["classe"] = "UNKNOW",
						}, -- [11]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002434,
							["damage_from"] = {
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["nome"] = "破碎的死尸 <被毁坏的死尸>",
							["tipo"] = 1,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002434,
							["end_time"] = 1590922697,
							["monster"] = true,
							["total"] = 0.002434,
							["damage_taken"] = 3434.002434,
							["ownerName"] = "被毁坏的死尸",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1590922697,
							["serial"] = "Creature-0-4999-329-27480-10383-0000538D9A",
							["dps_started"] = false,
						}, -- [12]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 51,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 831.00164,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["亡者农药"] = 831,
							},
							["delay"] = 1590922679,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["亡者农药"] = true,
							},
							["healing_taken"] = 831.00164,
							["totalover"] = 0.00164,
							["total_without_pet"] = 831.00164,
							["totalover_without_pet"] = 0.00164,
							["totaldenied"] = 0.00164,
							["classe"] = "MAGE",
							["total"] = 831.00164,
							["heal_enemy_amt"] = 0,
							["end_time"] = 1590922697,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["防护冰霜结界"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 198,
										["targets_overheal"] = {
										},
										["n_max"] = 103,
										["targets"] = {
											["亡者农药"] = 198,
										},
										["n_min"] = 95,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 198,
										["c_max"] = 0,
										["id"] = "防护冰霜结界",
										["targets_absorbs"] = {
											["亡者农药"] = 198,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 198,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 633,
										["targets_overheal"] = {
										},
										["n_max"] = 139,
										["targets"] = {
											["亡者农药"] = 633,
										},
										["n_min"] = 64,
										["counter"] = 7,
										["overheal"] = 0,
										["total"] = 633,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["亡者农药"] = 633,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 7,
										["n_curado"] = 633,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["nome"] = "亡者农药",
							["custom"] = 0,
							["last_event"] = 1590922694,
							["on_hold"] = false,
							["start_time"] = 1590922693,
							["serial"] = "Player-4920-01DA4323",
							["targets_absorbs"] = {
								["亡者农药"] = 831,
							},
						}, -- [1]
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.002211,
							["total_without_pet"] = 1376.002211,
							["total"] = 1376.002211,
							["targets_absorbs"] = {
								["潇潇"] = 1376,
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-022A2037",
							["totalabsorb"] = 1376.002211,
							["last_hps"] = 0,
							["targets"] = {
								["潇潇"] = 1376,
							},
							["totalover_without_pet"] = 0.002211,
							["healing_taken"] = 1376.002211,
							["end_time"] = 1590922697,
							["tipo"] = 2,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 1376,
										["targets_overheal"] = {
										},
										["n_max"] = 688,
										["targets"] = {
											["潇潇"] = 1376,
										},
										["n_min"] = 160,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 1376,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 1376,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 1376,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["spec"] = 64,
							["totaldenied"] = 0.002211,
							["custom"] = 0,
							["last_event"] = 1590922662,
							["classe"] = "MAGE",
							["start_time"] = 1590922693,
							["delay"] = 1590922662,
							["boss_fight_component"] = true,
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 51,
					["_ActorTable"] = {
						{
							["received"] = 366.007481,
							["resource"] = 0.007481,
							["targets"] = {
								["亡者农药"] = 366,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.007481,
							["total"] = 366.007481,
							["nome"] = "亡者农药",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 366,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["亡者农药"] = 366,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.007481,
							["flag_original"] = 1298,
							["last_event"] = 1590922684,
							["tipo"] = 3,
							["alternatepower"] = 0.007481,
							["serial"] = "Player-4920-01DA4323",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 51,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "寒冰箭",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -40,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 69,
										["targets"] = {
										},
										["appliedamt"] = 77,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 55,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["activedamt"] = 2,
										["id"] = "寒冰护体",
										["targets"] = {
										},
										["actived_at"] = 1590922656,
										["uptime"] = 6,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 2,
									},
									["魔法抑制"] = {
										["activedamt"] = 1,
										["id"] = "魔法抑制",
										["targets"] = {
										},
										["actived_at"] = 1590922627,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["奥术智慧"] = {
										["activedamt"] = 1,
										["id"] = "奥术智慧",
										["targets"] = {
										},
										["actived_at"] = 1590922627,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["能量无常"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "能量无常",
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["防护冰霜结界"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "防护冰霜结界",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪现术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪现术",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["activedamt"] = 1,
										["id"] = "魔甲术",
										["targets"] = {
										},
										["actived_at"] = 1590922627,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 78,
							["nome"] = "亡者农药",
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["冰霜新星"] = 2,
								["暴风雪"] = 4,
								["闪现术"] = 1,
								["寒冰箭"] = 3,
								["火焰冲击"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1590922684,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01DA4323",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -7,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 70,
										["targets"] = {
										},
										["appliedamt"] = 111,
									},
									["寒冰箭"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "寒冰箭",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 28,
									},
									["冰锥术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰锥术",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 35,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术智慧"] = {
										["activedamt"] = 1,
										["id"] = "奥术智慧",
										["targets"] = {
										},
										["actived_at"] = 1590922627,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["activedamt"] = 1,
										["id"] = "呀啊啊啊啊",
										["targets"] = {
										},
										["actived_at"] = 1590922627,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["能量无常"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 11,
										["id"] = "能量无常",
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["activedamt"] = 1,
										["id"] = "魔甲术",
										["targets"] = {
										},
										["actived_at"] = 1590922627,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["activedamt"] = 1,
										["id"] = "魔法抑制",
										["targets"] = {
										},
										["actived_at"] = 1590922627,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 90,
							["nome"] = "我瞿李媚",
							["grupo"] = true,
							["spell_cast"] = {
								["冰霜新星"] = 3,
								["暴风雪"] = 4,
								["寒冰箭"] = 3,
								["火焰冲击"] = 1,
								["冰锥术"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1590922695,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01DA138E",
							["debuff_uptime_targets"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -37,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 69,
										["targets"] = {
										},
										["appliedamt"] = 55,
									},
									["冰冻"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰冻",
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 21,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 101,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["奥术智慧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术智慧",
										["uptime"] = 35,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 35,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["洛丹伦的回响"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "洛丹伦的回响",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["寒冰屏障"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰屏障",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 91,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["急速冷却"] = 1,
								["冰霜新星"] = 1,
								["寒冰屏障"] = 1,
								["暴风雪"] = 1,
								["冰锥术"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1590922663,
							["pets"] = {
							},
							["nome"] = "潇潇",
							["serial"] = "Player-4920-022A2037",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "骷髅守护者",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["奥术箭"] = 1,
								["寒冰箭"] = 4,
								["暗影箭"] = 7,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-329-27480-10390-000ED38B5F",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 13,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["我瞿李媚"] = {
									["uptime"] = 4,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
								["亡者农药"] = {
									["uptime"] = 9,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1590922660,
							["tipo"] = 4,
							["damage_twin"] = "骷髅守护者",
							["serial"] = "Creature-0-4999-329-27480-10390-000ED38B5F",
							["damage_spellid"] = "寒冰箭",
							["nome"] = "寒冰箭",
						}, -- [5]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "恶疫食尸鬼",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["狂怒"] = 3,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-329-27480-10405-0000538B5E",
							["boss_fight_component"] = true,
						}, -- [6]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "缝补憎恶",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["击退"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-329-27480-10414-0000538B5E",
							["boss_fight_component"] = true,
						}, -- [7]
						{
							["flag_original"] = 68136,
							["nome"] = "弗雷斯特恩",
							["spell_cast"] = {
								["射击"] = 1,
								["挫志怒吼"] = 1,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["tipo"] = 4,
							["last_event"] = 0,
							["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
							["boss_fight_component"] = true,
						}, -- [8]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "被毁坏的死尸",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["召唤破碎的死尸"] = 10,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-329-27480-10381-000A538B5F",
							["boss_fight_component"] = true,
						}, -- [9]
						{
							["flag_original"] = 68136,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["debuff_uptime"] = 4,
							["spellschool"] = 1,
							["nome"] = "眩晕",
							["boss_fight_component"] = true,
							["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
							["last_event"] = 1590922661,
							["damage_twin"] = "弗雷斯特恩",
							["debuff_uptime_targets"] = {
								["潇潇"] = {
									["uptime"] = 4,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["damage_spellid"] = "眩晕",
							["tipo"] = 4,
						}, -- [10]
						{
							["flag_original"] = 68136,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["debuff_uptime"] = 4,
							["spellschool"] = 1,
							["nome"] = "挫志怒吼",
							["boss_fight_component"] = true,
							["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
							["last_event"] = 1590922662,
							["damage_twin"] = "弗雷斯特恩",
							["debuff_uptime_targets"] = {
								["潇潇"] = {
									["uptime"] = 4,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["damage_spellid"] = "挫志怒吼",
							["tipo"] = 4,
						}, -- [11]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 51,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 803784.297,
				["overall_added"] = true,
				["last_events_tables"] = {
					{
						{
							{
								false, -- [1]
								"寒冰护体", -- [2]
								688, -- [3]
								1590922642.688, -- [4]
								1980, -- [5]
								"潇潇", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [1]
							{
								true, -- [1]
								"击退", -- [2]
								873, -- [3]
								1590922642.688, -- [4]
								1980, -- [5]
								"缝补憎恶", -- [6]
								688, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [2]
							{
								true, -- [1]
								"射击", -- [2]
								507, -- [3]
								1590922643.075, -- [4]
								1980, -- [5]
								"弗雷斯特恩", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [3]
							{
								true, -- [1]
								"!Melee", -- [2]
								517, -- [3]
								1590922645.108, -- [4]
								1288, -- [5]
								"弗雷斯特恩", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [4]
							{
								true, -- [1]
								"!Melee", -- [2]
								602, -- [3]
								1590922656.732, -- [4]
								771, -- [5]
								"弗雷斯特恩", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [5]
							{
								4, -- [1]
								"眩晕", -- [2]
								1, -- [3]
								1590922656.866, -- [4]
								771, -- [5]
								"弗雷斯特恩", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [6]
							{
								4, -- [1]
								"挫志怒吼", -- [2]
								1, -- [3]
								1590922658.07, -- [4]
								169, -- [5]
								"弗雷斯特恩", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [7]
							{
								true, -- [1]
								"!Melee", -- [2]
								528, -- [3]
								1590922659.117, -- [4]
								169, -- [5]
								"弗雷斯特恩", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [8]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								528, -- [3]
								1590922659.284, -- [4]
								169, -- [5]
								"潇潇", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [9]
							{
								true, -- [1]
								"!Melee", -- [2]
								704, -- [3]
								1590922661.62, -- [4]
								169, -- [5]
								"弗雷斯特恩", -- [6]
								160, -- [7]
								1, -- [8]
								false, -- [9]
								375, -- [10]
							}, -- [10]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								160, -- [3]
								1590922661.703, -- [4]
								169, -- [5]
								"潇潇", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [11]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"潇潇", -- [6]
							}, -- [12]
						}, -- [1]
						1590922662.12, -- [2]
						"潇潇", -- [3]
						"MAGE", -- [4]
						1980, -- [5]
						"0m 34s", -- [6]
						["dead"] = true,
						["dead_at"] = 34.9959999999264,
					}, -- [1]
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					255705, -- [1]
					2207, -- [2]
					{
						0, -- [1]
						[0] = 366,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 1,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "18:58:22",
				["cleu_timeline"] = {
				},
				["enemy"] = "弗雷斯特恩",
				["TotalElapsedCombatTime"] = 34.3939999999711,
				["CombatEndedAt"] = 803818.691,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "18:57:07",
				["end_time"] = 803856.804,
				["combat_id"] = 51,
				["combat_counter"] = 78,
				["tempo_start"] = 1590922627,
				["contra"] = "被毁坏的死尸",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "东部王国",
					["encounter"] = "弗雷斯特恩",
					["mapid"] = 0,
					["try_number"] = 1,
					["name"] = "弗雷斯特恩",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					250920, -- [1]
					2207, -- [2]
					{
						0, -- [1]
						[0] = 366,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 1,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["潇潇"] = 42788.001229,
							["我瞿李媚"] = 74106.00114,
							["亡者农药"] = 87049.003214,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["亡者农药"] = 831.00164,
							["潇潇"] = 1376.002211,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 803783.695,
				["TimeData"] = {
				},
				["frags"] = {
					["骷髅狂战士"] = 12,
					["被撕裂的死尸"] = 8,
					["恶疫食尸鬼"] = 3,
					["破碎的死尸"] = 10,
					["缝补憎恶"] = 1,
					["被毁坏的死尸"] = 10,
					["石翼石像鬼"] = 2,
					["骷髅守护者"] = 12,
				},
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 45,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003964,
							["damage_from"] = {
								["斯库尔"] = true,
							},
							["targets"] = {
								["骷髅狂战士"] = 6659,
								["被撕裂的死尸"] = 5398,
								["斯库尔"] = 7108,
								["缝补憎恶"] = 720,
								["被毁坏的死尸"] = 2340,
								["恶疫食尸鬼"] = 1080,
								["骷髅守护者"] = 6299,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["nome"] = "我瞿李媚",
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 7468,
							},
							["total_without_pet"] = 29604.003964,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 29604.003964,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 906.003964,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 960,
										["g_amt"] = 0,
										["n_max"] = 601,
										["targets"] = {
											["斯库尔"] = 1561,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 601,
										["n_min"] = 601,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1561,
										["c_max"] = 960,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 960,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1523,
										["g_amt"] = 0,
										["n_max"] = 765,
										["targets"] = {
											["斯库尔"] = 4524,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3001,
										["n_min"] = 736,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 4524,
										["c_max"] = 1523,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 1523,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰锥术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1023,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["斯库尔"] = 1023,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1023,
										["c_max"] = 1023,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["c_min"] = 1023,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 180,
										["targets"] = {
											["骷髅狂战士"] = 6659,
											["被撕裂的死尸"] = 5398,
											["恶疫食尸鬼"] = 1080,
											["缝补憎恶"] = 720,
											["被毁坏的死尸"] = 2340,
											["骷髅守护者"] = 6299,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 22496,
										["n_min"] = 179,
										["g_dmg"] = 0,
										["counter"] = 125,
										["total"] = 22496,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 125,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590921751,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590921751,
							["on_hold"] = false,
							["start_time"] = 1590921639,
							["serial"] = "Player-4920-01DA138E",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 577.004003,
							["damage_from"] = {
								["亡者农药"] = true,
								["我瞿李媚"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
								["我瞿李媚"] = 906,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 906.004003,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1590921661,
							["nome"] = "斯库尔",
							["damage_taken"] = 13363.004003,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["奥术箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 273,
										["targets"] = {
											["我瞿李媚"] = 273,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 273,
										["n_min"] = 273,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 273,
										["c_max"] = 0,
										["id"] = "奥术箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 304,
										["targets"] = {
											["我瞿李媚"] = 304,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 304,
										["n_min"] = 304,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 304,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 1,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["REFLECT"] = 1,
									},
									["冰霜震击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 329,
										["targets"] = {
											["我瞿李媚"] = 329,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 329,
										["n_min"] = 329,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 329,
										["c_max"] = 0,
										["id"] = "冰霜震击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 1,
										["a_dmg"] = 329,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 906.004003,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590921655,
							["on_hold"] = false,
							["start_time"] = 1590921647,
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003847,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅狂战士"] = 40,
								["被撕裂的死尸"] = 82,
								["斯库尔"] = 5038,
								["恶疫食尸鬼"] = 41,
								["骷髅守护者"] = 367,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["nome"] = "亡者农药",
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 5038,
							},
							["total_without_pet"] = 5568.003847,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 5568.003847,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 0.003847,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 62,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["斯库尔"] = 62,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 62,
										["c_max"] = 62,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 62,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 565,
										["targets"] = {
											["斯库尔"] = 565,
											["恶疫食尸鬼"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 565,
										["n_min"] = 565,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 565,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 1,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 761,
										["targets"] = {
											["斯库尔"] = 3764,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3764,
										["n_min"] = 746,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 3764,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 647,
										["targets"] = {
											["斯库尔"] = 647,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 647,
										["n_min"] = 647,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 647,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 41,
										["targets"] = {
											["骷髅狂战士"] = 40,
											["被撕裂的死尸"] = 82,
											["恶疫食尸鬼"] = 41,
											["骷髅守护者"] = 367,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 530,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 530,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 13,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590921751,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590921751,
							["on_hold"] = false,
							["start_time"] = 1590921640,
							["serial"] = "Player-4920-01DA4323",
							["friendlyfire"] = {
							},
						}, -- [3]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004361,
							["damage_from"] = {
							},
							["targets"] = {
								["斯库尔"] = 1217,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 821,
										["g_amt"] = 0,
										["n_max"] = 396,
										["targets"] = {
											["斯库尔"] = 1217,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 396,
										["n_min"] = 396,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1217,
										["c_max"] = 821,
										["c_min"] = 821,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 1,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 1217,
							},
							["total_without_pet"] = 1217.004361,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 1217.004361,
							["damage_taken"] = 0.004361,
							["nome"] = "潇潇",
							["boss_fight_component"] = true,
							["spec"] = 64,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1590921661,
							["custom"] = 0,
							["last_event"] = 1590921655,
							["on_hold"] = false,
							["start_time"] = 1590921650,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 45,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 856.007866,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["我瞿李媚"] = 856,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["我瞿李媚"] = true,
							},
							["healing_taken"] = 856.007866,
							["totalover"] = 0.007866,
							["total_without_pet"] = 856.007866,
							["totalover_without_pet"] = 0.007866,
							["totaldenied"] = 0.007866,
							["classe"] = "MAGE",
							["total"] = 856.007866,
							["heal_enemy_amt"] = 0,
							["end_time"] = 1590921661,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 856,
										["targets_overheal"] = {
										},
										["n_max"] = 304,
										["targets"] = {
											["我瞿李媚"] = 856,
										},
										["n_min"] = 273,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 856,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["我瞿李媚"] = 856,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 856,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["nome"] = "我瞿李媚",
							["custom"] = 0,
							["last_event"] = 1590921654,
							["on_hold"] = false,
							["start_time"] = 1590921647,
							["serial"] = "Player-4920-01DA138E",
							["targets_absorbs"] = {
								["我瞿李媚"] = 856,
							},
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 45,
					["_ActorTable"] = {
						{
							["received"] = 359.005804,
							["resource"] = 0.005804,
							["targets"] = {
								["我瞿李媚"] = 359,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.005804,
							["total"] = 359.005804,
							["nome"] = "我瞿李媚",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 359,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["我瞿李媚"] = 359,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.005804,
							["flag_original"] = 1298,
							["last_event"] = 1590921656,
							["tipo"] = 3,
							["alternatepower"] = 0.005804,
							["serial"] = "Player-4920-01DA138E",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 45,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "寒冰箭",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["冰锥术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰锥术",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 98,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术智慧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术智慧",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["防护冰霜结界"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "防护冰霜结界",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 12,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["冰霜新星"] = 1,
								["冰锥术"] = 1,
								["寒冰箭"] = 5,
								["法术反制"] = 1,
								["火焰冲击"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1590921661,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01DA4323",
							["nome"] = "亡者农药",
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -1,
										["refreshamt"] = 0,
										["id"] = "寒冰箭",
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["冰锥术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰锥术",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 85,
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["斯库尔"] = 1,
										},
										["interrompeu_oque"] = {
											["寒冰箭"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["防护冰霜结界"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "防护冰霜结界",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术智慧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术智慧",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["寒冰箭"] = 1,
							},
							["debuff_uptime"] = 31,
							["tipo"] = 4,
							["boss_fight_component"] = true,
							["interrupt_targets"] = {
								["斯库尔"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["法术反制"] = 1,
								["寒冰箭"] = 4,
								["火焰冲击"] = 2,
								["冰锥术"] = 1,
							},
							["interrupt"] = 1.004875,
							["pets"] = {
							},
							["last_event"] = 1590921661,
							["debuff_uptime_targets"] = {
							},
							["nome"] = "我瞿李媚",
							["serial"] = "Player-4920-01DA138E",
							["buff_uptime_targets"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 1300,
							["nome"] = "潇潇",
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 60,
							["pets"] = {
							},
							["last_event"] = 1590921661,
							["classe"] = "MAGE",
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["寒冰箭"] = 4,
								["法术反制"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术智慧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术智慧",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 22,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "斯库尔",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["奥术箭"] = 1,
								["寒冰箭"] = 3,
								["冰霜震击"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 4,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["我瞿李媚"] = {
									["uptime"] = 4,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1590921656,
							["tipo"] = 4,
							["damage_twin"] = "斯库尔",
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["damage_spellid"] = "寒冰箭",
							["nome"] = "寒冰箭",
						}, -- [5]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["我瞿李媚"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1590921654,
								},
							},
							["last_event"] = 1590921654,
							["tipo"] = 4,
							["damage_twin"] = "斯库尔",
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["damage_spellid"] = "冰霜震击",
							["nome"] = "冰霜震击",
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 45,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 802805.703,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					37294.974911, -- [1]
					856, -- [2]
					{
						0, -- [1]
						[0] = 359,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "18:41:01",
				["cleu_timeline"] = {
				},
				["enemy"] = "斯库尔",
				["TotalElapsedCombatTime"] = 10.9770000000717,
				["CombatEndedAt"] = 802816.68,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "18:40:39",
				["end_time"] = 802817.28,
				["combat_id"] = 45,
				["combat_counter"] = 71,
				["tempo_start"] = 1590921639,
				["contra"] = "斯库尔",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "斯坦索姆",
					["encounter"] = "斯库尔",
					["mapid"] = 329,
					["try_number"] = 3,
					["name"] = "斯库尔",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					36389, -- [1]
					856, -- [2]
					{
						0, -- [1]
						[0] = 359,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["亡者农药"] = 5038.003847,
							["我瞿李媚"] = 7108.003964,
							["潇潇"] = 1217.004361,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["我瞿李媚"] = 856.007866,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 802795.279,
				["TimeData"] = {
				},
				["frags"] = {
					["斯库尔"] = 1,
				},
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 43,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 2080.002211,
							["damage_from"] = {
								["潇潇"] = true,
								["亡者农药"] = true,
								["斯库尔"] = true,
								["我瞿李媚"] = true,
							},
							["targets"] = {
								["潇潇"] = 482,
								["亡者农药"] = 2814,
								["我瞿李媚"] = 1740,
								["斯库尔"] = 446,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
								[128] = 446,
							},
							["total_without_pet"] = 5482.002211,
							["delay"] = 1590921397,
							["monster"] = true,
							["end_time"] = 1590921425,
							["nome"] = "斯库尔",
							["damage_taken"] = 5118.002211,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["奥术箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 455,
										["targets"] = {
											["我瞿李媚"] = 409,
											["亡者农药"] = 1670,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2079,
										["n_min"] = 232,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2079,
										["c_max"] = 0,
										["id"] = "奥术箭",
										["r_dmg"] = 902,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 446,
										["targets"] = {
											["亡者农药"] = 1144,
											["斯库尔"] = 446,
											["我瞿李媚"] = 1331,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2921,
										["n_min"] = 223,
										["g_dmg"] = 0,
										["counter"] = 13,
										["c_min"] = 0,
										["total"] = 2921,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["n_amt"] = 10,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 10,
										["a_dmg"] = 774,
										["RESIST"] = 2,
										["spellschool"] = 16,
										["REFLECT"] = 1,
									},
									["冰霜震击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 482,
										["targets"] = {
											["潇潇"] = 482,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 482,
										["n_min"] = 482,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 482,
										["c_max"] = 0,
										["id"] = "冰霜震击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 5482.002211,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590921424,
							["on_hold"] = false,
							["start_time"] = 1590921391,
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002467,
							["damage_from"] = {
								["斯库尔"] = true,
								["缝补憎恶"] = true,
							},
							["targets"] = {
								["石翼石像鬼"] = 2119,
								["被撕裂的死尸"] = 516,
								["斯库尔"] = 1375,
								["缝补憎恶"] = 1304,
								["被毁坏的死尸"] = 688,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 6002.002467,
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 1375,
							},
							["total_without_pet"] = 6002.002467,
							["delay"] = 1590921406,
							["dps_started"] = false,
							["end_time"] = 1590921425,
							["nome"] = "亡者农药",
							["damage_taken"] = 3678.002467,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 172,
										["targets"] = {
											["石翼石像鬼"] = 2062,
											["被撕裂的死尸"] = 516,
											["斯库尔"] = 1375,
											["缝补憎恶"] = 1275,
											["被毁坏的死尸"] = 688,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5916,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 39,
										["total"] = 5916,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 39,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29,
										["targets"] = {
											["缝补憎恶"] = 29,
											["石翼石像鬼"] = 57,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 86,
										["n_min"] = 28,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 86,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590921406,
							["friendlyfire"] = {
							},
							["start_time"] = 1590921398,
							["serial"] = "Player-4920-01DA4323",
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003773,
							["damage_from"] = {
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003773,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.003773,
							["classe"] = "UNKNOW",
							["damage_taken"] = 3093.003773,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["nome"] = "被撕裂的死尸",
							["last_dps"] = 0,
							["end_time"] = 1590921425,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590921425,
							["serial"] = "Creature-0-4887-329-19161-10382-0004D387FC",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005845,
							["damage_from"] = {
								["缝补憎恶"] = true,
								["斯库尔"] = true,
							},
							["targets"] = {
								["石翼石像鬼"] = 2234,
								["被撕裂的死尸"] = 2577,
								["斯库尔"] = 2277,
								["缝补憎恶"] = 2203,
								["被毁坏的死尸"] = 1029,
								["破碎的死尸"] = 687,
								["破碎的死尸 <被毁坏的死尸>"] = 344,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 11351.005845,
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 2277,
							},
							["total_without_pet"] = 11351.005845,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1590921425,
							["nome"] = "我瞿李媚",
							["damage_taken"] = 4258.005845,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 172,
										["targets"] = {
											["石翼石像鬼"] = 2234,
											["被撕裂的死尸"] = 2577,
											["斯库尔"] = 1628,
											["缝补憎恶"] = 2141,
											["被毁坏的死尸"] = 1029,
											["破碎的死尸"] = 687,
											["破碎的死尸 <被毁坏的死尸>"] = 344,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 10640,
										["n_min"] = 41,
										["g_dmg"] = 0,
										["counter"] = 65,
										["total"] = 10640,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 65,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["斯库尔"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰霜新星"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 62,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["缝补憎恶"] = 62,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 62,
										["c_max"] = 62,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 62,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 649,
										["targets"] = {
											["斯库尔"] = 649,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 649,
										["n_min"] = 649,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 649,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590921419,
							["friendlyfire"] = {
							},
							["start_time"] = 1590921380,
							["serial"] = "Player-4920-01DA138E",
							["friendlyfire_total"] = 0,
						}, -- [4]
						{
							["flag_original"] = 8776,
							["totalabsorbed"] = 0.006074,
							["damage_from"] = {
								["亡者农药"] = true,
								["我瞿李媚"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006074,
							["last_event"] = 0,
							["dps_started"] = false,
							["total"] = 0.006074,
							["delay"] = 0,
							["nome"] = "石翼石像鬼",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 4853.006074,
							["end_time"] = 1590921425,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590921425,
							["serial"] = "Creature-0-4887-329-19161-10408-0000538872",
							["classe"] = "PET",
						}, -- [5]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 795.006181,
							["damage_from"] = {
								["亡者农药"] = true,
								["我瞿李媚"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
								["亡者农药"] = 864,
								["我瞿李媚"] = 2518,
								["潇潇"] = 2397,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5779.006181,
							["delay"] = 1590921381,
							["monster"] = true,
							["end_time"] = 1590921425,
							["nome"] = "缝补憎恶",
							["damage_taken"] = 5692.006181,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["疾病之云"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["潇潇"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "疾病之云",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 8,
										["IMMUNE"] = 1,
									},
									["击退"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 864,
										["targets"] = {
											["我瞿李媚"] = 1641,
											["亡者农药"] = 864,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2505,
										["n_min"] = 795,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2505,
										["c_max"] = 0,
										["id"] = "击退",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1235,
										["targets"] = {
											["我瞿李媚"] = 877,
											["潇潇"] = 2397,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3274,
										["n_min"] = 877,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 3274,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 1235,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 5779.006181,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590921424,
							["on_hold"] = false,
							["start_time"] = 1590921410,
							["serial"] = "Creature-0-4887-329-19161-10414-00015387FB",
							["dps_started"] = false,
						}, -- [6]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005408,
							["damage_from"] = {
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
								"破碎的死尸 <被毁坏的死尸>", -- [1]
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005408,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.005408,
							["classe"] = "UNKNOW",
							["damage_taken"] = 1717.005408,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["召唤破碎的死尸"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "召唤破碎的死尸",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "被毁坏的死尸",
							["last_dps"] = 0,
							["end_time"] = 1590921425,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590921425,
							["serial"] = "Creature-0-4887-329-19161-10381-00005387FC",
							["dps_started"] = false,
						}, -- [7]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006318,
							["damage_from"] = {
								["我瞿李媚"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006318,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.006318,
							["classe"] = "UNKNOW",
							["damage_taken"] = 687.006318,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["nome"] = "破碎的死尸",
							["last_dps"] = 0,
							["end_time"] = 1590921425,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590921425,
							["serial"] = "Creature-0-4887-329-19161-10383-00005388A4",
							["dps_started"] = false,
						}, -- [8]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001156,
							["damage_from"] = {
								["斯库尔"] = true,
								["缝补憎恶"] = true,
							},
							["targets"] = {
								["石翼石像鬼"] = 500,
								["斯库尔"] = 1020,
								["缝补憎恶"] = 2185,
							},
							["delay"] = 1590921409,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 64,
										["targets"] = {
											["缝补憎恶"] = 64,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 64,
										["n_min"] = 64,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 64,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 125,
										["targets"] = {
											["石翼石像鬼"] = 500,
											["斯库尔"] = 250,
											["缝补憎恶"] = 562,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1312,
										["n_min"] = 94,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 1312,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 188,
										["c_min"] = 0,
										["r_amt"] = 2,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 772,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["缝补憎恶"] = 772,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 772,
										["c_max"] = 772,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 772,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 397,
										["targets"] = {
											["缝补憎恶"] = 787,
											["斯库尔"] = 392,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1179,
										["n_min"] = 390,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1179,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 378,
										["targets"] = {
											["斯库尔"] = 378,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 378,
										["n_min"] = 378,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 378,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 1020,
							},
							["total_without_pet"] = 3705.001156,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 3705.001156,
							["damage_taken"] = 2879.001156,
							["nome"] = "潇潇",
							["boss_fight_component"] = true,
							["spec"] = 64,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1590921425,
							["custom"] = 0,
							["last_event"] = 1590921419,
							["on_hold"] = false,
							["start_time"] = 1590921401,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [9]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002074,
							["damage_from"] = {
								["我瞿李媚"] = true,
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["nome"] = "破碎的死尸 <被毁坏的死尸>",
							["tipo"] = 1,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002074,
							["end_time"] = 1590921425,
							["monster"] = true,
							["total"] = 0.002074,
							["damage_taken"] = 344.002074,
							["ownerName"] = "被毁坏的死尸",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1590921425,
							["serial"] = "Creature-0-4887-329-19161-10383-00005388B2",
							["dps_started"] = false,
						}, -- [10]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 43,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 1160.00804,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["亡者农药"] = 1410,
							},
							["delay"] = 1590921412,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["亡者农药"] = true,
							},
							["healing_taken"] = 1410.00804,
							["totalover"] = 0.00804,
							["total_without_pet"] = 1410.00804,
							["totalover_without_pet"] = 0.00804,
							["totaldenied"] = 0.00804,
							["classe"] = "MAGE",
							["total"] = 1410.00804,
							["heal_enemy_amt"] = 0,
							["end_time"] = 1590921425,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["防护冰霜结界"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 675,
										["targets_overheal"] = {
										},
										["n_max"] = 305,
										["targets"] = {
											["亡者农药"] = 675,
										},
										["n_min"] = 115,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 675,
										["c_max"] = 0,
										["id"] = "防护冰霜结界",
										["targets_absorbs"] = {
											["亡者农药"] = 675,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 675,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["亡者农药"] = 250,
										},
										["n_min"] = 250,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 250,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 250,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 485,
										["targets_overheal"] = {
										},
										["n_max"] = 313,
										["targets"] = {
											["亡者农药"] = 485,
										},
										["n_min"] = 172,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 485,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["亡者农药"] = 485,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 485,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["nome"] = "亡者农药",
							["custom"] = 0,
							["last_event"] = 1590921412,
							["on_hold"] = false,
							["start_time"] = 1590921413,
							["serial"] = "Player-4920-01DA4323",
							["targets_absorbs"] = {
								["亡者农药"] = 1160,
							},
						}, -- [1]
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.003866,
							["total_without_pet"] = 688.003866,
							["total"] = 688.003866,
							["targets_absorbs"] = {
								["潇潇"] = 688,
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-022A2037",
							["totalabsorb"] = 688.003866,
							["last_hps"] = 0,
							["targets"] = {
								["潇潇"] = 688,
							},
							["totalover_without_pet"] = 0.003866,
							["healing_taken"] = 688.003866,
							["end_time"] = 1590921425,
							["tipo"] = 2,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 688,
										["targets_overheal"] = {
										},
										["n_max"] = 482,
										["targets"] = {
											["潇潇"] = 688,
										},
										["n_min"] = 206,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 688,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 688,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 688,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["spec"] = 64,
							["totaldenied"] = 0.003866,
							["custom"] = 0,
							["last_event"] = 1590921413,
							["classe"] = "MAGE",
							["start_time"] = 1590921419,
							["delay"] = 1590921413,
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 1729.00227,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["我瞿李媚"] = 1729,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["我瞿李媚"] = true,
							},
							["healing_taken"] = 1729.00227,
							["totalover"] = 0.00227,
							["total_without_pet"] = 1729.00227,
							["totalover_without_pet"] = 0.00227,
							["totaldenied"] = 0.00227,
							["classe"] = "MAGE",
							["total"] = 1729.00227,
							["heal_enemy_amt"] = 0,
							["end_time"] = 1590921425,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 1729,
										["targets_overheal"] = {
										},
										["n_max"] = 795,
										["targets"] = {
											["我瞿李媚"] = 1729,
										},
										["n_min"] = 78,
										["counter"] = 5,
										["overheal"] = 0,
										["total"] = 1729,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["我瞿李媚"] = 1729,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 1729,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["nome"] = "我瞿李媚",
							["custom"] = 0,
							["last_event"] = 1590921423,
							["on_hold"] = false,
							["start_time"] = 1590921410,
							["serial"] = "Player-4920-01DA138E",
							["targets_absorbs"] = {
								["我瞿李媚"] = 1729,
							},
						}, -- [3]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 43,
					["_ActorTable"] = {
						{
							["received"] = 365.006255,
							["resource"] = 0.006255,
							["targets"] = {
								["亡者农药"] = 365,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.006255,
							["total"] = 365.006255,
							["nome"] = "亡者农药",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 365,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["亡者农药"] = 365,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.006255,
							["flag_original"] = 1298,
							["last_event"] = 1590921382,
							["tipo"] = 3,
							["alternatepower"] = 0.006255,
							["serial"] = "Player-4920-01DA4323",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["received"] = 1810.003049,
							["resource"] = 0.003049,
							["targets"] = {
								["我瞿李媚"] = 1810,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.003049,
							["total"] = 1810.003049,
							["nome"] = "我瞿李媚",
							["spells"] = {
								["_ActorTable"] = {
									["恢复法力"] = {
										["total"] = 722,
										["id"] = "恢复法力",
										["totalover"] = 0,
										["targets"] = {
											["我瞿李媚"] = 722,
										},
										["counter"] = 1,
									},
									["补充法力"] = {
										["total"] = 1088,
										["id"] = "补充法力",
										["totalover"] = 0,
										["targets"] = {
											["我瞿李媚"] = 1088,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.003049,
							["flag_original"] = 1298,
							["last_event"] = 1590921412,
							["tipo"] = 3,
							["alternatepower"] = 0.003049,
							["serial"] = "Player-4920-01DA138E",
							["boss_fight_component"] = true,
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 43,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["新近包扎"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "新近包扎",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -6,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 9,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 227,
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["斯库尔"] = 1,
										},
										["interrompeu_oque"] = {
											["寒冰箭"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["抗性"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "抗性",
										["uptime"] = 34,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 34,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["急救"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急救",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 34,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 34,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 34,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["洛丹伦的回响"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "洛丹伦的回响",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["闪现术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪现术",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["防护冰霜结界"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "防护冰霜结界",
										["uptime"] = 28,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["寒冰箭"] = 1,
							},
							["debuff_uptime"] = 58,
							["tipo"] = 4,
							["boss_fight_component"] = true,
							["interrupt_targets"] = {
								["斯库尔"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["急救"] = 1,
								["法术反制"] = 1,
								["防护冰霜结界"] = 1,
								["闪现术"] = 1,
								["冰霜新星"] = 1,
								["暴风雪"] = 2,
							},
							["interrupt"] = 1.001917,
							["pets"] = {
							},
							["last_event"] = 1590921414,
							["debuff_uptime_targets"] = {
							},
							["nome"] = "亡者农药",
							["serial"] = "Player-4920-01DA4323",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -3,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 23,
									},
									["冰霜新星"] = {
										["activedamt"] = -1,
										["id"] = "冰霜新星",
										["targets"] = {
										},
										["actived_at"] = 1590921381,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 214,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["洛丹伦的回响"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "洛丹伦的回响",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪现术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪现术",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "呀啊啊啊啊",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 44,
							["nome"] = "我瞿李媚",
							["grupo"] = true,
							["spell_cast"] = {
								["冰霜新星"] = 1,
								["暴风雪"] = 2,
								["寒冰护体"] = 1,
								["补充法力"] = 1,
								["法术反制"] = 1,
								["寒冰箭"] = 1,
								["闪现术"] = 1,
								["恢复法力"] = 1,
								["火焰冲击"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1590921424,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01DA138E",
							["debuff_uptime_targets"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 5,
									},
									["冰锥术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰锥术",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰冻"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰冻",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 86,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 33,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 40,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["洛丹伦的回响"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "洛丹伦的回响",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["寒冰屏障"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰屏障",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 27,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["暴风雪"] = 1,
								["冰霜新星"] = 1,
								["冰锥术"] = 3,
								["寒冰屏障"] = 1,
								["寒冰箭"] = 1,
								["火焰冲击"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1590921421,
							["pets"] = {
							},
							["nome"] = "潇潇",
							["serial"] = "Player-4920-022A2037",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "斯库尔",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["奥术箭"] = 6,
								["寒冰箭"] = 10,
								["冰霜震击"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "缝补憎恶",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["击退"] = 3,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4887-329-19161-10414-00015387FB",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 40,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["我瞿李媚"] = {
									["uptime"] = 10,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
								["亡者农药"] = {
									["uptime"] = 30,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = -1,
									["actived"] = true,
									["actived_at"] = 1590921414,
								},
							},
							["last_event"] = 1590921424,
							["tipo"] = 4,
							["damage_twin"] = "斯库尔",
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["damage_spellid"] = 0,
							["nome"] = "寒冰箭",
						}, -- [6]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "被毁坏的死尸",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["召唤破碎的死尸"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4887-329-19161-10381-00025387FC",
							["boss_fight_component"] = true,
						}, -- [7]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 5,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["潇潇"] = {
									["uptime"] = 5,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1590921413,
							["tipo"] = 4,
							["damage_twin"] = "斯库尔",
							["serial"] = "Creature-0-4887-329-19161-10393-00005387FB",
							["damage_spellid"] = "冰霜震击",
							["nome"] = "冰霜震击",
						}, -- [8]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 43,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 802548.81,
				["overall_added"] = true,
				["last_events_tables"] = {
					{
						{
							{
								false, -- [1]
								"寒冰护体", -- [2]
								313, -- [3]
								1590921390.521, -- [4]
								648, -- [5]
								"亡者农药", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [1]
							{
								true, -- [1]
								"奥术箭", -- [2]
								313, -- [3]
								1590921390.521, -- [4]
								648, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [2]
							{
								4, -- [1]
								"寒冰箭", -- [2]
								1, -- [3]
								1590921395.125, -- [4]
								648, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [3]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								172, -- [3]
								1590921395.125, -- [4]
								648, -- [5]
								"亡者农药", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [4]
							{
								false, -- [1]
								"防护冰霜结界", -- [2]
								115, -- [3]
								1590921395.125, -- [4]
								648, -- [5]
								"亡者农药", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [5]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								287, -- [3]
								1590921395.125, -- [4]
								648, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [6]
							{
								false, -- [1]
								"防护冰霜结界", -- [2]
								305, -- [3]
								1590921396.326, -- [4]
								648, -- [5]
								"亡者农药", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [7]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								305, -- [3]
								1590921396.326, -- [4]
								648, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [8]
							{
								4, -- [1]
								0, -- [2]
								1, -- [3]
								1590921396.326, -- [4]
								648, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [9]
							{
								true, -- [1]
								"奥术箭", -- [2]
								381, -- [3]
								1590921397.526, -- [4]
								648, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [10]
							{
								false, -- [1]
								"急救", -- [2]
								250, -- [3]
								1590921407.704, -- [4]
								267, -- [5]
								"亡者农药", -- [6]
								nil, -- [7]
								0, -- [8]
							}, -- [11]
							{
								true, -- [1]
								"奥术箭", -- [2]
								289, -- [3]
								1590921408.687, -- [4]
								517, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [12]
							{
								4, -- [1]
								"寒冰箭", -- [2]
								1, -- [3]
								1590921412.391, -- [4]
								228, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [13]
							{
								false, -- [1]
								"防护冰霜结界", -- [2]
								255, -- [3]
								1590921412.391, -- [4]
								228, -- [5]
								"亡者农药", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [14]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								293, -- [3]
								1590921412.391, -- [4]
								228, -- [5]
								"斯库尔", -- [6]
								255, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [15]
							{
								true, -- [1]
								"奥术箭", -- [2]
								455, -- [3]
								1590921414.791, -- [4]
								190, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								265, -- [10]
							}, -- [16]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"亡者农药", -- [6]
							}, -- [17]
						}, -- [1]
						1590921414.991, -- [2]
						"亡者农药", -- [3]
						"MAGE", -- [4]
						3290, -- [5]
						"0m 34s", -- [6]
						["dead"] = true,
						["dead_at"] = 34.4790000000503,
					}, -- [1]
					{
						{
							{
								4, -- [1]
								"冰霜震击", -- [2]
								1, -- [3]
								1590921408.454, -- [4]
								1980, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [1]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								482, -- [3]
								1590921408.454, -- [4]
								1980, -- [5]
								"潇潇", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [2]
							{
								true, -- [1]
								"冰霜震击", -- [2]
								482, -- [3]
								1590921408.47, -- [4]
								1980, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [3]
							{
								true, -- [1]
								"!Melee", -- [2]
								1235, -- [3]
								1590921413.358, -- [4]
								1980, -- [5]
								"缝补憎恶", -- [6]
								206, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [4]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								206, -- [3]
								1590921413.358, -- [4]
								1980, -- [5]
								"潇潇", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [5]
							{
								true, -- [1]
								"!Melee", -- [2]
								1162, -- [3]
								1590921420.712, -- [4]
								951, -- [5]
								"缝补憎恶", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								211, -- [10]
							}, -- [6]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"潇潇", -- [6]
							}, -- [7]
						}, -- [1]
						1590921421.114, -- [2]
						"潇潇", -- [3]
						"MAGE", -- [4]
						1980, -- [5]
						"0m 40s", -- [6]
						["dead"] = true,
						["dead_at"] = 40.6020000000717,
					}, -- [2]
					{
						{
							{
								false, -- [1]
								"寒冰护体", -- [2]
								795, -- [3]
								1590921410.922, -- [4]
								2373, -- [5]
								"我瞿李媚", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [1]
							{
								true, -- [1]
								"击退", -- [2]
								795, -- [3]
								1590921410.922, -- [4]
								2373, -- [5]
								"缝补憎恶", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [2]
							{
								4, -- [1]
								"寒冰箭", -- [2]
								1, -- [3]
								1590921412.991, -- [4]
								2373, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [3]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								78, -- [3]
								1590921412.991, -- [4]
								2373, -- [5]
								"我瞿李媚", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [4]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								258, -- [3]
								1590921412.991, -- [4]
								2373, -- [5]
								"斯库尔", -- [6]
								78, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [5]
							{
								true, -- [1]
								"!Melee", -- [2]
								877, -- [3]
								1590921416.759, -- [4]
								2193, -- [5]
								"缝补憎恶", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [6]
							{
								4, -- [1]
								"寒冰箭", -- [2]
								1, -- [3]
								1590921417.626, -- [4]
								1316, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [7]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								251, -- [3]
								1590921417.626, -- [4]
								1316, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [8]
							{
								4, -- [1]
								0, -- [2]
								1, -- [3]
								1590921418.66, -- [4]
								1065, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [9]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								284, -- [3]
								1590921418.66, -- [4]
								1065, -- [5]
								"我瞿李媚", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [10]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								284, -- [3]
								1590921418.66, -- [4]
								1065, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [11]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								409, -- [3]
								1590921420.029, -- [4]
								1065, -- [5]
								"我瞿李媚", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [12]
							{
								true, -- [1]
								"奥术箭", -- [2]
								409, -- [3]
								1590921420.029, -- [4]
								1065, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [13]
							{
								4, -- [1]
								"寒冰箭", -- [2]
								1, -- [3]
								1590921423.699, -- [4]
								1065, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [14]
							{
								false, -- [1]
								"寒冰护体", -- [2]
								163, -- [3]
								1590921423.699, -- [4]
								1065, -- [5]
								"我瞿李媚", -- [6]
								true, -- [7]
								0, -- [8]
							}, -- [15]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								223, -- [3]
								1590921423.699, -- [4]
								1065, -- [5]
								"斯库尔", -- [6]
								163, -- [7]
								16, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [16]
							{
								true, -- [1]
								"击退", -- [2]
								846, -- [3]
								1590921424.365, -- [4]
								1005, -- [5]
								"缝补憎恶", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [17]
							{
								4, -- [1]
								0, -- [2]
								1, -- [3]
								1590921424.899, -- [4]
								159, -- [5]
								"斯库尔", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [18]
							{
								true, -- [1]
								"寒冰箭", -- [2]
								315, -- [3]
								1590921424.899, -- [4]
								159, -- [5]
								"斯库尔", -- [6]
								nil, -- [7]
								16, -- [8]
								false, -- [9]
								156, -- [10]
							}, -- [19]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"我瞿李媚", -- [6]
							}, -- [20]
						}, -- [1]
						1590921425.182, -- [2]
						"我瞿李媚", -- [3]
						"MAGE", -- [4]
						3100, -- [5]
						"0m 44s", -- [6]
						["dead"] = true,
						["dead_at"] = 44.6700000000419,
					}, -- [3]
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32319, -- [1]
					3827, -- [2]
					{
						0, -- [1]
						[0] = 2175,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 3,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "18:37:06",
				["cleu_timeline"] = {
				},
				["enemy"] = "斯库尔",
				["TotalElapsedCombatTime"] = 28.875,
				["CombatEndedAt"] = 802577.685,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "18:36:21",
				["end_time"] = 802582.087,
				["combat_id"] = 43,
				["combat_counter"] = 69,
				["tempo_start"] = 1590921380,
				["contra"] = "斯库尔",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "斯坦索姆",
					["encounter"] = "斯库尔",
					["mapid"] = 329,
					["try_number"] = 2,
					["name"] = "斯库尔",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					21058, -- [1]
					3827, -- [2]
					{
						0, -- [1]
						[0] = 2175,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 3,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["亡者农药"] = 6002.002467,
							["我瞿李媚"] = 11351.005845,
							["潇潇"] = 3705.001156,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["亡者农药"] = 1410.00804,
							["我瞿李媚"] = 1729.00227,
							["潇潇"] = 688.003866,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 802537.083,
				["TimeData"] = {
				},
				["frags"] = {
					["石翼石像鬼"] = 2,
					["被毁坏的死尸"] = 1,
					["被撕裂的死尸"] = 1,
					["破碎的死尸"] = 1,
				},
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 41,
					["_ActorTable"] = {
						{
							["flag_original"] = 1352,
							["totalabsorbed"] = 1311.007011,
							["damage_from"] = {
								["大酒鬼"] = true,
								["我瞿李媚"] = true,
								["好羡慕狗"] = true,
								["潇潇"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
								["盘锦吴奇隆"] = 950,
								["大酒鬼"] = 1023,
								["亡者农药"] = 1104,
								["奶过苍井空"] = 635,
								["酒歌没歌了"] = 951,
								["受命于"] = 1097,
								["潇潇"] = 1265,
								["我瞿李媚"] = 1165,
								["吴老二"] = 552,
								["修辞"] = 932,
								["好羡慕狗"] = 305,
								["螺纹钢"] = 1257,
								["习惯被依赖"] = 1113,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 12349.007011,
							["last_event"] = 1590921199,
							["fight_component"] = true,
							["total"] = 12349.007011,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "灬争渡灬",
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 6,
										["b_amt"] = 0,
										["c_dmg"] = 2844,
										["g_amt"] = 0,
										["n_max"] = 428,
										["targets"] = {
											["盘锦吴奇隆"] = 950,
											["大酒鬼"] = 1023,
											["亡者农药"] = 1104,
											["奶过苍井空"] = 635,
											["酒歌没歌了"] = 951,
											["受命于"] = 1097,
											["潇潇"] = 1265,
											["我瞿李媚"] = 1165,
											["吴老二"] = 552,
											["修辞"] = 932,
											["好羡慕狗"] = 305,
											["螺纹钢"] = 1257,
											["习惯被依赖"] = 1113,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9505,
										["n_min"] = 216,
										["g_dmg"] = 0,
										["counter"] = 37,
										["total"] = 12349,
										["c_max"] = 486,
										["id"] = "魔爆术",
										["r_dmg"] = 233,
										["c_min"] = 460,
										["r_amt"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 31,
										["a_dmg"] = 1046,
										["spellschool"] = 64,
									},
									["闪现术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "闪现术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["法术反制"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "法术反制",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 2339.007011,
							["end_time"] = 1590921206,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590921194,
							["serial"] = "Player-4920-01DBA830",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.004621,
							["damage_from"] = {
								["灬争渡灬"] = true,
							},
							["targets"] = {
								["灬争渡灬"] = 1084,
							},
							["pets"] = {
							},
							["damage_taken"] = 1104.004621,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1084.004621,
							["last_event"] = 1590921199,
							["dps_started"] = false,
							["total"] = 1084.004621,
							["delay"] = 0,
							["classe"] = "MAGE",
							["nome"] = "亡者农药",
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 530,
										["targets"] = {
											["灬争渡灬"] = 530,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 530,
										["n_min"] = 530,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 530,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 530,
										["spellschool"] = 16,
									},
									["奥术飞弹"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 369,
										["g_amt"] = 0,
										["n_max"] = 185,
										["targets"] = {
											["灬争渡灬"] = 554,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 185,
										["n_min"] = 185,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 554,
										["c_max"] = 369,
										["id"] = "奥术飞弹",
										["r_dmg"] = 185,
										["c_min"] = 369,
										["r_amt"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 64,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590921206,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1590921195,
							["serial"] = "Player-4920-01DA4323",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00822,
							["damage_from"] = {
								["灬争渡灬"] = true,
							},
							["targets"] = {
								["灬争渡灬"] = 636,
							},
							["pets"] = {
							},
							["damage_taken"] = 1165.00822,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 636.00822,
							["last_event"] = 1590921200,
							["dps_started"] = false,
							["total"] = 636.00822,
							["delay"] = 0,
							["classe"] = "MAGE",
							["nome"] = "我瞿李媚",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 582,
										["targets"] = {
											["灬争渡灬"] = 582,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 582,
										["n_min"] = 582,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 582,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["冰霜新星"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 54,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["灬争渡灬"] = 54,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 54,
										["c_max"] = 54,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 54,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590921206,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1590921198,
							["serial"] = "Player-4920-01DA138E",
							["on_hold"] = false,
						}, -- [3]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002027,
							["damage_from"] = {
								["灬争渡灬"] = true,
							},
							["targets"] = {
								["灬争渡灬"] = 349,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 349.002027,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 349.002027,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1590921206,
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["灬争渡灬"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 349,
										["targets"] = {
											["灬争渡灬"] = 349,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 349,
										["n_min"] = 349,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 349,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1265.002027,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590921199,
							["on_hold"] = false,
							["start_time"] = 1590921199,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire"] = {
							},
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 41,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 856.006481,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["我瞿李媚"] = 856,
							},
							["total"] = 856.006481,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["我瞿李媚"] = true,
							},
							["healing_taken"] = 856.006481,
							["totalover"] = 0.006481,
							["total_without_pet"] = 856.006481,
							["totalover_without_pet"] = 0.006481,
							["totaldenied"] = 0.006481,
							["fight_component"] = true,
							["end_time"] = 1590921206,
							["classe"] = "MAGE",
							["heal_enemy_amt"] = 0,
							["nome"] = "我瞿李媚",
							["targets_absorbs"] = {
								["我瞿李媚"] = 856,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 856,
										["targets_overheal"] = {
										},
										["n_max"] = 304,
										["targets"] = {
											["我瞿李媚"] = 856,
										},
										["n_min"] = 265,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 856,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["我瞿李媚"] = 856,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 856,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["custom"] = 0,
							["last_event"] = 1590921198,
							["on_hold"] = false,
							["start_time"] = 1590921194,
							["serial"] = "Player-4920-01DA138E",
							["delay"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "MAGE",
							["totalover"] = 0.00459,
							["total_without_pet"] = 373.00459,
							["total"] = 373.00459,
							["targets_absorbs"] = {
								["潇潇"] = 373,
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-022A2037",
							["totalabsorb"] = 373.00459,
							["last_hps"] = 0,
							["targets"] = {
								["潇潇"] = 373,
							},
							["totalover_without_pet"] = 0.00459,
							["healing_taken"] = 373.00459,
							["fight_component"] = true,
							["end_time"] = 1590921206,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 373,
										["targets_overheal"] = {
										},
										["n_max"] = 373,
										["targets"] = {
											["潇潇"] = 373,
										},
										["n_min"] = 373,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 373,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 373,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 373,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1590921196,
							["totaldenied"] = 0.00459,
							["start_time"] = 1590921205,
							["delay"] = 1590921196,
							["spec"] = 64,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 241.008912,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["亡者农药"] = 241,
							},
							["total"] = 241.008912,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["亡者农药"] = true,
							},
							["healing_taken"] = 241.008912,
							["totalover"] = 0.008912,
							["total_without_pet"] = 241.008912,
							["totalover_without_pet"] = 0.008912,
							["totaldenied"] = 0.008912,
							["fight_component"] = true,
							["end_time"] = 1590921206,
							["classe"] = "MAGE",
							["heal_enemy_amt"] = 0,
							["nome"] = "亡者农药",
							["targets_absorbs"] = {
								["亡者农药"] = 241,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 241,
										["targets_overheal"] = {
										},
										["n_max"] = 241,
										["targets"] = {
											["亡者农药"] = 241,
										},
										["n_min"] = 241,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 241,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["亡者农药"] = 241,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 241,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["custom"] = 0,
							["last_event"] = 1590921196,
							["on_hold"] = false,
							["start_time"] = 1590921205,
							["serial"] = "Player-4920-01DA4323",
							["delay"] = 1590921196,
						}, -- [3]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 41,
					["_ActorTable"] = {
						{
							["received"] = 395.002709,
							["resource"] = 0.002709,
							["targets"] = {
								["灬争渡灬"] = 395,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["passiveover"] = 0.002709,
							["fight_component"] = true,
							["total"] = 395.002709,
							["nome"] = "灬争渡灬",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 395,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["灬争渡灬"] = 395,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["totalover"] = 0.002709,
							["last_event"] = 1590921198,
							["alternatepower"] = 0.002709,
							["tipo"] = 3,
							["serial"] = "Player-4920-01DBA830",
							["flag_original"] = 66888,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 41,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰锥术",
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 62,
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["骷髅守护者"] = 1,
										},
										["interrompeu_oque"] = {
											["暗影箭"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "耐力",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1590921194,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["暗影箭"] = 1,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 11,
							["buff_uptime_targets"] = {
							},
							["interrupt_targets"] = {
								["骷髅守护者"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["冰锥术"] = 1,
								["奥术飞弹"] = 2,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1590921260,
							["pets"] = {
							},
							["nome"] = "亡者农药",
							["serial"] = "Player-4920-01DA4323",
							["interrupt"] = 1.004217,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["fight_component"] = true,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "我瞿李媚",
							["pets"] = {
							},
							["last_event"] = 1590921206,
							["buff_uptime"] = 52,
							["classe"] = "MAGE",
							["spell_cast"] = {
								["火焰冲击"] = 1,
								["法术反制"] = 1,
								["冰霜新星"] = 1,
								["冰锥术"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1590921194,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "呀啊啊啊啊",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA138E",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1300,
							["fight_component"] = true,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["nome"] = "潇潇",
							["buff_uptime"] = 14,
							["pets"] = {
							},
							["spell_cast"] = {
								["法术反制"] = 1,
								["冰锥术"] = 1,
								["火焰冲击"] = 1,
							},
							["classe"] = "MAGE",
							["last_event"] = 1590921206,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1590921194,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [3]
						{
							["flag_original"] = 66888,
							["classe"] = "UNGROUPPLAYER",
							["fight_component"] = true,
							["nome"] = "灬争渡灬",
							["interrupt_targets"] = {
								["酒歌没歌了"] = 1,
							},
							["interrupt"] = 1.008156,
							["enemy"] = true,
							["pets"] = {
							},
							["last_event"] = 1590921197,
							["spell_cast"] = {
								["魔爆术"] = 3,
								["闪现术"] = 1,
								["法术反制"] = 1,
							},
							["tipo"] = 4,
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["酒歌没歌了"] = 1,
										},
										["interrompeu_oque"] = {
											["次级治疗波"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DBA830",
							["interrompeu_oque"] = {
								["次级治疗波"] = 1,
							},
						}, -- [4]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 41,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 802351.223,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					14417.957026, -- [1]
					1469.983059, -- [2]
					{
						0, -- [1]
						[0] = 395,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 2,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "18:33:27",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "灬争渡灬",
				["TotalElapsedCombatTime"] = 9.6820000000298,
				["CombatEndedAt"] = 802360.905,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["亡者农药"] = 1084.004621,
							["我瞿李媚"] = 636.00822,
							["潇潇"] = 349.002027,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 373.00459,
							["我瞿李媚"] = 856.006481,
							["亡者农药"] = 241.008912,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 802362.843,
				["combat_id"] = 41,
				["combat_counter"] = 66,
				["tempo_start"] = 1590921194,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["totals_grupo"] = {
					2069, -- [1]
					1470, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "18:33:15",
				["start_time"] = 802350.839,
				["contra"] = "灬争渡灬",
				["frags"] = {
					["菠萝小牧"] = 1,
				},
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 39,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005039,
							["damage_from"] = {
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
								["亡者农药"] = 169,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["end_time"] = 1590920417,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 169.005039,
							["delay"] = 1590920404,
							["monster"] = true,
							["total"] = 169.005039,
							["dps_started"] = false,
							["damage_taken"] = 1857.005039,
							["nome"] = "骷髅守护者",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 169,
										["targets"] = {
											["亡者农药"] = 169,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 169,
										["n_min"] = 169,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 169,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590920404,
							["on_hold"] = false,
							["start_time"] = 1590920416,
							["serial"] = "Creature-0-4887-329-16186-10390-000F53827C",
							["fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 66834,
							["totalabsorbed"] = 0.007101,
							["damage_from"] = {
								["骷髅狂战士"] = true,
								["骷髅守护者"] = true,
							},
							["targets"] = {
								["骷髅狂战士"] = 57,
								["被撕裂的死尸"] = 10697,
								["恶疫食尸鬼"] = 5172,
								["缝补憎恶"] = 1071,
								["被毁坏的死尸"] = 10412,
								["骷髅守护者"] = 975,
							},
							["pets"] = {
							},
							["damage_taken"] = 482.007101,
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 1071,
							},
							["total_without_pet"] = 28384.007101,
							["tipo"] = 1,
							["dps_started"] = false,
							["total"] = 28384.007101,
							["delay"] = 1590920405,
							["friendlyfire_total"] = 0,
							["nome"] = "亡者农药",
							["spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 62,
										["g_amt"] = 0,
										["n_max"] = 31,
										["targets"] = {
											["骷髅狂战士"] = 57,
											["被毁坏的死尸"] = 90,
											["骷髅守护者"] = 91,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 176,
										["n_min"] = 28,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 238,
										["c_max"] = 62,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 62,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 179,
										["targets"] = {
											["被撕裂的死尸"] = 10697,
											["恶疫食尸鬼"] = 5172,
											["缝补憎恶"] = 1071,
											["被毁坏的死尸"] = 10322,
											["骷髅守护者"] = 884,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 28146,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 158,
										["total"] = 28146,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 158,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590921062,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590921061,
							["on_hold"] = false,
							["start_time"] = 1590920416,
							["serial"] = "Player-4920-01DA4323",
							["friendlyfire"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 313.007191,
							["damage_from"] = {
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
								["亡者农药"] = 313,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["end_time"] = 1590920417,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 313.007191,
							["delay"] = 1590920405,
							["monster"] = true,
							["total"] = 313.007191,
							["dps_started"] = false,
							["damage_taken"] = 236.007191,
							["nome"] = "骷髅狂战士",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 160,
										["targets"] = {
											["亡者农药"] = 313,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 313,
										["n_min"] = 153,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 313,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590920405,
							["on_hold"] = false,
							["start_time"] = 1590920416,
							["serial"] = "Creature-0-4887-329-16186-10391-001053827C",
							["fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008893,
							["damage_from"] = {
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 1590920405,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008893,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.008893,
							["classe"] = "UNKNOW",
							["damage_taken"] = 19240.008893,
							["nome"] = "被毁坏的死尸",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["亡者农药"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["dps_started"] = false,
							["last_dps"] = 0,
							["end_time"] = 1590920417,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590920417,
							["serial"] = "Creature-0-4887-329-16186-10381-000A53827C",
							["fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001724,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅狂战士"] = 179,
								["被撕裂的死尸"] = 9526,
								["恶疫食尸鬼"] = 4151,
								["缝补憎恶"] = 864,
								["被毁坏的死尸"] = 8828,
								["骷髅守护者"] = 882,
							},
							["pets"] = {
							},
							["damage_taken"] = 0.001724,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 864,
							},
							["total_without_pet"] = 24430.001724,
							["last_event"] = 1590921062,
							["dps_started"] = false,
							["total"] = 24430.001724,
							["delay"] = 0,
							["classe"] = "MAGE",
							["nome"] = "我瞿李媚",
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 180,
										["targets"] = {
											["骷髅狂战士"] = 179,
											["被撕裂的死尸"] = 9526,
											["恶疫食尸鬼"] = 4151,
											["缝补憎恶"] = 864,
											["被毁坏的死尸"] = 8828,
											["骷髅守护者"] = 882,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 24430,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 141,
										["total"] = 24430,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 141,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1590921062,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1590921051,
							["serial"] = "Player-4920-01DA138E",
							["on_hold"] = false,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 39,
					["_ActorTable"] = {
						{
							["flag_original"] = 66834,
							["totalabsorb"] = 482.003112,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["亡者农药"] = 482,
							},
							["total"] = 482.003112,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["亡者农药"] = true,
							},
							["healing_taken"] = 482.003112,
							["totalover"] = 0.003112,
							["total_without_pet"] = 482.003112,
							["totalover_without_pet"] = 0.003112,
							["totaldenied"] = 0.003112,
							["fight_component"] = true,
							["end_time"] = 1590920417,
							["classe"] = "MAGE",
							["heal_enemy_amt"] = 0,
							["nome"] = "亡者农药",
							["targets_absorbs"] = {
								["亡者农药"] = 482,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 482,
										["targets_overheal"] = {
										},
										["n_max"] = 169,
										["targets"] = {
											["亡者农药"] = 482,
										},
										["n_min"] = 153,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 482,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["亡者农药"] = 482,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 482,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["custom"] = 0,
							["last_event"] = 1590920405,
							["on_hold"] = false,
							["start_time"] = 1590920415,
							["serial"] = "Player-4920-01DA4323",
							["delay"] = 1590920405,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 39,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 39,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 7,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 7,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 0,
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["骷髅守护者"] = 1,
										},
										["interrompeu_oque"] = {
											["暗影箭"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["activedamt"] = 1,
										["id"] = "寒冰护体",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["activedamt"] = 1,
										["id"] = "魔法抑制",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["activedamt"] = 1,
										["id"] = "护甲",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["防护冰霜结界"] = {
										["activedamt"] = 1,
										["id"] = "防护冰霜结界",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["闪现术"] = {
										["activedamt"] = 1,
										["id"] = "闪现术",
										["targets"] = {
										},
										["actived_at"] = 1590920406,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["activedamt"] = 1,
										["id"] = "耐力",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["activedamt"] = 1,
										["id"] = "魔甲术",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["暗影箭"] = 1,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 12,
							["buff_uptime_targets"] = {
							},
							["interrupt_targets"] = {
								["骷髅守护者"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["闪现术"] = 1,
								["冰霜新星"] = 1,
								["法术反制"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1590920406,
							["pets"] = {
							},
							["nome"] = "亡者农药",
							["serial"] = "Player-4920-01DA4323",
							["interrupt"] = 1.006346,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["nome"] = "我瞿李媚",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["last_event"] = 1590920404,
							["tipo"] = 4,
							["buff_uptime"] = 0,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["奥术光辉"] = {
										["activedamt"] = 1,
										["id"] = "奥术光辉",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["activedamt"] = 1,
										["id"] = "魔甲术",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔法抑制"] = {
										["activedamt"] = 1,
										["id"] = "魔法抑制",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["呀啊啊啊啊"] = {
										["activedamt"] = 1,
										["id"] = "呀啊啊啊啊",
										["targets"] = {
										},
										["actived_at"] = 1590920404,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DA138E",
							["buff_uptime_targets"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 1300,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["tipo"] = 4,
							["buff_uptime"] = 1,
							["buff_uptime_targets"] = {
							},
							["spell_cast"] = {
								["闪现术"] = 1,
							},
							["classe"] = "MAGE",
							["pets"] = {
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["洛丹伦的回响"] = {
										["activedamt"] = 4,
										["id"] = "洛丹伦的回响",
										["targets"] = {
										},
										["actived_at"] = 1590920416,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 4,
									},
									["闪现术"] = {
										["activedamt"] = 1,
										["id"] = "闪现术",
										["targets"] = {
										},
										["actived_at"] = 1590920411,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["无荣誉目标"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "无荣誉目标",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["last_event"] = 1590920417,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 39,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["CombatStartedAt"] = 801571.326,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					53295.986955, -- [1]
					482, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					52814, -- [1]
					482, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "18:20:17",
				["cleu_timeline"] = {
				},
				["enemy"] = "骷髅守护者",
				["TotalElapsedCombatTime"] = 2.11600000003818,
				["CombatEndedAt"] = 801573.442,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "18:20:05",
				["end_time"] = 801573.596,
				["combat_id"] = 39,
				["resincked"] = true,
				["player_last_events"] = {
				},
				["tempo_start"] = 1590920404,
				["spells_cast_timeline"] = {
				},
				["contra"] = "骷髅守护者",
				["combat_counter"] = 63,
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["亡者农药"] = 374.015592,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["亡者农药"] = 482.003112,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 801560.984,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 29,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 886.008943,
							["damage_from"] = {
								["我瞿李媚"] = true,
							},
							["targets"] = {
								["我瞿李媚"] = 1480,
								["亡者农药"] = 357,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1837.008943,
							["delay"] = 1590916598,
							["monster"] = true,
							["total"] = 1837.008943,
							["end_time"] = 1590916616,
							["damage_taken"] = 1791.008943,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["奥术箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 350,
										["targets"] = {
											["我瞿李媚"] = 350,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 350,
										["n_min"] = 350,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 350,
										["c_max"] = 0,
										["id"] = "奥术箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["n_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["RESIST"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 311,
										["targets"] = {
											["我瞿李媚"] = 1130,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1130,
										["n_min"] = 259,
										["g_dmg"] = 0,
										["counter"] = 6,
										["c_min"] = 0,
										["total"] = 1130,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["n_amt"] = 4,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 5,
										["a_dmg"] = 283,
										["RESIST"] = 1,
										["spellschool"] = 16,
										["REFLECT"] = 1,
									},
									["冰霜震击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 357,
										["targets"] = {
											["亡者农药"] = 357,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 357,
										["n_min"] = 357,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 357,
										["c_max"] = 0,
										["id"] = "冰霜震击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 1,
										["a_dmg"] = 357,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "斯库尔",
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590916598,
							["on_hold"] = false,
							["start_time"] = 1590916596,
							["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002365,
							["damage_from"] = {
								["斯库尔"] = true,
								["缝补憎恶"] = true,
							},
							["targets"] = {
								["被撕裂的死尸"] = 3765,
								["斯库尔"] = 1791,
								["缝补憎恶"] = 4419,
								["被毁坏的死尸"] = 22407,
								["幽灵市民"] = 43,
								["恶疫食尸鬼"] = 6271,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["nome"] = "我瞿李媚",
							["classe"] = "MAGE",
							["raid_targets"] = {
								[128] = 3046,
								[8] = 43,
							},
							["total_without_pet"] = 38696.002365,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1590917022,
							["friendlyfire"] = {
							},
							["damage_taken"] = 2286.002365,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 180,
										["targets"] = {
											["被撕裂的死尸"] = 3765,
											["斯库尔"] = 1202,
											["缝补憎恶"] = 2283,
											["被毁坏的死尸"] = 22407,
											["幽灵市民"] = 43,
											["恶疫食尸鬼"] = 6271,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 35971,
										["n_min"] = 43,
										["g_dmg"] = 0,
										["counter"] = 202,
										["total"] = 35971,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 43,
										["c_min"] = 0,
										["r_amt"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 202,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 765,
										["targets"] = {
											["缝补憎恶"] = 1500,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1500,
										["n_min"] = 735,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1500,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 607,
										["targets"] = {
											["斯库尔"] = 589,
											["缝补憎恶"] = 607,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1196,
										["n_min"] = 589,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1196,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29,
										["targets"] = {
											["缝补憎恶"] = 29,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 29,
										["n_min"] = 29,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 29,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590917019,
							["on_hold"] = false,
							["start_time"] = 1590916583,
							["serial"] = "Player-4920-01DA138E",
							["total"] = 38696.002365,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002875,
							["damage_from"] = {
								["缝补憎恶"] = true,
								["亡者农药"] = true,
								["我瞿李媚"] = true,
							},
							["targets"] = {
								["缝补憎恶"] = 4,
								["亡者农药"] = 950,
								["我瞿李媚"] = 806,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1760.002875,
							["delay"] = 1590916590,
							["monster"] = true,
							["total"] = 1760.002875,
							["end_time"] = 1590916616,
							["damage_taken"] = 7683.002875,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["痛击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["缝补憎恶"] = 4,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = "痛击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["击退"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 950,
										["targets"] = {
											["我瞿李媚"] = 806,
											["亡者农药"] = 950,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1756,
										["n_min"] = 806,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1756,
										["c_max"] = 0,
										["id"] = "击退",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 1,
										["a_dmg"] = 806,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "缝补憎恶",
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1590916610,
							["on_hold"] = false,
							["start_time"] = 1590916609,
							["serial"] = "Creature-0-4887-329-8197-10414-0000D3744B",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007934,
							["damage_from"] = {
								["斯库尔"] = true,
								["缝补憎恶"] = true,
							},
							["targets"] = {
								["被撕裂的死尸"] = 1030,
								["恶疫食尸鬼"] = 2574,
								["缝补憎恶"] = 3260,
								["被毁坏的死尸"] = 8756,
								["幽灵市民"] = 1191,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["nome"] = "亡者农药",
							["classe"] = "MAGE",
							["raid_targets"] = {
								[8] = 1191,
								[128] = 515,
							},
							["total_without_pet"] = 16811.007934,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 16811.007934,
							["on_hold"] = false,
							["damage_taken"] = 1307.007934,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 31,
										["targets"] = {
											["缝补憎恶"] = 60,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 60,
										["n_min"] = 29,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 60,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 452,
										["targets"] = {
											["幽灵市民"] = 452,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 452,
										["n_min"] = 452,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 452,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 452,
										["c_min"] = 0,
										["r_amt"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1527,
										["g_amt"] = 0,
										["n_max"] = 739,
										["targets"] = {
											["缝补憎恶"] = 2263,
											["幽灵市民"] = 739,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1475,
										["n_min"] = 736,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 3002,
										["c_max"] = 1527,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["c_min"] = 1527,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 95,
										["targets"] = {
											["缝补憎恶"] = 95,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 95,
										["n_min"] = 95,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 95,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 172,
										["targets"] = {
											["缝补憎恶"] = 842,
											["被毁坏的死尸"] = 8756,
											["恶疫食尸鬼"] = 2574,
											["被撕裂的死尸"] = 1030,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 13202,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 83,
										["total"] = 13202,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 83,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1590917022,
							["friendlyfire"] = {
							},
							["start_time"] = 1590916587,
							["serial"] = "Player-4920-01DA4323",
							["end_time"] = 1590917022,
						}, -- [4]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.0089,
							["damage_from"] = {
								["我瞿李媚"] = true,
								["亡者农药"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.0089,
							["last_event"] = 0,
							["dps_started"] = false,
							["total"] = 0.0089,
							["delay"] = 0,
							["nome"] = "幽灵市民",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1234.0089,
							["end_time"] = 1590916616,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1590916616,
							["serial"] = "Creature-0-4887-329-8197-10385-00005375B3",
							["classe"] = "UNKNOW",
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 29,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 132.002335,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["亡者农药"] = 1248,
							},
							["delay"] = 1590916593,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["亡者农药"] = true,
							},
							["healing_taken"] = 1248.002335,
							["totalover"] = 0.002335,
							["total_without_pet"] = 1248.002335,
							["totalover_without_pet"] = 0.002335,
							["totaldenied"] = 0.002335,
							["classe"] = "MAGE",
							["total"] = 1248.002335,
							["heal_enemy_amt"] = 0,
							["end_time"] = 1590916616,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 132,
										["targets_overheal"] = {
										},
										["n_max"] = 132,
										["targets"] = {
											["亡者农药"] = 132,
										},
										["n_min"] = 132,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 132,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["亡者农药"] = 132,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 132,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
									["治疗药水"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1116,
										["targets"] = {
											["亡者农药"] = 1116,
										},
										["n_min"] = 1116,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 1116,
										["c_max"] = 0,
										["id"] = "治疗药水",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 1116,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["nome"] = "亡者农药",
							["custom"] = 0,
							["last_event"] = 1590916593,
							["on_hold"] = false,
							["start_time"] = 1590916608,
							["serial"] = "Player-4920-01DA4323",
							["targets_absorbs"] = {
								["亡者农药"] = 132,
							},
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 1531.006642,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["我瞿李媚"] = 1531,
							},
							["delay"] = 1590916598,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["我瞿李媚"] = true,
							},
							["healing_taken"] = 1531.006642,
							["totalover"] = 0.006642,
							["total_without_pet"] = 1531.006642,
							["totalover_without_pet"] = 0.006642,
							["totaldenied"] = 0.006642,
							["classe"] = "MAGE",
							["total"] = 1531.006642,
							["heal_enemy_amt"] = 0,
							["end_time"] = 1590916616,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["防护冰霜结界"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 675,
										["targets_overheal"] = {
										},
										["n_max"] = 277,
										["targets"] = {
											["我瞿李媚"] = 675,
										},
										["n_min"] = 139,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 675,
										["c_max"] = 0,
										["id"] = "防护冰霜结界",
										["targets_absorbs"] = {
											["我瞿李媚"] = 675,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 675,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 856,
										["targets_overheal"] = {
										},
										["n_max"] = 506,
										["targets"] = {
											["我瞿李媚"] = 856,
										},
										["n_min"] = 350,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 856,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["我瞿李媚"] = 856,
										},
										["c_curado"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["c_min"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 856,
										["m_healed"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["nome"] = "我瞿李媚",
							["custom"] = 0,
							["last_event"] = 1590916610,
							["on_hold"] = false,
							["start_time"] = 1590916598,
							["serial"] = "Player-4920-01DA138E",
							["targets_absorbs"] = {
								["我瞿李媚"] = 1531,
							},
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 29,
					["_ActorTable"] = {
						{
							["received"] = 1902.008835,
							["resource"] = 0.008835,
							["targets"] = {
								["我瞿李媚"] = 1902,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.008835,
							["total"] = 1902.008835,
							["nome"] = "我瞿李媚",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 716,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["我瞿李媚"] = 716,
										},
										["counter"] = 2,
									},
									["补充法力"] = {
										["total"] = 1186,
										["id"] = "补充法力",
										["totalover"] = 0,
										["targets"] = {
											["我瞿李媚"] = 1186,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.008835,
							["flag_original"] = 1298,
							["last_event"] = 1590916591,
							["tipo"] = 3,
							["alternatepower"] = 0.008835,
							["serial"] = "Player-4920-01DA138E",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 29,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "寒冰箭",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 216,
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["斯库尔"] = 1,
										},
										["interrompeu_oque"] = {
											["寒冰箭"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 31,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["魔法抑制"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔法抑制",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["护甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "护甲",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "耐力",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["寒冰箭"] = 1,
							},
							["debuff_uptime"] = 23,
							["tipo"] = 4,
							["boss_fight_component"] = true,
							["interrupt_targets"] = {
								["斯库尔"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["火焰冲击"] = 1,
								["法术反制"] = 1,
								["冰霜新星"] = 2,
								["寒冰箭"] = 3,
								["射击"] = 1,
								["治疗药水"] = 1,
								["暴风雪"] = 1,
							},
							["interrupt"] = 1.008816,
							["pets"] = {
							},
							["last_event"] = 1590916616,
							["nome"] = "亡者农药",
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01DA4323",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "暴风雪",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
									["冰霜新星"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜新星",
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 143,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪现术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪现术",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["防护冰霜结界"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "防护冰霜结界",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["耐力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "耐力",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 14,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["补充法力"] = 1,
								["冰霜新星"] = 1,
								["防护冰霜结界"] = 1,
								["寒冰箭"] = 2,
								["暴风雪"] = 1,
								["火焰冲击"] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1590916616,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01DA138E",
							["nome"] = "我瞿李媚",
						}, -- [2]
						{
							["flag_original"] = 1300,
							["nome"] = "潇潇",
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 68,
							["pets"] = {
							},
							["last_event"] = 1590916616,
							["classe"] = "MAGE",
							["spell_cast"] = {
								["寒冰护体"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "寒冰护体",
										["uptime"] = 31,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 17,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["我瞿李媚"] = {
									["uptime"] = 17,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = -1,
									["actived"] = true,
									["actived_at"] = 1590916596,
								},
							},
							["last_event"] = 1590916596,
							["tipo"] = 4,
							["damage_twin"] = "斯库尔",
							["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
							["damage_spellid"] = 0,
							["nome"] = "寒冰箭",
						}, -- [4]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "斯库尔",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["奥术箭"] = 2,
								["寒冰箭"] = 5,
								["冰霜震击"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 8,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["亡者农药"] = {
									["uptime"] = 8,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1590916594,
							["tipo"] = 4,
							["damage_twin"] = "斯库尔",
							["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
							["damage_spellid"] = "冰霜震击",
							["nome"] = "冰霜震击",
						}, -- [6]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "缝补憎恶",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["击退"] = 2,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4887-329-8197-10414-0000D3744B",
							["boss_fight_component"] = true,
						}, -- [7]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 29,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["我瞿李媚"] = true,
					["亡者农药"] = true,
					["偸心戦"] = true,
					["潇潇"] = true,
					["Huhala"] = true,
					["沉默之下"] = true,
				},
				["overall_added"] = true,
				["cleu_timeline"] = {
				},
				["alternate_power"] = {
				},
				["tempo_start"] = 1590916579,
				["enemy"] = "斯库尔",
				["cleu_events"] = {
					["n"] = 1,
				},
				["last_events_tables"] = {
				},
				["totals"] = {
					59103.988194, -- [1]
					2779, -- [2]
					{
						0, -- [1]
						[0] = 1902,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					55507, -- [1]
					2779, -- [2]
					{
						0, -- [1]
						[0] = 1902,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["我瞿李媚"] = 4998.002365,
							["亡者农药"] = 3936.007934,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["我瞿李媚"] = 1531.006642,
							["亡者农药"] = 1248.002335,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "17:16:19",
				["end_time"] = 797772.32,
				["combat_counter"] = 52,
				["instance_type"] = "party",
				["player_last_events"] = {
				},
				["TimeData"] = {
				},
				["hasSaved"] = true,
				["frags"] = {
					["斯库尔"] = 1,
					["缝补憎恶"] = 1,
				},
				["data_fim"] = "17:16:56",
				["combat_id"] = 29,
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 797735.319,
				["contra"] = "斯库尔",
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "斯坦索姆",
					["encounter"] = "斯库尔",
					["mapid"] = 329,
					["try_number"] = 1,
					["name"] = "斯库尔",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
			}, -- [10]
			{
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004257,
							["damage_from"] = {
							},
							["targets"] = {
								["专诸刺秦"] = 638,
								["潇潇"] = 78,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["monster"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 716.004257,
							["serial"] = "Creature-0-4514-1-262-11686-00001DAF8F",
							["fight_component"] = true,
							["end_time"] = 1590909015,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "鬼魅掠夺者",
							["spells"] = {
								["_ActorTable"] = {
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 84,
										["targets"] = {
											["专诸刺秦"] = 638,
											["潇潇"] = 78,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 716,
										["n_min"] = 61,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 716,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 7,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["dps_started"] = false,
							["custom"] = 0,
							["last_event"] = 1587393134,
							["damage_taken"] = 0.004257,
							["start_time"] = 1590908993,
							["delay"] = 1587393134,
							["total"] = 716.004257,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001038,
							["damage_from"] = {
								["鬼魅掠夺者"] = true,
								["鬼魅袭击者"] = true,
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001038,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.001038,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1587393127,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 383.001038,
							["start_time"] = 1587393127,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 274.001093,
							["damage_from"] = {
							},
							["targets"] = {
								["潇潇"] = 155,
								["壹亿肆"] = 119,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["dps_started"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 274.001093,
							["serial"] = "Creature-0-4514-1-262-11687-00001DAF7F",
							["monster"] = true,
							["total"] = 274.001093,
							["damage_taken"] = 0.001093,
							["on_hold"] = false,
							["nome"] = "鬼魅袭击者",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 108,
										["targets"] = {
											["潇潇"] = 155,
											["壹亿肆"] = 119,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 274,
										["n_min"] = 25,
										["g_dmg"] = 0,
										["counter"] = 8,
										["MISS"] = 2,
										["total"] = 274,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1587393127,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1587393108,
							["friendlyfire"] = {
							},
							["start_time"] = 1587393120,
							["delay"] = 1587393108,
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = -2147483648,
							["totalabsorbed"] = 0.00194,
							["damage_from"] = {
							},
							["targets"] = {
								["壹亿肆"] = 89,
								["上帝灬之手"] = 222,
								["潇潇"] = 150,
								["怀恋青春"] = 708,
								["流动人口"] = 389,
								["后门植入"] = 480,
								["专诸刺秦"] = 70,
								["北风微凉"] = 279,
								["正月晴天"] = 45,
								["越跑越快丶"] = 245,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2677.00194,
							["last_dps"] = 0,
							["dps_started"] = false,
							["end_time"] = 1590909015,
							["serial"] = "",
							["fight_component"] = true,
							["nome"] = "环境伤害 (高处坠落)",
							["spells"] = {
								["_ActorTable"] = {
									["Falling"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 554,
										["targets"] = {
											["壹亿肆"] = 89,
											["上帝灬之手"] = 222,
											["潇潇"] = 150,
											["怀恋青春"] = 708,
											["流动人口"] = 389,
											["后门植入"] = 480,
											["专诸刺秦"] = 70,
											["北风微凉"] = 279,
											["正月晴天"] = 45,
											["越跑越快丶"] = 245,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2677,
										["n_min"] = 5,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 2677,
										["c_max"] = 0,
										["id"] = "Falling",
										["r_dmg"] = 0,
										["spellschool"] = 3,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 14,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 0.00194,
							["custom"] = 0,
							["last_event"] = 1590908837,
							["friendlyfire"] = {
							},
							["start_time"] = 1587393448,
							["delay"] = 1590908837,
							["total"] = 2677.00194,
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 155.008404,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["潇潇"] = 155,
							},
							["delay"] = 1587393108,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.008404,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["healing_taken"] = 155.008404,
							["totalover"] = 0.008404,
							["total_without_pet"] = 155.008404,
							["iniciar_hps"] = false,
							["start_time"] = 1587393125,
							["fight_component"] = true,
							["end_time"] = 1587393127,
							["classe"] = "MAGE",
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 155,
							},
							["grupo"] = true,
							["total"] = 155.008404,
							["heal_enemy"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 155,
										["targets_overheal"] = {
										},
										["n_max"] = 108,
										["targets"] = {
											["潇潇"] = 155,
										},
										["n_min"] = 47,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 155,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 155,
										},
										["c_curado"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 155,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["custom"] = 0,
							["last_event"] = 1587393108,
							["on_hold"] = false,
							["totaldenied"] = 0.008404,
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "潇潇",
							["spell_cast"] = {
								["奥术智慧"] = 1,
								["冰甲术"] = 1,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime"] = 60,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 30,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 14,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = "冰甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["last_event"] = 1587393127,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "鬼魅掠夺者",
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["射击"] = 7,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4514-1-262-11686-00001DAF75",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["就是个厨子"] = true,
					["潇潇"] = true,
					["鲁总"] = true,
					["喔愺"] = true,
				},
				["CombatStartedAt"] = 354907.568,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					3666.9006, -- [1]
					154.994948, -- [2]
					{
						0, -- [1]
						[0] = -0.0010480000000257,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["潇潇"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							83, -- [3]
							1590908817.765, -- [4]
							1887, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							5, -- [3]
							1590908820.55, -- [4]
							1819, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 3,
					},
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:32:08",
				["cleu_timeline"] = {
				},
				["enemy"] = "鬼魅掠夺者",
				["TotalElapsedCombatTime"] = 1.82199999998556,
				["CombatEndedAt"] = 354909.39,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 155.008404,
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 0.001038,
						}, -- [1]
					},
				},
				["end_time"] = 354864.386,
				["combat_id"] = 10,
				["combat_counter"] = 30,
				["tempo_start"] = 1587393097,
				["frags"] = {
				},
				["spells_cast_timeline"] = {
				},
				["contra"] = "鬼魅掠夺者",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					0, -- [1]
					155, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 354834.377,
				["TimeData"] = {
				},
				["data_inicio"] = "22:31:38",
			}, -- [11]
			{
				{
					["tipo"] = 2,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 63.00166,
							["damage_from"] = {
							},
							["targets"] = {
								["来瓶老雪"] = 1100,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["last_event"] = 1587391254,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1100.00166,
							["serial"] = "Player-4920-022A2037",
							["dps_started"] = false,
							["total"] = 1100.00166,
							["spec"] = 64,
							["on_hold"] = false,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 219,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["来瓶老雪"] = 219,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 219,
										["c_max"] = 219,
										["id"] = "魔爆术",
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["a_dmg"] = 219,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 219,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 1,
										["r_amt"] = 0,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 63,
										["targets"] = {
											["来瓶老雪"] = 63,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 63,
										["n_min"] = 63,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 63,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 397,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["来瓶老雪"] = 397,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 397,
										["c_max"] = 397,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 397,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["冰锥术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 421,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["来瓶老雪"] = 421,
											["田昊眼成小"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 421,
										["c_max"] = 421,
										["spellschool"] = 16,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["a_dmg"] = 421,
										["RESIST"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["c_min"] = 421,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.00166,
							["start_time"] = 1587391244,
							["delay"] = 0,
							["end_time"] = 1587391260,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.008338,
							["damage_from"] = {
								["小恶魔提利昂"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008338,
							["dps_started"] = false,
							["fight_component"] = true,
							["total"] = 0.008338,
							["serial"] = "Player-4920-0219F0FF",
							["damage_taken"] = 2001.008338,
							["nome"] = "来瓶老雪",
							["spells"] = {
								["_ActorTable"] = {
									["真言术：盾"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：盾",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1587391260,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1587391260,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 9,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 9,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["ress_targets"] = {
								["无情萨满"] = 1,
							},
							["buff_uptime"] = 16,
							["classe"] = "SHAMAN",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = "无荣誉目标",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["ress"] = 1.00523,
							["buff_uptime_targets"] = {
							},
							["spec"] = 263,
							["grupo"] = true,
							["spell_cast"] = {
								["先祖之魂"] = 1,
							},
							["ress_spells"] = {
								["_ActorTable"] = {
									[0] = {
										["id"] = 0,
										["ress"] = 1,
										["targets"] = {
											["无情萨满"] = 1,
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["last_event"] = 1587391260,
							["nome"] = "鲁总",
							["pets"] = {
							},
							["serial"] = "Player-4920-022E7DE4",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["activedamt"] = -1,
										["id"] = "冰锥术",
										["targets"] = {
										},
										["actived_at"] = 1587391249,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰霜新星"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 2,
										["id"] = "冰霜新星",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = "冰甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 2,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["魔爆术"] = 2,
								["冰锥术"] = 1,
								["冰霜新星"] = 1,
								["火焰冲击"] = 1,
							},
							["buff_uptime"] = 48,
							["last_event"] = 1587391260,
							["nome"] = "潇潇",
							["tipo"] = 4,
							["serial"] = "Player-4920-022A2037",
							["debuff_uptime_targets"] = {
							},
						}, -- [2]
						{
							["flag_original"] = 66888,
							["spell_cast"] = {
								["真言术：盾"] = 1,
							},
							["nome"] = "来瓶老雪",
							["enemy"] = true,
							["pets"] = {
							},
							["fight_component"] = true,
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Player-4920-0219F0FF",
							["classe"] = "UNGROUPPLAYER",
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 9,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["就是个厨子"] = true,
					["鲁总"] = true,
					["潇潇"] = true,
					["喔愺"] = true,
					["无情萨满"] = true,
				},
				["CombatStartedAt"] = 354833.977,
				["tempo_start"] = 1587391244,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 29,
				["totals"] = {
					1099.950692, -- [1]
					-0.005907, -- [2]
					{
						0, -- [1]
						[0] = -0.00322099999999637,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 1,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					1100, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 1,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:01:00",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "来瓶老雪",
				["TotalElapsedCombatTime"] = 3.93400000000838,
				["CombatEndedAt"] = 353006.928,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 1100.00166,
						}, -- [1]
					},
				},
				["end_time"] = 352997.038,
				["combat_id"] = 9,
				["frags"] = {
					["来瓶老雪"] = 1,
					["田昊眼成小"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["contra"] = "来瓶老雪",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 352981.027,
				["TimeData"] = {
				},
				["data_inicio"] = "22:00:44",
			}, -- [12]
			{
				{
					["tipo"] = 2,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["flag_original"] = 1352,
							["totalabsorbed"] = 518.004962,
							["damage_from"] = {
								["安东尼达斯丶"] = true,
							},
							["targets"] = {
								["全部一起来吧"] = 845,
								["潇潇"] = 539,
								["安东尼达斯丶"] = 1208,
								["潜行哲"] = 533,
								["黄百万"] = 826,
								["无情萨满"] = 667,
								["菠蘿"] = 752,
								["弟中弟志"] = 267,
								["不做痴情种"] = 518,
								["小懋懋"] = 267,
								["喔愺"] = 823,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["last_event"] = 1587391197,
							["classe"] = "UNGROUPPLAYER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7245.004962,
							["dps_started"] = false,
							["fight_component"] = true,
							["end_time"] = 1587391205,
							["serial"] = "Player-4920-0203EB0D",
							["friendlyfire_total"] = 0,
							["nome"] = "闪闪光头",
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1194,
										["g_amt"] = 0,
										["n_max"] = 282,
										["targets"] = {
											["全部一起来吧"] = 845,
											["潇潇"] = 539,
											["安东尼达斯丶"] = 1208,
											["潜行哲"] = 533,
											["黄百万"] = 826,
											["无情萨满"] = 667,
											["菠蘿"] = 752,
											["弟中弟志"] = 267,
											["不做痴情种"] = 518,
											["小懋懋"] = 267,
											["喔愺"] = 823,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 6051,
										["n_min"] = 196,
										["g_dmg"] = 0,
										["counter"] = 26,
										["total"] = 7245,
										["c_max"] = 408,
										["id"] = "魔爆术",
										["r_dmg"] = 196,
										["spellschool"] = 64,
										["a_dmg"] = 408,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 391,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 23,
										["a_amt"] = 1,
										["r_amt"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1335.004962,
							["start_time"] = 1587391193,
							["delay"] = 0,
							["total"] = 7245.004962,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008528,
							["damage_from"] = {
								["闪闪光头"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008528,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1587391205,
							["serial"] = "Player-4920-0231F4BA",
							["total"] = 0.008528,
							["nome"] = "喔愺",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 823.008528,
							["start_time"] = 1587391205,
							["delay"] = 0,
							["classe"] = "ROGUE",
						}, -- [2]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003616,
							["damage_from"] = {
								["闪闪光头"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["total"] = 0.003616,
							["last_event"] = 0,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003616,
							["serial"] = "Player-4920-022A2037",
							["dps_started"] = false,
							["end_time"] = 1587391205,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["nome"] = "潇潇",
							["spec"] = 64,
							["grupo"] = true,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 539.003616,
							["start_time"] = 1587391205,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006744,
							["damage_from"] = {
								["闪闪光头"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006744,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1587391205,
							["serial"] = "Player-4920-01DAB206",
							["total"] = 0.006744,
							["nome"] = "无情萨满",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 667.006744,
							["start_time"] = 1587391205,
							["delay"] = 0,
							["classe"] = "SHAMAN",
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 8,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["received"] = 354.005221,
							["resource"] = 0.005221,
							["targets"] = {
								["闪闪光头"] = 354,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["passiveover"] = 0.005221,
							["fight_component"] = true,
							["total"] = 354.005221,
							["nome"] = "闪闪光头",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 354,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["闪闪光头"] = 354,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["flag_original"] = 1352,
							["last_event"] = 1587391198,
							["alternatepower"] = 0.005221,
							["tipo"] = 3,
							["serial"] = "Player-4920-0203EB0D",
							["totalover"] = 0.005221,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 8,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["buff_uptime"] = 0,
							["nome"] = "就是个厨子",
							["pets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1587391193,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["activedamt"] = 1,
										["id"] = "魔法抑制",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["activedamt"] = 1,
										["id"] = "魔甲术",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["activedamt"] = 1,
										["id"] = "奥术智慧",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D128EF",
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "喔愺",
							["spell_cast"] = {
								["消失"] = 1,
							},
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["last_event"] = 1587391197,
							["buff_uptime"] = 0,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["actived_at"] = 1587391197,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-0231F4BA",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["nome"] = "无情萨满",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "SHAMAN",
							["buff_uptime"] = 12,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = "无荣誉目标",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DAB206",
							["last_event"] = 1587391205,
						}, -- [3]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["last_event"] = 1587391205,
							["pets"] = {
							},
							["nome"] = "潇潇",
							["buff_uptime"] = 24,
							["tipo"] = 4,
							["spell_cast"] = {
								["火焰冲击"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = "冰甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["classe"] = "MAGE",
						}, -- [4]
						{
							["flag_original"] = 1352,
							["spell_cast"] = {
								["魔爆术"] = 3,
							},
							["nome"] = "闪闪光头",
							["enemy"] = true,
							["pets"] = {
							},
							["fight_component"] = true,
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Player-4920-0203EB0D",
							["classe"] = "UNGROUPPLAYER",
						}, -- [5]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 8,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["就是个厨子"] = true,
					["鲁总"] = true,
					["潇潇"] = true,
					["喔愺"] = true,
					["无情萨满"] = true,
				},
				["CombatStartedAt"] = 352981.027,
				["tempo_start"] = 1587391193,
				["last_events_tables"] = {
					{
						{
							{
								true, -- [1]
								"魔爆术", -- [2]
								272, -- [3]
								1587391193.911, -- [4]
								318, -- [5]
								"闪闪光头", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [1]
							{
								true, -- [1]
								"魔爆术", -- [2]
								395, -- [3]
								1587391195.112, -- [4]
								46, -- [5]
								"闪闪光头", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								349, -- [10]
							}, -- [2]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"无情萨满", -- [6]
							}, -- [3]
						}, -- [1]
						1587391195.578, -- [2]
						"无情萨满", -- [3]
						"SHAMAN", -- [4]
						813, -- [5]
						"0m 1s", -- [6]
						["dead_at"] = 1.66700000001583,
						["dead"] = true,
					}, -- [1]
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					7244.927212, -- [1]
					-0.00866899999982707, -- [2]
					{
						0, -- [1]
						[0] = 354,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:00:06",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "闪闪光头",
				["TotalElapsedCombatTime"] = 352942.044,
				["CombatEndedAt"] = 352942.044,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 0.003616,
							["喔愺"] = 0.008528,
							["无情萨满"] = 0.006744,
						}, -- [1]
					},
				},
				["end_time"] = 352942.278,
				["combat_id"] = 8,
				["frags"] = {
					["潜行哲"] = 1,
					["说情话"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["contra"] = "闪闪光头",
				["combat_counter"] = 28,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
				},
				["start_time"] = 352930.267,
				["TimeData"] = {
				},
				["data_inicio"] = "21:59:54",
			}, -- [13]
		},
	},
	["last_version"] = "v1.13.3.199",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["last_version"] = 11,
		["潇潇"] = {
			"潇潇", -- [1]
			"Interface\\EncounterJournal\\UI-EJ-BOSS-Argent Confessor Paletress", -- [2]
			{
				0, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			}, -- [3]
			"Interface\\PetBattles\\Weather-ArcaneStorm", -- [4]
			{
				0.129609375, -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
			}, -- [5]
			{
				1, -- [1]
				1, -- [2]
				1, -- [3]
			}, -- [6]
			3, -- [7]
		},
		["nextreset"] = 1592204655,
	},
	["last_instance_id"] = 329,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 1590925818,
	["active_profile"] = "潇潇-龙牙",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 0.2,
			["showamount"] = false,
			["animate"] = false,
			["useplayercolor"] = false,
			["useclasscolors"] = false,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["enabled"] = true,
		},
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["last_day"] = "31",
	["cached_talents"] = {
		["Player-4920-022A2037"] = {
			{
				135894, -- [1]
				2, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [1]
			{
				135892, -- [1]
				3, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [2]
			{
				136096, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [3]
			{
				135463, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [4]
			{
				136011, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [5]
			{
				136170, -- [1]
				3, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [6]
			{
				136006, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [7]
			{
				136116, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [8]
			{
				135733, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [9]
			{
				136153, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [10]
			{
				135856, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [11]
			{
				136208, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [12]
			{
				136031, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [13]
			{
				136129, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136222, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [15]
			{
				136048, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [16]
			{
				135812, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [17]
			{
				135821, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [18]
			{
				135818, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [19]
			{
				135815, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [20]
			{
				135807, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [21]
			{
				135813, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [22]
			{
				135826, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [23]
			{
				135808, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [24]
			{
				135805, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [25]
			{
				135827, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [26]
			{
				135806, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [27]
			{
				135820, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [28]
			{
				136115, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [29]
			{
				135903, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [30]
			{
				135817, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [31]
			{
				135824, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [32]
			{
				135850, -- [1]
				2, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [33]
			{
				135846, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [34]
			{
				135989, -- [1]
				3, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [35]
			{
				135855, -- [1]
				5, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [36]
			{
				135842, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [37]
			{
				135840, -- [1]
				2, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [38]
			{
				135864, -- [1]
				3, -- [2]
				2, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [39]
			{
				135845, -- [1]
				3, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [40]
			{
				135865, -- [1]
				1, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [41]
			{
				135857, -- [1]
				3, -- [2]
				3, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [42]
			{
				136141, -- [1]
				2, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [43]
			{
				135860, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [44]
			{
				135849, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135841, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [46]
			{
				135852, -- [1]
				3, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [47]
			{
				135836, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [48]
			{
				135988, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [49]
		},
		["Player-4920-01D0E17B"] = {
			{
				136076, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				[7] = 5,
			}, -- [1]
			{
				136080, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				[7] = 5,
			}, -- [2]
			{
				132150, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				[7] = 2,
			}, -- [3]
			{
				132159, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				[7] = 5,
			}, -- [4]
			{
				134355, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				[7] = 3,
			}, -- [5]
			{
				132163, -- [1]
				0, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				[7] = 2,
			}, -- [6]
			{
				132242, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				[7] = 2,
			}, -- [7]
			{
				132120, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				[7] = 1,
			}, -- [8]
			{
				132091, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				[7] = 5,
			}, -- [9]
			{
				132179, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				[7] = 2,
			}, -- [10]
			{
				134297, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				1, -- [5]
				[7] = 5,
			}, -- [11]
			{
				132121, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				1, -- [5]
				[7] = 2,
			}, -- [12]
			{
				132111, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				[7] = 1,
			}, -- [13]
			{
				136006, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				1, -- [5]
				[7] = 2,
			}, -- [14]
			{
				134296, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				1, -- [5]
				[7] = 5,
			}, -- [15]
			{
				132127, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				[7] = 1,
			}, -- [16]
			{
				135860, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [17]
			{
				135865, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [18]
			{
				132212, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [19]
			{
				132312, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [20]
			{
				135130, -- [1]
				1, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [21]
			{
				132218, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [22]
			{
				132327, -- [1]
				3, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [23]
			{
				132204, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [24]
			{
				132271, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [25]
			{
				132153, -- [1]
				1, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [26]
			{
				132330, -- [1]
				3, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [27]
			{
				132169, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [28]
			{
				135615, -- [1]
				5, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [29]
			{
				132329, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [30]
			{
				134154, -- [1]
				3, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [31]
			{
				135942, -- [1]
				3, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [32]
			{
				132269, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [33]
			{
				136100, -- [1]
				5, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [34]
			{
				132277, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [35]
			{
				132309, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [36]
			{
				136106, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [37]
			{
				136223, -- [1]
				4, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [38]
			{
				132369, -- [1]
				1, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [39]
			{
				132149, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [40]
			{
				132219, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [41]
			{
				132293, -- [1]
				2, -- [2]
				4, -- [3]
				4, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [42]
			{
				135881, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [43]
			{
				132336, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [44]
			{
				136047, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135125, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [46]
		},
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["last_realversion"] = 142,
	["combat_id"] = 75,
	["savedStyles"] = {
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_counter"] = 108,
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 942.152416,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["我瞿李媚"] = 1654,
						["亡者农药"] = 6716,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["total"] = 8370.15241600001,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 8370.15241600001,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1590909042,
					["damage_taken"] = 752237.152416,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 399,
								["targets"] = {
									["亡者农药"] = 6716,
									["我瞿李媚"] = 1654,
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8370,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 55,
								["total"] = 8370,
								["c_max"] = 0,
								["c_min"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_dmg"] = 2797,
								["m_crit"] = 0,
								["b_dmg"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 9,
								["n_amt"] = 26,
								["IMMUNE"] = 28,
								["MISS"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["nome"] = "被撕裂的死尸",
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590908998,
					["serial"] = "Creature-0-4517-329-15215-10382-0001D35783",
					["monster"] = true,
				}, -- [1]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 171.241329,
					["damage_from"] = {
						["石翼石像鬼"] = true,
						["斯库尔"] = true,
						["破碎的死尸"] = true,
						["灬争渡灬"] = true,
						["高端法爷"] = true,
						["骷髅守护者"] = true,
						["骷髅狂战士"] = true,
						["被撕裂的死尸"] = true,
						["恶疫食尸鬼"] = true,
						["缝补憎恶"] = true,
						["被毁坏的死尸"] = true,
					},
					["targets"] = {
						["石翼石像鬼"] = 12119,
						["破碎的死尸 <被毁坏的死尸>"] = 17728,
						["斯库尔"] = 6413,
						["破碎的死尸"] = 6753,
						["被毁坏的死尸"] = 287650,
						["高端法爷"] = 171,
						["骷髅守护者"] = 106392,
						["骷髅狂战士"] = 79220,
						["被撕裂的死尸"] = 306403,
						["恶疫食尸鬼"] = 129707,
						["缝补憎恶"] = 82984,
						["幽灵市民"] = 1191,
						["灬争渡灬"] = 1084,
						["鬼魂市民"] = 3177,
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["tipo"] = 1,
					["classe"] = "MAGE",
					["raid_targets"] = {
						[128] = 75475,
						[8] = 2722,
					},
					["total_without_pet"] = 1040992.241329,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1590909042,
					["nome"] = "亡者农药",
					["damage_taken"] = 39308.241329,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["冰霜新星"] = {
								["c_amt"] = 26,
								["b_amt"] = 0,
								["c_dmg"] = 1566,
								["g_amt"] = 0,
								["n_max"] = 35,
								["targets"] = {
									["石翼石像鬼"] = 117,
									["破碎的死尸 <被毁坏的死尸>"] = 30,
									["斯库尔"] = 62,
									["破碎的死尸"] = 59,
									["被毁坏的死尸"] = 1853,
									["骷髅守护者"] = 1484,
									["骷髅狂战士"] = 1957,
									["被撕裂的死尸"] = 1826,
									["恶疫食尸鬼"] = 671,
									["缝补憎恶"] = 479,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6972,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 261,
								["total"] = 8538,
								["c_max"] = 66,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 232,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 180,
								["targets"] = {
									["石翼石像鬼"] = 12002,
									["破碎的死尸 <被毁坏的死尸>"] = 13467,
									["斯库尔"] = 1375,
									["破碎的死尸"] = 6694,
									["被毁坏的死尸"] = 227682,
									["高端法爷"] = 171,
									["骷髅守护者"] = 95934,
									["骷髅狂战士"] = 57497,
									["被撕裂的死尸"] = 248116,
									["恶疫食尸鬼"] = 109522,
									["缝补憎恶"] = 37208,
									["鬼魂市民"] = 2852,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 812520,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4643,
								["total"] = 812520,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 2672,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 28,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 4643,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 3715,
								["g_amt"] = 0,
								["n_max"] = 653,
								["targets"] = {
									["被撕裂的死尸"] = 653,
									["斯库尔"] = 647,
									["缝补憎恶"] = 7627,
									["幽灵市民"] = 452,
									["被毁坏的死尸"] = 1535,
									["鬼魂市民"] = 325,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 7524,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 11239,
								["c_max"] = 980,
								["id"] = "火焰冲击",
								["r_dmg"] = 777,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 2,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 13,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["奥术飞弹"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1173,
								["g_amt"] = 0,
								["n_max"] = 268,
								["targets"] = {
									["缝补憎恶"] = 2409,
									["灬争渡灬"] = 554,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1790,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 2963,
								["c_max"] = 402,
								["id"] = "奥术飞弹",
								["r_dmg"] = 185,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 7,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 4462,
								["g_amt"] = 0,
								["n_max"] = 767,
								["targets"] = {
									["缝补憎恶"] = 29286,
									["幽灵市民"] = 739,
									["斯库尔"] = 3764,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 29327,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 42,
								["total"] = 33789,
								["c_max"] = 1527,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 39,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1374,
								["g_amt"] = 0,
								["n_max"] = 313,
								["targets"] = {
									["骷髅狂战士"] = 3157,
									["被撕裂的死尸"] = 1796,
									["恶疫食尸鬼"] = 613,
									["被毁坏的死尸"] = 3349,
									["骷髅守护者"] = 1184,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8725,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 33,
								["total"] = 10099,
								["c_max"] = 466,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 29,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["斯坦索姆圣水"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1033,
								["targets"] = {
									["被撕裂的死尸"] = 13657,
									["恶疫食尸鬼"] = 7688,
									["缝补憎恶"] = 2565,
									["被毁坏的死尸"] = 19025,
									["破碎的死尸 <被毁坏的死尸>"] = 1987,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 44922,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 53,
								["total"] = 44922,
								["c_max"] = 0,
								["id"] = "斯坦索姆圣水",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 53,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Autoshot"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 95,
								["targets"] = {
									["缝补憎恶"] = 95,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 95,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 95,
								["c_max"] = 0,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰锥术"] = {
								["c_amt"] = 15,
								["b_amt"] = 0,
								["c_dmg"] = 16816,
								["g_amt"] = 0,
								["n_max"] = 609,
								["targets"] = {
									["破碎的死尸 <被毁坏的死尸>"] = 2244,
									["斯库尔"] = 565,
									["灬争渡灬"] = 530,
									["骷髅守护者"] = 7790,
									["骷髅狂战士"] = 16609,
									["被撕裂的死尸"] = 40355,
									["恶疫食尸鬼"] = 11213,
									["缝补憎恶"] = 3315,
									["被毁坏的死尸"] = 34206,
									["鬼魂市民"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 100011,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 197,
								["total"] = 116827,
								["c_max"] = 1192,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 179,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 3,
								["a_amt"] = 1,
								["a_dmg"] = 530,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["on_hold"] = false,
					["total"] = 1040992.241329,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590908218,
					["serial"] = "Player-4920-01DA4323",
					["friendlyfire_total"] = 0,
				}, -- [2]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 1254.175296,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["我瞿李媚"] = 1017,
						["亡者农药"] = 8594,
					},
					["delay"] = 0,
					["pets"] = {
						"破碎的死尸 <被毁坏的死尸>", -- [1]
					},
					["total"] = 9611.175296,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 9611.175296,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1590909042,
					["damage_taken"] = 681659.175296,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1956,
								["g_amt"] = 0,
								["n_max"] = 405,
								["targets"] = {
									["亡者农药"] = 8594,
									["我瞿李媚"] = 1017,
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 7655,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 73,
								["c_min"] = 0,
								["total"] = 9611,
								["c_max"] = 674,
								["r_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["MISS"] = 2,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 8,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 3041,
								["n_amt"] = 23,
								["DODGE"] = 1,
								["IMMUNE"] = 44,
							},
							["召唤破碎的死尸"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "召唤破碎的死尸",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 106,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["nome"] = "被毁坏的死尸",
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590908992,
					["serial"] = "Creature-0-4517-329-15215-10381-0001535783",
					["monster"] = true,
				}, -- [3]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 1863.140814,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["亡者农药"] = 4372,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 4372.140814,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1590909042,
					["damage_taken"] = 167211.140814,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 276,
								["targets"] = {
									["亡者农药"] = 4372,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4372,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 43,
								["total"] = 4372,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 3,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 31,
								["a_dmg"] = 498,
								["MISS"] = 12,
							},
							["挫志怒吼"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["亡者农药"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "挫志怒吼",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["nome"] = "骷髅狂战士",
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590909007,
					["serial"] = "Creature-0-4517-329-15215-10391-0002D35783",
					["total"] = 4372.140814,
				}, -- [4]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 5552.156668,
					["damage_from"] = {
						["亡者农药"] = true,
						["潇潇"] = true,
						["我瞿李媚"] = true,
						["骷髅守护者"] = true,
					},
					["targets"] = {
						["亡者农药"] = 7853,
						["潇潇"] = 1303,
						["我瞿李媚"] = 3940,
						["骷髅守护者"] = 919,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 14015.156668,
					["dps_started"] = false,
					["monster"] = true,
					["end_time"] = 1590909042,
					["damage_taken"] = 225523.156668,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["奥术箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 103,
								["targets"] = {
									["我瞿李媚"] = 720,
									["亡者农药"] = 1359,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2079,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 35,
								["total"] = 2079,
								["c_max"] = 0,
								["id"] = "奥术箭",
								["r_dmg"] = 205,
								["c_min"] = 0,
								["r_amt"] = 4,
								["m_crit"] = 0,
								["n_amt"] = 26,
								["m_amt"] = 0,
								["successful_casted"] = 32,
								["b_dmg"] = 0,
								["RESIST"] = 9,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 305,
								["g_amt"] = 0,
								["n_max"] = 279,
								["targets"] = {
									["亡者农药"] = 466,
									["潇潇"] = 1098,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1259,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 41,
								["total"] = 1564,
								["c_max"] = 305,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 5,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 6,
								["a_dmg"] = 1123,
								["IMMUNE"] = 34,
							},
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 73,
								["targets"] = {
									["亡者农药"] = 73,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 73,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 73,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 73,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 1,
								["a_dmg"] = 73,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 205,
								["targets"] = {
									["亡者农药"] = 1450,
									["潇潇"] = 205,
									["我瞿李媚"] = 1314,
									["骷髅守护者"] = 919,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3888,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 52,
								["total"] = 3888,
								["c_max"] = 0,
								["c_min"] = 0,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["n_amt"] = 35,
								["m_crit"] = 0,
								["b_dmg"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 45,
								["a_amt"] = 0,
								["RESIST"] = 10,
								["a_dmg"] = 0,
								["REFLECT"] = 7,
							},
							["暗影箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 156,
								["targets"] = {
									["我瞿李媚"] = 1906,
									["亡者农药"] = 4505,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6411,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 73,
								["total"] = 6411,
								["c_max"] = 0,
								["id"] = "暗影箭",
								["r_dmg"] = 1410,
								["c_min"] = 0,
								["r_amt"] = 16,
								["m_crit"] = 0,
								["n_amt"] = 63,
								["m_amt"] = 0,
								["successful_casted"] = 69,
								["b_dmg"] = 0,
								["RESIST"] = 10,
								["a_amt"] = 6,
								["a_dmg"] = 689,
							},
						},
						["tipo"] = 2,
					},
					["nome"] = "骷髅守护者",
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590908879,
					["serial"] = "Creature-0-4517-329-15215-10390-0003535783",
					["total"] = 14015.156668,
				}, -- [5]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 1608.121001,
					["damage_from"] = {
						["缝补憎恶"] = true,
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["缝补憎恶"] = 4,
						["亡者农药"] = 4402,
						["我瞿李媚"] = 5887,
						["潇潇"] = 3270,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["monster"] = true,
					["damage_taken"] = 197851.121001,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 13563.121001,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["total"] = 13563.121001,
					["last_dps"] = 0,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["疾病之云"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 49,
								["targets"] = {
									["潇潇"] = 0,
									["亡者农药"] = 49,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 49,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 49,
								["c_max"] = 0,
								["id"] = "疾病之云",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_dmg"] = 0,
								["IMMUNE"] = 4,
							},
							["击退"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 950,
								["targets"] = {
									["亡者农药"] = 2671,
									["我瞿李媚"] = 5010,
									["潇潇"] = 873,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8554,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 8554,
								["c_max"] = 0,
								["id"] = "击退",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 10,
								["b_dmg"] = 0,
								["n_amt"] = 10,
								["a_amt"] = 3,
								["a_dmg"] = 2565,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1235,
								["targets"] = {
									["亡者农药"] = 1682,
									["我瞿李媚"] = 877,
									["潇潇"] = 2397,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4956,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 4956,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_dmg"] = 1235,
								["IMMUNE"] = 3,
							},
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["缝补憎恶"] = 4,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 4,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["nome"] = "缝补憎恶",
					["end_time"] = 1590910009,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590909967,
					["serial"] = "Creature-0-4889-329-20975-10414-0001535B44",
					["fight_component"] = true,
				}, -- [6]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 344.142279,
					["damage_from"] = {
						["石翼石像鬼"] = true,
						["被撕裂的死尸"] = true,
						["斯库尔"] = true,
						["缝补憎恶"] = true,
						["灬争渡灬"] = true,
						["被毁坏的死尸"] = true,
						["骷髅守护者"] = true,
					},
					["targets"] = {
						["石翼石像鬼"] = 11812,
						["破碎的死尸 <被毁坏的死尸>"] = 17007,
						["斯库尔"] = 11176,
						["破碎的死尸"] = 6180,
						["被毁坏的死尸"] = 266723,
						["高端法爷"] = 516,
						["骷髅守护者"] = 92435,
						["骷髅狂战士"] = 55921,
						["被撕裂的死尸"] = 291587,
						["恶疫食尸鬼"] = 134844,
						["灬争渡灬"] = 636,
						["缝补憎恶"] = 88790,
						["幽灵市民"] = 472,
						["要水收钱"] = 472,
						["鬼魂市民"] = 3912,
					},
					["pets"] = {
					},
					["damage_taken"] = 18470.142279,
					["tipo"] = 1,
					["classe"] = "MAGE",
					["raid_targets"] = {
						[128] = 80737,
						[8] = 2402,
					},
					["total_without_pet"] = 982483.142279,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 982483.142279,
					["nome"] = "我瞿李媚",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["火焰冲击"] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 5501,
								["g_amt"] = 0,
								["n_max"] = 649,
								["targets"] = {
									["破碎的死尸 <被毁坏的死尸>"] = 877,
									["斯库尔"] = 2799,
									["缝补憎恶"] = 12840,
									["鬼魂市民"] = 316,
									["灬争渡灬"] = 582,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 11913,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 17414,
								["c_max"] = 973,
								["id"] = "火焰冲击",
								["r_dmg"] = 316,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 20,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["斯坦索姆圣水"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 851,
								["targets"] = {
									["被毁坏的死尸"] = 10416,
									["恶疫食尸鬼"] = 4572,
									["被撕裂的死尸"] = 14832,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 29820,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 38,
								["total"] = 29820,
								["c_max"] = 0,
								["id"] = "斯坦索姆圣水",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 38,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰霜新星"] = {
								["c_amt"] = 19,
								["b_amt"] = 0,
								["c_dmg"] = 1147,
								["g_amt"] = 0,
								["n_max"] = 34,
								["targets"] = {
									["石翼石像鬼"] = 64,
									["破碎的死尸 <被毁坏的死尸>"] = 31,
									["被毁坏的死尸"] = 573,
									["骷髅守护者"] = 62,
									["骷髅狂战士"] = 625,
									["被撕裂的死尸"] = 929,
									["恶疫食尸鬼"] = 580,
									["缝补憎恶"] = 541,
									["灬争渡灬"] = 54,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2312,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 96,
								["total"] = 3459,
								["c_max"] = 66,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 77,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["奥术飞弹"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 399,
								["g_amt"] = 0,
								["n_max"] = 266,
								["targets"] = {
									["缝补憎恶"] = 1196,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 797,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 1196,
								["c_max"] = 399,
								["id"] = "奥术飞弹",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1360,
								["g_amt"] = 0,
								["n_max"] = 310,
								["targets"] = {
									["破碎的死尸 <被毁坏的死尸>"] = 1794,
									["恶疫食尸鬼"] = 2118,
									["缝补憎恶"] = 752,
									["被毁坏的死尸"] = 605,
									["被撕裂的死尸"] = 912,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4821,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 19,
								["total"] = 6181,
								["c_max"] = 455,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 16,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 7,
								["b_amt"] = 0,
								["c_dmg"] = 10529,
								["g_amt"] = 0,
								["n_max"] = 768,
								["targets"] = {
									["缝补憎恶"] = 35151,
									["斯库尔"] = 4524,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 29146,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 47,
								["total"] = 39675,
								["c_max"] = 1529,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 39,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰锥术"] = {
								["c_amt"] = 11,
								["b_amt"] = 0,
								["c_dmg"] = 11449,
								["g_amt"] = 0,
								["n_max"] = 566,
								["targets"] = {
									["破碎的死尸 <被毁坏的死尸>"] = 2165,
									["斯库尔"] = 1023,
									["被毁坏的死尸"] = 15139,
									["骷髅守护者"] = 508,
									["骷髅狂战士"] = 4623,
									["被撕裂的死尸"] = 22537,
									["恶疫食尸鬼"] = 7812,
									["缝补憎恶"] = 2589,
									["鬼魂市民"] = 500,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 45447,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 98,
								["total"] = 56896,
								["c_max"] = 1105,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 87,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 180,
								["targets"] = {
									["石翼石像鬼"] = 11748,
									["破碎的死尸 <被毁坏的死尸>"] = 12140,
									["斯库尔"] = 2830,
									["破碎的死尸"] = 6180,
									["被毁坏的死尸"] = 239990,
									["高端法爷"] = 516,
									["骷髅守护者"] = 91865,
									["骷髅狂战士"] = 50673,
									["被撕裂的死尸"] = 252377,
									["恶疫食尸鬼"] = 119762,
									["缝补憎恶"] = 35721,
									["幽灵市民"] = 472,
									["要水收钱"] = 472,
									["鬼魂市民"] = 3096,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 827842,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4723,
								["total"] = 827842,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 2816,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 29,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 4723,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["on_hold"] = false,
					["end_time"] = 1590910009,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590909179,
					["serial"] = "Player-4920-01DA138E",
					["friendlyfire_total"] = 0,
				}, -- [7]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.09641,
					["fight_component"] = true,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["total"] = 0.09641,
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.09641,
					["damage_taken"] = 39704.09641,
					["delay"] = 0,
					["monster"] = true,
					["end_time"] = 1590915637,
					["classe"] = "UNKNOW",
					["ownerName"] = "被毁坏的死尸",
					["nome"] = "破碎的死尸 <被毁坏的死尸>",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["我瞿李媚"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["MISS"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590915634,
					["serial"] = "Creature-0-4514-329-15671-10383-000053722B",
					["friendlyfire"] = {
					},
				}, -- [8]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 3543.017776,
					["damage_from"] = {
						["我瞿李媚"] = true,
						["潇潇"] = true,
						["斯库尔"] = true,
						["亡者农药"] = true,
					},
					["targets"] = {
						["斯库尔"] = 446,
						["潇潇"] = 482,
						["我瞿李媚"] = 4126,
						["亡者农药"] = 3171,
					},
					["pets"] = {
					},
					["damage_taken"] = 20272.017776,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
						[128] = 446,
					},
					["total_without_pet"] = 8225.017776,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 8225.017776,
					["nome"] = "斯库尔",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["奥术箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 455,
								["targets"] = {
									["我瞿李媚"] = 1032,
									["亡者农药"] = 1670,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2702,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["total"] = 2702,
								["c_max"] = 0,
								["id"] = "奥术箭",
								["r_dmg"] = 902,
								["c_min"] = 0,
								["r_amt"] = 3,
								["m_crit"] = 0,
								["n_amt"] = 8,
								["m_amt"] = 0,
								["successful_casted"] = 9,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 446,
								["targets"] = {
									["亡者农药"] = 1144,
									["我瞿李媚"] = 2765,
									["斯库尔"] = 446,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4355,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 22,
								["total"] = 4355,
								["c_max"] = 0,
								["c_min"] = 0,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["n_amt"] = 15,
								["m_crit"] = 0,
								["b_dmg"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 18,
								["a_amt"] = 4,
								["RESIST"] = 4,
								["a_dmg"] = 1057,
								["REFLECT"] = 3,
							},
							["冰霜震击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 482,
								["targets"] = {
									["亡者农药"] = 357,
									["我瞿李媚"] = 329,
									["潇潇"] = 482,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1168,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 1168,
								["c_max"] = 0,
								["id"] = "冰霜震击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 2,
								["a_dmg"] = 686,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["end_time"] = 1590916616,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590916545,
					["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
					["monster"] = true,
				}, -- [9]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.015071,
					["damage_from"] = {
						["我瞿李媚"] = true,
						["亡者农药"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["nome"] = "幽灵市民",
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.015071,
					["delay"] = 0,
					["fight_component"] = true,
					["end_time"] = 1590916616,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 1663.015071,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["dps_started"] = false,
					["total"] = 0.015071,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590916613,
					["serial"] = "Creature-0-4887-329-8197-10385-00005375B3",
					["friendlyfire"] = {
					},
				}, -- [10]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.093945,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["亡者农药"] = 2275,
						["潇潇"] = 3283,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 5558.093945,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1590917053,
					["damage_taken"] = 320275.093945,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 765,
								["g_amt"] = 0,
								["n_max"] = 737,
								["targets"] = {
									["亡者农药"] = 2275,
									["潇潇"] = 3283,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4793,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 37,
								["total"] = 5558,
								["c_max"] = 765,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 9,
								["a_dmg"] = 430,
								["IMMUNE"] = 27,
							},
							["食尸鬼瘟疫"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "食尸鬼瘟疫",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["狂怒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "狂怒",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 42,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["nome"] = "恶疫食尸鬼",
					["friendlyfire"] = {
					},
					["total"] = 5558.093945,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590917038,
					["serial"] = "Creature-0-4887-329-8197-10405-0001D3744C",
					["monster"] = true,
				}, -- [11]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 106.050222,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["亡者农药"] = 106,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["monster"] = true,
					["damage_taken"] = 13058.050222,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 106.050222,
					["classe"] = "UNKNOW",
					["dps_started"] = false,
					["total"] = 106.050222,
					["last_dps"] = 0,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 106,
								["targets"] = {
									["亡者农药"] = 106,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 106,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 106,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["nome"] = "破碎的死尸",
					["end_time"] = 1590917053,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590917047,
					["serial"] = "Creature-0-4887-329-8197-10383-000053779D",
					["fight_component"] = true,
				}, -- [12]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 556.110087,
					["damage_from"] = {
						["石翼石像鬼"] = true,
						["斯库尔"] = true,
						["灬争渡灬"] = true,
						["高端法爷"] = true,
						["骷髅守护者"] = true,
						["圣光一闪"] = true,
						["恶疫食尸鬼"] = true,
						["弗雷斯特恩"] = true,
						["缝补憎恶"] = true,
					},
					["targets"] = {
						["石翼石像鬼"] = 4909,
						["破碎的死尸 <被毁坏的死尸>"] = 4969,
						["来瓶老雪"] = 0,
						["被毁坏的死尸"] = 127286,
						["高端法爷"] = 556,
						["骷髅狂战士"] = 32070,
						["圣光一闪"] = 464,
						["恶疫食尸鬼"] = 55724,
						["小俊俊"] = 439,
						["斯库尔"] = 2237,
						["破碎的死尸"] = 125,
						["灬争渡灬"] = 349,
						["骷髅守护者"] = 25777,
						["被撕裂的死尸"] = 154247,
						["猫影貂蝉"] = 410,
						["缝补憎恶"] = 26073,
						["要水收钱"] = 463,
						["鬼魂市民"] = 1948,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["classe"] = "MAGE",
					["raid_targets"] = {
						[128] = 20664,
						[8] = 1258,
					},
					["total_without_pet"] = 438046.110087,
					["nome"] = "潇潇",
					["dps_started"] = false,
					["end_time"] = 1590921095,
					["damage_taken"] = 14700.110087,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spec"] = 64,
					["grupo"] = true,
					["total"] = 438046.110087,
					["spells"] = {
						["_ActorTable"] = {
							["冰锥术"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1577,
								["g_amt"] = 0,
								["n_max"] = 439,
								["targets"] = {
									["石翼石像鬼"] = 0,
									["破碎的死尸 <被毁坏的死尸>"] = 411,
									["斯库尔"] = 392,
									["灬争渡灬"] = 0,
									["高端法爷"] = 0,
									["来瓶老雪"] = 0,
									["田昊眼成小"] = 0,
									["被撕裂的死尸"] = 2421,
									["恶疫食尸鬼"] = 1586,
									["猫影貂蝉"] = 410,
									["缝补憎恶"] = 1578,
									["被毁坏的死尸"] = 4006,
									["圣光一闪"] = 401,
									["小俊俊"] = 439,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 10067,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 29,
								["total"] = 11644,
								["c_max"] = 797,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 25,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 126,
								["targets"] = {
									["石翼石像鬼"] = 4783,
									["破碎的死尸 <被毁坏的死尸>"] = 4500,
									["斯库尔"] = 250,
									["破碎的死尸"] = 125,
									["被毁坏的死尸"] = 121235,
									["骷髅守护者"] = 25719,
									["骷髅狂战士"] = 31882,
									["被撕裂的死尸"] = 150484,
									["恶疫食尸鬼"] = 53892,
									["缝补憎恶"] = 14472,
									["鬼魂市民"] = 1751,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 409093,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3356,
								["total"] = 409093,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 20234,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 245,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3356,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰冻"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["缝补憎恶"] = 0,
									["弗雷斯特恩"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰冻",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰霜新星"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 127,
								["g_amt"] = 0,
								["n_max"] = 65,
								["targets"] = {
									["石翼石像鬼"] = 126,
									["破碎的死尸 <被毁坏的死尸>"] = 58,
									["来瓶老雪"] = 0,
									["被毁坏的死尸"] = 1283,
									["骷髅守护者"] = 58,
									["骷髅狂战士"] = 188,
									["被撕裂的死尸"] = 1342,
									["恶疫食尸鬼"] = 246,
									["缝补憎恶"] = 250,
									["弗雷斯特恩"] = 0,
									["鬼魂市民"] = 0,
									["要水收钱"] = 62,
									["圣光一闪"] = 63,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3549,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 62,
								["total"] = 3676,
								["c_max"] = 127,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 58,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 149,
								["targets"] = {
									["高端法爷"] = 149,
									["来瓶老雪"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 149,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 149,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 4765,
								["g_amt"] = 0,
								["n_max"] = 414,
								["targets"] = {
									["缝补憎恶"] = 7544,
									["被毁坏的死尸"] = 411,
									["斯库尔"] = 1217,
									["要水收钱"] = 401,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4808,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 19,
								["total"] = 9573,
								["c_max"] = 826,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 12,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Autoshot"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["缝补憎恶"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 4,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 407,
								["g_amt"] = 0,
								["n_max"] = 407,
								["targets"] = {
									["来瓶老雪"] = 0,
									["斯库尔"] = 378,
									["灬争渡灬"] = 349,
									["缝补憎恶"] = 2229,
									["被毁坏的死尸"] = 351,
									["高端法爷"] = 407,
									["鬼魂市民"] = 197,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3504,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 3911,
								["c_max"] = 407,
								["id"] = "火焰冲击",
								["r_dmg"] = 880,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 3,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 10,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590920634,
					["serial"] = "Player-4920-022A2037",
					["friendlyfire_total"] = 0,
				}, -- [13]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 1311.015514,
					["damage_from"] = {
						["大酒鬼"] = true,
						["好羡慕狗"] = true,
						["亡者农药"] = true,
						["潇潇"] = true,
						["我瞿李媚"] = true,
					},
					["targets"] = {
						["盘锦吴奇隆"] = 950,
						["大酒鬼"] = 1023,
						["亡者农药"] = 1104,
						["习惯被依赖"] = 1113,
						["吴老二"] = 552,
						["好羡慕狗"] = 305,
						["修辞"] = 932,
						["我瞿李媚"] = 1165,
						["酒歌没歌了"] = 951,
						["螺纹钢"] = 1257,
						["受命于"] = 1097,
						["潇潇"] = 1265,
						["奶过苍井空"] = 635,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 12349.015514,
					["damage_taken"] = 2339.015514,
					["dps_started"] = false,
					["end_time"] = 1590921207,
					["delay"] = 0,
					["fight_component"] = true,
					["nome"] = "灬争渡灬",
					["spells"] = {
						["_ActorTable"] = {
							["魔爆术"] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 2844,
								["g_amt"] = 0,
								["n_max"] = 428,
								["targets"] = {
									["盘锦吴奇隆"] = 950,
									["大酒鬼"] = 1023,
									["亡者农药"] = 1104,
									["习惯被依赖"] = 1113,
									["吴老二"] = 552,
									["好羡慕狗"] = 305,
									["修辞"] = 932,
									["我瞿李媚"] = 1165,
									["酒歌没歌了"] = 951,
									["螺纹钢"] = 1257,
									["受命于"] = 1097,
									["潇潇"] = 1265,
									["奶过苍井空"] = 635,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 9505,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 37,
								["total"] = 12349,
								["c_max"] = 486,
								["id"] = "魔爆术",
								["r_dmg"] = 233,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 31,
								["a_amt"] = 3,
								["a_dmg"] = 1046,
							},
							["闪现术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "闪现术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["法术反制"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "法术反制",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590921192,
					["serial"] = "Player-4920-01DBA830",
					["total"] = 12349.015514,
				}, -- [14]
				{
					["flag_original"] = 8776,
					["totalabsorbed"] = 514.026916,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["潇潇"] = 1119,
						["我瞿李媚"] = 681,
						["亡者农药"] = 279,
					},
					["pets"] = {
					},
					["damage_taken"] = 28840.026916,
					["end_time"] = 1590921426,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 2079.026916,
					["delay"] = 0,
					["fight_component"] = true,
					["total"] = 2079.026916,
					["nome"] = "石翼石像鬼",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 605,
								["g_amt"] = 0,
								["n_max"] = 514,
								["targets"] = {
									["潇潇"] = 1119,
									["我瞿李媚"] = 681,
									["亡者农药"] = 279,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1474,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 2079,
								["c_max"] = 605,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 4,
								["a_dmg"] = 605,
								["IMMUNE"] = 9,
							},
							["破甲攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "破甲攻击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["classe"] = "PET",
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590921398,
					["serial"] = "Creature-0-4887-329-19161-10408-0000538872",
					["dps_started"] = false,
				}, -- [15]
				{
					["flag_original"] = 68136,
					["totalabsorbed"] = 528.014424,
					["damage_from"] = {
					},
					["targets"] = {
						["潇潇"] = 2858,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 2858.014424,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1590922702,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 704,
								["g_amt"] = 0,
								["n_max"] = 602,
								["targets"] = {
									["潇潇"] = 2351,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1647,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 2351,
								["c_max"] = 704,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_dmg"] = 704,
								["IMMUNE"] = 4,
							},
							["射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 507,
								["targets"] = {
									["潇潇"] = 507,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 507,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 507,
								["c_max"] = 0,
								["id"] = "射击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.014424,
					["total"] = 2858.014424,
					["nome"] = "弗雷斯特恩",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590922679,
					["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
					["friendlyfire"] = {
					},
				}, -- [16]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 228.011823,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
						["茶几"] = 125,
						["心语千翠"] = 72,
						["大酒鬼"] = 119,
						["宸含"] = 30,
						["潇潇"] = 106,
						["法神四号"] = 71,
						["老蔡"] = 120,
						["法神三号"] = 177,
						["带鳝人"] = 71,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 891.011823,
					["damage_taken"] = 464.011823,
					["dps_started"] = false,
					["end_time"] = 1590923084,
					["delay"] = 0,
					["fight_component"] = true,
					["nome"] = "圣光一闪",
					["spells"] = {
						["_ActorTable"] = {
							["自由祝福"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "自由祝福",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["奉献"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 36,
								["targets"] = {
									["茶几"] = 125,
									["心语千翠"] = 72,
									["大酒鬼"] = 119,
									["宸含"] = 30,
									["潇潇"] = 106,
									["法神四号"] = 71,
									["老蔡"] = 120,
									["法神三号"] = 177,
									["带鳝人"] = 71,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 891,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 891,
								["c_max"] = 0,
								["id"] = "奉献",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 27,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590923073,
					["serial"] = "Player-4920-0228564A",
					["total"] = 891.011823,
				}, -- [17]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.016811,
					["damage_from"] = {
						["亡者农药"] = true,
						["我瞿李媚"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.016811,
					["last_dps"] = 0,
					["fight_component"] = true,
					["end_time"] = 1590923407,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "鬼魂市民",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 9037.016811,
					["total"] = 0.016811,
					["dps_started"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1590923404,
					["serial"] = "Creature-0-4504-329-30439-10384-0003538F3D",
					["friendlyfire"] = {
					},
				}, -- [18]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 282.014715,
					["damage_from"] = {
						["冬郭"] = true,
						["我吥猜"] = true,
						["魔导师"] = true,
						["潇潇"] = true,
						["弑丶晓宇"] = true,
						["我瞿李媚"] = true,
					},
					["targets"] = {
						["魔导师"] = 282,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 282.014715,
					["damage_taken"] = 4257.014715,
					["dps_started"] = false,
					["end_time"] = 1590924648,
					["delay"] = 0,
					["fight_component"] = true,
					["nome"] = "要水收钱",
					["spells"] = {
						["_ActorTable"] = {
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 282,
								["targets"] = {
									["魔导师"] = 282,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 282,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 282,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["闪现术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "闪现术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590924644,
					["serial"] = "Player-4920-01D6E9FD",
					["total"] = 282.014715,
				}, -- [19]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.010344,
					["damage_from"] = {
						["魔导师"] = true,
						["潇潇"] = true,
						["我吥猜"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.010344,
					["damage_taken"] = 1849.010344,
					["dps_started"] = false,
					["end_time"] = 1590924660,
					["delay"] = 0,
					["fight_component"] = true,
					["nome"] = "小俊俊",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590924657,
					["serial"] = "Player-4920-025FF372",
					["total"] = 0.010344,
				}, -- [20]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.008919,
					["damage_from"] = {
						["魔导师"] = true,
						["潇潇"] = true,
						["我吥猜"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008919,
					["damage_taken"] = 1373.008919,
					["dps_started"] = false,
					["end_time"] = 1590924660,
					["delay"] = 0,
					["fight_component"] = true,
					["nome"] = "猫影貂蝉",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590924657,
					["serial"] = "Player-4920-01DB6C85",
					["total"] = 0.008919,
				}, -- [21]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 661.02658,
					["damage_from"] = {
						["冬郭"] = true,
						["我瞿李媚"] = true,
						["我吥猜"] = true,
						["潇潇"] = true,
						["亡者农药"] = true,
						["弑丶晓宇"] = true,
						["魔导师"] = true,
					},
					["targets"] = {
						["魔导师"] = 225,
						["可爱的憨憨"] = 0,
						["冬邪"] = 0,
						["亡者农药"] = 436,
						["冬郭"] = 0,
						["青青沸羊羊"] = 0,
						["无心法"] = 0,
						["青青美羊羊"] = 0,
						["接托管 <弑丶晓宇>"] = 0,
						["青青喜羊羊"] = 0,
						["哎嘿灬"] = 0,
						["Oldd"] = 0,
						["弑丶晓宇"] = 0,
						["潇潇"] = 1014,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1675.02658,
					["damage_taken"] = 3610.02658,
					["dps_started"] = false,
					["end_time"] = 1590924660,
					["delay"] = 0,
					["fight_component"] = true,
					["nome"] = "高端法爷",
					["spells"] = {
						["_ActorTable"] = {
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 436,
								["targets"] = {
									["魔导师"] = 225,
									["亡者农药"] = 436,
									["潇潇"] = 602,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1263,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 1263,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 4,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["Oldd"] = 0,
									["可爱的憨憨"] = 0,
									["青青美羊羊"] = 0,
									["魔导师"] = 0,
									["无心法"] = 0,
									["冬郭"] = 0,
									["接托管 <弑丶晓宇>"] = 0,
									["青青喜羊羊"] = 0,
									["哎嘿灬"] = 0,
									["青青沸羊羊"] = 0,
									["弑丶晓宇"] = 0,
									["冬邪"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["冰霜新星"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 27,
								["targets"] = {
									["潇潇"] = 27,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 27,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 27,
								["c_max"] = 0,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰锥术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 385,
								["targets"] = {
									["潇潇"] = 385,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 385,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 385,
								["c_max"] = 0,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 1,
								["a_dmg"] = 385,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1590924646,
					["serial"] = "Player-4920-01D6EAA0",
					["total"] = 1675.02658,
				}, -- [22]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.003199,
					["damage_from"] = {
					},
					["targets"] = {
						["专诸刺秦"] = 0,
						["潇潇"] = 0,
					},
					["fight_component"] = true,
					["pets"] = {
					},
					["end_time"] = 1590931612,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.003199,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.003199,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "鬼魅掠夺者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["专诸刺秦"] = 0,
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "射击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["on_hold"] = false,
					["serial"] = "Creature-0-4514-1-262-11686-00001DAF8F",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.003199,
					["start_time"] = 1590931609,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [23]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.006071,
					["damage_from"] = {
					},
					["targets"] = {
						["壹亿肆"] = 0,
						["潇潇"] = 0,
					},
					["fight_component"] = true,
					["pets"] = {
					},
					["end_time"] = 1590931612,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006071,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.006071,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "鬼魅袭击者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["壹亿肆"] = 0,
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["on_hold"] = false,
					["serial"] = "Creature-0-4514-1-262-11687-00001DAF7F",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.006071,
					["start_time"] = 1590931609,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [24]
				{
					["flag_original"] = -2147483648,
					["totalabsorbed"] = 0.006386,
					["damage_from"] = {
					},
					["targets"] = {
						["壹亿肆"] = 0,
						["北风微凉"] = 0,
						["潇潇"] = 0,
						["流动人口"] = 0,
						["越跑越快丶"] = 0,
						["后门植入"] = 0,
						["专诸刺秦"] = 0,
						["怀恋青春"] = 0,
						["正月晴天"] = 0,
						["上帝灬之手"] = 0,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006386,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1590931612,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["nome"] = "环境伤害 (高处坠落)",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["Falling"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["壹亿肆"] = 0,
									["北风微凉"] = 0,
									["潇潇"] = 0,
									["流动人口"] = 0,
									["越跑越快丶"] = 0,
									["后门植入"] = 0,
									["专诸刺秦"] = 0,
									["怀恋青春"] = 0,
									["正月晴天"] = 0,
									["上帝灬之手"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "Falling",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire_total"] = 0,
					["total"] = 0.006386,
					["serial"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.006386,
					["start_time"] = 1590931609,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [25]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.003594,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["end_time"] = 1590931612,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.003594,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 0.003594,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["nome"] = "来瓶老雪",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["真言术：盾"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "真言术：盾",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["serial"] = "Player-4920-0219F0FF",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.003594,
					["start_time"] = 1590931609,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [26]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.001128,
					["damage_from"] = {
					},
					["targets"] = {
						["全部一起来吧"] = 0,
						["潇潇"] = 0,
						["安东尼达斯丶"] = 0,
						["潜行哲"] = 0,
						["黄百万"] = 0,
						["无情萨满"] = 0,
						["菠蘿"] = 0,
						["弟中弟志"] = 0,
						["不做痴情种"] = 0,
						["喔愺"] = 0,
						["小懋懋"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["end_time"] = 1590931612,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001128,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 0.001128,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["nome"] = "闪闪光头",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["全部一起来吧"] = 0,
									["潇潇"] = 0,
									["安东尼达斯丶"] = 0,
									["潜行哲"] = 0,
									["黄百万"] = 0,
									["无情萨满"] = 0,
									["菠蘿"] = 0,
									["弟中弟志"] = 0,
									["不做痴情种"] = 0,
									["喔愺"] = 0,
									["小懋懋"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["serial"] = "Player-4920-0203EB0D",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.001128,
					["start_time"] = 1590931609,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [27]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.008509,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008509,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1590931612,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "喔愺",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["grupo"] = true,
					["total"] = 0.008509,
					["serial"] = "Player-4920-0231F4BA",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.008509,
					["start_time"] = 1590931609,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [28]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.007282,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "SHAMAN",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.007282,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1590931612,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "无情萨满",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["grupo"] = true,
					["total"] = 0.007282,
					["serial"] = "Player-4920-01DAB206",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.007282,
					["start_time"] = 1590931609,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [29]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1298,
					["healing_from"] = {
						["亡者农药"] = true,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "MAGE",
					["totalover"] = 0.157512,
					["total_without_pet"] = 17906.157512,
					["total"] = 17906.157512,
					["targets_absorbs"] = {
						["亡者农药"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01DA4323",
					["totalabsorb"] = 14901.157512,
					["last_hps"] = 0,
					["targets"] = {
						["亡者农药"] = 0,
					},
					["totalover_without_pet"] = 0.157512,
					["healing_taken"] = 17906.157512,
					["fight_component"] = true,
					["end_time"] = 1590909042,
					["heal_enemy_amt"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["防护冰霜结界"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 1371,
								["targets_overheal"] = {
								},
								["n_max"] = 305,
								["targets"] = {
									["亡者农药"] = 1371,
								},
								["n_min"] = 0,
								["counter"] = 10,
								["overheal"] = 0,
								["total"] = 1371,
								["c_max"] = 0,
								["id"] = "防护冰霜结界",
								["targets_absorbs"] = {
									["亡者农药"] = 1371,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 10,
								["n_curado"] = 1371,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
							["寒冰护体"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 13530,
								["targets_overheal"] = {
								},
								["n_max"] = 436,
								["targets"] = {
									["亡者农药"] = 13530,
								},
								["n_min"] = 0,
								["counter"] = 77,
								["overheal"] = 0,
								["total"] = 13530,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["targets_absorbs"] = {
									["亡者农药"] = 13530,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 77,
								["n_curado"] = 13530,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
							["急救"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 250,
								["targets"] = {
									["亡者农药"] = 250,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 250,
								["c_max"] = 0,
								["id"] = "急救",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 1,
								["n_curado"] = 250,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
							["治疗药水"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 1639,
								["targets"] = {
									["亡者农药"] = 2755,
								},
								["n_min"] = 0,
								["counter"] = 2,
								["overheal"] = 0,
								["total"] = 2755,
								["c_max"] = 0,
								["id"] = "治疗药水",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 2,
								["n_curado"] = 2755,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["targets_overheal"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.157512,
					["start_time"] = 1590908923,
					["delay"] = 0,
					["nome"] = "亡者农药",
				}, -- [1]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "MAGE",
					["totalover"] = 0.060995,
					["total_without_pet"] = 10154.060995,
					["total"] = 10154.060995,
					["targets_absorbs"] = {
						["我瞿李媚"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01DA138E",
					["totalabsorb"] = 10154.060995,
					["last_hps"] = 0,
					["targets"] = {
						["我瞿李媚"] = 0,
					},
					["totalover_without_pet"] = 0.060995,
					["healing_taken"] = 10154.060995,
					["fight_component"] = true,
					["end_time"] = 1590916616,
					["heal_enemy_amt"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["防护冰霜结界"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 1268,
								["targets_overheal"] = {
								},
								["n_max"] = 277,
								["targets"] = {
									["我瞿李媚"] = 1268,
								},
								["n_min"] = 0,
								["counter"] = 9,
								["overheal"] = 0,
								["total"] = 1268,
								["c_max"] = 0,
								["id"] = "防护冰霜结界",
								["targets_absorbs"] = {
									["我瞿李媚"] = 1268,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 9,
								["n_curado"] = 1268,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
							["寒冰护体"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 8886,
								["targets_overheal"] = {
								},
								["n_max"] = 856,
								["targets"] = {
									["我瞿李媚"] = 8886,
								},
								["n_min"] = 0,
								["counter"] = 43,
								["overheal"] = 0,
								["total"] = 8886,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["targets_absorbs"] = {
									["我瞿李媚"] = 8886,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 43,
								["n_curado"] = 8886,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["healing_from"] = {
						["我瞿李媚"] = true,
					},
					["tipo"] = 2,
					["custom"] = 0,
					["last_event"] = 0,
					["totaldenied"] = 0.060995,
					["start_time"] = 1590916510,
					["delay"] = 0,
					["nome"] = "我瞿李媚",
				}, -- [2]
				{
					["flag_original"] = 1297,
					["healing_from"] = {
						["潇潇"] = true,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "MAGE",
					["totalover"] = 0.038633,
					["total_without_pet"] = 3807.038633,
					["total"] = 3807.038633,
					["targets_absorbs"] = {
						["潇潇"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-022A2037",
					["totalabsorb"] = 3807.038633,
					["last_hps"] = 0,
					["targets"] = {
						["潇潇"] = 0,
					},
					["totalover_without_pet"] = 0.038633,
					["healing_taken"] = 3807.038633,
					["fight_component"] = true,
					["end_time"] = 1590921207,
					["targets_overheal"] = {
					},
					["last_event"] = 0,
					["nome"] = "潇潇",
					["spells"] = {
						["_ActorTable"] = {
							["寒冰护体"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 3807,
								["targets_overheal"] = {
								},
								["n_max"] = 688,
								["targets"] = {
									["潇潇"] = 3807,
								},
								["n_min"] = 0,
								["counter"] = 13,
								["overheal"] = 0,
								["total"] = 3807,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["targets_absorbs"] = {
									["潇潇"] = 3807,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 13,
								["n_curado"] = 3807,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["heal_enemy_amt"] = 0,
					["totaldenied"] = 0.038633,
					["custom"] = 0,
					["tipo"] = 2,
					["spec"] = 64,
					["start_time"] = 1590921174,
					["delay"] = 0,
					["boss_fight_component"] = true,
				}, -- [3]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["flag_original"] = 1298,
					["resource"] = 0.069609,
					["targets"] = {
						["亡者农药"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["totalover"] = 0.008467,
					["fight_component"] = true,
					["alternatepower"] = 0.055873,
					["nome"] = "亡者农药",
					["spells"] = {
						["_ActorTable"] = {
							["恢复法力"] = {
								["total"] = 1600,
								["id"] = "恢复法力",
								["totalover"] = 0,
								["targets"] = {
									["亡者农药"] = 1600,
								},
								["counter"] = 2,
							},
							["魔法吸收"] = {
								["total"] = 4747,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["亡者农药"] = 0,
								},
								["counter"] = 13,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["tipo"] = 3,
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["total"] = 6347.055873,
					["passiveover"] = 0.008467,
					["serial"] = "Player-4920-01DA4323",
					["received"] = 6347.055873,
				}, -- [1]
				{
					["flag_original"] = 1298,
					["resource"] = 0.071551,
					["targets"] = {
						["我瞿李媚"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["totalover"] = 0.003819,
					["fight_component"] = true,
					["alternatepower"] = 0.053863,
					["nome"] = "我瞿李媚",
					["spells"] = {
						["_ActorTable"] = {
							["魔法吸收"] = {
								["total"] = 4302,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["我瞿李媚"] = 0,
								},
								["counter"] = 12,
							},
							["恢复法力"] = {
								["total"] = 1541,
								["id"] = "恢复法力",
								["totalover"] = 0,
								["targets"] = {
									["我瞿李媚"] = 0,
								},
								["counter"] = 2,
							},
							["补充法力"] = {
								["total"] = 2274,
								["id"] = "补充法力",
								["totalover"] = 0,
								["targets"] = {
									["我瞿李媚"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["tipo"] = 3,
					["passiveover"] = 0.003819,
					["last_event"] = 0,
					["total"] = 8117.053863,
					["boss_fight_component"] = true,
					["serial"] = "Player-4920-01DA138E",
					["received"] = 8117.053863,
				}, -- [2]
				{
					["received"] = 395.005602,
					["resource"] = 0.008311,
					["targets"] = {
						["灬争渡灬"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.002893,
					["fight_component"] = true,
					["total"] = 395.005602,
					["nome"] = "灬争渡灬",
					["spells"] = {
						["_ActorTable"] = {
							["魔法吸收"] = {
								["total"] = 395,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["灬争渡灬"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["flag_original"] = 66888,
					["tipo"] = 3,
					["alternatepower"] = 0.005602,
					["last_event"] = 0,
					["serial"] = "Player-4920-01DBA830",
					["totalover"] = 0.002893,
				}, -- [3]
				{
					["received"] = 1807.011289,
					["resource"] = 0.011289,
					["targets"] = {
						["潇潇"] = 1807,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["passiveover"] = 0.006681,
					["total"] = 1807.011289,
					["nome"] = "潇潇",
					["spells"] = {
						["_ActorTable"] = {
							["补充法力"] = {
								["total"] = 1807,
								["id"] = "补充法力",
								["totalover"] = 0,
								["targets"] = {
									["潇潇"] = 1807,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["flag_original"] = 1297,
					["spec"] = 64,
					["tipo"] = 3,
					["last_event"] = 0,
					["alternatepower"] = 0.011289,
					["serial"] = "Player-4920-022A2037",
					["totalover"] = 0.006681,
				}, -- [4]
				{
					["received"] = 710.008369,
					["resource"] = 0.009826,
					["targets"] = {
						["高端法爷"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.006912,
					["fight_component"] = true,
					["total"] = 710.008369,
					["nome"] = "高端法爷",
					["spells"] = {
						["_ActorTable"] = {
							["魔法吸收"] = {
								["total"] = 710,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["高端法爷"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["flag_original"] = 66888,
					["tipo"] = 3,
					["alternatepower"] = 0.008369,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D6EAA0",
					["totalover"] = 0.006912,
				}, -- [5]
				{
					["received"] = 0.003777,
					["resource"] = 0.008998,
					["targets"] = {
						["闪闪光头"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.003777,
					["fight_component"] = true,
					["total"] = 0.003777,
					["tipo"] = 3,
					["nome"] = "闪闪光头",
					["spells"] = {
						["tipo"] = 7,
						["_ActorTable"] = {
							["魔法吸收"] = {
								["total"] = 0,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["闪闪光头"] = 0,
								},
								["counter"] = 0,
							},
						},
					},
					["totalover"] = 0.003777,
					["flag_original"] = 1352,
					["last_event"] = 0,
					["alternatepower"] = 0.003777,
					["serial"] = "Player-4920-0203EB0D",
				}, -- [6]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["新近包扎"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = "新近包扎",
								["uptime"] = 8,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰冻"] = {
								["counter"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 21,
								["id"] = "冰冻",
								["uptime"] = 68,
								["targets"] = {
								},
								["refreshamt"] = 2,
							},
							["冰霜新星"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 29,
								["uptime"] = 532,
								["id"] = "冰霜新星",
								["appliedamt"] = 248,
								["targets"] = {
								},
								["actived_at"] = 1590909981,
							},
							["寒冰箭"] = {
								["counter"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 13,
								["id"] = "寒冰箭",
								["uptime"] = 44,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰锥术"] = {
								["counter"] = 0,
								["activedamt"] = 6,
								["appliedamt"] = 11,
								["id"] = "冰锥术",
								["uptime"] = 60,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["暴风雪"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = -360,
								["uptime"] = 595,
								["id"] = "暴风雪",
								["appliedamt"] = 1039,
								["targets"] = {
								},
								["actived_at"] = 4772768984,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "MAGE",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["法术反制"] = {
								["id"] = "法术反制",
								["counter"] = 14,
								["targets"] = {
									["斯库尔"] = 2,
									["骷髅守护者"] = 12,
								},
								["interrompeu_oque"] = {
									["暗影箭"] = 4,
									["寒冰箭"] = 10,
								},
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["魔法抑制"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 49,
								["uptime"] = 1256,
								["id"] = "魔法抑制",
								["appliedamt"] = 49,
								["targets"] = {
								},
								["actived_at"] = 3181843031,
							},
							["魔甲术"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 48,
								["uptime"] = 1130,
								["id"] = "魔甲术",
								["appliedamt"] = 48,
								["targets"] = {
								},
								["actived_at"] = 4772767856,
							},
							["护甲"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 25,
								["uptime"] = 544,
								["id"] = "护甲",
								["appliedamt"] = 25,
								["targets"] = {
								},
								["actived_at"] = 1590920404,
							},
							["寒冰护体"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 53,
								["uptime"] = 554,
								["id"] = "寒冰护体",
								["appliedamt"] = 53,
								["targets"] = {
								},
								["actived_at"] = 9545530082,
							},
							["法力护盾"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = "法力护盾",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰甲术"] = {
								["counter"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "冰甲术",
								["uptime"] = 167,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["洛丹伦的回响"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "洛丹伦的回响",
								["appliedamt"] = 1,
								["targets"] = {
								},
								["actived_at"] = 1590923081,
							},
							["耐力"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 14,
								["uptime"] = 305,
								["id"] = "耐力",
								["appliedamt"] = 14,
								["targets"] = {
								},
								["actived_at"] = 1590920404,
							},
							["精神"] = {
								["counter"] = 0,
								["activedamt"] = 19,
								["appliedamt"] = 19,
								["id"] = "精神",
								["uptime"] = 449,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["抗性"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "抗性",
								["uptime"] = 34,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["奥术智慧"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 21,
								["uptime"] = 620,
								["id"] = "奥术智慧",
								["appliedamt"] = 21,
								["targets"] = {
								},
								["actived_at"] = 1590922627,
							},
							["急救"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "急救",
								["uptime"] = 2,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["喝水"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = "喝水",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["无荣誉目标"] = {
								["counter"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["actived_at"] = 1590921194,
								["id"] = "无荣誉目标",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["防护冰霜结界"] = {
								["counter"] = 0,
								["appliedamt"] = 25,
								["activedamt"] = 25,
								["actived_at"] = 28636533944,
								["id"] = "防护冰霜结界",
								["uptime"] = 154,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["闪现术"] = {
								["counter"] = 0,
								["appliedamt"] = 16,
								["activedamt"] = 16,
								["actived_at"] = 14318254268,
								["id"] = "闪现术",
								["uptime"] = 7,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["能量无常"] = {
								["counter"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = "能量无常",
								["uptime"] = 181,
								["targets"] = {
								},
								["refreshamt"] = 44,
							},
							["节能施法"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "节能施法",
								["uptime"] = 92,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["interrompeu_oque"] = {
						["暗影箭"] = 4,
						["寒冰箭"] = 10,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 1307,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["interrupt_targets"] = {
						["斯库尔"] = 2,
						["骷髅守护者"] = 12,
					},
					["grupo"] = true,
					["spell_cast"] = {
						["法术反制"] = 17,
						["暴风雪"] = 44,
						["寒冰护体"] = 8,
						["魔爆术"] = 3,
						["射击"] = 1,
						["急速冷却"] = 1,
						["急救"] = 1,
						["冰霜新星"] = 41,
						["火焰冲击"] = 18,
						["奥术飞弹"] = 9,
						["寒冰箭"] = 43,
						["治疗药水"] = 2,
						["斯坦索姆圣水"] = 2,
						["防护冰霜结界"] = 1,
						["闪现术"] = 16,
						["恢复法力"] = 2,
						["冰锥术"] = 15,
					},
					["buff_uptime"] = 5495,
					["debuff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["interrupt"] = 14.074665,
					["serial"] = "Player-4920-01DA4323",
					["nome"] = "亡者农药",
				}, -- [1]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["冰冻"] = {
								["counter"] = 0,
								["appliedamt"] = 0,
								["activedamt"] = -1,
								["actived_at"] = 1590910009,
								["id"] = "冰冻",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰霜新星"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["uptime"] = 128,
								["id"] = "冰霜新星",
								["appliedamt"] = 94,
								["targets"] = {
								},
								["actived_at"] = 1590921381,
							},
							["寒冰箭"] = {
								["counter"] = 0,
								["activedamt"] = -2,
								["appliedamt"] = 10,
								["id"] = "寒冰箭",
								["uptime"] = 47,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰锥术"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 9,
								["id"] = "冰锥术",
								["uptime"] = 20,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["暴风雪"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = -272,
								["uptime"] = 575,
								["id"] = "暴风雪",
								["appliedamt"] = 1230,
								["targets"] = {
								},
								["actived_at"] = 3181848569,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 5450,
					["classe"] = "MAGE",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["法术反制"] = {
								["id"] = "法术反制",
								["counter"] = 1,
								["targets"] = {
									["斯库尔"] = 1,
									["要水收钱"] = 0,
								},
								["interrompeu_oque"] = {
									["寒冰箭"] = 1,
								},
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["魔法抑制"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 37,
								["uptime"] = 901,
								["id"] = "魔法抑制",
								["appliedamt"] = 37,
								["targets"] = {
								},
								["actived_at"] = 11136444243,
							},
							["奥术光辉"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 36,
								["uptime"] = 728,
								["id"] = "奥术光辉",
								["appliedamt"] = 36,
								["targets"] = {
								},
								["actived_at"] = 7954591398,
							},
							["魔甲术"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 50,
								["uptime"] = 1089,
								["id"] = "魔甲术",
								["appliedamt"] = 50,
								["targets"] = {
								},
								["actived_at"] = 14318279777,
							},
							["护甲"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 19,
								["uptime"] = 404,
								["id"] = "护甲",
								["appliedamt"] = 19,
								["targets"] = {
								},
								["actived_at"] = 4772754566,
							},
							["寒冰护体"] = {
								["counter"] = 0,
								["activedamt"] = 26,
								["appliedamt"] = 26,
								["id"] = "寒冰护体",
								["uptime"] = 438,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰甲术"] = {
								["counter"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = "冰甲术",
								["uptime"] = 80,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["洛丹伦的回响"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "洛丹伦的回响",
								["appliedamt"] = 1,
								["targets"] = {
								},
								["actived_at"] = 1590923081,
							},
							["耐力"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 17,
								["uptime"] = 339,
								["id"] = "耐力",
								["appliedamt"] = 17,
								["targets"] = {
								},
								["actived_at"] = 3181831878,
							},
							["精神"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 8,
								["uptime"] = 150,
								["id"] = "精神",
								["appliedamt"] = 8,
								["targets"] = {
								},
								["actived_at"] = 3181837346,
							},
							["奥术智慧"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 17,
								["uptime"] = 441,
								["id"] = "奥术智慧",
								["appliedamt"] = 17,
								["targets"] = {
								},
								["actived_at"] = 6363688379,
							},
							["节能施法"] = {
								["counter"] = 0,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = "节能施法",
								["uptime"] = 23,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["进食"] = {
								["counter"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["actived_at"] = 1590925074,
								["id"] = "进食",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["能量无常"] = {
								["counter"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = "能量无常",
								["uptime"] = 156,
								["targets"] = {
								},
								["refreshamt"] = 33,
							},
							["无荣誉目标"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3181846019,
								["id"] = "无荣誉目标",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["防护冰霜结界"] = {
								["counter"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = "防护冰霜结界",
								["uptime"] = 155,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["闪现术"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 18,
								["uptime"] = 6,
								["id"] = "闪现术",
								["appliedamt"] = 18,
								["targets"] = {
								},
								["actived_at"] = 15909197835,
							},
							["喝水"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["uptime"] = 0,
								["id"] = "喝水",
								["appliedamt"] = 2,
								["targets"] = {
								},
								["actived_at"] = 3181852985,
							},
							["呀啊啊啊啊"] = {
								["counter"] = 0,
								["appliedamt"] = 29,
								["activedamt"] = 29,
								["actived_at"] = 7954602774,
								["id"] = "呀啊啊啊啊",
								["uptime"] = 540,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["interrompeu_oque"] = {
						["寒冰箭"] = 1,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 770,
					["pets"] = {
					},
					["interrupt"] = 1.004875,
					["interrupt_targets"] = {
						["斯库尔"] = 1,
						["要水收钱"] = 0,
					},
					["grupo"] = true,
					["spell_cast"] = {
						["变异鱼大餐"] = 1,
						["火焰冲击"] = 25,
						["冰霜新星"] = 22,
						["法术反制"] = 3,
						["寒冰箭"] = 45,
						["魔爆术"] = 8,
						["冰锥术"] = 14,
						["暴风雪"] = 44,
						["寒冰护体"] = 4,
						["斯坦索姆圣水"] = 3,
						["奥术飞弹"] = 5,
						["补充法力"] = 2,
						["防护冰霜结界"] = 2,
						["闪现术"] = 16,
						["恢复法力"] = 2,
						["呀啊啊啊啊"] = 1,
					},
					["nome"] = "我瞿李媚",
					["tipo"] = 4,
					["last_event"] = 0,
					["buff_uptime_targets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["serial"] = "Player-4920-01DA138E",
					["boss_fight_component"] = true,
				}, -- [2]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["冰霜新星"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 57,
								["id"] = "冰霜新星",
								["uptime"] = 54,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰锥术"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = -2,
								["uptime"] = 6,
								["id"] = "冰锥术",
								["appliedamt"] = 2,
								["targets"] = {
								},
								["actived_at"] = 1590924653,
							},
							["冰冻"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 3,
								["id"] = "冰冻",
								["uptime"] = 22,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["暴风雪"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = -61,
								["uptime"] = 329,
								["id"] = "暴风雪",
								["appliedamt"] = 933,
								["targets"] = {
								},
								["actived_at"] = 3181848911,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 3381,
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["喝水"] = {
								["counter"] = 0,
								["appliedamt"] = 4,
								["activedamt"] = 4,
								["actived_at"] = 4772752053,
								["id"] = "喝水",
								["uptime"] = 25,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["节能施法"] = {
								["counter"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = "节能施法",
								["uptime"] = 18,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["进食"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3181848192,
								["id"] = "进食",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["寒冰屏障"] = {
								["counter"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = "寒冰屏障",
								["uptime"] = 24,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["寒冰护体"] = {
								["counter"] = 0,
								["activedamt"] = 42,
								["appliedamt"] = 42,
								["id"] = "寒冰护体",
								["uptime"] = 751,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["护甲"] = {
								["counter"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = "护甲",
								["uptime"] = 252,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["无荣誉目标"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["uptime"] = 0,
								["id"] = "无荣誉目标",
								["appliedamt"] = 2,
								["targets"] = {
								},
								["actived_at"] = 3181846019,
							},
							["力量"] = {
								["counter"] = 0,
								["activedamt"] = 11,
								["appliedamt"] = 11,
								["id"] = "力量",
								["uptime"] = 252,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["敏捷"] = {
								["counter"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "敏捷",
								["uptime"] = 57,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["奥术智慧"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "奥术智慧",
								["uptime"] = 403,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰甲术"] = {
								["counter"] = 0,
								["activedamt"] = 50,
								["appliedamt"] = 50,
								["id"] = "冰甲术",
								["uptime"] = 1281,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["洛丹伦的回响"] = {
								["counter"] = 0,
								["appliedamt"] = 8,
								["activedamt"] = 8,
								["actived_at"] = 3181843497,
								["id"] = "洛丹伦的回响",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["闪现术"] = {
								["counter"] = 0,
								["appliedamt"] = 3,
								["activedamt"] = 3,
								["actived_at"] = 1590920411,
								["id"] = "闪现术",
								["uptime"] = 1,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["唤醒"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "唤醒",
								["uptime"] = 8,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["精神"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "精神",
								["uptime"] = 309,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 411,
					["buff_uptime_targets"] = {
					},
					["spec"] = 64,
					["grupo"] = true,
					["spell_cast"] = {
						["寒冰箭"] = 20,
						["急速冷却"] = 2,
						["奥术智慧"] = 0,
						["冰霜新星"] = 10,
						["冰锥术"] = 18,
						["火焰冲击"] = 12,
						["闪现术"] = 3,
						["暴风雪"] = 33,
						["寒冰护体"] = 8,
						["唤醒"] = 1,
						["寒冰屏障"] = 3,
						["冰甲术"] = 0,
						["魔爆术"] = 3,
						["射击"] = 4,
						["法术反制"] = 2,
						["补充法力"] = 2,
					},
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["pets"] = {
					},
					["nome"] = "潇潇",
					["serial"] = "Player-4920-022A2037",
					["debuff_uptime_targets"] = {
					},
				}, -- [3]
				{
					["monster"] = true,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["spell_cast"] = {
						["奥术箭"] = 32,
						["寒冰箭"] = 45,
						["暗影箭"] = 69,
					},
					["nome"] = "骷髅守护者",
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["serial"] = "Creature-0-4517-329-15215-10390-0003535783",
					["flag_original"] = 2632,
				}, -- [4]
				{
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["boss_fight_component"] = true,
					["last_event"] = 0,
					["spell_cast"] = {
						["击退"] = 10,
					},
					["nome"] = "缝补憎恶",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["pets"] = {
					},
					["serial"] = "Creature-0-4889-329-20975-10414-0001535B44",
					["monster"] = true,
				}, -- [5]
				{
					["flag_original"] = 1300,
					["nome"] = "偸心戦",
					["grupo"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["buff_uptime"] = 0,
					["classe"] = "WARRIOR",
					["last_event"] = 0,
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["counter"] = 0,
								["appliedamt"] = 4,
								["activedamt"] = 4,
								["actived_at"] = 6363668637,
								["id"] = "无荣誉目标",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-01DBAA02",
					["buff_uptime_targets"] = {
					},
				}, -- [6]
				{
					["flag_original"] = 1300,
					["nome"] = "沉默之下",
					["grupo"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["buff_uptime"] = 0,
					["classe"] = "WARLOCK",
					["last_event"] = 0,
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["counter"] = 0,
								["appliedamt"] = 4,
								["activedamt"] = 4,
								["actived_at"] = 6363668637,
								["id"] = "无荣誉目标",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-021D0F5E",
					["buff_uptime_targets"] = {
					},
				}, -- [7]
				{
					["monster"] = true,
					["flag_original"] = 2632,
					["boss_fight_component"] = true,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["spell_cast"] = {
						["召唤破碎的死尸"] = 106,
					},
					["fight_component"] = true,
					["tipo"] = 4,
					["last_event"] = 0,
					["serial"] = "Creature-0-4514-329-15671-10381-0001D3710C",
					["nome"] = "被毁坏的死尸",
				}, -- [8]
				{
					["flag_original"] = 2632,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 162,
					["spellschool"] = 16,
					["nome"] = "寒冰箭",
					["debuff_uptime_targets"] = {
						["亡者农药"] = {
							["uptime"] = 68,
							["refreshamt"] = 0,
							["activedamt"] = -1,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["我瞿李媚"] = {
							["uptime"] = 90,
							["refreshamt"] = 0,
							["activedamt"] = -5,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["潇潇"] = {
							["uptime"] = 4,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["damage_twin"] = "斯库尔",
					["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
					["damage_spellid"] = 0,
					["boss_fight_component"] = true,
				}, -- [9]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "斯库尔",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
					["spell_cast"] = {
						["奥术箭"] = 9,
						["寒冰箭"] = 18,
						["冰霜震击"] = 3,
					},
				}, -- [10]
				{
					["flag_original"] = 2632,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 13,
					["spellschool"] = 16,
					["nome"] = "冰霜震击",
					["debuff_uptime_targets"] = {
						["亡者农药"] = {
							["uptime"] = 8,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["我瞿李媚"] = {
							["uptime"] = 0,
							["refreshamt"] = 0,
							["activedamt"] = 1,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["潇潇"] = {
							["uptime"] = 5,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["damage_twin"] = "斯库尔",
					["serial"] = "Creature-0-4887-329-8197-10393-000053744B",
					["damage_spellid"] = "冰霜震击",
					["boss_fight_component"] = true,
				}, -- [11]
				{
					["fight_component"] = true,
					["boss_fight_component"] = true,
					["nome"] = "恶疫食尸鬼",
					["last_event"] = 0,
					["spell_cast"] = {
						["食尸鬼瘟疫"] = 1,
						["狂怒"] = 42,
					},
					["flag_original"] = 2632,
					["pets"] = {
					},
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-4887-329-16186-10405-000053827C",
					["monster"] = true,
				}, -- [12]
				{
					["flag_original"] = 66888,
					["classe"] = "UNGROUPPLAYER",
					["fight_component"] = true,
					["interrupt"] = 1.008156,
					["interrupt_targets"] = {
						["酒歌没歌了"] = 1,
					},
					["nome"] = "灬争渡灬",
					["enemy"] = true,
					["spell_cast"] = {
						["魔爆术"] = 3,
						["闪现术"] = 1,
						["法术反制"] = 1,
					},
					["last_event"] = 0,
					["pets"] = {
					},
					["tipo"] = 4,
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["法术反制"] = {
								["id"] = "法术反制",
								["counter"] = 1,
								["targets"] = {
									["酒歌没歌了"] = 1,
								},
								["interrompeu_oque"] = {
									["次级治疗波"] = 1,
								},
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-01DBA830",
					["interrompeu_oque"] = {
						["次级治疗波"] = 1,
					},
				}, -- [13]
				{
					["flag_original"] = 68136,
					["nome"] = "弗雷斯特恩",
					["boss_fight_component"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
					["spell_cast"] = {
						["挫志怒吼"] = 1,
						["射击"] = 1,
					},
				}, -- [14]
				{
					["flag_original"] = 68136,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["debuff_uptime"] = 8,
					["spellschool"] = 1,
					["nome"] = "眩晕",
					["debuff_uptime_targets"] = {
						["潇潇"] = {
							["uptime"] = 4,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["亡者农药"] = {
							["uptime"] = 4,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
					["last_event"] = 0,
					["damage_twin"] = "弗雷斯特恩",
					["tipo"] = 4,
					["damage_spellid"] = "眩晕",
					["boss_fight_component"] = true,
				}, -- [15]
				{
					["flag_original"] = 68136,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["debuff_uptime"] = 34,
					["spellschool"] = 1,
					["nome"] = "挫志怒吼",
					["debuff_uptime_targets"] = {
						["潇潇"] = {
							["uptime"] = 4,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["我瞿李媚"] = {
							["uptime"] = 0,
							["refreshamt"] = 0,
							["activedamt"] = -2,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["亡者农药"] = {
							["uptime"] = 30,
							["refreshamt"] = 0,
							["activedamt"] = -1,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["serial"] = "Creature-0-4999-329-27480-10558-0000538B5E",
					["last_event"] = 0,
					["damage_twin"] = "弗雷斯特恩",
					["tipo"] = 4,
					["damage_spellid"] = "挫志怒吼",
					["boss_fight_component"] = true,
				}, -- [16]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "骷髅狂战士",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-4999-329-27480-10391-0006D38B5F",
					["spell_cast"] = {
						["挫志怒吼"] = 3,
					},
				}, -- [17]
				{
					["fight_component"] = true,
					["tipo"] = 4,
					["nome"] = "圣光一闪",
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["last_event"] = 0,
					["flag_original"] = 66888,
					["serial"] = "Player-4920-0228564A",
					["spell_cast"] = {
						["自由祝福"] = 1,
					},
				}, -- [18]
				{
					["fight_component"] = true,
					["nome"] = "鬼魂市民",
					["spell_cast"] = {
						["衰弱之触"] = 5,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-4504-329-30439-10384-0003538F3D",
					["flag_original"] = 2600,
				}, -- [19]
				{
					["fight_component"] = true,
					["tipo"] = 4,
					["nome"] = "要水收钱",
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["last_event"] = 0,
					["flag_original"] = 66888,
					["serial"] = "Player-4920-01D6E9FD",
					["spell_cast"] = {
						["魔爆术"] = 1,
						["闪现术"] = 1,
					},
				}, -- [20]
				{
					["fight_component"] = true,
					["tipo"] = 4,
					["nome"] = "高端法爷",
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["last_event"] = 0,
					["flag_original"] = 66888,
					["serial"] = "Player-4920-01D6EAA0",
					["spell_cast"] = {
						["魔爆术"] = 2,
						["冰霜新星"] = 1,
						["冰锥术"] = 1,
					},
				}, -- [21]
				{
					["fight_component"] = true,
					["nome"] = "石翼石像鬼",
					["spell_cast"] = {
						["破甲攻击"] = 1,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["classe"] = "PET",
					["serial"] = "Creature-0-4888-329-12918-10408-0000539665",
					["flag_original"] = 74312,
				}, -- [22]
				{
					["monster"] = true,
					["nome"] = "鬼魅掠夺者",
					["tipo"] = 4,
					["pets"] = {
					},
					["spell_cast"] = {
						["射击"] = 0,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4514-1-262-11686-00001DAF75",
					["classe"] = "UNKNOW",
				}, -- [23]
				{
					["flag_original"] = 1047,
					["ress_targets"] = {
						["无情萨满"] = 0,
					},
					["buff_uptime"] = 0,
					["classe"] = "SHAMAN",
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["id"] = "无荣誉目标",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["ress"] = 0,
					["buff_uptime_targets"] = {
					},
					["spec"] = 263,
					["grupo"] = true,
					["spell_cast"] = {
						["先祖之魂"] = 0,
					},
					["ress_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[0] = {
								["id"] = 0,
								["targets"] = {
									["无情萨满"] = 0,
								},
								["counter"] = 0,
							},
						},
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["nome"] = "鲁总",
					["serial"] = "Player-4920-022E7DE4",
					["pets"] = {
					},
				}, -- [24]
				{
					["fight_component"] = true,
					["nome"] = "来瓶老雪",
					["enemy"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						["真言术：盾"] = 0,
					},
					["flag_original"] = 66888,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-0219F0FF",
					["classe"] = "UNGROUPPLAYER",
				}, -- [25]
				{
					["flag_original"] = 1047,
					["buff_uptime_targets"] = {
					},
					["spec"] = 64,
					["grupo"] = true,
					["buff_uptime"] = 0,
					["nome"] = "就是个厨子",
					["pets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["id"] = "无荣誉目标",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["魔法抑制"] = {
								["id"] = "魔法抑制",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["奥术智慧"] = {
								["id"] = "奥术智慧",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["魔甲术"] = {
								["id"] = "魔甲术",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-4920-01D128EF",
					["classe"] = "MAGE",
				}, -- [26]
				{
					["flag_original"] = 1047,
					["buff_uptime_targets"] = {
					},
					["grupo"] = true,
					["nome"] = "喔愺",
					["spell_cast"] = {
						["消失"] = 0,
					},
					["tipo"] = 4,
					["pets"] = {
					},
					["last_event"] = 0,
					["buff_uptime"] = 0,
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["id"] = "无荣誉目标",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["潜行"] = {
								["id"] = "潜行",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-4920-0231F4BA",
					["classe"] = "ROGUE",
				}, -- [27]
				{
					["flag_original"] = 1047,
					["nome"] = "无情萨满",
					["grupo"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["classe"] = "SHAMAN",
					["buff_uptime"] = 0,
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["id"] = "无荣誉目标",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-4920-01DAB206",
					["last_event"] = 0,
				}, -- [28]
				{
					["fight_component"] = true,
					["nome"] = "闪闪光头",
					["enemy"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						["魔爆术"] = 0,
					},
					["flag_original"] = 1352,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-0203EB0D",
					["classe"] = "UNGROUPPLAYER",
				}, -- [29]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1590908858,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["cleu_timeline"] = {
		},
		["combat_counter"] = 32,
		["totals"] = {
			2545476.437248, -- [1]
			31867.205607, -- [2]
			{
				0, -- [1]
				[0] = 17376.106224,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 16.087696,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
			["voidzone_damage"] = 0,
			["frags_total"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "15:10:16",
		["end_time"] = 809189.6,
		["totals_grupo"] = {
			2461521.48283, -- [1]
			31867.238525, -- [2]
			{
				0, -- [1]
				[0] = 16271.102058,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 15.07954,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
		},
		["segments_added"] = {
			{
				["elapsed"] = 31.0089999999618,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "20:26:42",
			}, -- [1]
			{
				["elapsed"] = 25.0139999999665,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "20:25:12",
			}, -- [2]
			{
				["elapsed"] = 40.0009999999311,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:47:23",
			}, -- [3]
			{
				["elapsed"] = 56.0119999999879,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:42:58",
			}, -- [4]
			{
				["elapsed"] = 46.0010000000475,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:37:54",
			}, -- [5]
			{
				["elapsed"] = 32.0090000000782,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:35:27",
			}, -- [6]
			{
				["elapsed"] = 26.0039999999572,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:33:46",
			}, -- [7]
			{
				["elapsed"] = 10.0080000000307,
				["type"] = 0,
				["name"] = "高端法爷",
				["clock"] = "19:31:45",
			}, -- [8]
			{
				["elapsed"] = 3.00300000002608,
				["type"] = 0,
				["name"] = "高端法爷",
				["clock"] = "19:31:36",
			}, -- [9]
			{
				["elapsed"] = 7.00500000000466,
				["type"] = 0,
				["name"] = "小俊俊",
				["clock"] = "19:30:53",
			}, -- [10]
			{
				["elapsed"] = 10.0080000000307,
				["type"] = 0,
				["name"] = "要水收钱",
				["clock"] = "19:30:38",
			}, -- [11]
			{
				["elapsed"] = 52.0099999998929,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:23:01",
			}, -- [12]
			{
				["elapsed"] = 30.0070000000997,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:20:08",
			}, -- [13]
			{
				["elapsed"] = 20.0029999999097,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:17:51",
			}, -- [14]
			{
				["elapsed"] = 25.0019999999786,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:16:03",
			}, -- [15]
			{
				["elapsed"] = 37.0100000000093,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:12:51",
			}, -- [16]
			{
				["elapsed"] = 30.0080000000307,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:09:37",
			}, -- [17]
			{
				["elapsed"] = 18.0139999999665,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:07:11",
			}, -- [18]
			{
				["elapsed"] = 25.0039999999572,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:05:19",
			}, -- [19]
			{
				["elapsed"] = 10.1469999999972,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:04:34",
			}, -- [20]
			{
				["elapsed"] = 30.0089999999618,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:02:27",
			}, -- [21]
			{
				["elapsed"] = 73.1089999999385,
				["type"] = 0,
				["name"] = "弗雷斯特恩",
				["clock"] = "18:57:07",
			}, -- [22]
			{
				["elapsed"] = 21.0010000000475,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "18:54:45",
			}, -- [23]
			{
				["elapsed"] = 24.0130000000354,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "18:53:11",
			}, -- [24]
			{
				["elapsed"] = 25.0050000000047,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "18:46:31",
			}, -- [25]
			{
				["elapsed"] = 44.0139999999665,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "18:42:31",
			}, -- [26]
			{
				["elapsed"] = 22.0010000000475,
				["type"] = 6,
				["name"] = "斯库尔",
				["clock"] = "18:40:39",
			}, -- [27]
			{
				["elapsed"] = 32.0089999999618,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "18:39:38",
			}, -- [28]
			{
				["elapsed"] = 45.0040000000736,
				["type"] = 6,
				["name"] = "斯库尔",
				["clock"] = "18:36:21",
			}, -- [29]
			{
				["elapsed"] = 25.0019999999786,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "18:34:22",
			}, -- [30]
		},
		["hasSaved"] = true,
		["spells_cast_timeline"] = {
		},
		["data_fim"] = "20:27:13",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["frags"] = {
		},
		["start_time"] = 807730.374,
		["TimeData"] = {
		},
		["cleu_events"] = {
			["n"] = 1,
		},
	},
	["force_font_outline"] = "",
	["local_instances_config"] = {
		{
			["segment"] = -1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -349.866256713867,
					["x"] = 751.715698242188,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -171.866271972656,
					["x"] = 751.715698242188,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["character_data"] = {
		["logons"] = 3,
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-4920-022A2037"] = 64,
	},
}
