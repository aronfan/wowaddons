
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 10,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004257,
							["monster"] = true,
							["damage_from"] = {
							},
							["targets"] = {
								["专诸刺秦"] = 638,
								["潇潇"] = 78,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["timeMachine"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 716.004257,
							["on_hold"] = true,
							["dps_started"] = true,
							["total"] = 716.004257,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-4514-1-262-11686-00001DAF8F",
							["nome"] = "鬼魅掠夺者",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 84,
										["targets"] = {
											["专诸刺秦"] = 638,
											["潇潇"] = 78,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 716,
										["n_min"] = 61,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 716,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 7,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.004257,
							["start_time"] = 1587393113,
							["delay"] = 1587393134,
							["last_event"] = 1587393134,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001038,
							["damage_from"] = {
								["鬼魅掠夺者"] = true,
								["鬼魅袭击者"] = true,
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001038,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.001038,
							["classe"] = "MAGE",
							["serial"] = "Player-4920-022A2037",
							["nome"] = "潇潇",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["end_time"] = 1587393127,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 295.001038,
							["start_time"] = 1587393127,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 274.001093,
							["monster"] = true,
							["damage_from"] = {
							},
							["targets"] = {
								["潇潇"] = 155,
								["壹亿肆"] = 119,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 274.001093,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 274.001093,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-4514-1-262-11687-00001DAF7F",
							["nome"] = "鬼魅袭击者",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 108,
										["targets"] = {
											["潇潇"] = 155,
											["壹亿肆"] = 119,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 274,
										["n_min"] = 25,
										["g_dmg"] = 0,
										["counter"] = 8,
										["MISS"] = 2,
										["total"] = 274,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1587393127,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.001093,
							["start_time"] = 1587393120,
							["delay"] = 1587393108,
							["last_event"] = 1587393108,
						}, -- [3]
						{
							["flag_original"] = -2147483648,
							["totalabsorbed"] = 0.00194,
							["damage_from"] = {
							},
							["targets"] = {
								["专诸刺秦"] = 70,
								["壹亿肆"] = 89,
								["潇潇"] = 62,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 221.00194,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 221.00194,
							["classe"] = "UNKNOW",
							["serial"] = "",
							["nome"] = "环境伤害 (高处坠落)",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["Falling"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 89,
										["targets"] = {
											["专诸刺秦"] = 70,
											["壹亿肆"] = 89,
											["潇潇"] = 62,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 221,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 221,
										["c_max"] = 0,
										["id"] = "Falling",
										["r_dmg"] = 0,
										["spellschool"] = 3,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1587393127,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.00194,
							["start_time"] = 1587393118,
							["delay"] = 1587393115,
							["last_event"] = 1587393115,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 10,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 155.008404,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["潇潇"] = 155,
							},
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 155,
										["targets_overheal"] = {
										},
										["n_max"] = 108,
										["targets"] = {
											["潇潇"] = 155,
										},
										["n_min"] = 47,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 155,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 155,
										},
										["m_healed"] = 0,
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 155,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.008404,
							["total_without_pet"] = 155.008404,
							["end_time"] = 1587393127,
							["totalover_without_pet"] = 0.008404,
							["fight_component"] = true,
							["total"] = 155.008404,
							["healing_taken"] = 155.008404,
							["serial"] = "Player-4920-022A2037",
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 155,
							},
							["grupo"] = true,
							["classe"] = "MAGE",
							["heal_enemy"] = {
							},
							["start_time"] = 1587393125,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["totaldenied"] = 0.008404,
							["delay"] = 1587393108,
							["last_event"] = 1587393108,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 10,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 10,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "潇潇",
							["buff_uptime"] = 60,
							["spell_cast"] = {
								["奥术智慧"] = 1,
								["冰甲术"] = 1,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["寒冰护体"] = {
										["activedamt"] = 1,
										["id"] = "寒冰护体",
										["targets"] = {
										},
										["uptime"] = 30,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["activedamt"] = 1,
										["id"] = "奥术智慧",
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰甲术"] = {
										["activedamt"] = 1,
										["id"] = "冰甲术",
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4920-022A2037",
							["last_event"] = 1587393127,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "鬼魅掠夺者",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["射击"] = 7,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4514-1-262-11686-00001DAF75",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["combatId"] = 10,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["就是个厨子"] = true,
					["潇潇"] = true,
					["鲁总"] = true,
					["喔愺"] = true,
				},
				["CombatStartedAt"] = 354907.568,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["instance_type"] = "none",
				["enemy"] = "鬼魅掠夺者",
				["combat_counter"] = 30,
				["tempo_start"] = 1587393097,
				["totals"] = {
					1210.963153, -- [1]
					154.994948, -- [2]
					{
						0, -- [1]
						[0] = -0.0010480000000257,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["cleu_timeline"] = {
				},
				["CombatEndedAt"] = 354909.39,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:31:38",
				["end_time"] = 354864.386,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 10,
				["totals_grupo"] = {
					0, -- [1]
					155, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 155.008404,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["潇潇"] = 0.001038,
						}, -- [1]
					},
				},
				["frags"] = {
				},
				["data_fim"] = "22:32:08",
				["TotalElapsedCombatTime"] = 1.82199999998556,
				["CombatSkillCache"] = {
				},
				["spells_cast_timeline"] = {
				},
				["start_time"] = 354834.377,
				["contra"] = "鬼魅掠夺者",
				["TimeData"] = {
				},
			}, -- [1]
			{
				{
					["combatId"] = 9,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 63.00166,
							["damage_from"] = {
							},
							["targets"] = {
								["来瓶老雪"] = 1100,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1100.00166,
							["on_hold"] = false,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1587391260,
							["friendlyfire_total"] = 0,
							["spec"] = 64,
							["nome"] = "潇潇",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 219,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["来瓶老雪"] = 219,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 219,
										["c_max"] = 219,
										["id"] = "魔爆术",
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["a_dmg"] = 219,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 219,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 63,
										["targets"] = {
											["来瓶老雪"] = 63,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 63,
										["n_min"] = 63,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 63,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 397,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["来瓶老雪"] = 397,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 397,
										["c_max"] = 397,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 397,
									},
									["冰锥术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 421,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["来瓶老雪"] = 421,
											["田昊眼成小"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 421,
										["c_max"] = 421,
										["RESIST"] = 1,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 421,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 421,
									},
								},
							},
							["grupo"] = true,
							["total"] = 1100.00166,
							["serial"] = "Player-4920-022A2037",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1587391254,
							["damage_taken"] = 0.00166,
							["start_time"] = 1587391244,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.008338,
							["damage_from"] = {
								["小恶魔提利昂"] = true,
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008338,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.008338,
							["classe"] = "UNGROUPPLAYER",
							["serial"] = "Player-4920-0219F0FF",
							["nome"] = "来瓶老雪",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["真言术：盾"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：盾",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1587391260,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 2001.008338,
							["start_time"] = 1587391260,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["combatId"] = 9,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 9,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 9,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["ress_targets"] = {
								["无情萨满"] = 1,
							},
							["buff_uptime"] = 16,
							["classe"] = "SHAMAN",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["ress"] = 1.00523,
							["buff_uptime_targets"] = {
							},
							["spec"] = 263,
							["grupo"] = true,
							["spell_cast"] = {
								["先祖之魂"] = 1,
							},
							["ress_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									[0] = {
										["id"] = 0,
										["ress"] = 1,
										["targets"] = {
											["无情萨满"] = 1,
										},
										["counter"] = 0,
									},
								},
							},
							["last_event"] = 1587391260,
							["nome"] = "鲁总",
							["pets"] = {
							},
							["serial"] = "Player-4920-022E7DE4",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["冰锥术"] = {
										["activedamt"] = -1,
										["id"] = "冰锥术",
										["targets"] = {
										},
										["actived_at"] = 1587391249,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰霜新星"] = {
										["activedamt"] = 0,
										["id"] = "冰霜新星",
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 48,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["寒冰护体"] = {
										["activedamt"] = 1,
										["id"] = "寒冰护体",
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["activedamt"] = 1,
										["id"] = "奥术智慧",
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰甲术"] = {
										["activedamt"] = 1,
										["id"] = "冰甲术",
										["targets"] = {
										},
										["uptime"] = 16,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 2,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["魔爆术"] = 2,
								["冰锥术"] = 1,
								["冰霜新星"] = 1,
								["火焰冲击"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1587391260,
							["nome"] = "潇潇",
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 66888,
							["nome"] = "来瓶老雪",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["真言术：盾"] = 1,
							},
							["last_event"] = 0,
							["enemy"] = true,
							["serial"] = "Player-4920-0219F0FF",
							["classe"] = "UNGROUPPLAYER",
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 9,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["就是个厨子"] = true,
					["鲁总"] = true,
					["潇潇"] = true,
					["喔愺"] = true,
					["无情萨满"] = true,
				},
				["CombatStartedAt"] = 354833.977,
				["tempo_start"] = 1587391244,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					1099.950692, -- [1]
					-0.005907, -- [2]
					{
						0, -- [1]
						[0] = -0.00322099999999637,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 1,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					1100, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 1,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "22:01:00",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "来瓶老雪",
				["TotalElapsedCombatTime"] = 3.93400000000838,
				["CombatEndedAt"] = 353006.928,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:00:44",
				["end_time"] = 352997.038,
				["combat_id"] = 9,
				["overall_added"] = true,
				["combat_counter"] = 29,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["潇潇"] = 1100.00166,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["来瓶老雪"] = 1,
					["田昊眼成小"] = 1,
				},
				["start_time"] = 352981.027,
				["contra"] = "来瓶老雪",
				["TimeData"] = {
				},
			}, -- [2]
			{
				{
					["combatId"] = 8,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1352,
							["totalabsorbed"] = 518.004962,
							["damage_from"] = {
								["安东尼达斯丶"] = true,
							},
							["targets"] = {
								["全部一起来吧"] = 845,
								["潇潇"] = 539,
								["安东尼达斯丶"] = 1208,
								["潜行哲"] = 533,
								["黄百万"] = 826,
								["无情萨满"] = 667,
								["菠蘿"] = 752,
								["弟中弟志"] = 267,
								["不做痴情种"] = 518,
								["小懋懋"] = 267,
								["喔愺"] = 823,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["classe"] = "UNGROUPPLAYER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7245.004962,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 7245.004962,
							["end_time"] = 1587391205,
							["friendlyfire_total"] = 0,
							["nome"] = "闪闪光头",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1194,
										["g_amt"] = 0,
										["n_max"] = 282,
										["targets"] = {
											["全部一起来吧"] = 845,
											["潇潇"] = 539,
											["安东尼达斯丶"] = 1208,
											["潜行哲"] = 533,
											["黄百万"] = 826,
											["无情萨满"] = 667,
											["菠蘿"] = 752,
											["弟中弟志"] = 267,
											["不做痴情种"] = 518,
											["小懋懋"] = 267,
											["喔愺"] = 823,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 6051,
										["n_min"] = 196,
										["g_dmg"] = 0,
										["counter"] = 26,
										["total"] = 7245,
										["c_max"] = 408,
										["id"] = "魔爆术",
										["r_dmg"] = 196,
										["spellschool"] = 64,
										["a_dmg"] = 408,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 23,
										["r_amt"] = 1,
										["c_min"] = 391,
									},
								},
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-0203EB0D",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1587391197,
							["damage_taken"] = 1335.004962,
							["start_time"] = 1587391193,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008528,
							["damage_from"] = {
								["闪闪光头"] = true,
							},
							["targets"] = {
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["end_time"] = 1587391205,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008528,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.008528,
							["classe"] = "ROGUE",
							["serial"] = "Player-4920-0231F4BA",
							["nome"] = "喔愺",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 823.008528,
							["start_time"] = 1587391205,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [2]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003616,
							["damage_from"] = {
								["闪闪光头"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003616,
							["on_hold"] = false,
							["end_time"] = 1587391205,
							["dps_started"] = false,
							["total"] = 0.003616,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["nome"] = "潇潇",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["spec"] = 64,
							["serial"] = "Player-4920-022A2037",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 539.003616,
							["start_time"] = 1587391205,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006744,
							["damage_from"] = {
								["闪闪光头"] = true,
							},
							["targets"] = {
							},
							["friendlyfire"] = {
							},
							["pets"] = {
							},
							["end_time"] = 1587391205,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006744,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.006744,
							["classe"] = "SHAMAN",
							["serial"] = "Player-4920-01DAB206",
							["nome"] = "无情萨满",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["grupo"] = true,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 667.006744,
							["start_time"] = 1587391205,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [4]
					},
				}, -- [1]
				{
					["combatId"] = 8,
					["tipo"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["combatId"] = 8,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 354.005221,
							["resource"] = 0.005221,
							["targets"] = {
								["闪闪光头"] = 354,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["passiveover"] = 0.005221,
							["fight_component"] = true,
							["total"] = 354.005221,
							["nome"] = "闪闪光头",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 354,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["闪闪光头"] = 354,
										},
										["counter"] = 1,
									},
								},
							},
							["flag_original"] = 1352,
							["last_event"] = 1587391198,
							["alternatepower"] = 0.005221,
							["tipo"] = 3,
							["serial"] = "Player-4920-0203EB0D",
							["totalover"] = 0.005221,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 8,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["buff_uptime"] = 0,
							["nome"] = "就是个厨子",
							["pets"] = {
							},
							["last_event"] = 1587391193,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["activedamt"] = 1,
										["id"] = "魔法抑制",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["activedamt"] = 1,
										["id"] = "魔甲术",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["activedamt"] = 1,
										["id"] = "奥术智慧",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4920-01D128EF",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "喔愺",
							["buff_uptime"] = 0,
							["spell_cast"] = {
								["消失"] = 1,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["actived_at"] = 1587391197,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4920-0231F4BA",
							["last_event"] = 1587391197,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["nome"] = "无情萨满",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1587391205,
							["buff_uptime"] = 12,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4920-01DAB206",
							["classe"] = "SHAMAN",
						}, -- [3]
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
							},
							["buff_uptime"] = 24,
							["nome"] = "潇潇",
							["pets"] = {
							},
							["last_event"] = 1587391205,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1587391193,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["activedamt"] = 1,
										["id"] = "奥术智慧",
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰甲术"] = {
										["activedamt"] = 1,
										["id"] = "冰甲术",
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [4]
						{
							["flag_original"] = 1352,
							["nome"] = "闪闪光头",
							["tipo"] = 4,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["魔爆术"] = 3,
							},
							["last_event"] = 0,
							["enemy"] = true,
							["serial"] = "Player-4920-0203EB0D",
							["classe"] = "UNGROUPPLAYER",
						}, -- [5]
					},
				}, -- [4]
				{
					["combatId"] = 8,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["就是个厨子"] = true,
					["鲁总"] = true,
					["潇潇"] = true,
					["喔愺"] = true,
					["无情萨满"] = true,
				},
				["CombatStartedAt"] = 352981.027,
				["tempo_start"] = 1587391193,
				["last_events_tables"] = {
					{
						{
							{
								true, -- [1]
								"魔爆术", -- [2]
								272, -- [3]
								1587391193.911, -- [4]
								318, -- [5]
								"闪闪光头", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [1]
							{
								true, -- [1]
								"魔爆术", -- [2]
								395, -- [3]
								1587391195.112, -- [4]
								46, -- [5]
								"闪闪光头", -- [6]
								nil, -- [7]
								64, -- [8]
								false, -- [9]
								349, -- [10]
							}, -- [2]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"无情萨满", -- [6]
							}, -- [3]
						}, -- [1]
						1587391195.578, -- [2]
						"无情萨满", -- [3]
						"SHAMAN", -- [4]
						813, -- [5]
						"0m 1s", -- [6]
						["dead_at"] = 1.66700000001583,
						["dead"] = true,
					}, -- [1]
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					7244.927212, -- [1]
					-0.00866899999982707, -- [2]
					{
						0, -- [1]
						[0] = 354,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "22:00:06",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "闪闪光头",
				["TotalElapsedCombatTime"] = 352942.044,
				["CombatEndedAt"] = 352942.044,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:59:54",
				["end_time"] = 352942.278,
				["combat_id"] = 8,
				["overall_added"] = true,
				["combat_counter"] = 28,
				["spells_cast_timeline"] = {
				},
				["player_last_events"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["潇潇"] = 0.003616,
							["喔愺"] = 0.008528,
							["无情萨满"] = 0.006744,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["潜行哲"] = 1,
					["说情话"] = 1,
				},
				["start_time"] = 352930.267,
				["contra"] = "闪闪光头",
				["TimeData"] = {
				},
			}, -- [3]
		},
	},
	["last_version"] = "v1.13.3.199",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_pets"] = {
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["last_version"] = 11,
		["潇潇"] = {
			"潇潇", -- [1]
			"Interface\\EncounterJournal\\UI-EJ-BOSS-Argent Confessor Paletress", -- [2]
			{
				0, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			}, -- [3]
			"Interface\\PetBattles\\Weather-ArcaneStorm", -- [4]
			{
				0.129609375, -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
			}, -- [5]
			{
				1, -- [1]
				1, -- [2]
				1, -- [3]
			}, -- [6]
			3, -- [7]
		},
		["nextreset"] = 1588680364,
	},
	["last_instance_id"] = 349,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 1587393172,
	["active_profile"] = "潇潇-龙牙",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 0.2,
			["useclasscolors"] = false,
			["animate"] = false,
			["useplayercolor"] = false,
			["showamount"] = false,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["enabled"] = true,
		},
	},
	["cached_talents"] = {
		["Player-4920-022A2037"] = {
			{
				135894, -- [1]
				2, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [1]
			{
				135892, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [2]
			{
				136096, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [3]
			{
				135463, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [4]
			{
				136011, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [5]
			{
				136170, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [6]
			{
				136006, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [7]
			{
				136116, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [8]
			{
				135733, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [9]
			{
				136153, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [10]
			{
				135856, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [11]
			{
				136208, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [12]
			{
				136031, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [13]
			{
				136129, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136222, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [15]
			{
				136048, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [16]
			{
				135812, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [17]
			{
				135821, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [18]
			{
				135818, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [19]
			{
				135815, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [20]
			{
				135807, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [21]
			{
				135813, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [22]
			{
				135826, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [23]
			{
				135808, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [24]
			{
				135805, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [25]
			{
				135827, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [26]
			{
				135806, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [27]
			{
				135820, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [28]
			{
				136115, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [29]
			{
				135903, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [30]
			{
				135817, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [31]
			{
				135824, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [32]
			{
				135850, -- [1]
				2, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [33]
			{
				135846, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [34]
			{
				135989, -- [1]
				3, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [35]
			{
				135855, -- [1]
				4, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [36]
			{
				135842, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [37]
			{
				135840, -- [1]
				2, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [38]
			{
				135864, -- [1]
				3, -- [2]
				2, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [39]
			{
				135845, -- [1]
				3, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [40]
			{
				135865, -- [1]
				1, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [41]
			{
				135857, -- [1]
				3, -- [2]
				3, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [42]
			{
				136141, -- [1]
				2, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [43]
			{
				135860, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [44]
			{
				135849, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135841, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [46]
			{
				135852, -- [1]
				3, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [47]
			{
				135836, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [48]
			{
				135988, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [49]
		},
		["Player-4920-01D128EF"] = {
			{
				135894, -- [1]
				2, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [1]
			{
				135892, -- [1]
				3, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [2]
			{
				136096, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [3]
			{
				135463, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [4]
			{
				136011, -- [1]
				5, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [5]
			{
				136170, -- [1]
				2, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [6]
			{
				136006, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [7]
			{
				136116, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [8]
			{
				135733, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [9]
			{
				136153, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [10]
			{
				135856, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [11]
			{
				136208, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [12]
			{
				136031, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [13]
			{
				136129, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136222, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [15]
			{
				136048, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [16]
			{
				135812, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [17]
			{
				135821, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [18]
			{
				135818, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [19]
			{
				135815, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [20]
			{
				135807, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [21]
			{
				135813, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [22]
			{
				135826, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [23]
			{
				135808, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [24]
			{
				135805, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [25]
			{
				135827, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [26]
			{
				135806, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [27]
			{
				135820, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [28]
			{
				136115, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [29]
			{
				135903, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [30]
			{
				135817, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [31]
			{
				135824, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [32]
			{
				135850, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [33]
			{
				135846, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [34]
			{
				135989, -- [1]
				3, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [35]
			{
				135855, -- [1]
				5, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [36]
			{
				135842, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [37]
			{
				135840, -- [1]
				2, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [38]
			{
				135864, -- [1]
				3, -- [2]
				2, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [39]
			{
				135845, -- [1]
				3, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [40]
			{
				135865, -- [1]
				1, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [41]
			{
				135857, -- [1]
				3, -- [2]
				3, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [42]
			{
				136141, -- [1]
				2, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [43]
			{
				135860, -- [1]
				3, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [44]
			{
				135849, -- [1]
				4, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135841, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [46]
			{
				135852, -- [1]
				3, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [47]
			{
				135836, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [48]
			{
				135988, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [49]
		},
		["Player-4920-022E7DE4"] = {
			{
				136116, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				262, -- [6]
				5, -- [7]
			}, -- [1]
			{
				135807, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				262, -- [6]
				5, -- [7]
			}, -- [2]
			{
				136097, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				262, -- [6]
				2, -- [7]
			}, -- [3]
			{
				136094, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				262, -- [6]
				3, -- [7]
			}, -- [4]
			{
				135817, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				262, -- [6]
				3, -- [7]
			}, -- [5]
			{
				136170, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				262, -- [6]
				1, -- [7]
			}, -- [6]
			{
				135850, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				262, -- [6]
				5, -- [7]
			}, -- [7]
			{
				136014, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				262, -- [6]
				5, -- [7]
			}, -- [8]
			{
				135824, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				1, -- [5]
				262, -- [6]
				2, -- [7]
			}, -- [9]
			{
				136032, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				262, -- [6]
				3, -- [7]
			}, -- [10]
			{
				135791, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				1, -- [5]
				262, -- [6]
				3, -- [7]
			}, -- [11]
			{
				136099, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				1, -- [5]
				262, -- [6]
				2, -- [7]
			}, -- [12]
			{
				135830, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				262, -- [6]
				1, -- [7]
			}, -- [13]
			{
				135990, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				1, -- [5]
				262, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136115, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				262, -- [6]
				1, -- [7]
			}, -- [15]
			{
				136162, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				263, -- [6]
				5, -- [7]
			}, -- [16]
			{
				134952, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				263, -- [6]
				5, -- [7]
			}, -- [17]
			{
				136098, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				263, -- [6]
				2, -- [7]
			}, -- [18]
			{
				132325, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				263, -- [6]
				5, -- [7]
			}, -- [19]
			{
				136095, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				263, -- [6]
				2, -- [7]
			}, -- [20]
			{
				136051, -- [1]
				0, -- [2]
				2, -- [3]
				4, -- [4]
				2, -- [5]
				263, -- [6]
				3, -- [7]
			}, -- [21]
			{
				136023, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				263, -- [6]
				2, -- [7]
			}, -- [22]
			{
				132401, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				2, -- [5]
				263, -- [6]
				1, -- [7]
			}, -- [23]
			{
				136056, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				263, -- [6]
				5, -- [7]
			}, -- [24]
			{
				132152, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				263, -- [6]
				5, -- [7]
			}, -- [25]
			{
				135892, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				263, -- [6]
				5, -- [7]
			}, -- [26]
			{
				135792, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				263, -- [6]
				2, -- [7]
			}, -- [27]
			{
				135814, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				263, -- [6]
				3, -- [7]
			}, -- [28]
			{
				132269, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				263, -- [6]
				1, -- [7]
			}, -- [29]
			{
				132215, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				263, -- [6]
				5, -- [7]
			}, -- [30]
			{
				135963, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				263, -- [6]
				1, -- [7]
			}, -- [31]
			{
				136052, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				264, -- [6]
				5, -- [7]
			}, -- [32]
			{
				135859, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				264, -- [6]
				5, -- [7]
			}, -- [33]
			{
				136080, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				264, -- [6]
				2, -- [7]
			}, -- [34]
			{
				136109, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				264, -- [6]
				3, -- [7]
			}, -- [35]
			{
				136057, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				264, -- [6]
				5, -- [7]
			}, -- [36]
			{
				135860, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				264, -- [6]
				3, -- [7]
			}, -- [37]
			{
				136043, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				264, -- [6]
				5, -- [7]
			}, -- [38]
			{
				136069, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				264, -- [6]
				1, -- [7]
			}, -- [39]
			{
				136041, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				3, -- [5]
				264, -- [6]
				3, -- [7]
			}, -- [40]
			{
				136053, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				264, -- [6]
				5, -- [7]
			}, -- [41]
			{
				136107, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				264, -- [6]
				5, -- [7]
			}, -- [42]
			{
				136044, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				3, -- [5]
				264, -- [6]
				3, -- [7]
			}, -- [43]
			{
				136076, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				264, -- [6]
				1, -- [7]
			}, -- [44]
			{
				135865, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				264, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135861, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				264, -- [6]
				1, -- [7]
			}, -- [46]
		},
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["last_day"] = "20",
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["last_realversion"] = 142,
	["combat_id"] = 10,
	["savedStyles"] = {
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_counter"] = 30,
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.025124,
					["damage_from"] = {
						["腐烂萨特"] = true,
						["深腐纠缠者"] = true,
						["腐化劣魔"] = true,
						["腐烂欺骗者"] = true,
						["毒劣魔"] = true,
						["毒性软泥怪"] = true,
						["洞窟游荡者"] = true,
					},
					["targets"] = {
						["洞窟潜伏者"] = 35967,
						["腐烂欺骗者"] = 109740,
						["毒劣魔"] = 22809,
						["腐烂萨特"] = 71676,
						["腐烂巡影者"] = 20506,
						["毒性软泥怪"] = 88693,
						["腐化劣魔"] = 171,
						["深腐纠缠者"] = 72627,
						["深腐践踏者"] = 49741,
						["洞窟游荡者"] = 25816,
					},
					["on_hold"] = false,
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 497746.025124,
					["colocacao"] = 1,
					["last_event"] = 0,
					["dps_started"] = false,
					["total"] = 497746.025124,
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["nome"] = "就是个厨子",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["火焰冲击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 139,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["深腐纠缠者"] = 139,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 139,
								["c_max"] = 139,
								["id"] = "火焰冲击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["冰霜新星"] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 358,
								["g_amt"] = 0,
								["n_max"] = 31,
								["targets"] = {
									["洞窟潜伏者"] = 91,
									["腐烂欺骗者"] = 355,
									["毒劣魔"] = 57,
									["腐烂萨特"] = 352,
									["腐烂巡影者"] = 29,
									["深腐纠缠者"] = 57,
									["毒性软泥怪"] = 322,
									["深腐践踏者"] = 61,
									["洞窟游荡者"] = 89,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1055,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 42,
								["total"] = 1413,
								["c_max"] = 61,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 36,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 2229,
								["g_amt"] = 0,
								["n_max"] = 311,
								["targets"] = {
									["腐烂萨特"] = 1223,
									["毒性软泥怪"] = 741,
									["深腐纠缠者"] = 1502,
									["毒劣魔"] = 1071,
									["腐烂欺骗者"] = 1479,
									["洞窟游荡者"] = 3448,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 7235,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["total"] = 9464,
								["c_max"] = 463,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["RESIST"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 24,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 745,
								["targets"] = {
									["深腐纠缠者"] = 745,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 745,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 745,
								["c_max"] = 0,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 171,
								["targets"] = {
									["洞窟潜伏者"] = 35343,
									["腐烂欺骗者"] = 107906,
									["毒劣魔"] = 21681,
									["腐烂萨特"] = 67937,
									["腐烂巡影者"] = 20477,
									["毒性软泥怪"] = 86037,
									["腐化劣魔"] = 171,
									["深腐纠缠者"] = 69647,
									["深腐践踏者"] = 49680,
									["洞窟游荡者"] = 18942,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 477821,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2799,
								["total"] = 477821,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2799,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["冰锥术"] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 4378,
								["g_amt"] = 0,
								["n_max"] = 568,
								["targets"] = {
									["腐烂萨特"] = 2164,
									["洞窟潜伏者"] = 533,
									["毒性软泥怪"] = 1593,
									["深腐纠缠者"] = 537,
									["洞窟游荡者"] = 3337,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3786,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 8164,
								["c_max"] = 1136,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 7,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["grupo"] = true,
					["spec"] = 64,
					["serial"] = "Player-4920-01D128EF",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 4727.72752611563,
					["start_time"] = 1587386946,
					["delay"] = 0,
					["damage_taken"] = 4392.025124,
				}, -- [1]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 63.033802,
					["damage_from"] = {
						["鬼魅掠夺者"] = true,
						["环境伤害 (高处坠落)"] = true,
						["毒劣魔"] = true,
						["鬼魅袭击者"] = true,
						["闪闪光头"] = true,
					},
					["targets"] = {
						["坐骑人"] = 605,
						["洞窟潜伏者"] = 6156,
						["来瓶老雪"] = 1100,
						["腐烂欺骗者"] = 20687,
						["毒劣魔"] = 9199,
						["鼠公子"] = 696,
						["腐烂萨特"] = 15459,
						["腐烂巡影者"] = 3430,
						["深腐纠缠者"] = 13116,
						["腐化劣魔"] = 70,
						["毒性软泥怪"] = 22331,
						["深腐践踏者"] = 10117,
						["洞窟游荡者"] = 4152,
					},
					["on_hold"] = false,
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 107118.033802,
					["colocacao"] = 2,
					["last_event"] = 0,
					["dps_started"] = false,
					["total"] = 107118.033802,
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["nome"] = "潇潇",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["火焰冲击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 397,
								["g_amt"] = 0,
								["n_max"] = 269,
								["targets"] = {
									["坐骑人"] = 269,
									["来瓶老雪"] = 397,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 269,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 666,
								["c_max"] = 397,
								["id"] = "火焰冲击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["冰霜新星"] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 453,
								["g_amt"] = 0,
								["n_max"] = 64,
								["targets"] = {
									["坐骑人"] = 120,
									["来瓶老雪"] = 63,
									["腐烂欺骗者"] = 292,
									["毒劣魔"] = 305,
									["鼠公子"] = 54,
									["腐烂萨特"] = 286,
									["毒性软泥怪"] = 63,
									["深腐纠缠者"] = 62,
									["深腐践踏者"] = 58,
									["洞窟游荡者"] = 248,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1098,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 22,
								["total"] = 1551,
								["c_max"] = 120,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 18,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 219,
								["g_amt"] = 0,
								["n_max"] = 156,
								["targets"] = {
									["毒劣魔"] = 1506,
									["鼠公子"] = 268,
									["来瓶老雪"] = 219,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1774,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 1993,
								["c_max"] = 219,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["RESIST"] = 1,
								["a_dmg"] = 219,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 12,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 257,
								["targets"] = {
									["深腐纠缠者"] = 257,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 257,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 257,
								["c_max"] = 0,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 70,
								["targets"] = {
									["洞窟潜伏者"] = 6156,
									["腐烂欺骗者"] = 19516,
									["毒劣魔"] = 5598,
									["腐烂萨特"] = 14275,
									["腐烂巡影者"] = 3430,
									["深腐纠缠者"] = 12797,
									["腐化劣魔"] = 70,
									["毒性软泥怪"] = 21830,
									["深腐践踏者"] = 9653,
									["洞窟游荡者"] = 3219,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 96544,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1380,
								["total"] = 96544,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1380,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["冰锥术"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1201,
								["g_amt"] = 0,
								["n_max"] = 233,
								["targets"] = {
									["坐骑人"] = 216,
									["来瓶老雪"] = 421,
									["腐烂欺骗者"] = 879,
									["毒劣魔"] = 1790,
									["鼠公子"] = 374,
									["腐烂萨特"] = 898,
									["毒性软泥怪"] = 438,
									["田昊眼成小"] = 0,
									["深腐践踏者"] = 406,
									["洞窟游荡者"] = 685,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4906,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 6107,
								["c_max"] = 421,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["RESIST"] = 2,
								["a_dmg"] = 421,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 22,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["grupo"] = true,
					["spec"] = 64,
					["serial"] = "Player-4920-022A2037",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 972.856831425375,
					["start_time"] = 1587386934,
					["delay"] = 0,
					["damage_taken"] = 1730.033802,
				}, -- [2]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 544.021595,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["就是个厨子"] = 1499,
					},
					["dps_started"] = false,
					["pets"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 1499.021595,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 1499.021595,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["nome"] = "洞窟游荡者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["击倒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 138,
								["targets"] = {
									["就是个厨子"] = 138,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 138,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 138,
								["c_max"] = 0,
								["id"] = "击倒",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["野性回复"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "野性回复",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 9,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 295,
								["targets"] = {
									["就是个厨子"] = 1361,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1361,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1361,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-12224-00001D97F8",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387061,
					["delay"] = 0,
					["damage_taken"] = 29968.021595,
				}, -- [3]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 553.020943,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["就是个厨子"] = 647,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 647.020943,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 647.020943,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "毒性软泥怪",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 189,
								["targets"] = {
									["就是个厨子"] = 553,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 553,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 553,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["MISS"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["毒害之云"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 56,
								["targets"] = {
									["就是个厨子"] = 94,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 94,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 94,
								["c_max"] = 0,
								["id"] = "毒害之云",
								["r_dmg"] = 94,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 70,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 2,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-12221-00019D97F8",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387072,
					["delay"] = 0,
					["damage_taken"] = 111024.020943,
				}, -- [4]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 1269.023613,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["就是个厨子"] = 1012,
						["潇潇"] = 880,
					},
					["dps_started"] = false,
					["pets"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 1892.023613,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 1892.023613,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["nome"] = "毒劣魔",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 67,
								["targets"] = {
									["就是个厨子"] = 67,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 67,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 67,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["毒液箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 138,
								["targets"] = {
									["就是个厨子"] = 945,
									["潇潇"] = 880,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1825,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 141,
								["total"] = 1825,
								["c_max"] = 0,
								["id"] = "毒液箭",
								["r_dmg"] = 94,
								["RESIST"] = 109,
								["a_dmg"] = 114,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 122,
								["b_dmg"] = 0,
								["n_amt"] = 32,
								["r_amt"] = 3,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-12216-00011D97F7",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587386992,
					["delay"] = 0,
					["damage_taken"] = 32008.023613,
				}, -- [5]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 129.024921,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
						["腐烂欺骗者"] = true,
					},
					["targets"] = {
						["就是个厨子"] = 264,
						["腐烂欺骗者"] = 178,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 442.024921,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 442.024921,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "腐烂欺骗者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["腐烂欺骗者"] = 178,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 178,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 89,
								["total"] = 178,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 89,
								["b_dmg"] = 0,
								["n_amt"] = 89,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 135,
								["targets"] = {
									["就是个厨子"] = 264,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 264,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 264,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-11791-00001D97F6",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387016,
					["delay"] = 0,
					["damage_taken"] = 130605.024921,
				}, -- [6]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 210.007958,
					["on_hold"] = false,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["就是个厨子"] = 276,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 276.007958,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1587387083,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "腐化劣魔",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["腐蚀术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 36,
								["targets"] = {
									["就是个厨子"] = 276,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 276,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 276,
								["c_max"] = 0,
								["id"] = "腐蚀术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 8,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 276.007958,
					["serial"] = "Creature-0-4891-349-20864-12217-00031D97F8",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 241.007958,
					["start_time"] = 1587387069,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [7]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 135.031479,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["就是个厨子"] = 135,
					},
					["dps_started"] = false,
					["pets"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 135.031479,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 135.031479,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["nome"] = "腐烂萨特",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 135,
								["targets"] = {
									["就是个厨子"] = 135,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 135,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 135,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-11790-00009D97F7",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387076,
					["delay"] = 0,
					["damage_taken"] = 87135.031479,
				}, -- [8]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.021128,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.021128,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 0.021128,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "腐烂巡影者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["闪避"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "闪避",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 11,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-11792-00019D97F6",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387080,
					["delay"] = 0,
					["damage_taken"] = 23936.021128,
				}, -- [9]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.014784,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.014784,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 0.014784,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "洞窟潜伏者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-12223-00011D97F6",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387080,
					["delay"] = 0,
					["damage_taken"] = 42123.014784,
				}, -- [10]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.014943,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.014943,
					["last_event"] = 0,
					["on_hold"] = false,
					["monster"] = true,
					["total"] = 0.014943,
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "深腐践踏者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-13141-00011D97F8",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387080,
					["delay"] = 0,
					["damage_taken"] = 59858.014943,
				}, -- [11]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 183.015265,
					["damage_from"] = {
						["就是个厨子"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["就是个厨子"] = 559,
					},
					["dps_started"] = false,
					["pets"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 559.015265,
					["fight_component"] = true,
					["monster"] = true,
					["total"] = 559.015265,
					["classe"] = "UNKNOW",
					["last_event"] = 0,
					["nome"] = "深腐纠缠者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["纠缠根须"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "纠缠根须",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 29,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 191,
								["targets"] = {
									["就是个厨子"] = 559,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 559,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 559,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 185,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["荆棘术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "荆棘术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 4,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["end_time"] = 1587387083,
					["serial"] = "Creature-0-4891-349-20864-13142-00019D97F7",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587387075,
					["delay"] = 0,
					["damage_taken"] = 85743.015265,
				}, -- [12]
				{
					["flag_original"] = -2147483648,
					["totalabsorbed"] = 0.005852,
					["fight_component"] = true,
					["damage_from"] = {
					},
					["targets"] = {
						["专诸刺秦"] = 70,
						["潇潇"] = 78,
						["壹亿肆"] = 89,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 237.005852,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1587389105,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "环境伤害 (高处坠落)",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["Falling"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 89,
								["targets"] = {
									["专诸刺秦"] = 70,
									["潇潇"] = 78,
									["壹亿肆"] = 89,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 237,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 237,
								["c_max"] = 0,
								["id"] = "Falling",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 4,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["total"] = 237.005852,
					["serial"] = "",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.005852,
					["start_time"] = 1587389092,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [13]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.01763,
					["damage_from"] = {
						["涛声依旧"] = true,
						["东岸乡花一枝"] = true,
						["小恶魔提利昂"] = true,
						["诺步联盟一"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.01763,
					["end_time"] = 1587390145,
					["dps_started"] = false,
					["total"] = 0.01763,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "坐骑人",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["寒冰护体"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["serial"] = "Player-4920-0214EE49",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587390142,
					["delay"] = 0,
					["damage_taken"] = 3025.01763,
				}, -- [14]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.007963,
					["damage_from"] = {
						["涛声依旧"] = true,
						["潇潇"] = true,
						["诺步联盟一"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.007963,
					["end_time"] = 1587390145,
					["dps_started"] = false,
					["total"] = 0.007963,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "鼠公子",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["治疗药水"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗药水",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["serial"] = "Player-4920-01DDFD03",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587390142,
					["delay"] = 0,
					["damage_taken"] = 2833.007963,
				}, -- [15]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 518.010602,
					["damage_from"] = {
						["安东尼达斯丶"] = true,
					},
					["targets"] = {
						["全部一起来吧"] = 845,
						["潇潇"] = 539,
						["安东尼达斯丶"] = 1208,
						["潜行哲"] = 533,
						["黄百万"] = 826,
						["无情萨满"] = 667,
						["菠蘿"] = 752,
						["弟中弟志"] = 267,
						["不做痴情种"] = 518,
						["喔愺"] = 823,
						["小懋懋"] = 267,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 7245.010602,
					["end_time"] = 1587391206,
					["dps_started"] = false,
					["total"] = 7245.010602,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "闪闪光头",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["魔爆术"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1194,
								["g_amt"] = 0,
								["n_max"] = 282,
								["targets"] = {
									["全部一起来吧"] = 845,
									["潇潇"] = 539,
									["安东尼达斯丶"] = 1208,
									["潜行哲"] = 533,
									["黄百万"] = 826,
									["无情萨满"] = 667,
									["菠蘿"] = 752,
									["弟中弟志"] = 267,
									["不做痴情种"] = 518,
									["喔愺"] = 823,
									["小懋懋"] = 267,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6051,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 7245,
								["c_max"] = 408,
								["id"] = "魔爆术",
								["r_dmg"] = 196,
								["a_dmg"] = 408,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 23,
								["r_amt"] = 1,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["serial"] = "Player-4920-0203EB0D",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587391191,
					["delay"] = 0,
					["damage_taken"] = 1335.010602,
				}, -- [16]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.016859,
					["damage_from"] = {
						["闪闪光头"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.016859,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1587391206,
					["friendlyfire_total"] = 0,
					["friendlyfire"] = {
					},
					["nome"] = "喔愺",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["grupo"] = true,
					["total"] = 0.016859,
					["serial"] = "Player-4920-0231F4BA",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 823.016859,
					["start_time"] = 1587391203,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [17]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.015153,
					["damage_from"] = {
						["闪闪光头"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "SHAMAN",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.015153,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1587391206,
					["friendlyfire_total"] = 0,
					["friendlyfire"] = {
					},
					["nome"] = "无情萨满",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
						},
					},
					["grupo"] = true,
					["total"] = 0.015153,
					["serial"] = "Player-4920-01DAB206",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 667.015153,
					["start_time"] = 1587391203,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [18]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.014977,
					["damage_from"] = {
						["潇潇"] = true,
						["小恶魔提利昂"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.014977,
					["end_time"] = 1587391260,
					["dps_started"] = false,
					["total"] = 0.014977,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["nome"] = "来瓶老雪",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["真言术：盾"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "真言术：盾",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["serial"] = "Player-4920-0219F0FF",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1587391257,
					["delay"] = 0,
					["damage_taken"] = 2001.014977,
				}, -- [19]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.007027,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["专诸刺秦"] = 476,
						["潇潇"] = 78,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 554.007027,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1587393128,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "鬼魅掠夺者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 78,
								["targets"] = {
									["专诸刺秦"] = 476,
									["潇潇"] = 78,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 554,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 554,
								["c_max"] = 0,
								["id"] = "射击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 7,
								["b_dmg"] = 0,
								["n_amt"] = 8,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 554.007027,
					["serial"] = "Creature-0-4514-1-262-11686-00001DAF8F",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.007027,
					["start_time"] = 1587393111,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [20]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 274.005169,
					["on_hold"] = false,
					["damage_from"] = {
					},
					["targets"] = {
						["壹亿肆"] = 119,
						["潇潇"] = 155,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 274.005169,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1587393128,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["nome"] = "鬼魅袭击者",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 108,
								["targets"] = {
									["壹亿肆"] = 119,
									["潇潇"] = 155,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 274,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 274,
								["c_max"] = 0,
								["DODGE"] = 1,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["MISS"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["total"] = 274.005169,
					["serial"] = "Creature-0-4514-1-262-11687-00001DAF7F",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.005169,
					["start_time"] = 1587393118,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [21]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.01231,
					["total_without_pet"] = 3216.01231,
					["total"] = 3216.01231,
					["targets_absorbs"] = {
						["就是个厨子"] = 2492,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01D128EF",
					["totalabsorb"] = 2492.01231,
					["last_hps"] = 0,
					["targets"] = {
						["就是个厨子"] = 3216,
					},
					["totalover_without_pet"] = 0.01231,
					["healing_taken"] = 3216.01231,
					["fight_component"] = true,
					["end_time"] = 1587387083,
					["healing_from"] = {
						["就是个厨子"] = true,
					},
					["nome"] = "就是个厨子",
					["spells"] = {
						["tipo"] = 3,
						["_ActorTable"] = {
							["寒冰护体"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 2492,
								["targets_overheal"] = {
								},
								["n_max"] = 280,
								["targets"] = {
									["就是个厨子"] = 2492,
								},
								["n_min"] = 0,
								["counter"] = 32,
								["overheal"] = 0,
								["total"] = 2492,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["targets_absorbs"] = {
									["就是个厨子"] = 2492,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 2492,
								["n_amt"] = 32,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							["治疗药水"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 724,
								["targets"] = {
									["就是个厨子"] = 724,
								},
								["n_min"] = 0,
								["counter"] = 1,
								["overheal"] = 0,
								["total"] = 724,
								["c_max"] = 0,
								["id"] = "治疗药水",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 724,
								["n_amt"] = 1,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
					},
					["grupo"] = true,
					["start_time"] = 1587387020,
					["classe"] = "MAGE",
					["custom"] = 0,
					["tipo"] = 2,
					["spec"] = 64,
					["totaldenied"] = 0.01231,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [1]
				{
					["flag_original"] = 1297,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.019972,
					["total_without_pet"] = 794.019972,
					["total"] = 794.019972,
					["targets_absorbs"] = {
						["潇潇"] = 794,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-022A2037",
					["totalabsorb"] = 794.019972,
					["last_hps"] = 0,
					["targets"] = {
						["潇潇"] = 794,
					},
					["totalover_without_pet"] = 0.019972,
					["healing_taken"] = 794.019972,
					["fight_component"] = true,
					["end_time"] = 1587389105,
					["healing_from"] = {
						["潇潇"] = true,
					},
					["nome"] = "潇潇",
					["spells"] = {
						["tipo"] = 3,
						["_ActorTable"] = {
							["寒冰护体"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 794,
								["targets_overheal"] = {
								},
								["n_max"] = 138,
								["targets"] = {
									["潇潇"] = 794,
								},
								["n_min"] = 0,
								["counter"] = 8,
								["overheal"] = 0,
								["total"] = 794,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["targets_absorbs"] = {
									["潇潇"] = 794,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 794,
								["n_amt"] = 8,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
					},
					["grupo"] = true,
					["start_time"] = 1587389086,
					["classe"] = "MAGE",
					["custom"] = 0,
					["tipo"] = 2,
					["spec"] = 64,
					["totaldenied"] = 0.019972,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [2]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 7239.01912,
					["resource"] = 0.01912,
					["targets"] = {
						["就是个厨子"] = 7239,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["passiveover"] = 0.001437,
					["fight_component"] = true,
					["total"] = 7239.01912,
					["tipo"] = 3,
					["nome"] = "就是个厨子",
					["spells"] = {
						["tipo"] = 7,
						["_ActorTable"] = {
							["魔法吸收"] = {
								["total"] = 7239,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["就是个厨子"] = 7239,
								},
								["counter"] = 28,
							},
						},
					},
					["grupo"] = true,
					["totalover"] = 0.001437,
					["flag_original"] = 1298,
					["alternatepower"] = 0.01912,
					["last_event"] = 0,
					["spec"] = 64,
					["serial"] = "Player-4920-01D128EF",
				}, -- [1]
				{
					["received"] = 354.013914,
					["resource"] = 0.013914,
					["targets"] = {
						["闪闪光头"] = 354,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.008693,
					["fight_component"] = true,
					["total"] = 354.013914,
					["tipo"] = 3,
					["nome"] = "闪闪光头",
					["spells"] = {
						["tipo"] = 7,
						["_ActorTable"] = {
							["魔法吸收"] = {
								["total"] = 354,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["闪闪光头"] = 354,
								},
								["counter"] = 1,
							},
						},
					},
					["totalover"] = 0.008693,
					["flag_original"] = 1352,
					["last_event"] = 0,
					["alternatepower"] = 0.013914,
					["serial"] = "Player-4920-0203EB0D",
				}, -- [2]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["暴风雪"] = {
								["actived_at"] = 1587389927,
								["refreshamt"] = 0,
								["activedamt"] = -319,
								["appliedamt"] = 805,
								["id"] = "暴风雪",
								["uptime"] = 136,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冰霜新星"] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 41,
								["id"] = "冰霜新星",
								["uptime"] = 13,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冰锥术"] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = "冰锥术",
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["buff_uptime"] = 624,
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["寒冰护体"] = {
								["refreshamt"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = "寒冰护体",
								["uptime"] = 115,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["奥术智慧"] = {
								["actived_at"] = 1587391193,
								["refreshamt"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "奥术智慧",
								["uptime"] = 151,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "无荣誉目标",
								["actived_at"] = 1587391193,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["魔甲术"] = {
								["actived_at"] = 1587391193,
								["refreshamt"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "魔甲术",
								["uptime"] = 151,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["护甲"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "护甲",
								["uptime"] = 56,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["魔法抑制"] = {
								["actived_at"] = 1587391193,
								["refreshamt"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "魔法抑制",
								["uptime"] = 151,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["fight_component"] = true,
					["debuff_uptime"] = 149,
					["nome"] = "就是个厨子",
					["spec"] = 64,
					["grupo"] = true,
					["spell_cast"] = {
						["寒冰护体"] = 1,
						["火焰冲击"] = 1,
						["冰霜新星"] = 1,
						["治疗药水"] = 1,
						["魔爆术"] = 12,
						["寒冰箭"] = 1,
						["暴风雪"] = 5,
						["冰锥术"] = 4,
					},
					["debuff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["pets"] = {
					},
					["serial"] = "Player-4920-01D128EF",
					["last_event"] = 0,
				}, -- [1]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["暴风雪"] = {
								["refreshamt"] = 0,
								["activedamt"] = -11,
								["appliedamt"] = 455,
								["id"] = "暴风雪",
								["uptime"] = 76,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冰霜新星"] = {
								["refreshamt"] = 1,
								["activedamt"] = 0,
								["appliedamt"] = 20,
								["id"] = "冰霜新星",
								["uptime"] = 24,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冰锥术"] = {
								["actived_at"] = 3174781378,
								["refreshamt"] = 0,
								["activedamt"] = -2,
								["appliedamt"] = 10,
								["id"] = "冰锥术",
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["buff_uptime"] = 685,
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["寒冰护体"] = {
								["refreshamt"] = 0,
								["activedamt"] = 8,
								["appliedamt"] = 8,
								["id"] = "寒冰护体",
								["uptime"] = 185,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["奥术智慧"] = {
								["refreshamt"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "奥术智慧",
								["uptime"] = 130,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["智力"] = {
								["actived_at"] = 1587390129,
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = "智力",
								["uptime"] = 63,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冰甲术"] = {
								["actived_at"] = 1587390129,
								["refreshamt"] = 0,
								["activedamt"] = 8,
								["appliedamt"] = 8,
								["id"] = "冰甲术",
								["uptime"] = 195,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "无荣誉目标",
								["actived_at"] = 1587391193,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["耐力"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "耐力",
								["uptime"] = 56,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["精神"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "精神",
								["uptime"] = 56,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["fight_component"] = true,
					["debuff_uptime"] = 112,
					["buff_uptime_targets"] = {
					},
					["spec"] = 64,
					["grupo"] = true,
					["spell_cast"] = {
						["急速冷却"] = 1,
						["冰霜新星"] = 7,
						["暴风雪"] = 8,
						["寒冰护体"] = 1,
						["奥术智慧"] = 1,
						["冰甲术"] = 1,
						["魔爆术"] = 7,
						["寒冰箭"] = 1,
						["火焰冲击"] = 4,
						["冰锥术"] = 7,
					},
					["debuff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["nome"] = "潇潇",
					["pets"] = {
					},
					["serial"] = "Player-4920-022A2037",
					["last_event"] = 0,
				}, -- [2]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "腐烂欺骗者",
					["pets"] = {
					},
					["spell_cast"] = {
						["痛击"] = 89,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4891-349-20864-11791-00009D97F6",
					["classe"] = "UNKNOW",
				}, -- [3]
				{
					["fight_component"] = true,
					["nome"] = "毒劣魔",
					["flag_original"] = 2632,
					["spell_cast"] = {
						["毒液箭"] = 122,
					},
					["monster"] = true,
					["tipo"] = 4,
					["classe"] = "UNKNOW",
					["pets"] = {
					},
					["serial"] = "Creature-0-4891-349-20864-12216-00011D97F7",
					["last_event"] = 0,
				}, -- [4]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "深腐纠缠者",
					["pets"] = {
					},
					["spell_cast"] = {
						["纠缠根须"] = 29,
						["荆棘术"] = 4,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4891-349-20864-13142-00001D97F8",
					["classe"] = "UNKNOW",
				}, -- [5]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "洞窟游荡者",
					["pets"] = {
					},
					["spell_cast"] = {
						["击倒"] = 1,
						["野性回复"] = 9,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4891-349-20864-12224-00001D97F8",
					["classe"] = "UNKNOW",
				}, -- [6]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "腐烂巡影者",
					["pets"] = {
					},
					["spell_cast"] = {
						["闪避"] = 11,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4891-349-20864-11792-00011D97F6",
					["classe"] = "UNKNOW",
				}, -- [7]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "毒性软泥怪",
					["pets"] = {
					},
					["spell_cast"] = {
						["毒害之云"] = 70,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4891-349-20864-12221-00011D97F6",
					["classe"] = "UNKNOW",
				}, -- [8]
				{
					["fight_component"] = true,
					["nome"] = "坐骑人",
					["enemy"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						["寒冰护体"] = 1,
					},
					["flag_original"] = 1352,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-0214EE49",
					["classe"] = "UNGROUPPLAYER",
				}, -- [9]
				{
					["fight_component"] = true,
					["nome"] = "鼠公子",
					["enemy"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						["治疗药水"] = 1,
					},
					["flag_original"] = 66888,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-01DDFD03",
					["classe"] = "UNGROUPPLAYER",
				}, -- [10]
				{
					["flag_original"] = 1047,
					["nome"] = "喔愺",
					["buff_uptime_targets"] = {
					},
					["grupo"] = true,
					["spell_cast"] = {
						["消失"] = 1,
					},
					["tipo"] = 4,
					["pets"] = {
					},
					["last_event"] = 0,
					["buff_uptime"] = 0,
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "无荣誉目标",
								["actived_at"] = 1587391193,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["潜行"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "潜行",
								["actived_at"] = 1587391197,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-4920-0231F4BA",
					["classe"] = "ROGUE",
				}, -- [11]
				{
					["flag_original"] = 1047,
					["nome"] = "无情萨满",
					["grupo"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["classe"] = "SHAMAN",
					["buff_uptime"] = 12,
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "无荣誉目标",
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["serial"] = "Player-4920-01DAB206",
					["last_event"] = 0,
				}, -- [12]
				{
					["fight_component"] = true,
					["nome"] = "闪闪光头",
					["enemy"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						["魔爆术"] = 3,
					},
					["flag_original"] = 1352,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-0203EB0D",
					["classe"] = "UNGROUPPLAYER",
				}, -- [13]
				{
					["flag_original"] = 1047,
					["ress_targets"] = {
						["无情萨满"] = 1,
					},
					["buff_uptime"] = 16,
					["classe"] = "SHAMAN",
					["buff_uptime_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "无荣誉目标",
								["uptime"] = 16,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
					},
					["ress"] = 1.00523,
					["buff_uptime_targets"] = {
					},
					["spec"] = 263,
					["grupo"] = true,
					["spell_cast"] = {
						["先祖之魂"] = 1,
					},
					["ress_spells"] = {
						["tipo"] = 9,
						["_ActorTable"] = {
							[0] = {
								["id"] = 0,
								["ress"] = 1,
								["targets"] = {
									["无情萨满"] = 1,
								},
								["counter"] = 0,
							},
						},
					},
					["tipo"] = 4,
					["nome"] = "鲁总",
					["pets"] = {
					},
					["serial"] = "Player-4920-022E7DE4",
					["last_event"] = 0,
				}, -- [14]
				{
					["fight_component"] = true,
					["nome"] = "来瓶老雪",
					["enemy"] = true,
					["pets"] = {
					},
					["spell_cast"] = {
						["真言术：盾"] = 1,
					},
					["flag_original"] = 66888,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-0219F0FF",
					["classe"] = "UNGROUPPLAYER",
				}, -- [15]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "鬼魅掠夺者",
					["pets"] = {
					},
					["spell_cast"] = {
						["射击"] = 7,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4514-1-262-11686-00001DAF75",
					["classe"] = "UNKNOW",
				}, -- [16]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1587386206,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["combat_counter"] = 20,
		["totals"] = {
			618624.15787, -- [1]
			4009.937082, -- [2]
			{
				0, -- [1]
				[0] = 7593.019249,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 1.00523,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["spells_cast_timeline"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "20:50:27",
		["end_time"] = 354864.386,
		["cleu_events"] = {
			["n"] = 1,
		},
		["segments_added"] = {
			{
				["elapsed"] = 30.00900000002,
				["type"] = 0,
				["name"] = "鬼魅掠夺者",
				["clock"] = "22:31:38",
			}, -- [1]
			{
				["elapsed"] = 16.0109999999986,
				["type"] = 0,
				["name"] = "来瓶老雪",
				["clock"] = "22:00:44",
			}, -- [2]
			{
				["elapsed"] = 12.0109999999986,
				["type"] = 0,
				["name"] = "闪闪光头",
				["clock"] = "21:59:54",
			}, -- [3]
			{
				["elapsed"] = 32.0109999999986,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "21:55:13",
			}, -- [4]
			{
				["elapsed"] = 15.5949999999721,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "21:42:09",
			}, -- [5]
			{
				["elapsed"] = 12.0109999999986,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "21:38:47",
			}, -- [6]
			{
				["elapsed"] = 51.00900000002,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "21:24:14",
			}, -- [7]
			{
				["elapsed"] = 55.9990000000107,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "20:50:27",
			}, -- [8]
		},
		["totals_grupo"] = {
			604864.064144, -- [1]
			4010.022307, -- [2]
			{
				0, -- [1]
				[0] = 7239.017683,
				["alternatepower"] = 0,
				[3] = 0,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 1.00523,
				["debuff_uptime"] = 0,
				["cooldowns_defensive"] = 0,
				["interrupt"] = 0,
				["dispell"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["frags"] = {
		},
		["data_fim"] = "22:32:08",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["cleu_timeline"] = {
		},
		["start_time"] = 354639.73,
		["TimeData"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
			["damage"] = {
			},
		},
	},
	["force_font_outline"] = "",
	["local_instances_config"] = {
		{
			["segment"] = -1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -349.866165161133,
					["x"] = 751.715454101563,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -171.866149902344,
					["x"] = 751.715576171875,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["character_data"] = {
		["logons"] = 1,
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-4920-022A2037"] = 64,
		["Player-4920-01D128EF"] = 64,
		["Player-4920-022E7DE4"] = 263,
	},
}
