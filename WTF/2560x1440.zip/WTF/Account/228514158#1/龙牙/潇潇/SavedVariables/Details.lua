
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 128,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00272,
							["damage_from"] = {
							},
							["targets"] = {
								["风御九天"] = 1614,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1614.00272,
							["serial"] = "Player-4920-022A2037",
							["dps_started"] = false,
							["total"] = 1614.00272,
							["spec"] = 64,
							["on_hold"] = false,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1011,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["风御九天"] = 1011,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1011,
										["c_max"] = 1011,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1011,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 603,
										["targets"] = {
											["风御九天"] = 603,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 603,
										["n_min"] = 603,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 603,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1593697903,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697898,
							["damage_taken"] = 0.00272,
							["start_time"] = 1593697896,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.001594,
							["damage_from"] = {
								["潇潇"] = true,
								["舅子大帅比"] = true,
								["镇裆射鸡"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001594,
							["dps_started"] = false,
							["fight_component"] = true,
							["total"] = 0.001594,
							["serial"] = "Player-4920-0272452D",
							["on_hold"] = false,
							["nome"] = "风御九天",
							["spells"] = {
								["_ActorTable"] = {
									["法力护盾"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "法力护盾",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1593697903,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 1958.001594,
							["start_time"] = 1593697903,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 128,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 128,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 128,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["activedamt"] = -1,
										["id"] = "冰锥术",
										["targets"] = {
										},
										["actived_at"] = 1593697898,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 14,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 0,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1593697903,
							["nome"] = "潇潇",
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["pets"] = {
							},
							["nome"] = "风御九天",
							["enemy"] = true,
							["spell_cast"] = {
								["法力护盾"] = 1,
							},
							["fight_component"] = true,
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Player-4920-0272452D",
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 128,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["火抗梯"] = true,
					["Loveqln"] = true,
					["星游"] = true,
					["幼儿园战神"] = true,
					["麦了佛冷"] = true,
					["小小法"] = true,
					["小米有品"] = true,
					["不帅还有点坏"] = true,
					["奇异灬博士"] = true,
					["窥见身外之身"] = true,
					["带鳝人"] = true,
					["潇潇"] = true,
					["就是个厨子"] = true,
					["灬坏蛋灬"] = true,
					["油焖小龙虾"] = true,
					["板板狗"] = true,
					["希洛克"] = true,
					["风哥"] = true,
					["赚她一个亿"] = true,
					["香油田鸡"] = true,
					["半瓶矿泉水灬"] = true,
					["过兒我是咕咕"] = true,
				},
				["tempo_start"] = 1593697896,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 744,
				["totals"] = {
					1613.826158, -- [1]
					-0.007391, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "21:51:44",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "风御九天",
				["TotalElapsedCombatTime"] = 82068.229,
				["CombatEndedAt"] = 82068.229,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:51:37",
				["end_time"] = 82068.379,
				["combat_id"] = 128,
				["spells_cast_timeline"] = {
				},
				["totals_grupo"] = {
					1614, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags"] = {
					["风御九天"] = 1,
				},
				["overall_added"] = true,
				["TimeData"] = {
				},
				["CombatSkillCache"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["start_time"] = 82061.376,
				["contra"] = "风御九天",
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 1614.00272,
						}, -- [1]
					},
				},
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 127,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008372,
							["damage_from"] = {
							},
							["targets"] = {
								["冲击波"] = 99,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["last_event"] = 1593697857,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 99.008372,
							["serial"] = "Player-4920-022A2037",
							["dps_started"] = false,
							["total"] = 99.008372,
							["spec"] = 64,
							["on_hold"] = false,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 99,
										["targets"] = {
											["冲击波"] = 99,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 99,
										["n_min"] = 99,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 99,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.008372,
							["start_time"] = 1593697866,
							["delay"] = 1593697857,
							["end_time"] = 1593697867,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.002806,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002806,
							["dps_started"] = false,
							["fight_component"] = true,
							["total"] = 0.002806,
							["serial"] = "Player-4920-01D0DDE4",
							["on_hold"] = false,
							["nome"] = "冲击波",
							["spells"] = {
								["_ActorTable"] = {
									["闪现术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "闪现术",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1593697867,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 99.002806,
							["start_time"] = 1593697867,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 127,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 127,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 127,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["nome"] = "风哥",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "WARRIOR",
							["buff_uptime"] = 10,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "无荣誉目标",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D157B4",
							["last_event"] = 1593697867,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰霜新星"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 1,
										["id"] = "冰霜新星",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 20,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 1,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
								["冰锥术"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1593697867,
							["nome"] = "潇潇",
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 66888,
							["pets"] = {
							},
							["nome"] = "冲击波",
							["enemy"] = true,
							["spell_cast"] = {
								["闪现术"] = 1,
							},
							["fight_component"] = true,
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Player-4920-01D0DDE4",
							["classe"] = "UNGROUPPLAYER",
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 127,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["火抗梯"] = true,
					["Loveqln"] = true,
					["星游"] = true,
					["幼儿园战神"] = true,
					["麦了佛冷"] = true,
					["小小法"] = true,
					["小米有品"] = true,
					["不帅还有点坏"] = true,
					["奇异灬博士"] = true,
					["窥见身外之身"] = true,
					["带鳝人"] = true,
					["潇潇"] = true,
					["就是个厨子"] = true,
					["灬坏蛋灬"] = true,
					["油焖小龙虾"] = true,
					["板板狗"] = true,
					["希洛克"] = true,
					["风哥"] = true,
					["赚她一个亿"] = true,
					["香油田鸡"] = true,
					["半瓶矿泉水灬"] = true,
					["过兒我是咕咕"] = true,
				},
				["CombatStartedAt"] = 82061.376,
				["tempo_start"] = 1593697857,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 743,
				["totals"] = {
					98.9802790000001, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = -0.007911,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					99, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "21:51:08",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "冲击波",
				["TotalElapsedCombatTime"] = 82031.783,
				["CombatEndedAt"] = 82031.783,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 99.008372,
						}, -- [1]
					},
				},
				["end_time"] = 82032.118,
				["combat_id"] = 127,
				["frags"] = {
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["contra"] = "冲击波",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 82022.108,
				["TimeData"] = {
				},
				["data_inicio"] = "21:50:58",
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 126,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006774,
							["damage_from"] = {
							},
							["targets"] = {
								["风御九天"] = 701,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["last_event"] = 1593697313,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 701.006774,
							["serial"] = "Player-4920-022A2037",
							["dps_started"] = false,
							["total"] = 701.006774,
							["spec"] = 64,
							["on_hold"] = false,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 601,
										["targets"] = {
											["风御九天"] = 601,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 601,
										["n_min"] = 601,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 601,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["冰霜新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 100,
										["targets"] = {
											["风御九天"] = 100,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 100,
										["n_min"] = 100,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 100,
										["c_max"] = 0,
										["id"] = "冰霜新星",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.006774,
							["start_time"] = 1593697312,
							["delay"] = 0,
							["end_time"] = 1593697320,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.001143,
							["damage_from"] = {
								["窥见身外之身"] = true,
								["币毛漫天浪"] = true,
								["潇潇"] = true,
								["休闲与娱乐"] = true,
								["舅子大帅比"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001143,
							["dps_started"] = false,
							["fight_component"] = true,
							["total"] = 0.001143,
							["serial"] = "Player-4920-0272452D",
							["on_hold"] = false,
							["nome"] = "风御九天",
							["spells"] = {
								["_ActorTable"] = {
									["法力护盾"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "法力护盾",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1593697320,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 1985.001143,
							["start_time"] = 1593697320,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007474,
							["damage_from"] = {
							},
							["targets"] = {
								["风御九天"] = 219,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 219.007474,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 219.007474,
							["serial"] = "Player-4920-02628F22",
							["end_time"] = 1593697320,
							["nome"] = "窥见身外之身",
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 219,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["风御九天"] = 219,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 219,
										["c_max"] = 219,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 219,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697313,
							["damage_taken"] = 0.007474,
							["start_time"] = 1593697313,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [3]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.001273,
							["damage_from"] = {
								["麦蕾蒂"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001273,
							["on_hold"] = false,
							["dps_started"] = false,
							["end_time"] = 1593697857,
							["serial"] = "Player-4920-01D1852F",
							["total"] = 0.001273,
							["nome"] = "火抗梯",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 570.001273,
							["start_time"] = 1593697857,
							["delay"] = 0,
							["classe"] = "WARRIOR",
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 126,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 126,
					["_ActorTable"] = {
						{
							["received"] = 120.007928,
							["resource"] = 0.007928,
							["targets"] = {
								["过兒我是咕咕"] = 120,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "DRUID",
							["passiveover"] = 0.007928,
							["total"] = 120.007928,
							["nome"] = "过兒我是咕咕",
							["spells"] = {
								["_ActorTable"] = {
									["激怒"] = {
										["total"] = 120,
										["id"] = "激怒",
										["totalover"] = 0,
										["targets"] = {
											["过兒我是咕咕"] = 120,
										},
										["counter"] = 3,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["flag_original"] = 1300,
							["last_event"] = 1593697780,
							["alternatepower"] = 0.007928,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D67BC1",
							["totalover"] = 0.007928,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 126,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["nome"] = "香油田鸡",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "HUNTER",
							["buff_uptime"] = 9,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["灵猴守护"] = {
										["activedamt"] = 1,
										["id"] = "灵猴守护",
										["targets"] = {
										},
										["actived_at"] = 1593697312,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["狂怒之嚎"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 9,
										["id"] = "狂怒之嚎",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-026E1D50",
							["last_event"] = 1593697355,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = "冰锥术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["喝水"] = {
										["activedamt"] = 1,
										["id"] = "喝水",
										["targets"] = {
										},
										["actived_at"] = 1593697312,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["进食"] = {
										["activedamt"] = 1,
										["id"] = "进食",
										["targets"] = {
										},
										["actived_at"] = 1593697312,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 0,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["冰锥术"] = 1,
							},
							["nome"] = "窥见身外之身",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593697320,
							["serial"] = "Player-4920-02628F22",
							["buff_uptime"] = 8,
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = "冰锥术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["冰霜新星"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 1,
										["id"] = "冰霜新星",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 24,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 1,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["spell_cast"] = {
								["冰锥术"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1593697320,
							["nome"] = "潇潇",
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [3]
						{
							["flag_original"] = 66888,
							["pets"] = {
							},
							["nome"] = "风御九天",
							["enemy"] = true,
							["spell_cast"] = {
								["法力护盾"] = 1,
							},
							["fight_component"] = true,
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Player-4920-0272452D",
							["classe"] = "UNGROUPPLAYER",
						}, -- [4]
						{
							["flag_original"] = 1300,
							["nome"] = "火抗梯",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "WARRIOR",
							["buff_uptime"] = 0,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = "无荣誉目标",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["防御姿态"] = {
										["activedamt"] = 1,
										["id"] = "防御姿态",
										["targets"] = {
										},
										["actived_at"] = 1593697319,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D1852F",
							["last_event"] = 1593697320,
						}, -- [5]
						{
							["flag_original"] = 1300,
							["nome"] = "奇异灬博士",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "WARLOCK",
							["buff_uptime"] = 97,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["血之契印"] = {
										["activedamt"] = 2,
										["id"] = "血之契印",
										["targets"] = {
										},
										["actived_at"] = 1593697596,
										["uptime"] = 97,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01EBF4BE",
							["last_event"] = 1593697596,
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 126,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["火抗梯"] = true,
					["星游"] = true,
					["幼儿园战神"] = true,
					["风哥"] = true,
					["不帅还有点坏"] = true,
					["奇异灬博士"] = true,
					["窥见身外之身"] = true,
					["带鳝人"] = true,
					["潇潇"] = true,
					["赚她一个亿"] = true,
					["灬坏蛋灬"] = true,
					["就是个厨子"] = true,
					["板板狗"] = true,
					["希洛克"] = true,
					["小米有品"] = true,
					["油焖小龙虾"] = true,
					["香油田鸡"] = true,
					["半瓶矿泉水灬"] = true,
					["过兒我是咕咕"] = true,
				},
				["CombatStartedAt"] = 82022.108,
				["tempo_start"] = 1593697312,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 742,
				["totals"] = {
					919.912165, -- [1]
					-0.011493, -- [2]
					{
						-0.00866299999999853, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 120,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					920, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 120,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "21:42:00",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "风御九天",
				["TotalElapsedCombatTime"] = 5.70400000001246,
				["CombatEndedAt"] = 81500.847,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["窥见身外之身"] = 219.007474,
							["潇潇"] = 701.006774,
						}, -- [1]
					},
				},
				["end_time"] = 81484.985,
				["combat_id"] = 126,
				["frags"] = {
					["风御九天"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["contra"] = "风御九天",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
					["火抗梯"] = {
						{
							true, -- [1]
							"冲击波", -- [2]
							570, -- [3]
							1593697325.731, -- [4]
							6752, -- [5]
							"麦蕾蒂", -- [6]
							nil, -- [7]
							4, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["start_time"] = 81476.979,
				["TimeData"] = {
				},
				["data_inicio"] = "21:41:52",
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 125,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00763,
							["damage_from"] = {
								["哈卡莱神谕者"] = true,
								["古拉巴什战士"] = true,
							},
							["targets"] = {
								["哈卡莱神谕者"] = 842,
								["古拉巴什战士"] = 1109,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1951.00763,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 1951.00763,
							["serial"] = "Player-4920-02628F22",
							["end_time"] = 1593697290,
							["nome"] = "窥见身外之身",
							["spells"] = {
								["_ActorTable"] = {
									["魔爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 288,
										["targets"] = {
											["哈卡莱神谕者"] = 842,
											["古拉巴什战士"] = 1109,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1951,
										["n_min"] = 271,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 1951,
										["c_max"] = 0,
										["id"] = "魔爆术",
										["r_dmg"] = 0,
										["spellschool"] = 64,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697271,
							["damage_taken"] = 1044.00763,
							["start_time"] = 1593697284,
							["delay"] = 1593697271,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005768,
							["damage_from"] = {
								["嚣张的步伐"] = true,
								["贼浪漫"] = true,
								["舅子大帅比"] = true,
								["风哥"] = true,
								["小白不黑"] = true,
								["币毛漫天浪"] = true,
								["小花妹"] = true,
								["甜汤"] = true,
								["鲁豫"] = true,
								["窥见身外之身"] = true,
							},
							["targets"] = {
								["嚣张的步伐"] = 665,
								["窥见身外之身"] = 334,
								["鲁豫"] = 778,
								["处男刺青"] = 233,
							},
							["pets"] = {
							},
							["monster"] = true,
							["total"] = 2010.005768,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2010.005768,
							["serial"] = "Creature-0-4999-0-282-11355-00007DDB6F",
							["fight_component"] = true,
							["end_time"] = 1593697290,
							["dps_started"] = false,
							["on_hold"] = false,
							["nome"] = "古拉巴什战士",
							["spells"] = {
								["_ActorTable"] = {
									["击倒"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 159,
										["targets"] = {
											["嚣张的步伐"] = 159,
											["鲁豫"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 159,
										["n_min"] = 159,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 159,
										["c_max"] = 0,
										["id"] = "击倒",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["RESIST"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 334,
										["targets"] = {
											["嚣张的步伐"] = 506,
											["窥见身外之身"] = 334,
											["鲁豫"] = 778,
											["处男刺青"] = 233,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1851,
										["n_min"] = 233,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 1851,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["狂怒"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "狂怒",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593697287,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 14658.005768,
							["start_time"] = 1593697268,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006574,
							["damage_from"] = {
								["鲁豫"] = true,
								["窥见身外之身"] = true,
								["处男刺青"] = true,
								["舅子大帅比"] = true,
								["灬坏蛋灬"] = true,
								["甜汤"] = true,
								["贼浪漫"] = true,
								["币毛漫天浪"] = true,
								["小漾丶钻石"] = true,
								["小花妹"] = true,
								["小白不黑"] = true,
								["风哥"] = true,
							},
							["targets"] = {
								["窥见身外之身"] = 710,
								["风哥"] = 142,
								["小花妹"] = 595,
							},
							["pets"] = {
							},
							["monster"] = true,
							["total"] = 1447.006574,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1447.006574,
							["serial"] = "Creature-0-4999-0-282-11346-00007DDB8E",
							["fight_component"] = true,
							["end_time"] = 1593697290,
							["dps_started"] = false,
							["on_hold"] = false,
							["nome"] = "哈卡莱神谕者",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 710,
										["g_amt"] = 0,
										["n_max"] = 142,
										["targets"] = {
											["风哥"] = 142,
											["窥见身外之身"] = 710,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 142,
										["n_min"] = 142,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 852,
										["c_max"] = 710,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 710,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["地震术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 595,
										["targets"] = {
											["小花妹"] = 595,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 595,
										["n_min"] = 595,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 595,
										["c_max"] = 0,
										["id"] = "地震术",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593697274,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 6225.006574,
							["start_time"] = 1593697283,
							["delay"] = 1593697274,
							["friendlyfire_total"] = 0,
						}, -- [3]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004282,
							["damage_from"] = {
								["哈卡莱神谕者"] = true,
							},
							["targets"] = {
								["哈卡莱神谕者"] = 360,
								["古拉巴什战士"] = 208,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 568.004282,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 568.004282,
							["serial"] = "Player-4920-01D157B4",
							["end_time"] = 1593697290,
							["nome"] = "风哥",
							["spells"] = {
								["_ActorTable"] = {
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["古拉巴什战士"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 104,
										["targets"] = {
											["古拉巴什战士"] = 208,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 208,
										["n_min"] = 104,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 208,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["盾牌猛击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 360,
										["targets"] = {
											["哈卡莱神谕者"] = 360,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 360,
										["n_min"] = 360,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 360,
										["c_max"] = 0,
										["id"] = "盾牌猛击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697274,
							["damage_taken"] = 142.004282,
							["start_time"] = 1593697284,
							["delay"] = 1593697274,
							["classe"] = "WARRIOR",
						}, -- [4]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.003192,
							["damage_from"] = {
							},
							["targets"] = {
								["哈卡莱神谕者"] = 535,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 535.003192,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 535.003192,
							["serial"] = "Player-4920-01D03E40",
							["end_time"] = 1593697290,
							["nome"] = "灬坏蛋灬",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 484,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["哈卡莱神谕者"] = 484,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 484,
										["c_max"] = 484,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 484,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["重伤"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 51,
										["targets"] = {
											["哈卡莱神谕者"] = 51,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 51,
										["n_min"] = 51,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 51,
										["c_max"] = 0,
										["id"] = "重伤",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697274,
							["damage_taken"] = 0.003192,
							["start_time"] = 1593697285,
							["delay"] = 1593697274,
							["classe"] = "WARRIOR",
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 125,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 125,
					["_ActorTable"] = {
						{
							["received"] = 25.005068,
							["resource"] = 0.005068,
							["targets"] = {
								["风哥"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.005068,
							["total"] = 25.005068,
							["nome"] = "风哥",
							["spells"] = {
								["_ActorTable"] = {
									["血性狂暴"] = {
										["total"] = 25,
										["id"] = "血性狂暴",
										["totalover"] = 0,
										["targets"] = {
											["风哥"] = 25,
										},
										["counter"] = 11,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["flag_original"] = 1300,
							["last_event"] = 1593697279,
							["alternatepower"] = 0.005068,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D157B4",
							["totalover"] = 0.005068,
						}, -- [1]
						{
							["received"] = 1.005975,
							["resource"] = 0.005975,
							["targets"] = {
								["灬坏蛋灬"] = 1,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.005975,
							["total"] = 1.005975,
							["nome"] = "灬坏蛋灬",
							["spells"] = {
								["_ActorTable"] = {
									["怒不可遏"] = {
										["total"] = 1,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["灬坏蛋灬"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["flag_original"] = 1300,
							["last_event"] = 1593697271,
							["alternatepower"] = 0.005975,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D03E40",
							["totalover"] = 0.005975,
						}, -- [2]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 125,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["心灵尖啸"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 3,
										["id"] = "心灵尖啸",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["dispell"] = 1.006413,
							["buff_uptime"] = 48,
							["classe"] = "PRIEST",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["神圣之灵"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 24,
										["id"] = "神圣之灵",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["真言术：韧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 24,
										["id"] = "真言术：韧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["dispell_spells"] = {
								["_ActorTable"] = {
									["驱散魔法"] = {
										["dispell"] = 1,
										["id"] = "驱散魔法",
										["dispell_oque"] = {
											["冰霜新星"] = 1,
										},
										["targets"] = {
											["板板狗"] = 1,
										},
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_targets"] = {
							},
							["debuff_uptime"] = 3,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["驱散魔法"] = 2,
								["心灵尖啸"] = 1,
							},
							["pets"] = {
							},
							["dispell_targets"] = {
								["板板狗"] = 1,
							},
							["tipo"] = 4,
							["nome"] = "板板狗",
							["last_event"] = 1593697290,
							["serial"] = "Player-4920-01D0B865",
							["dispell_oque"] = {
								["冰霜新星"] = 1,
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "风哥",
							["buff_uptime"] = 10,
							["tipo"] = 4,
							["spell_cast"] = {
								["破甲攻击"] = 1,
								["盾牌猛击"] = 1,
								["血性狂暴"] = 1,
							},
							["classe"] = "WARRIOR",
							["pets"] = {
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1593697266,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["血性狂暴"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "血性狂暴",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D157B4",
							["last_event"] = 1593697279,
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["猎人印记"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "猎人印记",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["灵猴守护"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 24,
										["id"] = "灵猴守护",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["狂怒之嚎"] = {
										["activedamt"] = 1,
										["id"] = "狂怒之嚎",
										["targets"] = {
										},
										["actived_at"] = 1593697291,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 5,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["猎人印记"] = 1,
							},
							["nome"] = "香油田鸡",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593697291,
							["serial"] = "Player-4920-026E1D50",
							["buff_uptime"] = 24,
						}, -- [3]
						{
							["flag_original"] = 1300,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["classe"] = "MAGE",
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["魔甲术"] = 1,
							},
							["nome"] = "潇潇",
							["pets"] = {
							},
							["last_event"] = 1593697290,
							["buff_uptime"] = 65,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["activedamt"] = 1,
										["id"] = "无荣誉目标",
										["targets"] = {
										},
										["actived_at"] = 1593697266,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 24,
										["id"] = "魔甲术",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 24,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["nome"] = "窥见身外之身",
							["spell_cast"] = {
								["魔爆术"] = 3,
								["寒冰护体"] = 1,
							},
							["tipo"] = 4,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime"] = 17,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 17,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-02628F22",
							["last_event"] = 1593697290,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "哈卡莱神谕者",
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["地震术"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4999-0-282-11346-00007DDB8E",
							["classe"] = "UNKNOW",
						}, -- [6]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "古拉巴什战士",
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["击倒"] = 2,
								["狂怒"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4999-0-282-11355-00007DDB7E",
							["classe"] = "UNKNOW",
						}, -- [7]
						{
							["flag_original"] = 1300,
							["debuff_uptime"] = 6,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["重伤"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = "重伤",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "灬坏蛋灬",
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime"] = 16,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1593697286,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = "乱舞",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D03E40",
							["classe"] = "WARRIOR",
						}, -- [8]
						{
							["flag_original"] = 1300,
							["nome"] = "奇异灬博士",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "WARLOCK",
							["tipo"] = 4,
							["spell_cast"] = {
								["召唤仪式"] = 1,
							},
							["serial"] = "Player-4920-01EBF4BE",
							["last_event"] = 0,
						}, -- [9]
						{
							["flag_original"] = 1300,
							["buff_uptime_targets"] = {
							},
							["spec"] = 260,
							["grupo"] = true,
							["buff_uptime"] = 0,
							["nome"] = "希洛克",
							["pets"] = {
							},
							["last_event"] = 1593697290,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D09CF8",
							["tipo"] = 4,
						}, -- [10]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 125,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["火抗梯"] = true,
					["星游"] = true,
					["幼儿园战神"] = true,
					["风哥"] = true,
					["不帅还有点坏"] = true,
					["奇异灬博士"] = true,
					["窥见身外之身"] = true,
					["带鳝人"] = true,
					["赚她一个亿"] = true,
					["潇潇"] = true,
					["油焖小龙虾"] = true,
					["灬坏蛋灬"] = true,
					["就是个厨子"] = true,
					["板板狗"] = true,
					["希洛克"] = true,
					["小米有品"] = true,
					["补阳还五汤"] = true,
					["香油田鸡"] = true,
					["半瓶矿泉水灬"] = true,
					["过兒我是咕咕"] = true,
				},
				["CombatStartedAt"] = 81476.979,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					6510.932448, -- [1]
					-0.0365730000000003, -- [2]
					{
						25.984276, -- [1]
						[0] = -0.0182819999999979,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0.993601,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "21:41:31",
				["cleu_timeline"] = {
				},
				["enemy"] = "古拉巴什战士",
				["TotalElapsedCombatTime"] = 81431.928,
				["CombatEndedAt"] = 81431.928,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:41:07",
				["end_time"] = 81455.494,
				["combat_id"] = 125,
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1593697266,
				["frags"] = {
					["灼热图腾"] = 1,
					["古拉巴什战士"] = 2,
					["哈卡莱神谕者"] = 1,
					["处男刺青"] = 1,
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["窥见身外之身"] = 1951.00763,
							["灬坏蛋灬"] = 535.003192,
							["风哥"] = 568.004282,
						}, -- [1]
					},
				},
				["combat_counter"] = 741,
				["CombatSkillCache"] = {
				},
				["contra"] = "古拉巴什战士",
				["start_time"] = 81431.493,
				["TimeData"] = {
				},
				["totals_grupo"] = {
					3054, -- [1]
					0, -- [2]
					{
						26, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 1,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 124,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005767,
							["damage_from"] = {
								["霜影碎寒水"] = true,
							},
							["targets"] = {
								["古拉巴什战士"] = 608,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 608.005767,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 608.005767,
							["serial"] = "Player-4920-01D03E40",
							["end_time"] = 1593697244,
							["nome"] = "灬坏蛋灬",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 203,
										["g_amt"] = 0,
										["n_max"] = 86,
										["targets"] = {
											["古拉巴什战士"] = 289,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 86,
										["n_min"] = 86,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 289,
										["c_max"] = 203,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 203,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["英勇打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 319,
										["targets"] = {
											["古拉巴什战士"] = 319,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 319,
										["n_min"] = 319,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 319,
										["c_max"] = 0,
										["id"] = "英勇打击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697241,
							["damage_taken"] = 35.005767,
							["start_time"] = 1593697239,
							["delay"] = 0,
							["classe"] = "WARRIOR",
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003031,
							["damage_from"] = {
								["鲁豫"] = true,
								["窥见身外之身"] = true,
								["处男刺青"] = true,
								["灬坏蛋灬"] = true,
								["小白不黑"] = true,
								["嚣张的步伐"] = true,
								["贼浪漫"] = true,
								["灼热图腾 <不是萨满>"] = true,
								["混分巨兽"] = true,
							},
							["targets"] = {
								["混分巨兽"] = 134,
							},
							["pets"] = {
							},
							["monster"] = true,
							["total"] = 134.003031,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 134.003031,
							["serial"] = "Creature-0-4999-0-282-11355-00007DE3C2",
							["fight_component"] = true,
							["end_time"] = 1593697244,
							["dps_started"] = false,
							["on_hold"] = false,
							["nome"] = "古拉巴什战士",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 134,
										["targets"] = {
											["混分巨兽"] = 134,
											["贼浪漫"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 134,
										["n_min"] = 134,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 134,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593697241,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 5559.003031,
							["start_time"] = 1593697241,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001953,
							["damage_from"] = {
								["霜影碎寒水"] = true,
							},
							["targets"] = {
								["古拉巴什战士"] = 602,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 602.001953,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 602.001953,
							["serial"] = "Player-4920-02628F22",
							["end_time"] = 1593697244,
							["nome"] = "窥见身外之身",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 602,
										["targets"] = {
											["古拉巴什战士"] = 602,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 602,
										["n_min"] = 602,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 602,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697241,
							["damage_taken"] = 31.001953,
							["start_time"] = 1593697241,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [3]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004457,
							["damage_from"] = {
								["霜影碎寒水"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
								"劲爆鸡米花 <香油田鸡>", -- [1]
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004457,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.004457,
							["serial"] = "Player-4920-026E1D50",
							["end_time"] = 1593697266,
							["nome"] = "香油田鸡",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 31.004457,
							["start_time"] = 1593697266,
							["delay"] = 0,
							["classe"] = "HUNTER",
						}, -- [4]
						{
							["flag_original"] = 4372,
							["totalabsorbed"] = 0.001788,
							["damage_from"] = {
								["霜影碎寒水"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001788,
							["classe"] = "PET",
							["dps_started"] = false,
							["total"] = 0.001788,
							["serial"] = "Pet-0-4504-309-23514-14339-0100CBA968",
							["ownerName"] = "香油田鸡",
							["nome"] = "劲爆鸡米花 <香油田鸡>",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["end_time"] = 1593697266,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32.001788,
							["start_time"] = 1593697266,
							["delay"] = 0,
							["friendlyfire"] = {
							},
						}, -- [5]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001549,
							["damage_from"] = {
								["霜影碎寒水"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001549,
							["serial"] = "Player-4920-022A2037",
							["dps_started"] = false,
							["total"] = 0.001549,
							["spec"] = 64,
							["on_hold"] = false,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1593697266,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 30.001549,
							["start_time"] = 1593697266,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [6]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008064,
							["damage_from"] = {
								["霜影碎寒水"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008064,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.008064,
							["serial"] = "Player-4920-01EBF4BE",
							["end_time"] = 1593697266,
							["nome"] = "奇异灬博士",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 30.008064,
							["start_time"] = 1593697266,
							["delay"] = 0,
							["classe"] = "WARLOCK",
						}, -- [7]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005678,
							["damage_from"] = {
								["霜影碎寒水"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005678,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.005678,
							["serial"] = "Player-4920-01D0B865",
							["end_time"] = 1593697266,
							["nome"] = "板板狗",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 32.005678,
							["start_time"] = 1593697266,
							["delay"] = 0,
							["classe"] = "PRIEST",
						}, -- [8]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 124,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 124,
					["_ActorTable"] = {
						{
							["received"] = 1.006278,
							["resource"] = 0.006278,
							["targets"] = {
								["灬坏蛋灬"] = 1,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.006278,
							["total"] = 1.006278,
							["nome"] = "灬坏蛋灬",
							["spells"] = {
								["_ActorTable"] = {
									["怒不可遏"] = {
										["total"] = 1,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["灬坏蛋灬"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["flag_original"] = 1300,
							["last_event"] = 1593697242,
							["alternatepower"] = 0.006278,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D03E40",
							["totalover"] = 0.006278,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 124,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["nome"] = "板板狗",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "PRIEST",
							["buff_uptime"] = 10,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["神圣之灵"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "神圣之灵",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["真言术：韧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "真言术：韧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D0B865",
							["last_event"] = 1593697244,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["buff_uptime_targets"] = {
							},
							["spec"] = 260,
							["grupo"] = true,
							["buff_uptime"] = 5,
							["nome"] = "希洛克",
							["pets"] = {
							},
							["last_event"] = 1593697244,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D09CF8",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["重伤"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 3,
										["id"] = "重伤",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 5,
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "乱舞",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 3,
							["nome"] = "灬坏蛋灬",
							["grupo"] = true,
							["spell_cast"] = {
								["英勇打击"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593697244,
							["serial"] = "Player-4920-01D03E40",
							["pets"] = {
							},
						}, -- [3]
						{
							["flag_original"] = 1300,
							["nome"] = "香油田鸡",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "HUNTER",
							["buff_uptime"] = 10,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "无荣誉目标",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["灵猴守护"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "灵猴守护",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-026E1D50",
							["last_event"] = 1593697244,
						}, -- [4]
						{
							["flag_original"] = 1300,
							["buff_uptime_targets"] = {
							},
							["spec"] = 64,
							["grupo"] = true,
							["buff_uptime"] = 15,
							["nome"] = "潇潇",
							["pets"] = {
							},
							["last_event"] = 1593697244,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["无荣誉目标"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "无荣誉目标",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 4,
						}, -- [5]
						{
							["flag_original"] = 1298,
							["nome"] = "窥见身外之身",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["tipo"] = 4,
							["spell_cast"] = {
								["寒冰箭"] = 1,
							},
							["serial"] = "Player-4920-02628F22",
							["last_event"] = 0,
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 124,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["火抗梯"] = true,
					["星游"] = true,
					["幼儿园战神"] = true,
					["风哥"] = true,
					["不帅还有点坏"] = true,
					["奇异灬博士"] = true,
					["窥见身外之身"] = true,
					["带鳝人"] = true,
					["赚她一个亿"] = true,
					["潇潇"] = true,
					["油焖小龙虾"] = true,
					["灬坏蛋灬"] = true,
					["就是个厨子"] = true,
					["板板狗"] = true,
					["希洛克"] = true,
					["小米有品"] = true,
					["补阳还五汤"] = true,
					["香油田鸡"] = true,
					["半瓶矿泉水灬"] = true,
					["过兒我是咕咕"] = true,
				},
				["CombatStartedAt"] = 81425.872,
				["tempo_start"] = 1593697239,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["enemy"] = "古拉巴什战士",
				["combat_counter"] = 740,
				["overall_added"] = true,
				["totals"] = {
					1343.878614, -- [1]
					-0.0390730000000294, -- [2]
					{
						0.989585999999999, -- [1]
						[0] = -0.0205179999999824,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = -0.016834,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["窥见身外之身"] = {
						{
							true, -- [1]
							"冰霜新星", -- [2]
							31, -- [3]
							1593697260.844, -- [4]
							3010, -- [5]
							"霜影碎寒水", -- [6]
							nil, -- [7]
							16, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
					["板板狗"] = {
						{
							true, -- [1]
							"冰霜新星", -- [2]
							32, -- [3]
							1593697260.844, -- [4]
							5127, -- [5]
							"霜影碎寒水", -- [6]
							nil, -- [7]
							16, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
					["香油田鸡"] = {
						{
							true, -- [1]
							"冰霜新星", -- [2]
							31, -- [3]
							1593697260.844, -- [4]
							4507, -- [5]
							"霜影碎寒水", -- [6]
							nil, -- [7]
							16, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
					["潇潇"] = {
						{
							true, -- [1]
							"冰霜新星", -- [2]
							30, -- [3]
							1593697260.844, -- [4]
							4440, -- [5]
							"霜影碎寒水", -- [6]
							nil, -- [7]
							16, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
					["奇异灬博士"] = {
						{
							true, -- [1]
							"冰霜新星", -- [2]
							30, -- [3]
							1593697260.844, -- [4]
							4484, -- [5]
							"霜影碎寒水", -- [6]
							nil, -- [7]
							16, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
					["灬坏蛋灬"] = {
						{
							true, -- [1]
							"冰霜新星", -- [2]
							35, -- [3]
							1593697260.844, -- [4]
							4279, -- [5]
							"霜影碎寒水", -- [6]
							nil, -- [7]
							16, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["cleu_timeline"] = {
				},
				["frags_need_refresh"] = true,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["窥见身外之身"] = 602.001953,
							["灬坏蛋灬"] = 608.005767,
						}, -- [1]
					},
				},
				["end_time"] = 81409.44,
				["cleu_events"] = {
					["n"] = 1,
				},
				["combat_id"] = 124,
				["frags"] = {
					["古拉巴什战士"] = 1,
				},
				["totals_grupo"] = {
					1210, -- [1]
					0, -- [2]
					{
						1, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["hasSaved"] = true,
				["spells_cast_timeline"] = {
				},
				["data_fim"] = "21:40:45",
				["instance_type"] = "none",
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "21:40:40",
				["start_time"] = 81404.436,
				["TimeData"] = {
				},
				["contra"] = "古拉巴什战士",
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005997,
							["damage_from"] = {
							},
							["targets"] = {
								["潇潇"] = 93,
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 93.005997,
							["serial"] = "Creature-0-4505-0-197-4474-000076C37C",
							["dps_started"] = false,
							["total"] = 93.005997,
							["monster"] = true,
							["damage_taken"] = 0.005997,
							["nome"] = "腐烂的死尸",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 93,
										["targets"] = {
											["潇潇"] = 93,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 93,
										["n_min"] = 93,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 93,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593234333,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234318,
							["on_hold"] = false,
							["start_time"] = 1593234332,
							["delay"] = 1593234318,
							["classe"] = "UNKNOW",
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00321,
							["damage_from"] = {
								["腐烂的死尸"] = true,
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00321,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.00321,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593234333,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["damage_taken"] = 849.00321,
							["start_time"] = 1593234333,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003663,
							["damage_from"] = {
							},
							["targets"] = {
								["古拉巴什战士"] = 492,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 492.003663,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 492.003663,
							["serial"] = "Player-4920-02628F22",
							["end_time"] = 1593697239,
							["nome"] = "窥见身外之身",
							["spells"] = {
								["_ActorTable"] = {
									["暴风雪"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 164,
										["targets"] = {
											["古拉巴什战士"] = 492,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 492,
										["n_min"] = 164,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 492,
										["c_max"] = 0,
										["id"] = "暴风雪",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697238,
							["damage_taken"] = 0.003663,
							["start_time"] = 1593697236,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [3]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004974,
							["damage_from"] = {
							},
							["targets"] = {
								["古拉巴什战士"] = 476,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 476.004974,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 476.004974,
							["serial"] = "Player-4920-01D03E40",
							["end_time"] = 1593697239,
							["nome"] = "灬坏蛋灬",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 476,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["古拉巴什战士"] = 476,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 476,
										["c_max"] = 476,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 476,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593697238,
							["damage_taken"] = 0.004974,
							["start_time"] = 1593697238,
							["delay"] = 0,
							["classe"] = "WARRIOR",
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 93.004095,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["潇潇"] = 93,
							},
							["total"] = 93.004095,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["classe"] = "MAGE",
							["totalover"] = 0.004095,
							["total_without_pet"] = 93.004095,
							["totalover_without_pet"] = 0.004095,
							["start_time"] = 1593234332,
							["fight_component"] = true,
							["end_time"] = 1593234333,
							["healing_taken"] = 93.004095,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 93,
							},
							["grupo"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 93,
										["targets_overheal"] = {
										},
										["n_max"] = 93,
										["targets"] = {
											["潇潇"] = 93,
										},
										["n_min"] = 93,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 93,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 93,
										},
										["c_curado"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 93,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["custom"] = 0,
							["last_event"] = 1593234318,
							["on_hold"] = false,
							["totaldenied"] = 0.004095,
							["delay"] = 1593234318,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 123,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["fight_component"] = true,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["flag_original"] = 1047,
							["buff_uptime"] = 60,
							["nome"] = "潇潇",
							["last_event"] = 1593234333,
							["tipo"] = 4,
							["pets"] = {
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["紫色骷髅战马"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "紫色骷髅战马",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 1300,
							["nome"] = "奇异灬博士",
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["classe"] = "WARLOCK",
							["buff_uptime"] = 0,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["血之契印"] = {
										["activedamt"] = 1,
										["id"] = "血之契印",
										["targets"] = {
										},
										["actived_at"] = 1593697236,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01EBF4BE",
							["last_event"] = 1593697236,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 123,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 735,
				["playing_solo"] = true,
				["totals"] = {
					1060.672107, -- [1]
					93, -- [2]
					{
						-0.011469, -- [1]
						[0] = -0.00863300000003164,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["潇潇"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							450, -- [3]
							1593234463.524, -- [4]
							3730, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							82, -- [3]
							1593234477.088, -- [4]
							3416, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							"Falling", -- [2]
							224, -- [3]
							1593234701.25, -- [4]
							3730, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 4,
					},
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "13:05:34",
				["cleu_timeline"] = {
				},
				["enemy"] = "腐烂的死尸",
				["TotalElapsedCombatTime"] = 156029.357,
				["CombatEndedAt"] = 156029.357,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 93.004095,
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 0.00321,
						}, -- [1]
					},
				},
				["end_time"] = 156029.357,
				["combat_id"] = 123,
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1593234318,
				["frags"] = {
				},
				["contra"] = "腐烂的死尸",
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					968, -- [1]
					93, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 156014.378,
				["TimeData"] = {
				},
				["data_inicio"] = "13:05:19",
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 122,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005055,
							["damage_from"] = {
								["坏死的僵尸"] = true,
							},
							["targets"] = {
								["坏死的僵尸"] = 3366,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3366.005055,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 3366.005055,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593234235,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 664,
										["targets"] = {
											["坏死的僵尸"] = 664,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 664,
										["n_min"] = 664,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 664,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 917,
										["targets"] = {
											["坏死的僵尸"] = 2702,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2702,
										["n_min"] = 888,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2702,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234233,
							["damage_taken"] = 86.005055,
							["start_time"] = 1593234228,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 86.004249,
							["damage_from"] = {
								["血色猎人"] = true,
								["潇潇"] = true,
								["血色祈求者"] = true,
							},
							["targets"] = {
								["血色祈求者"] = 60,
								["潇潇"] = 86,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 146.004249,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 146.004249,
							["serial"] = "Creature-0-4505-0-197-4475-000076C94D",
							["monster"] = true,
							["end_time"] = 1593234318,
							["fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "坏死的僵尸",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 86,
										["targets"] = {
											["血色祈求者"] = 60,
											["潇潇"] = 86,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 146,
										["n_min"] = 60,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 146,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593234241,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3625.004249,
							["start_time"] = 1593234308,
							["delay"] = 1593234241,
							["friendlyfire_total"] = 0,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 122,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 86.004762,
							["last_hps"] = 0,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 86,
							},
							["total"] = 86.004762,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.004762,
							["targets_overheal"] = {
							},
							["classe"] = "MAGE",
							["totalover"] = 0.004762,
							["total_without_pet"] = 86.004762,
							["iniciar_hps"] = false,
							["start_time"] = 1593234232,
							["fight_component"] = true,
							["end_time"] = 1593234235,
							["healing_taken"] = 86.004762,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 86,
							},
							["grupo"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 86,
										["targets_overheal"] = {
										},
										["n_max"] = 86,
										["targets"] = {
											["潇潇"] = 86,
										},
										["n_min"] = 86,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 86,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 86,
										},
										["c_curado"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 86,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["delay"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234232,
							["on_hold"] = false,
							["totaldenied"] = 0.004762,
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 122,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 122,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 4,
										["id"] = "寒冰箭",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 28,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 4,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
								["寒冰箭"] = 2,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["last_event"] = 1593234235,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 122,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 156013.56,
				["tempo_start"] = 1593234228,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 734,
				["playing_solo"] = true,
				["totals"] = {
					3511.977717, -- [1]
					86, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "13:03:56",
				["cleu_timeline"] = {
				},
				["enemy"] = "坏死的僵尸",
				["TotalElapsedCombatTime"] = 15.7299999999814,
				["CombatEndedAt"] = 155975.446,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 86.004762,
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 3366.005055,
						}, -- [1]
					},
				},
				["end_time"] = 155930.894,
				["combat_id"] = 122,
				["frags"] = {
					["坏死的僵尸"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3366, -- [1]
					86, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155924.537,
				["contra"] = "坏死的僵尸",
				["data_inicio"] = "13:03:49",
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 121,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008937,
							["damage_from"] = {
							},
							["targets"] = {
								["腐烂虫"] = 1189,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1189.008937,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 1189.008937,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593234221,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 606,
										["targets"] = {
											["腐烂虫"] = 1189,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1189,
										["n_min"] = 583,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1189,
										["c_max"] = 0,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234219,
							["damage_taken"] = 0.008937,
							["start_time"] = 1593234219,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007857,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007857,
							["serial"] = "Creature-0-4505-0-197-10925-0000F6D32A",
							["dps_started"] = false,
							["total"] = 0.007857,
							["monster"] = true,
							["damage_taken"] = 1189.007857,
							["nome"] = "腐烂虫",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593234221,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1593234221,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 121,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 121,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 121,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime"] = 0,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["activedamt"] = -1,
										["id"] = "冰锥术",
										["targets"] = {
										},
										["actived_at"] = 1593234219,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "潇潇",
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime"] = 8,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1593234221,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-022A2037",
							["classe"] = "MAGE",
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 121,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155924.086,
				["tempo_start"] = 1593234219,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 733,
				["playing_solo"] = true,
				["totals"] = {
					1189, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "13:03:42",
				["cleu_timeline"] = {
				},
				["enemy"] = "腐烂虫",
				["TotalElapsedCombatTime"] = 155917.631,
				["CombatEndedAt"] = 155917.631,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 1189.008937,
						}, -- [1]
					},
				},
				["end_time"] = 155917.631,
				["combat_id"] = 121,
				["frags"] = {
					["腐烂虫"] = 2,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					1189, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155915.598,
				["contra"] = "腐烂虫",
				["data_inicio"] = "13:03:40",
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004626,
							["damage_from"] = {
								["腐烂的死尸"] = true,
								["腐烂虫"] = true,
							},
							["targets"] = {
								["腐烂的死尸"] = 3613,
								["护锅者玛维诺斯"] = 3236,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 6849.004626,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 6849.004626,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593234218,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 773,
										["targets"] = {
											["腐烂的死尸"] = 773,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 773,
										["n_min"] = 773,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 773,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1096,
										["targets"] = {
											["腐烂的死尸"] = 2840,
											["护锅者玛维诺斯"] = 3236,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 6076,
										["n_min"] = 906,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 6076,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234217,
							["damage_taken"] = 494.004626,
							["start_time"] = 1593234199,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003924,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003924,
							["serial"] = "Creature-0-4505-0-197-11077-000076D2FE",
							["dps_started"] = false,
							["total"] = 0.003924,
							["monster"] = true,
							["damage_taken"] = 3236.003924,
							["nome"] = "护锅者玛维诺斯",
							["spells"] = {
								["_ActorTable"] = {
									["暗影箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["潇潇"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "暗影箭",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["RESIST"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593234218,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234203,
							["on_hold"] = false,
							["start_time"] = 1593234218,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 347.006309,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 438,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 438.006309,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 438.006309,
							["serial"] = "Creature-0-4505-0-197-4474-000076CF0F",
							["monster"] = true,
							["end_time"] = 1593234218,
							["fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "腐烂的死尸",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 96,
										["targets"] = {
											["潇潇"] = 438,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 438,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 438,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 91,
										["r_amt"] = 0,
									},
									["腐化耐力"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["潇潇"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "腐化耐力",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["RESIST"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593234216,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3613.006309,
							["start_time"] = 1593234204,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 390.007822,
							["last_hps"] = 0,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 390,
							},
							["total"] = 390.007822,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.007822,
							["targets_overheal"] = {
							},
							["classe"] = "MAGE",
							["totalover"] = 0.007822,
							["total_without_pet"] = 390.007822,
							["iniciar_hps"] = false,
							["start_time"] = 1593234204,
							["fight_component"] = true,
							["end_time"] = 1593234218,
							["healing_taken"] = 390.007822,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 390,
							},
							["grupo"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 390,
										["targets_overheal"] = {
										},
										["n_max"] = 96,
										["targets"] = {
											["潇潇"] = 390,
										},
										["n_min"] = 43,
										["counter"] = 5,
										["overheal"] = 0,
										["total"] = 390,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 390,
										},
										["c_curado"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 390,
										["n_amt"] = 5,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["delay"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234215,
							["on_hold"] = false,
							["totaldenied"] = 0.007822,
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["received"] = 340.007741,
							["resource"] = 0.007741,
							["targets"] = {
								["潇潇"] = 340,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.007741,
							["fight_component"] = true,
							["total"] = 340.007741,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 340,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["潇潇"] = 340,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["flag_original"] = 1297,
							["last_event"] = 1593234204,
							["alternatepower"] = 0.007741,
							["tipo"] = 3,
							["serial"] = "Player-4920-022A2037",
							["totalover"] = 0.007741,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 120,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 17,
										["id"] = "寒冰箭",
										["refreshamt"] = 3,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 88,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 16,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 19,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["能量无常"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "能量无常",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 19,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 19,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 17,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["寒冰箭"] = 5,
								["火焰冲击"] = 1,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["last_event"] = 1593234218,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["nome"] = "护锅者玛维诺斯",
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["暗影箭"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4505-0-197-11077-000076D2FE",
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 120,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155915.148,
				["tempo_start"] = 1593234199,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 732,
				["playing_solo"] = true,
				["totals"] = {
					7286.991993, -- [1]
					390, -- [2]
					{
						0, -- [1]
						[0] = 340,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["潇潇"] = {
						{
							true, -- [1]
							"!Melee", -- [2]
							56, -- [3]
							1593234218.908, -- [4]
							3642, -- [5]
							"腐烂虫", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "13:03:39",
				["cleu_timeline"] = {
				},
				["enemy"] = "腐烂的死尸",
				["TotalElapsedCombatTime"] = 155913.981,
				["CombatEndedAt"] = 155913.981,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 390.007822,
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 6849.004626,
						}, -- [1]
					},
				},
				["end_time"] = 155913.981,
				["combat_id"] = 120,
				["frags"] = {
					["腐烂的死尸"] = 1,
					["护锅者玛维诺斯"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					6849, -- [1]
					390, -- [2]
					{
						0, -- [1]
						[0] = 340,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155895.084,
				["contra"] = "护锅者玛维诺斯",
				["data_inicio"] = "13:03:20",
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 119,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 50.007227,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 161,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 161.007227,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 161.007227,
							["serial"] = "Creature-0-4505-0-197-10925-000076D309",
							["monster"] = true,
							["end_time"] = 1593234188,
							["fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "腐烂虫",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 111,
										["targets"] = {
											["潇潇"] = 161,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 161,
										["n_min"] = 50,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 161,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593234187,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1809.007227,
							["start_time"] = 1593234187,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005107,
							["damage_from"] = {
								["腐烂虫"] = true,
							},
							["targets"] = {
								["腐烂虫"] = 1809,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1809.005107,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 1809.005107,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593234188,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1201,
										["g_amt"] = 0,
										["n_max"] = 608,
										["targets"] = {
											["腐烂虫"] = 1809,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 608,
										["n_min"] = 608,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1809,
										["c_max"] = 1201,
										["id"] = "冰锥术",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1201,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234187,
							["damage_taken"] = 161.005107,
							["start_time"] = 1593234187,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 119,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 161.005572,
							["last_hps"] = 0,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 161,
							},
							["total"] = 161.005572,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.005572,
							["targets_overheal"] = {
							},
							["classe"] = "MAGE",
							["totalover"] = 0.005572,
							["total_without_pet"] = 161.005572,
							["iniciar_hps"] = false,
							["start_time"] = 1593234187,
							["fight_component"] = true,
							["end_time"] = 1593234188,
							["healing_taken"] = 161.005572,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 161,
							},
							["grupo"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 161,
										["targets_overheal"] = {
										},
										["n_max"] = 111,
										["targets"] = {
											["潇潇"] = 161,
										},
										["n_min"] = 50,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 161,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 161,
										},
										["c_curado"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 161,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["delay"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234187,
							["on_hold"] = false,
							["totaldenied"] = 0.005572,
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 119,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 119,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰锥术"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = "冰锥术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 0,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["nome"] = "潇潇",
							["last_event"] = 1593234188,
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 119,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155894.03,
				["tempo_start"] = 1593234187,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 731,
				["playing_solo"] = true,
				["totals"] = {
					1970, -- [1]
					161, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "13:03:09",
				["cleu_timeline"] = {
				},
				["enemy"] = "腐烂虫",
				["TotalElapsedCombatTime"] = 155884.787,
				["CombatEndedAt"] = 155884.787,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 161.005572,
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 1809.005107,
						}, -- [1]
					},
				},
				["end_time"] = 155884.787,
				["combat_id"] = 119,
				["frags"] = {
					["腐烂虫"] = 2,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					1809, -- [1]
					161, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155883.37,
				["contra"] = "腐烂虫",
				["data_inicio"] = "13:03:08",
			}, -- [10]
			{
				{
					["tipo"] = 2,
					["combatId"] = 118,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 391.008958,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 481,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["monster"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 481.008958,
							["serial"] = "Creature-0-4505-0-197-4474-000076D043",
							["dps_started"] = false,
							["end_time"] = 1593234185,
							["total"] = 481.008958,
							["on_hold"] = false,
							["nome"] = "腐烂的死尸",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 103,
										["targets"] = {
											["潇潇"] = 481,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 481,
										["n_min"] = 90,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 481,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["腐化耐力"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["潇潇"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "腐化耐力",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["RESIST"] = 1,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["b_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593234184,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3334.008958,
							["start_time"] = 1593234174,
							["delay"] = 0,
							["fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008876,
							["damage_from"] = {
								["腐烂的死尸"] = true,
								["腐烂虫"] = true,
							},
							["targets"] = {
								["腐烂的死尸"] = 3334,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3334.008876,
							["end_time"] = 1593234185,
							["dps_started"] = false,
							["total"] = 3334.008876,
							["serial"] = "Player-4920-022A2037",
							["friendlyfire_total"] = 0,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 660,
										["targets"] = {
											["腐烂的死尸"] = 660,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 660,
										["n_min"] = 660,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 660,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1773,
										["g_amt"] = 0,
										["n_max"] = 901,
										["targets"] = {
											["腐烂的死尸"] = 2674,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 901,
										["n_min"] = 901,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2674,
										["c_max"] = 1773,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1773,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["last_event"] = 1593234184,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 583.008876,
							["start_time"] = 1593234180,
							["delay"] = 0,
							["on_hold"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 118,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 391.008298,
							["last_hps"] = 0,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 391,
							},
							["total"] = 391.008298,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.008298,
							["targets_overheal"] = {
							},
							["classe"] = "MAGE",
							["totalover"] = 0.008298,
							["total_without_pet"] = 391.008298,
							["iniciar_hps"] = false,
							["start_time"] = 1593234176,
							["fight_component"] = true,
							["end_time"] = 1593234185,
							["healing_taken"] = 391.008298,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 391,
							},
							["grupo"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 391,
										["targets_overheal"] = {
										},
										["n_max"] = 103,
										["targets"] = {
											["潇潇"] = 391,
										},
										["n_min"] = 92,
										["counter"] = 4,
										["overheal"] = 0,
										["total"] = 391,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 391,
										},
										["c_curado"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 391,
										["n_amt"] = 4,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["delay"] = 0,
							["custom"] = 0,
							["last_event"] = 1593234182,
							["on_hold"] = false,
							["totaldenied"] = 0.008298,
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 118,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 118,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 4,
										["id"] = "寒冰箭",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 43,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 11,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 11,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["紫色骷髅战马"] = {
										["activedamt"] = 1,
										["id"] = "紫色骷髅战马",
										["targets"] = {
										},
										["actived_at"] = 1593234174,
										["uptime"] = 0,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = true,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 11,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 4,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰护体"] = 1,
								["寒冰箭"] = 2,
								["火焰冲击"] = 1,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["last_event"] = 1593234185,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 118,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155882.353,
				["tempo_start"] = 1593234174,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 730,
				["playing_solo"] = true,
				["totals"] = {
					3814.995285, -- [1]
					391, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
					["潇潇"] = {
						{
							true, -- [1]
							"!Melee", -- [2]
							57, -- [3]
							1593234185.996, -- [4]
							3640, -- [5]
							"腐烂虫", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"!Melee", -- [2]
							45, -- [3]
							1593234185.996, -- [4]
							3640, -- [5]
							"腐烂虫", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 3,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "13:03:06",
				["cleu_timeline"] = {
				},
				["enemy"] = "腐烂的死尸",
				["TotalElapsedCombatTime"] = 155881.519,
				["CombatEndedAt"] = 155881.519,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 391.008298,
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 3334.008876,
						}, -- [1]
					},
				},
				["end_time"] = 155881.519,
				["combat_id"] = 118,
				["frags"] = {
					["腐烂的死尸"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3334, -- [1]
					391, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155870.194,
				["contra"] = "腐烂的死尸",
				["data_inicio"] = "13:02:55",
			}, -- [11]
			{
				{
					["tipo"] = 2,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004994,
							["damage_from"] = {
								["喋喋不休的食尸鬼"] = true,
							},
							["targets"] = {
								["骷髅巫师"] = 2523,
								["喋喋不休的食尸鬼"] = 3300,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5823.004994,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 5823.004994,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593233957,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1702,
										["g_amt"] = 0,
										["n_max"] = 834,
										["targets"] = {
											["骷髅巫师"] = 2523,
											["喋喋不休的食尸鬼"] = 2482,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3303,
										["n_min"] = 820,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 5005,
										["c_max"] = 1702,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1702,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 167,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["喋喋不休的食尸鬼"] = 167,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 167,
										["c_max"] = 167,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 167,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 651,
										["targets"] = {
											["喋喋不休的食尸鬼"] = 651,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 651,
										["n_min"] = 651,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 651,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233957,
							["damage_taken"] = 83.004994,
							["start_time"] = 1593233946,
							["delay"] = 1593233945,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 83.008618,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 83,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 83.008618,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 83.008618,
							["serial"] = "Creature-0-4505-0-197-10801-000076CAE4",
							["monster"] = true,
							["end_time"] = 1593233957,
							["fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "喋喋不休的食尸鬼",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 83,
										["targets"] = {
											["潇潇"] = 83,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 83,
										["n_min"] = 83,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 83,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["狂怒"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "狂怒",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593233945,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3300.008618,
							["start_time"] = 1593233956,
							["delay"] = 1593233945,
							["friendlyfire_total"] = 0,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003203,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003203,
							["serial"] = "Creature-0-4505-0-197-1784-000076BC52",
							["dps_started"] = false,
							["total"] = 0.003203,
							["monster"] = true,
							["damage_taken"] = 2523.003203,
							["nome"] = "骷髅巫师",
							["spells"] = {
								["_ActorTable"] = {
									["火焰新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["潇潇"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "火焰新星",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["RESIST"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["潇潇"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["RESIST"] = 3,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593233957,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233956,
							["on_hold"] = false,
							["start_time"] = 1593233957,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 83.004548,
							["last_hps"] = 0,
							["healing_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
								["潇潇"] = 83,
							},
							["total"] = 83.004548,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.004548,
							["targets_overheal"] = {
							},
							["classe"] = "MAGE",
							["totalover"] = 0.004548,
							["total_without_pet"] = 83.004548,
							["iniciar_hps"] = false,
							["start_time"] = 1593233956,
							["fight_component"] = true,
							["end_time"] = 1593233957,
							["healing_taken"] = 83.004548,
							["heal_enemy_amt"] = 0,
							["nome"] = "潇潇",
							["targets_absorbs"] = {
								["潇潇"] = 83,
							},
							["grupo"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 83,
										["targets_overheal"] = {
										},
										["n_max"] = 83,
										["targets"] = {
											["潇潇"] = 83,
										},
										["n_min"] = 83,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 83,
										["c_max"] = 0,
										["id"] = "寒冰护体",
										["targets_absorbs"] = {
											["潇潇"] = 83,
										},
										["c_curado"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 83,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["is_shield"] = true,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["heal_enemy"] = {
							},
							["delay"] = 1593233945,
							["custom"] = 0,
							["last_event"] = 1593233945,
							["on_hold"] = false,
							["totaldenied"] = 0.004548,
							["serial"] = "Player-4920-022A2037",
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["received"] = 1390.002102,
							["resource"] = 0.002102,
							["targets"] = {
								["潇潇"] = 1390,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.002102,
							["fight_component"] = true,
							["total"] = 1390.002102,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["魔法吸收"] = {
										["total"] = 1390,
										["id"] = "魔法吸收",
										["totalover"] = 0,
										["targets"] = {
											["潇潇"] = 1390,
										},
										["counter"] = 4,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["flag_original"] = 1297,
							["last_event"] = 1593233957,
							["alternatepower"] = 0.002102,
							["tipo"] = 3,
							["serial"] = "Player-4920-022A2037",
							["totalover"] = 0.002102,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 117,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 18,
										["id"] = "寒冰箭",
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 142,
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["interrompeu_oque"] = {
											["寒冰箭"] = 1,
										},
										["targets"] = {
											["骷髅巫师"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["防护冰霜结界"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 16,
										["id"] = "防护冰霜结界",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["护甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = "护甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["银色黎明委任徽章"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 21,
										["id"] = "银色黎明委任徽章",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["寒冰箭"] = 1,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 18,
							["buff_uptime_targets"] = {
							},
							["interrupt_targets"] = {
								["骷髅巫师"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["法术反制"] = 1,
								["防护冰霜结界"] = 1,
								["射击"] = 1,
								["寒冰箭"] = 4,
								["火焰冲击"] = 1,
							},
							["interrupt"] = 1.002491,
							["last_event"] = 1593233957,
							["tipo"] = 4,
							["nome"] = "潇潇",
							["pets"] = {
							},
							["serial"] = "Player-4920-022A2037",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "骷髅巫师",
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["火焰新星"] = 1,
								["寒冰箭"] = 3,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4505-0-197-1784-000076BC52",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["nome"] = "喋喋不休的食尸鬼",
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["狂怒"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4505-0-197-10801-000076CAE4",
							["classe"] = "UNKNOW",
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 117,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155869.376,
				["tempo_start"] = 1593233936,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 729,
				["playing_solo"] = true,
				["totals"] = {
					5906, -- [1]
					83, -- [2]
					{
						0, -- [1]
						[0] = 1390,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:59:18",
				["cleu_timeline"] = {
				},
				["enemy"] = "喋喋不休的食尸鬼",
				["TotalElapsedCombatTime"] = 155653.715,
				["CombatEndedAt"] = 155653.715,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["潇潇"] = 83.004548,
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 5823.004994,
						}, -- [1]
					},
				},
				["end_time"] = 155653.715,
				["combat_id"] = 117,
				["frags"] = {
					["骷髅巫师"] = 1,
					["喋喋不休的食尸鬼"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					5823, -- [1]
					83, -- [2]
					{
						0, -- [1]
						[0] = 1390,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155632.665,
				["contra"] = "喋喋不休的食尸鬼",
				["data_inicio"] = "12:58:57",
			}, -- [12]
			{
				{
					["tipo"] = 2,
					["combatId"] = 116,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007801,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅剥皮者"] = 3381,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3381.007801,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 3381.007801,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593233927,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 852,
										["targets"] = {
											["骷髅剥皮者"] = 3381,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3381,
										["n_min"] = 837,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 3381,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233927,
							["damage_taken"] = 0.007801,
							["start_time"] = 1593233920,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002737,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002737,
							["serial"] = "Creature-0-4505-0-197-1783-000076C9A1",
							["dps_started"] = false,
							["total"] = 0.002737,
							["monster"] = true,
							["damage_taken"] = 3381.002737,
							["nome"] = "骷髅剥皮者",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593233927,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1593233927,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 116,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 116,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 116,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 4,
										["id"] = "寒冰箭",
										["refreshamt"] = 2,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["银色黎明委任徽章"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "银色黎明委任徽章",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["护甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 7,
										["id"] = "护甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["节能施法"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "节能施法",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 4,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["寒冰箭"] = 3,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593233927,
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 43,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 116,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155631.43,
				["tempo_start"] = 1593233920,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 728,
				["playing_solo"] = true,
				["totals"] = {
					3381, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:58:48",
				["cleu_timeline"] = {
				},
				["enemy"] = "骷髅剥皮者",
				["TotalElapsedCombatTime"] = 155623.74,
				["CombatEndedAt"] = 155623.74,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 3381.007801,
						}, -- [1]
					},
				},
				["end_time"] = 155623.74,
				["combat_id"] = 116,
				["frags"] = {
					["骷髅剥皮者"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3381, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155616.168,
				["contra"] = "骷髅剥皮者",
				["data_inicio"] = "12:58:41",
			}, -- [13]
			{
				{
					["tipo"] = 2,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004139,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅剥皮者"] = 3124,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3124.004139,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 3124.004139,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593233877,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 625,
										["targets"] = {
											["骷髅剥皮者"] = 625,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 625,
										["n_min"] = 625,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 625,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 840,
										["targets"] = {
											["骷髅剥皮者"] = 2499,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2499,
										["n_min"] = 826,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2499,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233876,
							["damage_taken"] = 0.004139,
							["start_time"] = 1593233872,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002133,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002133,
							["serial"] = "Creature-0-4505-0-197-1783-000076CABA",
							["dps_started"] = false,
							["total"] = 0.002133,
							["monster"] = true,
							["damage_taken"] = 3124.002133,
							["nome"] = "骷髅剥皮者",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593233877,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1593233877,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 115,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 115,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 3,
										["id"] = "寒冰箭",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["银色黎明委任徽章"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "银色黎明委任徽章",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["护甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "护甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["节能施法"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "节能施法",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 3,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
								["寒冰箭"] = 2,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593233877,
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 31,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 115,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155615.25,
				["tempo_start"] = 1593233872,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 727,
				["playing_solo"] = true,
				["totals"] = {
					3124, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:57:58",
				["cleu_timeline"] = {
				},
				["enemy"] = "骷髅剥皮者",
				["TotalElapsedCombatTime"] = 155573.516,
				["CombatEndedAt"] = 155573.516,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 3124.004139,
						}, -- [1]
					},
				},
				["end_time"] = 155573.516,
				["combat_id"] = 115,
				["frags"] = {
					["骷髅剥皮者"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3124, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155567.946,
				["contra"] = "骷髅剥皮者",
				["data_inicio"] = "12:57:53",
			}, -- [14]
			{
				{
					["tipo"] = 2,
					["combatId"] = 114,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00239,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅剥皮者"] = 3196,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3196.00239,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 3196.00239,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593233842,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 699,
										["targets"] = {
											["骷髅剥皮者"] = 699,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 699,
										["n_min"] = 699,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 699,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1661,
										["g_amt"] = 0,
										["n_max"] = 836,
										["targets"] = {
											["骷髅剥皮者"] = 2497,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 836,
										["n_min"] = 836,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2497,
										["c_max"] = 1661,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1661,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233842,
							["damage_taken"] = 0.00239,
							["start_time"] = 1593233838,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00455,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00455,
							["serial"] = "Creature-0-4505-0-197-1783-000076CA90",
							["dps_started"] = false,
							["total"] = 0.00455,
							["monster"] = true,
							["damage_taken"] = 3196.00455,
							["nome"] = "骷髅剥皮者",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593233842,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1593233842,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 114,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 114,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 114,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 1,
										["id"] = "寒冰箭",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["护甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "护甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["银色黎明委任徽章"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "银色黎明委任徽章",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 1,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
								["寒冰箭"] = 1,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593233842,
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 24,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 114,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155567.026,
				["tempo_start"] = 1593233838,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 726,
				["playing_solo"] = true,
				["totals"] = {
					3196, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:57:23",
				["cleu_timeline"] = {
				},
				["enemy"] = "骷髅剥皮者",
				["TotalElapsedCombatTime"] = 155538.669,
				["CombatEndedAt"] = 155538.669,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 3196.00239,
						}, -- [1]
					},
				},
				["end_time"] = 155538.669,
				["combat_id"] = 114,
				["frags"] = {
					["骷髅剥皮者"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3196, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155534.767,
				["contra"] = "骷髅剥皮者",
				["data_inicio"] = "12:57:19",
			}, -- [15]
			{
				{
					["tipo"] = 2,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00412,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅剥皮者"] = 3178,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3178.00412,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 3178.00412,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593233831,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 664,
										["targets"] = {
											["骷髅剥皮者"] = 664,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 664,
										["n_min"] = 664,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 664,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1681,
										["g_amt"] = 0,
										["n_max"] = 833,
										["targets"] = {
											["骷髅剥皮者"] = 2514,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 833,
										["n_min"] = 833,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2514,
										["c_max"] = 1681,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1681,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233830,
							["damage_taken"] = 0.00412,
							["start_time"] = 1593233827,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004474,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004474,
							["serial"] = "Creature-0-4505-0-197-1783-000076D181",
							["dps_started"] = false,
							["total"] = 0.004474,
							["monster"] = true,
							["damage_taken"] = 3178.004474,
							["nome"] = "骷髅剥皮者",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593233831,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1593233831,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 113,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 113,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 1,
										["id"] = "寒冰箭",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["银色黎明委任徽章"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "银色黎明委任徽章",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["护甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 4,
										["id"] = "护甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["节能施法"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "节能施法",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 1,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
								["寒冰箭"] = 1,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593233831,
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 26,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 113,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155533.815,
				["tempo_start"] = 1593233827,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 725,
				["playing_solo"] = true,
				["totals"] = {
					3178, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:57:12",
				["cleu_timeline"] = {
				},
				["enemy"] = "骷髅剥皮者",
				["TotalElapsedCombatTime"] = 155527.329,
				["CombatEndedAt"] = 155527.329,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 3178.00412,
						}, -- [1]
					},
				},
				["end_time"] = 155527.329,
				["combat_id"] = 113,
				["frags"] = {
					["骷髅剥皮者"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3178, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155523.408,
				["contra"] = "骷髅剥皮者",
				["data_inicio"] = "12:57:08",
			}, -- [16]
			{
				{
					["tipo"] = 2,
					["combatId"] = 112,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005084,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅巫师"] = 2509,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2509.005084,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 2509.005084,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593233801,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 853,
										["targets"] = {
											["骷髅巫师"] = 2509,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2509,
										["n_min"] = 825,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2509,
										["c_max"] = 0,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233800,
							["damage_taken"] = 0.005084,
							["start_time"] = 1593233795,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006797,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006797,
							["serial"] = "Creature-0-4505-0-197-1784-000076BF4B",
							["dps_started"] = false,
							["total"] = 0.006797,
							["monster"] = true,
							["damage_taken"] = 2509.006797,
							["nome"] = "骷髅巫师",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593233801,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1593233801,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 112,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 112,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 112,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 4,
										["id"] = "寒冰箭",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["interrompeu_oque"] = {
											["寒冰箭"] = 1,
										},
										["targets"] = {
											["骷髅巫师"] = 1,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["护甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "护甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["银色黎明委任徽章"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "银色黎明委任徽章",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["寒冰箭"] = 1,
							},
							["debuff_uptime"] = 4,
							["buff_uptime_targets"] = {
							},
							["interrupt_targets"] = {
								["骷髅巫师"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["法术反制"] = 1,
								["寒冰箭"] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1593233801,
							["tipo"] = 4,
							["interrupt"] = 1.001164,
							["nome"] = "潇潇",
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 36,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 112,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155522.875,
				["tempo_start"] = 1593233795,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 724,
				["playing_solo"] = true,
				["totals"] = {
					2509, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:56:42",
				["cleu_timeline"] = {
				},
				["enemy"] = "骷髅巫师",
				["TotalElapsedCombatTime"] = 155497.321,
				["CombatEndedAt"] = 155497.321,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 2509.005084,
						}, -- [1]
					},
				},
				["end_time"] = 155497.321,
				["combat_id"] = 112,
				["frags"] = {
					["骷髅巫师"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					2509, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155490.848,
				["contra"] = "骷髅巫师",
				["data_inicio"] = "12:56:35",
			}, -- [17]
			{
				{
					["tipo"] = 2,
					["combatId"] = 111,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001296,
							["damage_from"] = {
							},
							["targets"] = {
								["骷髅剥皮者"] = 3235,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3235.001296,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 3235.001296,
							["serial"] = "Player-4920-022A2037",
							["end_time"] = 1593233787,
							["nome"] = "潇潇",
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 694,
										["targets"] = {
											["骷髅剥皮者"] = 694,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 694,
										["n_min"] = 694,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 694,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["spellschool"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["寒冰箭"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1704,
										["g_amt"] = 0,
										["n_max"] = 837,
										["targets"] = {
											["骷髅剥皮者"] = 2541,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 837,
										["n_min"] = 837,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2541,
										["c_max"] = 1704,
										["id"] = "寒冰箭",
										["r_dmg"] = 0,
										["spellschool"] = 16,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1704,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593233786,
							["damage_taken"] = 0.001296,
							["start_time"] = 1593233782,
							["delay"] = 0,
							["classe"] = "MAGE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006606,
							["damage_from"] = {
								["潇潇"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["fight_component"] = true,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006606,
							["serial"] = "Creature-0-4505-0-197-1783-0000764565",
							["dps_started"] = false,
							["total"] = 0.006606,
							["monster"] = true,
							["damage_taken"] = 3235.006606,
							["nome"] = "骷髅剥皮者",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1593233787,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1593233787,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 111,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 111,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 111,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰箭"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = -1,
										["uptime"] = 2,
										["id"] = "寒冰箭",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["寒冰护体"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "寒冰护体",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["奥术智慧"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "奥术智慧",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔法抑制"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "魔法抑制",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["防护冰霜结界"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "防护冰霜结界",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["魔甲术"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "魔甲术",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["护甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "护甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["银色黎明委任徽章"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 5,
										["id"] = "银色黎明委任徽章",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 2,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火焰冲击"] = 1,
								["寒冰箭"] = 1,
							},
							["nome"] = "潇潇",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593233787,
							["serial"] = "Player-4920-022A2037",
							["buff_uptime"] = 35,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 111,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["潇潇"] = true,
				},
				["CombatStartedAt"] = 155490.031,
				["tempo_start"] = 1593233782,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 723,
				["playing_solo"] = true,
				["totals"] = {
					3235, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:56:28",
				["cleu_timeline"] = {
				},
				["enemy"] = "骷髅剥皮者",
				["TotalElapsedCombatTime"] = 155483.543,
				["CombatEndedAt"] = 155483.543,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["潇潇"] = 3235.001296,
						}, -- [1]
					},
				},
				["end_time"] = 155483.543,
				["combat_id"] = 111,
				["frags"] = {
					["骷髅剥皮者"] = 1,
				},
				["overall_added"] = true,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3235, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 155478.437,
				["contra"] = "骷髅剥皮者",
				["data_inicio"] = "12:56:23",
			}, -- [18]
		},
	},
	["last_version"] = "v1.13.4.209",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["last_version"] = 11,
		["潇潇"] = {
			"潇潇", -- [1]
			"Interface\\EncounterJournal\\UI-EJ-BOSS-Argent Confessor Paletress", -- [2]
			{
				0, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			}, -- [3]
			"Interface\\PetBattles\\Weather-ArcaneStorm", -- [4]
			{
				0.129609375, -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
			}, -- [5]
			{
				1, -- [1]
				1, -- [2]
				1, -- [3]
			}, -- [6]
			3, -- [7]
		},
		["nextreset"] = 1594824632,
	},
	["last_instance_id"] = 309,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 1593697366,
	["active_profile"] = "潇潇-龙牙",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["useclasscolors"] = false,
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["openedfromcommand"] = false,
			["updatespeed"] = 0.2,
			["dividebyhundred"] = true,
			["showamount"] = false,
			["useplayercolor"] = true,
			["author"] = "Details! Team",
		},
	},
	["cached_talents"] = {
		["Player-4920-022A2037"] = {
			{
				135894, -- [1]
				2, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [1]
			{
				135892, -- [1]
				3, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [2]
			{
				136096, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [3]
			{
				135463, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [4]
			{
				136011, -- [1]
				5, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [5]
			{
				136170, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [6]
			{
				136006, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [7]
			{
				136116, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [8]
			{
				135733, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [9]
			{
				136153, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [10]
			{
				135856, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				2, -- [7]
			}, -- [11]
			{
				136208, -- [1]
				3, -- [2]
				4, -- [3]
				4, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [12]
			{
				136031, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [13]
			{
				136129, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				62, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136222, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				3, -- [7]
			}, -- [15]
			{
				136048, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				62, -- [6]
				1, -- [7]
			}, -- [16]
			{
				135812, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [17]
			{
				135821, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [18]
			{
				135818, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [19]
			{
				135815, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [20]
			{
				135807, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [21]
			{
				135813, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [22]
			{
				135826, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [23]
			{
				135808, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [24]
			{
				135805, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [25]
			{
				135827, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [26]
			{
				135806, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				2, -- [7]
			}, -- [27]
			{
				135820, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [28]
			{
				136115, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				3, -- [7]
			}, -- [29]
			{
				135903, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [30]
			{
				135817, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				63, -- [6]
				5, -- [7]
			}, -- [31]
			{
				135824, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				63, -- [6]
				1, -- [7]
			}, -- [32]
			{
				135850, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [33]
			{
				135846, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [34]
			{
				135989, -- [1]
				3, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [35]
			{
				135855, -- [1]
				5, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [36]
			{
				135842, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [37]
			{
				135840, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [38]
			{
				135864, -- [1]
				3, -- [2]
				2, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [39]
			{
				135845, -- [1]
				3, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [40]
			{
				135865, -- [1]
				1, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [41]
			{
				135857, -- [1]
				3, -- [2]
				3, -- [3]
				4, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [42]
			{
				136141, -- [1]
				2, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				64, -- [6]
				2, -- [7]
			}, -- [43]
			{
				135860, -- [1]
				3, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [44]
			{
				135849, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135841, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [46]
			{
				135852, -- [1]
				3, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				3, -- [7]
			}, -- [47]
			{
				135836, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				64, -- [6]
				5, -- [7]
			}, -- [48]
			{
				135988, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				64, -- [6]
				1, -- [7]
			}, -- [49]
		},
	},
	["last_encounter"] = "妖术师金度",
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["last_day"] = "10",
	["last_realversion"] = 142,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_id"] = 128,
	["savedStyles"] = {
	},
	["combat_counter"] = 750,
	["force_font_outline"] = "",
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 1348.632174,
					["damage_from"] = {
						["殺那個法師"] = true,
						["血色医护员"] = true,
						["血色猎犬"] = true,
						["骷髅巫师"] = true,
						["潇潇"] = true,
						["恐惧骸骨"] = true,
						["骷髅剥皮者"] = true,
						["血色猎人"] = true,
						["腐烂虫"] = true,
						["血色祈求者"] = true,
						["喋喋不休的食尸鬼"] = true,
						["坏死的僵尸"] = true,
						["游荡的骷髅"] = true,
						["腐烂的死尸"] = true,
						["被奴役的食尸鬼"] = true,
					},
					["targets"] = {
						["殺那個法師"] = 21248,
						["血色医护员"] = 23383,
						["骷髅巫师"] = 21612,
						["护锅者玛维诺斯"] = 3236,
						["骷髅剥皮者"] = 32738,
						["血色猎人"] = 16401,
						["血色祈求者"] = 16624,
						["坏死的僵尸"] = 203148,
						["游荡的骷髅"] = 25457,
						["裙带飘飘"] = 3089,
						["黑老鼠"] = 354,
						["被奴役的食尸鬼"] = 19609,
						["恐惧骸骨"] = 123692,
						["冲击波"] = 99,
						["血色猎犬"] = 17496,
						["喋喋不休的食尸鬼"] = 3300,
						["弗曼恩"] = 3105,
						["腐烂虫"] = 34253,
						["护锅者拜尔摩"] = 3524,
						["风御九天"] = 2315,
						["翘臀待君吸"] = 492,
						["腐烂的死尸"] = 208372,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["last_dps"] = 0,
					["friendlyfire"] = {
						["潇潇"] = {
							["spells"] = {
								["快速传染"] = 1732,
							},
							["total"] = 1732,
						},
					},
					["friendlyfire_total"] = 1732,
					["raid_targets"] = {
					},
					["total_without_pet"] = 783547.632174,
					["total"] = 783547.632174,
					["dps_started"] = false,
					["end_time"] = 1593224793,
					["on_hold"] = false,
					["tipo"] = 1,
					["nome"] = "潇潇",
					["spells"] = {
						["_ActorTable"] = {
							["冰锥术"] = {
								["c_amt"] = 19,
								["b_amt"] = 0,
								["c_dmg"] = 22147,
								["g_amt"] = 0,
								["n_max"] = 627,
								["targets"] = {
									["殺那個法師"] = 2351,
									["血色猎犬"] = 4134,
									["骷髅巫师"] = 1134,
									["骷髅剥皮者"] = 3486,
									["腐烂的死尸"] = 28423,
									["坏死的僵尸"] = 28560,
									["血色祈求者"] = 1190,
									["腐烂虫"] = 17265,
									["游荡的骷髅"] = 1751,
									["风御九天"] = 1204,
									["恐惧骸骨"] = 11167,
									["被奴役的食尸鬼"] = 2294,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 80812,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 158,
								["total"] = 102959,
								["c_max"] = 1246,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 139,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 187,
								["targets"] = {
									["黑老鼠"] = 354,
									["血色医护员"] = 2554,
									["血色猎犬"] = 5111,
									["恐惧骸骨"] = 65275,
									["骷髅剥皮者"] = 2852,
									["血色猎人"] = 6575,
									["血色祈求者"] = 2385,
									["弗曼恩"] = 2830,
									["腐烂虫"] = 7939,
									["坏死的僵尸"] = 95957,
									["腐烂的死尸"] = 110819,
									["被奴役的食尸鬼"] = 4459,
									["骷髅巫师"] = 2140,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 309250,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1771,
								["total"] = 309250,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1771,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 492,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["翘臀待君吸"] = 492,
									["血色猎犬"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 492,
								["c_max"] = 492,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["MISS"] = 2,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰霜新星"] = {
								["c_amt"] = 30,
								["b_amt"] = 0,
								["c_dmg"] = 5739,
								["g_amt"] = 0,
								["n_max"] = 103,
								["targets"] = {
									["殺那個法師"] = 99,
									["血色医护员"] = 300,
									["血色猎犬"] = 586,
									["骷髅巫师"] = 288,
									["恐惧骸骨"] = 4418,
									["骷髅剥皮者"] = 377,
									["血色猎人"] = 500,
									["腐烂虫"] = 2128,
									["弗曼恩"] = 275,
									["坏死的僵尸"] = 7985,
									["冲击波"] = 99,
									["风御九天"] = 100,
									["腐烂的死尸"] = 8604,
									["被奴役的食尸鬼"] = 479,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 20499,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 250,
								["total"] = 26238,
								["c_max"] = 208,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 6,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 214,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 21,
								["b_amt"] = 0,
								["c_dmg"] = 10135,
								["g_amt"] = 0,
								["n_max"] = 353,
								["targets"] = {
									["血色医护员"] = 517,
									["血色猎犬"] = 3865,
									["骷髅巫师"] = 1606,
									["骷髅剥皮者"] = 1467,
									["血色猎人"] = 2329,
									["血色祈求者"] = 1520,
									["腐烂虫"] = 6921,
									["坏死的僵尸"] = 7579,
									["腐烂的死尸"] = 14059,
									["恐惧骸骨"] = 3067,
									["被奴役的食尸鬼"] = 1951,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 34746,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 131,
								["total"] = 44881,
								["c_max"] = 521,
								["id"] = "魔爆术",
								["r_dmg"] = 1662,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 108,
								["m_amt"] = 0,
								["r_amt"] = 6,
							},
							["寒冰箭"] = {
								["c_amt"] = 31,
								["b_amt"] = 0,
								["c_dmg"] = 53701,
								["g_amt"] = 0,
								["n_max"] = 1096,
								["targets"] = {
									["殺那個法師"] = 16787,
									["血色医护员"] = 19345,
									["血色猎犬"] = 1738,
									["被奴役的食尸鬼"] = 10426,
									["骷髅巫师"] = 15464,
									["护锅者玛维诺斯"] = 3236,
									["恐惧骸骨"] = 32900,
									["骷髅剥皮者"] = 21182,
									["血色猎人"] = 6997,
									["喋喋不休的食尸鬼"] = 2482,
									["血色祈求者"] = 10584,
									["坏死的僵尸"] = 46928,
									["腐烂的死尸"] = 36321,
									["游荡的骷髅"] = 19437,
									["裙带飘飘"] = 1759,
									["护锅者拜尔摩"] = 2513,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 194398,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 259,
								["total"] = 248099,
								["c_max"] = 1821,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 226,
								["a_amt"] = 3,
								["a_dmg"] = 3712,
							},
							["!Autoshot"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 397,
								["g_amt"] = 0,
								["n_max"] = 160,
								["targets"] = {
									["腐烂的死尸"] = 676,
									["血色医护员"] = 667,
									["血色祈求者"] = 246,
									["坏死的僵尸"] = 500,
									["恐惧骸骨"] = 394,
									["游荡的骷髅"] = 938,
									["喋喋不休的食尸鬼"] = 167,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3191,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 3588,
								["c_max"] = 230,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 25,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 8,
								["b_amt"] = 0,
								["c_dmg"] = 7700,
								["g_amt"] = 0,
								["n_max"] = 773,
								["targets"] = {
									["殺那個法師"] = 2011,
									["血色猎犬"] = 2062,
									["恐惧骸骨"] = 6471,
									["护锅者拜尔摩"] = 1011,
									["骷髅剥皮者"] = 3374,
									["腐烂的死尸"] = 9470,
									["坏死的僵尸"] = 15639,
									["血色祈求者"] = 699,
									["喋喋不休的食尸鬼"] = 651,
									["风御九天"] = 1011,
									["游荡的骷髅"] = 3331,
									["裙带飘飘"] = 1330,
									["骷髅巫师"] = 980,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 40340,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 68,
								["total"] = 48040,
								["c_max"] = 1011,
								["id"] = "火焰冲击",
								["r_dmg"] = 1356,
								["r_amt"] = 2,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 60,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["classe"] = "MAGE",
					["spec"] = 64,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 64809.6321740001,
					["start_time"] = 1593223415,
					["serial"] = "Player-4920-022A2037",
					["fight_component"] = true,
				}, -- [1]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 690.018704,
					["damage_from"] = {
						["潇潇"] = true,
						["千里追风箭"] = true,
					},
					["targets"] = {
						["潇潇"] = 690,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 690.018704,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 690.018704,
					["delay"] = 0,
					["last_dps"] = 0,
					["nome"] = "殺那個法師",
					["spells"] = {
						["_ActorTable"] = {
							["精神控制"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "精神控制",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["暗言术：痛"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 115,
								["targets"] = {
									["潇潇"] = 690,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 690,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 690,
								["c_max"] = 0,
								["id"] = "暗言术：痛",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 6,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["绝望祷言"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "绝望祷言",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["真言术：盾"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "真言术：盾",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["恢复"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "恢复",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["快速治疗"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "快速治疗",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["心灵尖啸"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "心灵尖啸",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["驱散魔法"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "驱散魔法",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["恢复法力"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "恢复法力",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["祈祷之珠"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "祈祷之珠",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 22089.018704,
					["start_time"] = 1593224767,
					["serial"] = "Player-4920-01D1EDBB",
					["end_time"] = 1593224793,
				}, -- [2]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.014554,
					["damage_from"] = {
						["小辫儿丶"] = true,
						["千里追风箭"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.014554,
					["end_time"] = 1593224793,
					["dps_started"] = false,
					["total"] = 0.014554,
					["delay"] = 0,
					["last_dps"] = 0,
					["nome"] = "裙带飘飘",
					["spells"] = {
						["_ActorTable"] = {
							["寒冰护体"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["闪现术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "闪现术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 4840.014554,
					["start_time"] = 1593224790,
					["serial"] = "Player-4920-01D0BD72",
					["fight_component"] = true,
				}, -- [3]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.009365,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.009365,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 0.009365,
					["delay"] = 0,
					["last_dps"] = 0,
					["nome"] = "翘臀待君吸",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 492.009365,
					["start_time"] = 1593224812,
					["serial"] = "Player-4920-0283BB84",
					["end_time"] = 1593224815,
				}, -- [4]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 461.038681,
					["damage_from"] = {
						["骷髅剥皮者"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["潇潇"] = 1518,
						["骷髅剥皮者"] = 18,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 1536.038681,
					["serial"] = "Creature-0-4505-0-197-1783-00007687FF",
					["dps_started"] = false,
					["total"] = 1536.038681,
					["classe"] = "UNKNOW",
					["on_hold"] = false,
					["nome"] = "骷髅剥皮者",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 436,
								["g_amt"] = 0,
								["n_max"] = 64,
								["targets"] = {
									["潇潇"] = 1518,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1082,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 46,
								["MISS"] = 3,
								["total"] = 1518,
								["c_max"] = 117,
								["DODGE"] = 2,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 19,
								["IMMUNE"] = 18,
								["r_amt"] = 0,
							},
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["骷髅剥皮者"] = 18,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 18,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["total"] = 18,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 9,
								["b_dmg"] = 0,
								["n_amt"] = 9,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["end_time"] = 1593228367,
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 32756.038681,
					["start_time"] = 1593228299,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [5]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 1045.051806,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
						["潇潇"] = 2158,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 2158.051806,
					["serial"] = "Creature-0-4505-0-197-1784-00007688AB",
					["dps_started"] = false,
					["total"] = 2158.051806,
					["classe"] = "UNKNOW",
					["on_hold"] = false,
					["nome"] = "骷髅巫师",
					["spells"] = {
						["_ActorTable"] = {
							["火焰新星"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 240,
								["targets"] = {
									["潇潇"] = 475,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 475,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 475,
								["c_max"] = 0,
								["id"] = "火焰新星",
								["r_dmg"] = 235,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 3,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["m_amt"] = 0,
								["r_amt"] = 1,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 185,
								["targets"] = {
									["潇潇"] = 806,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 806,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 806,
								["c_max"] = 0,
								["IMMUNE"] = 1,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["RESIST"] = 12,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 18,
								["m_amt"] = 0,
								["n_amt"] = 5,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 174,
								["targets"] = {
									["潇潇"] = 877,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 877,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 877,
								["c_max"] = 0,
								["MISS"] = 1,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["IMMUNE"] = 3,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["m_amt"] = 0,
								["n_amt"] = 10,
								["a_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["end_time"] = 1593228367,
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 21612.051806,
					["start_time"] = 1593228290,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [6]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 1593.027893,
					["damage_from"] = {
						["被奴役的食尸鬼"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["潇潇"] = 2795,
						["被奴役的食尸鬼"] = 22,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 2817.027893,
					["serial"] = "Creature-0-4505-0-197-1791-000076A511",
					["dps_started"] = false,
					["total"] = 2817.027893,
					["classe"] = "UNKNOW",
					["on_hold"] = false,
					["nome"] = "被奴役的食尸鬼",
					["spells"] = {
						["_ActorTable"] = {
							["眩晕"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "眩晕",
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["被奴役的食尸鬼"] = 22,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 22,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 22,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 11,
								["b_dmg"] = 0,
								["n_amt"] = 11,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 136,
								["targets"] = {
									["潇潇"] = 2795,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2795,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 65,
								["total"] = 2795,
								["c_max"] = 0,
								["MISS"] = 3,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["IMMUNE"] = 24,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["m_amt"] = 0,
								["n_amt"] = 38,
								["a_dmg"] = 0,
								["r_amt"] = 0,
							},
							["毒性唾液"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "毒性唾液",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["end_time"] = 1593228367,
					["fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 19631.027893,
					["start_time"] = 1593228303,
					["delay"] = 0,
					["friendlyfire"] = {
					},
				}, -- [7]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 236.061901,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
						["恐惧骸骨"] = 166,
						["潇潇"] = 412,
						["游荡的骷髅"] = 58,
						["坏死的僵尸"] = 57,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 693.061901,
					["serial"] = "Creature-0-4505-0-197-10605-000076BB0A",
					["fight_component"] = true,
					["total"] = 693.061901,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 23383.061901,
					["nome"] = "血色医护员",
					["spells"] = {
						["_ActorTable"] = {
							["抵抗奥术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "抵抗奥术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["恢复"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "恢复",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["快速治疗"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "快速治疗",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 5,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 152,
								["targets"] = {
									["恐惧骸骨"] = 166,
									["潇潇"] = 412,
									["游荡的骷髅"] = 58,
									["坏死的僵尸"] = 57,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 693,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 693,
								["c_max"] = 0,
								["MISS"] = 1,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["m_amt"] = 0,
								["n_amt"] = 9,
								["a_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593228622,
					["delay"] = 0,
					["end_time"] = 1593228638,
				}, -- [8]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 1258.059418,
					["damage_from"] = {
						["恐惧骸骨"] = true,
						["潇潇"] = true,
						["游荡的骷髅"] = true,
						["坏死的僵尸"] = true,
					},
					["targets"] = {
						["恐惧骸骨"] = 1092,
						["潇潇"] = 4242,
						["游荡的骷髅"] = 728,
						["坏死的僵尸"] = 239,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 6301.059418,
					["serial"] = "Creature-0-4505-0-197-1835-000076BB34",
					["dps_started"] = false,
					["total"] = 6301.059418,
					["fight_component"] = true,
					["damage_taken"] = 16981.059418,
					["nome"] = "血色祈求者",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 88,
								["targets"] = {
									["坏死的僵尸"] = 57,
									["潇潇"] = 327,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 384,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 384,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["DODGE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["奥术飞弹"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 182,
								["targets"] = {
									["恐惧骸骨"] = 1092,
									["潇潇"] = 3915,
									["游荡的骷髅"] = 728,
									["坏死的僵尸"] = 182,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 5917,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 49,
								["total"] = 5917,
								["c_max"] = 0,
								["id"] = "奥术飞弹",
								["r_dmg"] = 775,
								["a_dmg"] = 482,
								["a_amt"] = 3,
								["m_crit"] = 0,
								["RESIST"] = 12,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 37,
								["m_amt"] = 0,
								["r_amt"] = 7,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593228631,
					["delay"] = 0,
					["end_time"] = 1593228721,
				}, -- [9]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 3393.040095,
					["damage_from"] = {
						["恐惧骸骨"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["恐惧骸骨"] = 214,
						["潇潇"] = 6887,
						["游荡的骷髅"] = 129,
						["坏死的僵尸"] = 154,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 7384.040095,
					["serial"] = "Creature-0-4505-0-197-1831-000076BAC1",
					["fight_component"] = true,
					["total"] = 7384.040095,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 16513.040095,
					["nome"] = "血色猎人",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 163,
								["g_amt"] = 0,
								["n_max"] = 100,
								["targets"] = {
									["恐惧骸骨"] = 122,
									["潇潇"] = 705,
									["游荡的骷髅"] = 129,
									["坏死的僵尸"] = 63,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 856,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 13,
								["total"] = 1019,
								["c_max"] = 163,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 11,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 133,
								["targets"] = {
									["恐惧骸骨"] = 92,
									["潇潇"] = 6182,
									["坏死的僵尸"] = 91,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6365,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 55,
								["total"] = 6365,
								["c_max"] = 0,
								["id"] = "射击",
								["r_dmg"] = 0,
								["a_dmg"] = 109,
								["m_crit"] = 0,
								["a_amt"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 55,
								["b_dmg"] = 0,
								["n_amt"] = 55,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["monster"] = true,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593228635,
					["delay"] = 0,
					["end_time"] = 1593228721,
				}, -- [10]
				{
					["flag_original"] = 4680,
					["totalabsorbed"] = 1133.055633,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
						["坏死的僵尸"] = 91,
						["潇潇"] = 2679,
						["游荡的骷髅"] = 144,
						["腐烂虫"] = 75,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 2989.055633,
					["classe"] = "PET",
					["dps_started"] = false,
					["end_time"] = 1593228721,
					["serial"] = "Creature-0-4505-0-197-10979-000076BB18",
					["damage_taken"] = 17496.055633,
					["nome"] = "血色猎犬",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 142,
								["g_amt"] = 0,
								["n_max"] = 76,
								["targets"] = {
									["坏死的僵尸"] = 91,
									["潇潇"] = 2679,
									["游荡的骷髅"] = 144,
									["腐烂虫"] = 75,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2847,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 50,
								["a_amt"] = 2,
								["total"] = 2989,
								["c_max"] = 142,
								["DODGE"] = 1,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 135,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["m_amt"] = 0,
								["n_amt"] = 44,
								["MISS"] = 3,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["friendlyfire"] = {
					},
					["total"] = 2989.055633,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593228647,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [11]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 7556.145185,
					["damage_from"] = {
						["血色猎人"] = true,
						["血色医护员"] = true,
						["血色祈求者"] = true,
						["血色猎犬"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["血色祈求者"] = 59,
						["潇潇"] = 14160,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 14219.145185,
					["serial"] = "Creature-0-4505-0-197-4475-000076BC52",
					["dps_started"] = false,
					["end_time"] = 1593229526,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 203689.145185,
					["nome"] = "坏死的僵尸",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 524,
								["g_amt"] = 0,
								["n_max"] = 174,
								["targets"] = {
									["血色祈求者"] = 59,
									["潇潇"] = 14160,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 13695,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 343,
								["MISS"] = 20,
								["total"] = 14219,
								["c_max"] = 180,
								["DODGE"] = 10,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 778,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 8,
								["n_amt"] = 152,
								["IMMUNE"] = 158,
								["r_amt"] = 0,
							},
							["快速传染"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "快速传染",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["total"] = 14219.145185,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593229174,
					["delay"] = 0,
					["monster"] = true,
				}, -- [12]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 3432.115732,
					["damage_from"] = {
						["血色猎人"] = true,
						["潇潇"] = true,
						["血色祈求者"] = true,
						["血色医护员"] = true,
					},
					["targets"] = {
						["血色猎人"] = 112,
						["潇潇"] = 6899,
						["血色祈求者"] = 95,
					},
					["pets"] = {
					},
					["monster"] = true,
					["damage_taken"] = 125164.115732,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 7106.115732,
					["serial"] = "Creature-0-4505-0-197-1785-0000F6BC6C",
					["dps_started"] = false,
					["end_time"] = 1593229538,
					["classe"] = "UNKNOW",
					["last_dps"] = 0,
					["nome"] = "恐惧骸骨",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 309,
								["g_amt"] = 0,
								["n_max"] = 102,
								["targets"] = {
									["血色猎人"] = 112,
									["潇潇"] = 6899,
									["血色祈求者"] = 95,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6797,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 365,
								["IMMUNE"] = 175,
								["total"] = 7106,
								["c_max"] = 161,
								["DODGE"] = 3,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 353,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 4,
								["n_amt"] = 98,
								["MISS"] = 86,
								["r_amt"] = 0,
							},
							["恐惧术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "恐惧术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 8,
								["c_min"] = 0,
								["successful_casted"] = 12,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["total"] = 7106.115732,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593229274,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [13]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 7281.147402,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
						["潇潇"] = 16350,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 16350.147402,
					["serial"] = "Creature-0-4505-0-197-4474-000076BD2D",
					["dps_started"] = false,
					["end_time"] = 1593229577,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 208372.147402,
					["nome"] = "腐烂的死尸",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 585,
								["g_amt"] = 0,
								["n_max"] = 203,
								["targets"] = {
									["潇潇"] = 16350,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 15765,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 349,
								["DODGE"] = 7,
								["total"] = 16350,
								["c_max"] = 210,
								["IMMUNE"] = 158,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 1671,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 18,
								["n_amt"] = 166,
								["MISS"] = 15,
								["r_amt"] = 0,
							},
							["腐化耐力"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 127,
								["total"] = 0,
								["c_max"] = 0,
								["IMMUNE"] = 102,
								["id"] = "腐化耐力",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["RESIST"] = 25,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["m_amt"] = 0,
								["n_amt"] = 0,
								["b_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["total"] = 16350.147402,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593229186,
					["delay"] = 0,
					["monster"] = true,
				}, -- [14]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 801.133633,
					["damage_from"] = {
						["潇潇"] = true,
						["腐烂虫"] = true,
						["血色猎犬"] = true,
					},
					["targets"] = {
						["腐烂虫"] = 2,
						["潇潇"] = 3152,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 3154.133633,
					["serial"] = "Creature-0-4505-0-197-10925-000076C108",
					["dps_started"] = false,
					["end_time"] = 1593229582,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 34330.133633,
					["nome"] = "腐烂虫",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 199,
								["g_amt"] = 0,
								["n_max"] = 111,
								["targets"] = {
									["潇潇"] = 3152,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2953,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 64,
								["total"] = 3152,
								["c_max"] = 103,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["MISS"] = 4,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 58,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["腐烂虫"] = 2,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 2,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["total"] = 3154.133633,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593229525,
					["delay"] = 0,
					["monster"] = true,
				}, -- [15]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 1159.047572,
					["damage_from"] = {
						["血色猎人"] = true,
						["血色医护员"] = true,
						["血色祈求者"] = true,
						["血色猎犬"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["血色祈求者"] = 203,
						["潇潇"] = 1159,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1362.047572,
					["serial"] = "Creature-0-4505-0-197-10816-000076C14E",
					["dps_started"] = false,
					["total"] = 1362.047572,
					["fight_component"] = true,
					["damage_taken"] = 26516.047572,
					["nome"] = "游荡的骷髅",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 104,
								["targets"] = {
									["血色祈求者"] = 203,
									["潇潇"] = 1159,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1362,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 17,
								["total"] = 1362,
								["c_max"] = 0,
								["DODGE"] = 1,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["MISS"] = 1,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["m_amt"] = 0,
								["n_amt"] = 15,
								["a_dmg"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593229925,
					["delay"] = 0,
					["end_time"] = 1593229958,
				}, -- [16]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.00986,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.00986,
					["friendlyfire"] = {
					},
					["fight_component"] = true,
					["end_time"] = 1593229958,
					["serial"] = "Creature-0-4505-0-197-2110-000076BC67",
					["damage_taken"] = 354.00986,
					["nome"] = "黑老鼠",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["total"] = 0.00986,
					["dps_started"] = false,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1593229955,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [17]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.008546,
					["damage_from"] = {
						["弗曼恩"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
						["弗曼恩"] = 6,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 6.008546,
					["serial"] = "Creature-0-4505-0-197-1847-000076C769",
					["fight_component"] = true,
					["end_time"] = 1593231362,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 3111.008546,
					["nome"] = "弗曼恩",
					["spells"] = {
						["_ActorTable"] = {
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["弗曼恩"] = 6,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 6,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["IMMUNE"] = 6,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 6.008546,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593231342,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [18]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.010827,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.010827,
					["serial"] = "Creature-0-4505-0-197-11075-000076D141",
					["fight_component"] = true,
					["end_time"] = 1593233773,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 3524.010827,
					["nome"] = "护锅者拜尔摩",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 0.010827,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593233770,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [19]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 83.011606,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
						["潇潇"] = 83,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 83.011606,
					["serial"] = "Creature-0-4505-0-197-10801-000076CAE4",
					["fight_component"] = true,
					["end_time"] = 1593233958,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 3300.011606,
					["nome"] = "喋喋不休的食尸鬼",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 83,
								["targets"] = {
									["潇潇"] = 83,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 83,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 83,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["狂怒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "狂怒",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 83.011606,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593233954,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [20]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.009857,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.009857,
					["serial"] = "Creature-0-4505-0-197-11077-000076D2FE",
					["fight_component"] = true,
					["end_time"] = 1593234219,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 3236.009857,
					["nome"] = "护锅者玛维诺斯",
					["spells"] = {
						["_ActorTable"] = {
							["暗影箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["潇潇"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "暗影箭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 0.009857,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593234216,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [21]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.010073,
					["damage_from"] = {
					},
					["targets"] = {
						["哈卡莱神谕者"] = 535,
						["古拉巴什战士"] = 608,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "WARRIOR",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1143.010073,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1593697245,
					["serial"] = "Player-4920-01D03E40",
					["total"] = 1143.010073,
					["nome"] = "灬坏蛋灬",
					["spells"] = {
						["_ActorTable"] = {
							["重伤"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 51,
								["targets"] = {
									["哈卡莱神谕者"] = 51,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 51,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 51,
								["c_max"] = 0,
								["id"] = "重伤",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["英勇打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 319,
								["targets"] = {
									["古拉巴什战士"] = 319,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 319,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 319,
								["c_max"] = 0,
								["id"] = "英勇打击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 687,
								["g_amt"] = 0,
								["n_max"] = 86,
								["targets"] = {
									["哈卡莱神谕者"] = 484,
									["古拉巴什战士"] = 289,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 86,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 773,
								["c_max"] = 484,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.010073,
					["start_time"] = 1593697232,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [22]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.015776,
					["damage_from"] = {
						["嚣张的步伐"] = true,
						["贼浪漫"] = true,
						["处男刺青"] = true,
						["舅子大帅比"] = true,
						["甜汤"] = true,
						["灬坏蛋灬"] = true,
						["小白不黑"] = true,
						["风哥"] = true,
						["币毛漫天浪"] = true,
						["小花妹"] = true,
						["灼热图腾 <不是萨满>"] = true,
						["鲁豫"] = true,
						["窥见身外之身"] = true,
						["混分巨兽"] = true,
					},
					["targets"] = {
						["鲁豫"] = 778,
						["窥见身外之身"] = 334,
						["处男刺青"] = 233,
						["嚣张的步伐"] = 665,
						["混分巨兽"] = 134,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 2144.015776,
					["serial"] = "Creature-0-4999-0-282-11355-00007DE3C2",
					["dps_started"] = false,
					["end_time"] = 1593697245,
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["nome"] = "古拉巴什战士",
					["spells"] = {
						["_ActorTable"] = {
							["击倒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 159,
								["targets"] = {
									["嚣张的步伐"] = 159,
									["鲁豫"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 159,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 159,
								["c_max"] = 0,
								["id"] = "击倒",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 334,
								["targets"] = {
									["嚣张的步伐"] = 506,
									["窥见身外之身"] = 334,
									["处男刺青"] = 233,
									["鲁豫"] = 778,
									["贼浪漫"] = 0,
									["混分巨兽"] = 134,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1985,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 1985,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 8,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["狂怒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "狂怒",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 2144.015776,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 17864.015776,
					["start_time"] = 1593697217,
					["delay"] = 0,
					["monster"] = true,
				}, -- [23]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.019938,
					["damage_from"] = {
						["哈卡莱神谕者"] = true,
						["古拉巴什战士"] = true,
					},
					["targets"] = {
						["古拉巴什战士"] = 1711,
						["哈卡莱神谕者"] = 842,
						["风御九天"] = 219,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 2772.019938,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1593697245,
					["serial"] = "Player-4920-02628F22",
					["total"] = 2772.019938,
					["nome"] = "窥见身外之身",
					["spells"] = {
						["_ActorTable"] = {
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 288,
								["targets"] = {
									["哈卡莱神谕者"] = 842,
									["古拉巴什战士"] = 1109,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1951,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 1951,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 7,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 602,
								["targets"] = {
									["古拉巴什战士"] = 602,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 602,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 602,
								["c_max"] = 0,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["冰锥术"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 219,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["风御九天"] = 219,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 219,
								["c_max"] = 219,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["暴风雪"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["古拉巴什战士"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "暴风雪",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1044.019938,
					["start_time"] = 1593697226,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [24]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.011583,
					["damage_from"] = {
						["鲁豫"] = true,
						["贼浪漫"] = true,
						["处男刺青"] = true,
						["舅子大帅比"] = true,
						["灬坏蛋灬"] = true,
						["甜汤"] = true,
						["风哥"] = true,
						["币毛漫天浪"] = true,
						["小白不黑"] = true,
						["小花妹"] = true,
						["小漾丶钻石"] = true,
						["窥见身外之身"] = true,
					},
					["targets"] = {
						["窥见身外之身"] = 710,
						["小花妹"] = 595,
						["风哥"] = 142,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["on_hold"] = false,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1447.011583,
					["serial"] = "Creature-0-4999-0-282-11346-00007DDB8E",
					["dps_started"] = false,
					["end_time"] = 1593697291,
					["friendlyfire_total"] = 0,
					["last_dps"] = 0,
					["nome"] = "哈卡莱神谕者",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 710,
								["g_amt"] = 0,
								["n_max"] = 142,
								["targets"] = {
									["窥见身外之身"] = 710,
									["风哥"] = 142,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 142,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 852,
								["c_max"] = 710,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["地震术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 595,
								["targets"] = {
									["小花妹"] = 595,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 595,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 595,
								["c_max"] = 0,
								["id"] = "地震术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 1447.011583,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 6225.011583,
					["start_time"] = 1593697281,
					["delay"] = 0,
					["monster"] = true,
				}, -- [25]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.007311,
					["damage_from"] = {
						["哈卡莱神谕者"] = true,
					},
					["targets"] = {
						["哈卡莱神谕者"] = 360,
						["古拉巴什战士"] = 208,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "WARRIOR",
					["raid_targets"] = {
					},
					["total_without_pet"] = 568.007311,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1593697291,
					["serial"] = "Player-4920-01D157B4",
					["total"] = 568.007311,
					["nome"] = "风哥",
					["spells"] = {
						["_ActorTable"] = {
							["破甲攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["古拉巴什战士"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "破甲攻击",
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 104,
								["targets"] = {
									["古拉巴什战士"] = 208,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 208,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 208,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["盾牌猛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 360,
								["targets"] = {
									["哈卡莱神谕者"] = 360,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 360,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 360,
								["c_max"] = 0,
								["id"] = "盾牌猛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 142.007311,
					["start_time"] = 1593697282,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [26]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.009503,
					["damage_from"] = {
						["窥见身外之身"] = true,
						["币毛漫天浪"] = true,
						["镇裆射鸡"] = true,
						["舅子大帅比"] = true,
						["休闲与娱乐"] = true,
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.009503,
					["total"] = 0.009503,
					["dps_started"] = false,
					["end_time"] = 1593697320,
					["serial"] = "Player-4920-0272452D",
					["friendlyfire"] = {
					},
					["nome"] = "风御九天",
					["spells"] = {
						["_ActorTable"] = {
							["法力护盾"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "法力护盾",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 3943.009503,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1593697317,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [27]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.010723,
					["damage_from"] = {
						["潇潇"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.010723,
					["total"] = 0.010723,
					["dps_started"] = false,
					["end_time"] = 1593697868,
					["serial"] = "Player-4920-01D0DDE4",
					["friendlyfire"] = {
					},
					["nome"] = "冲击波",
					["spells"] = {
						["_ActorTable"] = {
							["闪现术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "闪现术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 99.010723,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1593697865,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [28]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.005265,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["damage_taken"] = 0.005265,
					["classe"] = "WARRIOR",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005265,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1594210501,
					["delay"] = 0,
					["total"] = 0.005265,
					["nome"] = "火抗梯",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1594210498,
					["serial"] = "Player-4920-01D1852F",
					["friendlyfire"] = {
					},
				}, -- [29]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.001246,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["damage_taken"] = 0.001246,
					["classe"] = "HUNTER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001246,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1594210501,
					["delay"] = 0,
					["total"] = 0.001246,
					["nome"] = "香油田鸡",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1594210498,
					["serial"] = "Player-4920-026E1D50",
					["friendlyfire"] = {
					},
				}, -- [30]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.001915,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["damage_taken"] = 0.001915,
					["classe"] = "WARLOCK",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001915,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1594210501,
					["delay"] = 0,
					["total"] = 0.001915,
					["nome"] = "奇异灬博士",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1594210498,
					["serial"] = "Player-4920-01EBF4BE",
					["friendlyfire"] = {
					},
				}, -- [31]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.005953,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["damage_taken"] = 0.005953,
					["classe"] = "PRIEST",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005953,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1594210501,
					["delay"] = 0,
					["total"] = 0.005953,
					["nome"] = "板板狗",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1594210498,
					["serial"] = "Player-4920-01D0B865",
					["friendlyfire"] = {
					},
				}, -- [32]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["healing_from"] = {
						["潇潇"] = true,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["classe"] = "MAGE",
					["totalover"] = 0.249945,
					["total_without_pet"] = 32446.249945,
					["total"] = 32446.249945,
					["targets_absorbs"] = {
						["潇潇"] = 0,
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-022A2037",
					["totalabsorb"] = 32446.249945,
					["last_hps"] = 0,
					["targets"] = {
						["潇潇"] = 0,
					},
					["totalover_without_pet"] = 0.249945,
					["healing_taken"] = 32446.249945,
					["fight_component"] = true,
					["end_time"] = 1593224858,
					["targets_overheal"] = {
					},
					["nome"] = "潇潇",
					["spells"] = {
						["_ActorTable"] = {
							["寒冰护体"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 30736,
								["targets_overheal"] = {
								},
								["n_max"] = 240,
								["targets"] = {
									["潇潇"] = 30736,
								},
								["n_min"] = 0,
								["counter"] = 353,
								["overheal"] = 0,
								["total"] = 30736,
								["c_max"] = 0,
								["id"] = "寒冰护体",
								["targets_absorbs"] = {
									["潇潇"] = 30736,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["totaldenied"] = 0,
								["m_amt"] = 0,
								["m_healed"] = 0,
								["n_amt"] = 353,
								["n_curado"] = 30736,
								["c_min"] = 0,
								["absorbed"] = 0,
							},
							["法力护盾"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 1710,
								["targets_overheal"] = {
								},
								["n_max"] = 132,
								["targets"] = {
									["潇潇"] = 1710,
								},
								["n_min"] = 0,
								["counter"] = 24,
								["overheal"] = 0,
								["total"] = 1710,
								["c_max"] = 0,
								["id"] = "法力护盾",
								["targets_absorbs"] = {
									["潇潇"] = 1710,
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["n_curado"] = 1710,
								["n_amt"] = 24,
								["m_healed"] = 0,
								["totaldenied"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["heal_enemy_amt"] = 0,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.249945,
					["start_time"] = 1593224351,
					["delay"] = 0,
					["spec"] = 64,
				}, -- [1]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 1370.01393,
					["resource"] = 0.021649,
					["targets"] = {
						["殺那個法師"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.006211,
					["fight_component"] = true,
					["total"] = 1370.01393,
					["nome"] = "殺那個法師",
					["spells"] = {
						["_ActorTable"] = {
							["恢复法力"] = {
								["total"] = 1370,
								["id"] = "恢复法力",
								["totalover"] = 0,
								["targets"] = {
									["殺那個法師"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["flag_original"] = 66888,
					["tipo"] = 3,
					["alternatepower"] = 0.01393,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D1EDBB",
					["totalover"] = 0.006211,
				}, -- [1]
				{
					["received"] = 15942.109837,
					["resource"] = 0.214187,
					["targets"] = {
						["潇潇"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["passiveover"] = 0.004722,
					["fight_component"] = true,
					["total"] = 15942.109837,
					["nome"] = "潇潇",
					["spells"] = {
						["_ActorTable"] = {
							["魔法吸收"] = {
								["total"] = 10599,
								["id"] = "魔法吸收",
								["totalover"] = 0,
								["targets"] = {
									["潇潇"] = 0,
								},
								["counter"] = 35,
							},
							["补充法力"] = {
								["total"] = 5343,
								["id"] = "补充法力",
								["totalover"] = 0,
								["targets"] = {
									["潇潇"] = 5343,
								},
								["counter"] = 5,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["flag_original"] = 1297,
					["tipo"] = 3,
					["last_event"] = 0,
					["alternatepower"] = 0.109837,
					["spec"] = 64,
					["serial"] = "Player-4920-022A2037",
					["totalover"] = 0.004722,
				}, -- [2]
				{
					["received"] = 2.015522,
					["resource"] = 0.08904,
					["targets"] = {
						["灬坏蛋灬"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "WARRIOR",
					["passiveover"] = 0.003269,
					["total"] = 2.015522,
					["nome"] = "灬坏蛋灬",
					["spells"] = {
						["_ActorTable"] = {
							["怒不可遏"] = {
								["total"] = 2,
								["id"] = "怒不可遏",
								["totalover"] = 0,
								["targets"] = {
									["灬坏蛋灬"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["totalover"] = 0.003269,
					["tipo"] = 3,
					["alternatepower"] = 0.015522,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D03E40",
					["flag_original"] = 1300,
				}, -- [3]
				{
					["received"] = 25.007748,
					["resource"] = 0.038156,
					["targets"] = {
						["风哥"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "WARRIOR",
					["passiveover"] = 0.00268,
					["total"] = 25.007748,
					["nome"] = "风哥",
					["spells"] = {
						["_ActorTable"] = {
							["血性狂暴"] = {
								["total"] = 25,
								["id"] = "血性狂暴",
								["totalover"] = 0,
								["targets"] = {
									["风哥"] = 0,
								},
								["counter"] = 11,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["totalover"] = 0.00268,
					["tipo"] = 3,
					["alternatepower"] = 0.007748,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D157B4",
					["flag_original"] = 1300,
				}, -- [4]
				{
					["received"] = 0.006067,
					["resource"] = 0.053635,
					["targets"] = {
						["过兒我是咕咕"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["classe"] = "DRUID",
					["passiveover"] = 0.006067,
					["total"] = 0.006067,
					["nome"] = "过兒我是咕咕",
					["spells"] = {
						["_ActorTable"] = {
							["激怒"] = {
								["total"] = 0,
								["id"] = "激怒",
								["totalover"] = 0,
								["targets"] = {
									["过兒我是咕咕"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["flag_original"] = 1300,
					["tipo"] = 3,
					["alternatepower"] = 0.006067,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D67BC1",
					["totalover"] = 0.006067,
				}, -- [5]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["暴风雪"] = {
								["refreshamt"] = 0,
								["activedamt"] = -5,
								["appliedamt"] = 464,
								["id"] = "暴风雪",
								["uptime"] = 303,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["寒冰箭"] = {
								["counter"] = 0,
								["refreshamt"] = 82,
								["activedamt"] = -80,
								["uptime"] = 521,
								["id"] = "寒冰箭",
								["appliedamt"] = 11,
								["targets"] = {
								},
								["actived_at"] = 3186454841,
							},
							["冰锥术"] = {
								["actived_at"] = 9559859638,
								["counter"] = 0,
								["activedamt"] = -6,
								["appliedamt"] = 57,
								["id"] = "冰锥术",
								["uptime"] = 150,
								["targets"] = {
								},
								["refreshamt"] = 4,
							},
							["冰霜新星"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 215,
								["id"] = "冰霜新星",
								["uptime"] = 237,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 8619,
					["classe"] = "MAGE",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["法术反制"] = {
								["id"] = "法术反制",
								["counter"] = 6,
								["targets"] = {
									["殺那個法師"] = 2,
									["骷髅巫师"] = 4,
								},
								["interrompeu_oque"] = {
									["精神控制"] = 1,
									["寒冰箭"] = 4,
									["快速治疗"] = 1,
								},
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["被遗忘者的意志"] = {
								["counter"] = 0,
								["activedamt"] = 4,
								["appliedamt"] = 4,
								["id"] = "被遗忘者的意志",
								["uptime"] = 20,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["唤醒"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "唤醒",
								["uptime"] = 1,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["银色黎明委任徽章"] = {
								["refreshamt"] = 0,
								["activedamt"] = 113,
								["appliedamt"] = 113,
								["id"] = "银色黎明委任徽章",
								["uptime"] = 1592,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["闪现术"] = {
								["refreshamt"] = 0,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = "闪现术",
								["uptime"] = 12,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["无荣誉目标"] = {
								["actived_at"] = 1593697266,
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "无荣誉目标",
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["魔甲术"] = {
								["counter"] = 0,
								["activedamt"] = 127,
								["appliedamt"] = 127,
								["id"] = "魔甲术",
								["uptime"] = 1805,
								["targets"] = {
								},
								["refreshamt"] = 1,
							},
							["护甲"] = {
								["refreshamt"] = 0,
								["activedamt"] = 38,
								["appliedamt"] = 38,
								["id"] = "护甲",
								["uptime"] = 459,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["能量无常"] = {
								["counter"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "能量无常",
								["uptime"] = 88,
								["targets"] = {
								},
								["refreshamt"] = 22,
							},
							["寒冰护体"] = {
								["counter"] = 0,
								["activedamt"] = 115,
								["appliedamt"] = 115,
								["id"] = "寒冰护体",
								["uptime"] = 1062,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["法力护盾"] = {
								["refreshamt"] = 0,
								["activedamt"] = 7,
								["appliedamt"] = 7,
								["id"] = "法力护盾",
								["uptime"] = 88,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["魔法抑制"] = {
								["counter"] = 0,
								["activedamt"] = 103,
								["appliedamt"] = 103,
								["id"] = "魔法抑制",
								["uptime"] = 1405,
								["targets"] = {
								},
								["refreshamt"] = 2,
							},
							["紫色骷髅战马"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 14,
								["activedamt"] = 14,
								["uptime"] = 31,
								["id"] = "紫色骷髅战马",
								["actived_at"] = 19118776554,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["防护冰霜结界"] = {
								["counter"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "防护冰霜结界",
								["uptime"] = 60,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["寒冰屏障"] = {
								["counter"] = 0,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = "寒冰屏障",
								["uptime"] = 100,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["奥术智慧"] = {
								["counter"] = 0,
								["activedamt"] = 124,
								["appliedamt"] = 124,
								["id"] = "奥术智慧",
								["uptime"] = 1768,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["节能施法"] = {
								["counter"] = 0,
								["activedamt"] = 49,
								["appliedamt"] = 49,
								["id"] = "节能施法",
								["uptime"] = 123,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["interrompeu_oque"] = {
						["精神控制"] = 1,
						["寒冰箭"] = 4,
						["快速治疗"] = 1,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 1211,
					["pets"] = {
					},
					["interrupt"] = 6.026943,
					["interrupt_targets"] = {
						["殺那個法師"] = 2,
						["骷髅巫师"] = 4,
					},
					["grupo"] = true,
					["spell_cast"] = {
						["魔法抑制"] = 3,
						["法术反制"] = 8,
						["魔甲术"] = 1,
						["暴风雪"] = 51,
						["寒冰护体"] = 19,
						["法力护盾"] = 2,
						["魔爆术"] = 31,
						["寒冰屏障"] = 12,
						["补充法力"] = 5,
						["急速冷却"] = 3,
						["冰霜新星"] = 31,
						["冰锥术"] = 59,
						["射击"] = 27,
						["闪现术"] = 12,
						["被遗忘者的意志"] = 4,
						["防护冰霜结界"] = 3,
						["寒冰箭"] = 179,
						["唤醒"] = 1,
						["火焰冲击"] = 69,
					},
					["debuff_uptime_targets"] = {
					},
					["spec"] = 64,
					["tipo"] = 4,
					["last_event"] = 0,
					["buff_uptime_targets"] = {
					},
					["serial"] = "Player-4920-022A2037",
					["nome"] = "潇潇",
				}, -- [1]
				{
					["flag_original"] = 66888,
					["classe"] = "UNGROUPPLAYER",
					["fight_component"] = true,
					["nome"] = "殺那個法師",
					["dispell"] = 3.002621,
					["enemy"] = true,
					["spell_cast"] = {
						["精神控制"] = 2,
						["暗言术：痛"] = 1,
						["绝望祷言"] = 1,
						["真言术：盾"] = 2,
						["恢复"] = 3,
						["快速治疗"] = 5,
						["心灵尖啸"] = 1,
						["驱散魔法"] = 3,
						["恢复法力"] = 1,
						["祈祷之珠"] = 1,
					},
					["pets"] = {
					},
					["serial"] = "Player-4920-01D1EDBB",
					["last_event"] = 0,
					["tipo"] = 4,
					["dispell_targets"] = {
						["殺那個法師"] = 3,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							["驱散魔法"] = {
								["targets"] = {
									["殺那個法師"] = 3,
								},
								["id"] = "驱散魔法",
								["dispell_oque"] = {
									["寒冰箭"] = 3,
								},
								["dispell"] = 3,
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["dispell_oque"] = {
						["寒冰箭"] = 3,
					},
				}, -- [2]
				{
					["fight_component"] = true,
					["last_event"] = 0,
					["nome"] = "裙带飘飘",
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["tipo"] = 4,
					["spell_cast"] = {
						["寒冰护体"] = 1,
						["闪现术"] = 1,
					},
					["serial"] = "Player-4920-01D0BD72",
					["flag_original"] = 66888,
				}, -- [3]
				{
					["fight_component"] = true,
					["last_event"] = 0,
					["nome"] = "骷髅巫师",
					["spell_cast"] = {
						["火焰新星"] = 5,
						["寒冰箭"] = 18,
					},
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["serial"] = "Creature-0-4505-0-197-1784-00007688AB",
					["tipo"] = 4,
				}, -- [4]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "被奴役的食尸鬼",
					["pets"] = {
					},
					["spell_cast"] = {
						["痛击"] = 11,
						["毒性唾液"] = 1,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-197-1791-000076A511",
					["classe"] = "UNKNOW",
				}, -- [5]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "骷髅剥皮者",
					["pets"] = {
					},
					["spell_cast"] = {
						["痛击"] = 9,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-197-1783-000076262F",
					["classe"] = "UNKNOW",
				}, -- [6]
				{
					["fight_component"] = true,
					["last_event"] = 0,
					["nome"] = "血色医护员",
					["spell_cast"] = {
						["快速治疗"] = 5,
						["恢复"] = 1,
						["抵抗奥术"] = 2,
					},
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 68168,
					["serial"] = "Creature-0-4505-0-197-10605-000076BAEB",
					["tipo"] = 4,
				}, -- [7]
				{
					["fight_component"] = true,
					["last_event"] = 0,
					["nome"] = "血色猎人",
					["spell_cast"] = {
						["射击"] = 55,
					},
					["monster"] = true,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["serial"] = "Creature-0-4505-0-197-1831-000076BAC1",
					["tipo"] = 4,
				}, -- [8]
				{
					["flag_original"] = 2632,
					["last_event"] = 0,
					["nome"] = "恐惧骸骨",
					["pets"] = {
					},
					["monster"] = true,
					["fight_component"] = true,
					["tipo"] = 4,
					["spell_cast"] = {
						["恐惧术"] = 12,
					},
					["serial"] = "Creature-0-4505-0-197-1785-000076BD5C",
					["classe"] = "UNKNOW",
				}, -- [9]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "腐烂虫",
					["pets"] = {
					},
					["spell_cast"] = {
						["痛击"] = 1,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-197-10925-0000F6C357",
					["classe"] = "UNKNOW",
				}, -- [10]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "坏死的僵尸",
					["pets"] = {
					},
					["spell_cast"] = {
						["快速传染"] = 2,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-197-4475-000076C442",
					["classe"] = "UNKNOW",
				}, -- [11]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "弗曼恩",
					["pets"] = {
					},
					["spell_cast"] = {
						["痛击"] = 3,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-197-1847-000076C769",
					["classe"] = "UNKNOW",
				}, -- [12]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "喋喋不休的食尸鬼",
					["pets"] = {
					},
					["spell_cast"] = {
						["狂怒"] = 1,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-197-10801-000076CAE4",
					["classe"] = "UNKNOW",
				}, -- [13]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "护锅者玛维诺斯",
					["pets"] = {
					},
					["spell_cast"] = {
						["暗影箭"] = 1,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-197-11077-000076D2FE",
					["classe"] = "UNKNOW",
				}, -- [14]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["心灵尖啸"] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = "心灵尖啸",
								["uptime"] = 3,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["dispell"] = 1.006413,
					["pets"] = {
					},
					["classe"] = "PRIEST",
					["dispell_oque"] = {
						["冰霜新星"] = 1,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							["驱散魔法"] = {
								["dispell"] = 1,
								["id"] = "驱散魔法",
								["dispell_oque"] = {
									["冰霜新星"] = 1,
								},
								["targets"] = {
									["板板狗"] = 1,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["神圣之灵"] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "神圣之灵",
								["uptime"] = 29,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["真言术：韧"] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "真言术：韧",
								["uptime"] = 29,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 3,
					["nome"] = "板板狗",
					["grupo"] = true,
					["spell_cast"] = {
						["驱散魔法"] = 2,
						["心灵尖啸"] = 1,
					},
					["buff_uptime"] = 58,
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["buff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["serial"] = "Player-4920-01D0B865",
					["dispell_targets"] = {
						["板板狗"] = 1,
					},
				}, -- [15]
				{
					["flag_original"] = 1300,
					["buff_uptime_targets"] = {
					},
					["spec"] = 260,
					["grupo"] = true,
					["buff_uptime"] = 5,
					["nome"] = "希洛克",
					["pets"] = {
					},
					["tipo"] = 4,
					["classe"] = "ROGUE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["潜行"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "潜行",
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-01D09CF8",
					["last_event"] = 0,
				}, -- [16]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["重伤"] = {
								["refreshamt"] = 0,
								["activedamt"] = -1,
								["appliedamt"] = 1,
								["id"] = "重伤",
								["uptime"] = 9,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "WARRIOR",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["乱舞"] = {
								["refreshamt"] = 1,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "乱舞",
								["uptime"] = 21,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 9,
					["buff_uptime_targets"] = {
					},
					["grupo"] = true,
					["spell_cast"] = {
						["英勇打击"] = 1,
					},
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["nome"] = "灬坏蛋灬",
					["tipo"] = 4,
					["serial"] = "Player-4920-01D03E40",
					["buff_uptime"] = 21,
				}, -- [17]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["猎人印记"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "猎人印记",
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 34,
					["classe"] = "HUNTER",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["灵猴守护"] = {
								["actived_at"] = 1593697312,
								["refreshamt"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = "灵猴守护",
								["uptime"] = 29,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["狂怒之嚎"] = {
								["id"] = "狂怒之嚎",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "无荣誉目标",
								["uptime"] = 5,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 5,
					["nome"] = "香油田鸡",
					["grupo"] = true,
					["spell_cast"] = {
						["猎人印记"] = 1,
					},
					["debuff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["pets"] = {
					},
					["serial"] = "Player-4920-026E1D50",
					["last_event"] = 0,
				}, -- [18]
				{
					["flag_original"] = 1298,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["冰锥术"] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = "冰锥术",
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["寒冰护体"] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "寒冰护体",
								["uptime"] = 25,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["喝水"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "喝水",
								["actived_at"] = 1593697312,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["进食"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "进食",
								["actived_at"] = 1593697312,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 0,
					["nome"] = "窥见身外之身",
					["grupo"] = true,
					["spell_cast"] = {
						["魔爆术"] = 3,
						["寒冰箭"] = 1,
						["寒冰护体"] = 1,
						["冰锥术"] = 1,
					},
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["buff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["serial"] = "Player-4920-02628F22",
					["buff_uptime"] = 25,
				}, -- [19]
				{
					["flag_original"] = 1300,
					["nome"] = "风哥",
					["grupo"] = true,
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 20,
					["tipo"] = 4,
					["spell_cast"] = {
						["盾牌猛击"] = 1,
						["破甲攻击"] = 1,
						["血性狂暴"] = 1,
					},
					["classe"] = "WARRIOR",
					["pets"] = {
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["uptime"] = 10,
								["id"] = "无荣誉目标",
								["actived_at"] = 1593697266,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["血性狂暴"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "血性狂暴",
								["uptime"] = 10,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-01D157B4",
					["last_event"] = 0,
				}, -- [20]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "哈卡莱神谕者",
					["pets"] = {
					},
					["spell_cast"] = {
						["地震术"] = 1,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4999-0-282-11346-00007DDB8E",
					["classe"] = "UNKNOW",
				}, -- [21]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "古拉巴什战士",
					["pets"] = {
					},
					["spell_cast"] = {
						["击倒"] = 2,
						["狂怒"] = 1,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4999-0-282-11355-00007DDB7E",
					["classe"] = "UNKNOW",
				}, -- [22]
				{
					["flag_original"] = 1300,
					["nome"] = "奇异灬博士",
					["grupo"] = true,
					["buff_uptime_targets"] = {
					},
					["pets"] = {
					},
					["classe"] = "WARLOCK",
					["buff_uptime"] = 0,
					["last_event"] = 0,
					["spell_cast"] = {
						["召唤仪式"] = 1,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["血之契印"] = {
								["id"] = "血之契印",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-01EBF4BE",
					["tipo"] = 4,
				}, -- [23]
				{
					["fight_component"] = true,
					["flag_original"] = 66888,
					["nome"] = "风御九天",
					["enemy"] = true,
					["spell_cast"] = {
						["法力护盾"] = 2,
					},
					["pets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["serial"] = "Player-4920-0272452D",
					["classe"] = "UNGROUPPLAYER",
				}, -- [24]
				{
					["flag_original"] = 1300,
					["nome"] = "火抗梯",
					["grupo"] = true,
					["pets"] = {
					},
					["buff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["buff_uptime"] = 0,
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["无荣誉目标"] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = "无荣誉目标",
								["uptime"] = 0,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["防御姿态"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "防御姿态",
								["actived_at"] = 1593697319,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-01D1852F",
					["classe"] = "WARRIOR",
				}, -- [25]
				{
					["fight_component"] = true,
					["flag_original"] = 66888,
					["nome"] = "冲击波",
					["enemy"] = true,
					["spell_cast"] = {
						["闪现术"] = 1,
					},
					["pets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D0DDE4",
					["classe"] = "UNGROUPPLAYER",
				}, -- [26]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1593224746,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["segments_added"] = {
			{
				["elapsed"] = 7.00299999999697,
				["type"] = 0,
				["name"] = "风御九天",
				["clock"] = "21:51:37",
			}, -- [1]
			{
				["elapsed"] = 10.0099999999948,
				["type"] = 0,
				["name"] = "冲击波",
				["clock"] = "21:50:58",
			}, -- [2]
			{
				["elapsed"] = 8.00599999999395,
				["type"] = 0,
				["name"] = "风御九天",
				["clock"] = "21:41:52",
			}, -- [3]
			{
				["elapsed"] = 24.0010000000038,
				["type"] = 0,
				["name"] = "古拉巴什战士",
				["clock"] = "21:41:07",
			}, -- [4]
			{
				["elapsed"] = 5.00400000000082,
				["type"] = 0,
				["name"] = "古拉巴什战士",
				["clock"] = "21:40:40",
			}, -- [5]
			{
				["elapsed"] = 14.9789999999921,
				["type"] = 0,
				["name"] = "腐烂的死尸",
				["clock"] = "13:05:19",
			}, -- [6]
			{
				["elapsed"] = 6.35699999998906,
				["type"] = 0,
				["name"] = "坏死的僵尸",
				["clock"] = "13:03:49",
			}, -- [7]
			{
				["elapsed"] = 2.03299999999581,
				["type"] = 0,
				["name"] = "腐烂虫",
				["clock"] = "13:03:40",
			}, -- [8]
			{
				["elapsed"] = 18.8969999999972,
				["type"] = 0,
				["name"] = "腐烂的死尸",
				["clock"] = "13:03:20",
			}, -- [9]
			{
				["elapsed"] = 1.41700000001583,
				["type"] = 0,
				["name"] = "腐烂虫",
				["clock"] = "13:03:08",
			}, -- [10]
			{
				["elapsed"] = 11.3249999999825,
				["type"] = 0,
				["name"] = "腐烂的死尸",
				["clock"] = "13:02:55",
			}, -- [11]
			{
				["elapsed"] = 21.0499999999884,
				["type"] = 0,
				["name"] = "喋喋不休的食尸鬼",
				["clock"] = "12:58:57",
			}, -- [12]
			{
				["elapsed"] = 7.57199999998557,
				["type"] = 0,
				["name"] = "骷髅剥皮者",
				["clock"] = "12:58:41",
			}, -- [13]
			{
				["elapsed"] = 5.57000000000699,
				["type"] = 0,
				["name"] = "骷髅剥皮者",
				["clock"] = "12:57:53",
			}, -- [14]
			{
				["elapsed"] = 3.90200000000186,
				["type"] = 0,
				["name"] = "骷髅剥皮者",
				["clock"] = "12:57:19",
			}, -- [15]
			{
				["elapsed"] = 3.9210000000021,
				["type"] = 0,
				["name"] = "骷髅剥皮者",
				["clock"] = "12:57:08",
			}, -- [16]
			{
				["elapsed"] = 6.47299999999814,
				["type"] = 0,
				["name"] = "骷髅巫师",
				["clock"] = "12:56:35",
			}, -- [17]
			{
				["elapsed"] = 5.10599999999977,
				["type"] = 0,
				["name"] = "骷髅剥皮者",
				["clock"] = "12:56:23",
			}, -- [18]
			{
				["elapsed"] = 20.1520000000019,
				["type"] = 0,
				["name"] = "骷髅巫师",
				["clock"] = "12:55:53",
			}, -- [19]
			{
				["elapsed"] = 5.10599999999977,
				["type"] = 0,
				["name"] = "被奴役的食尸鬼",
				["clock"] = "12:55:22",
			}, -- [20]
			{
				["elapsed"] = 6.37200000000303,
				["type"] = 0,
				["name"] = "骷髅剥皮者",
				["clock"] = "12:55:06",
			}, -- [21]
			{
				["elapsed"] = 3.78599999999278,
				["type"] = 0,
				["name"] = "坏死的僵尸",
				["clock"] = "12:49:13",
			}, -- [22]
			{
				["elapsed"] = 1.1019999999844,
				["type"] = 0,
				["name"] = "腐烂虫",
				["clock"] = "12:48:59",
			}, -- [23]
			{
				["elapsed"] = 18.5139999999956,
				["type"] = 0,
				["name"] = "腐烂的死尸",
				["clock"] = "12:48:40",
			}, -- [24]
			{
				["elapsed"] = 8.52400000000489,
				["type"] = 0,
				["name"] = "恐惧骸骨",
				["clock"] = "12:48:24",
			}, -- [25]
			{
				["elapsed"] = 1.61999999999534,
				["type"] = 0,
				["name"] = "腐烂虫",
				["clock"] = "12:48:16",
			}, -- [26]
			{
				["elapsed"] = 9.97500000000582,
				["type"] = 0,
				["name"] = "腐烂的死尸",
				["clock"] = "12:48:06",
			}, -- [27]
			{
				["elapsed"] = 2.01900000000023,
				["type"] = 0,
				["name"] = "腐烂虫",
				["clock"] = "12:47:58",
			}, -- [28]
			{
				["elapsed"] = 9.85699999998906,
				["type"] = 0,
				["name"] = "腐烂的死尸",
				["clock"] = "12:47:48",
			}, -- [29]
			{
				["elapsed"] = 10.8269999999902,
				["type"] = 0,
				["name"] = "坏死的僵尸",
				["clock"] = "12:47:17",
			}, -- [30]
		},
		["combat_counter"] = 611,
		["totals"] = {
			883331.750554999, -- [1]
			34644.344591, -- [2]
			{
				58.044567, -- [1]
				[0] = 17688.137269,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 6.026943,
				["debuff_uptime"] = 0,
				["dispell"] = 5.013589,
				["cooldowns_defensive"] = 0,
			}, -- [4]
			["voidzone_damage"] = 0,
			["frags_total"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "10:25:47",
		["end_time"] = 82068.379,
		["cleu_timeline"] = {
		},
		["totals_grupo"] = {
			788030.656682, -- [1]
			32446.243227, -- [2]
			{
				27.017321, -- [1]
				[0] = 15942.105115,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 6.026943,
				["debuff_uptime"] = 0,
				["dispell"] = 1.006413,
				["cooldowns_defensive"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
		},
		["hasSaved"] = true,
		["spells_cast_timeline"] = {
		},
		["data_fim"] = "21:51:44",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["frags"] = {
		},
		["start_time"] = 80256.53,
		["TimeData"] = {
		},
		["cleu_events"] = {
			["n"] = 1,
		},
	},
	["local_instances_config"] = {
		{
			["segment"] = -1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -349.866226196289,
					["x"] = 751.715698242188,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -171.866271972656,
					["x"] = 751.715698242188,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["character_data"] = {
		["logons"] = 65,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-4920-022A2037"] = 64,
	},
}
