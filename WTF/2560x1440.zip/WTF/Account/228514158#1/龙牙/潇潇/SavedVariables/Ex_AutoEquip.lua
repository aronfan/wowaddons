
ExAE_Config = {
	["潇潇@Enigma"] = {
		{
			["Finger0Slot"] = {
				["name"] = "专注指环",
				["link"] = "item:19403::::::::60:::::::",
			},
			["BackSlot"] = {
				["name"] = "吞噬披风",
				["link"] = "item:19857::::::::60:::::::",
			},
			["Trinket0Slot"] = {
				["name"] = "石楠之环",
				["link"] = "item:12930::::::::60:::1::::",
			},
			["TabardSlot"] = {
			},
			["FeetSlot"] = {
				["name"] = "灵风长靴",
				["link"] = "item:16912:911:::::::60:::::::",
			},
			["NeckSlot"] = {
				["name"] = "火焰之王的项圈",
				["link"] = "item:18814::::::::60:::::::",
			},
			["Finger1Slot"] = {
				["name"] = "赞吉尔的徽记",
				["link"] = "item:19893::::::::60:::::::",
			},
			["ChestSlot"] = {
				["name"] = "灵风长袍",
				["link"] = "item:16916:1891:::::::60:::::::",
			},
			["Trinket1Slot"] = {
				["name"] = "赞达拉英雄护符",
				["link"] = "item:19950::::::::60:::11::::",
			},
			["ShoulderSlot"] = {
				["name"] = "灵风衬肩",
				["link"] = "item:16917::::::::60:::::::",
			},
			["MainHandSlot"] = {
				["name"] = "暗影烈焰法杖",
				["link"] = "item:19356:2504:::::::60:::::::",
			},
			["HandsSlot"] = {
				["name"] = "奥术师手套",
				["link"] = "item:16801::::::::60:::::::",
			},
			["LegsSlot"] = {
				["name"] = "灵风短裤",
				["link"] = "item:16915:2588:::::::60:::::::",
			},
			["ShirtSlot"] = {
				["name"] = "学徒衬衣",
				["link"] = "item:6096::::::::60:::::::",
			},
			["WaistSlot"] = {
				["name"] = "奥术师腰带",
				["link"] = "item:16802::::::::60:::::::",
			},
			["WristSlot"] = {
				["name"] = "奥术师护腕",
				["link"] = "item:16799:1883:::::::60:::::::",
			},
			["HeadSlot"] = {
				["name"] = "灵风头冠",
				["link"] = "item:16914:2588:::::::60:::::::",
			},
			["SecondaryHandSlot"] = {
			},
			["RangedSlot"] = {
				["name"] = "混乱之触",
				["link"] = "item:19861::::::::60:::::::",
			},
			["AmmoSlot"] = {
			},
		}, -- [1]
		{
			["Finger0Slot"] = {
				["name"] = "赞吉尔指环",
				["link"] = "item:19905::::::::60:::::::",
			},
			["BackSlot"] = {
				["name"] = "吞噬披风",
				["link"] = "item:19857::::::::60:::::::",
			},
			["Trinket0Slot"] = {
				["name"] = "银色黎明委任徽章",
				["link"] = "item:12846::::::::60:::11::::",
			},
			["TabardSlot"] = {
			},
			["FeetSlot"] = {
				["name"] = "灵风长靴",
				["link"] = "item:16912:911:::::::60:::::::",
			},
			["NeckSlot"] = {
				["name"] = "堕灵者项链",
				["link"] = "item:19876::::::::60:::::::",
			},
			["Finger1Slot"] = {
				["name"] = "赞吉尔的徽记",
				["link"] = "item:19893::::::::60:::::::",
			},
			["ChestSlot"] = {
				["name"] = "灵风长袍",
				["link"] = "item:16916:1891:::::::60:::::::",
			},
			["Trinket1Slot"] = {
				["name"] = "赞达拉英雄护符",
				["link"] = "item:19950::::::::60:::11::::",
			},
			["ShoulderSlot"] = {
				["name"] = "灵风衬肩",
				["link"] = "item:16917::::::::60:::::::",
			},
			["MainHandSlot"] = {
				["name"] = "暗影烈焰法杖",
				["link"] = "item:19356:2504:::::::60:::::::",
			},
			["AmmoSlot"] = {
			},
			["RangedSlot"] = {
				["name"] = "混乱之触",
				["link"] = "item:19861::::::::60:::::::",
			},
			["ShirtSlot"] = {
				["name"] = "学徒衬衣",
				["link"] = "item:6096::::::::60:::::::",
			},
			["SecondaryHandSlot"] = {
			},
			["HeadSlot"] = {
				["name"] = "灵风头冠",
				["link"] = "item:16914:2588:::::::60:::::::",
			},
			["WristSlot"] = {
				["name"] = "奥术师护腕",
				["link"] = "item:16799:1883:::::::60:::::::",
			},
			["WaistSlot"] = {
				["name"] = "奥术师腰带",
				["link"] = "item:16802::::::::60:::::::",
			},
			["LegsSlot"] = {
				["name"] = "灵风短裤",
				["link"] = "item:16915:2588:::::::60:::::::",
			},
			["HandsSlot"] = {
				["name"] = "奥术师手套",
				["link"] = "item:16801::::::::60:::::::",
			},
		}, -- [2]
		["CurrentSetId"] = 1,
	},
}
