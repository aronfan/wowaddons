
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["潇潇 - 龙牙"] = "潇潇 - 龙牙",
	},
	["profiles"] = {
		["潇潇 - 龙牙"] = {
		},
	},
}
