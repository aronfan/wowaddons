
GearMenuConfiguration = {
	["enableDragAndDrop"] = true,
	["addonVersion"] = "v1.3.0",
	["showKeyBindings"] = true,
	["enableTooltips"] = true,
	["slots"] = {
		1, -- [1]
		99, -- [2]
		99, -- [3]
		5, -- [4]
		6, -- [5]
		99, -- [6]
		8, -- [7]
		99, -- [8]
		99, -- [9]
		99, -- [10]
		99, -- [11]
		13, -- [12]
		14, -- [13]
		99, -- [14]
		16, -- [15]
		17, -- [16]
		99, -- [17]
	},
	["lockGearBar"] = true,
	["enableFastpress"] = true,
	["slotSize"] = 40,
	["showCooldowns"] = true,
	["frames"] = {
		["GM_GearBar"] = {
			["relativePoint"] = "BOTTOMRIGHT",
			["point"] = "BOTTOMRIGHT",
			["posY"] = 36.1558265686035,
			["posX"] = -130.799987792969,
		},
	},
	["enableSimpleTooltips"] = true,
	["quickChangeRules"] = {
	},
	["filterItemQuality"] = 2,
}
