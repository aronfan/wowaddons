
PowerSparkDB = {
	["default"] = {
		["timer"] = 519089.842,
	},
}
