
PowerSparkDB = {
	["default"] = {
		["timer"] = 812775.102,
	},
}
