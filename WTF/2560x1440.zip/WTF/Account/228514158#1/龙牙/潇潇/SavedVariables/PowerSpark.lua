
PowerSparkDB = {
	["default"] = {
		["timer"] = 1730155.2,
	},
}
