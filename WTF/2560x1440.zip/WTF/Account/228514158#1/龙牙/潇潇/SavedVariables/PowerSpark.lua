
PowerSparkDB = {
	["default"] = {
		["timer"] = 773808.752,
	},
}
