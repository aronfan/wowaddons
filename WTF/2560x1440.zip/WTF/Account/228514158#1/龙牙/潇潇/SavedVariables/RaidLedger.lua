
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1587265867,
			["items"] = {
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
