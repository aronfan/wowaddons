
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1592323465,
			["items"] = {
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:9402::::::::60:::::::|h[尘世褶裙]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13073::::::::60:::::::|h[玛格索尔之盔]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17682::::::::60:::::::|h[书卷：野性赐福]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18205::::::::60:::::::|h[艾斯卡达尔的项圈]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18422::::::::60:::::::|h[奥妮克希亚的头颅]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16939::::::::60:::::::|h[巨龙追猎者头盔]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16908::::::::60:::::::|h[血牙头巾]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "教堂七波流",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18705::::::::60:::::::|h[成年黑龙的肌腱]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [9]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [10]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [11]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19717::::::::60:::::::|h[原始哈卡莱护臂]|h|r",
						["count"] = 1,
					},
				}, -- [12]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22720::::::::60:::::::|h[祖利安头饰]|h|r",
						["count"] = 1,
					},
				}, -- [13]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19918::::::::60:::::::|h[耶克里克之锤]|h|r",
						["count"] = 1,
					},
				}, -- [14]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22713::::::::60:::::::|h[祖利安典礼权杖]|h|r",
						["count"] = 1,
					},
				}, -- [15]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19721::::::::60:::::::|h[原始哈卡莱披肩]|h|r",
						["count"] = 1,
					},
				}, -- [16]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19905::::::::60:::::::|h[赞吉尔指环]|h|r",
						["count"] = 1,
					},
				}, -- [17]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19716::::::::60:::::::|h[原始哈卡莱护腕]|h|r",
						["count"] = 1,
					},
				}, -- [18]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19927::::::::60:::::::|h[玛尔里之触]|h|r",
						["count"] = 1,
					},
				}, -- [19]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22713::::::::60:::::::|h[祖利安典礼权杖]|h|r",
						["count"] = 1,
					},
				}, -- [20]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [21]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [22]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19870::::::::60:::::::|h[哈卡莱血披风]|h|r",
						["count"] = 1,
					},
				}, -- [23]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22637::::::::60:::::::|h[原始哈卡莱神像]|h|r",
						["count"] = 1,
					},
				}, -- [24]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19869::::::::60:::::::|h[浴血护手]|h|r",
						["count"] = 1,
					},
				}, -- [25]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19724::::::::60:::::::|h[原始哈卡莱之盾]|h|r",
						["count"] = 1,
					},
				}, -- [26]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [27]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19721::::::::60:::::::|h[原始哈卡莱披肩]|h|r",
						["count"] = 1,
					},
				}, -- [28]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:22721::::::::60:::::::|h[惩戒指环]|h|r",
						["count"] = 1,
					},
				}, -- [29]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19901::::::::60:::::::|h[祖利安切割者]|h|r",
						["count"] = 1,
					},
				}, -- [30]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [31]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [32]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19716::::::::60:::::::|h[原始哈卡莱护腕]|h|r",
						["count"] = 1,
					},
				}, -- [33]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19922::::::::60:::::::|h[娅尔罗的巫毒棒]|h|r",
						["count"] = 1,
					},
				}, -- [34]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22714::::::::60:::::::|h[祭祀护手]|h|r",
						["count"] = 1,
					},
				}, -- [35]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [36]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [37]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [38]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19802::::::::60:::::::|h[哈卡之心]|h|r",
						["count"] = 1,
					},
				}, -- [39]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19876::::::::60:::::::|h[堕灵者项链]|h|r",
						["count"] = 1,
					},
				}, -- [40]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19864::::::::60:::::::|h[血之召唤者]|h|r",
						["count"] = 1,
					},
				}, -- [41]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19946::::::::60:::::::|h[提古勒的鱼叉]|h|r",
						["count"] = 1,
					},
				}, -- [42]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [43]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [44]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [45]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18335::::::::60:::::::|h[原始黑钻石]|h|r",
						["count"] = 1,
					},
				}, -- [46]
				{
					["beneficiary"] = "大脚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [47]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19927::::::::60:::::::|h[玛尔里之触]|h|r",
						["count"] = 1,
					},
				}, -- [48]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22637::::::::60:::::::|h[原始哈卡莱神像]|h|r",
						["count"] = 1,
					},
				}, -- [49]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19716::::::::60:::::::|h[原始哈卡莱护腕]|h|r",
						["count"] = 1,
					},
				}, -- [50]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19889::::::::60:::::::|h[浴血护腿]|h|r",
						["count"] = 1,
					},
				}, -- [51]
				{
					["beneficiary"] = "灬有容乃大灬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19891::::::::60:::::::|h[金度的厄运袋]|h|r",
						["count"] = 1,
					},
				}, -- [52]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
