
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1587265867,
			["items"] = {
				{
					["beneficiary"] = "亡者农药",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13003::::::::51:::1::::|h[亚历山大的战斧]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "我瞿李媚",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19261::::::::52:::1::::|h[督军之四]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19261::::::::52:::1::::|h[督军之四]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "亡者农药",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18335::::::::54:::::::|h[原始黑钻石]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "亡者农药",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17683::::::::54:::1::::|h[书卷：野性赐福 II]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "我瞿李媚",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13395::::::::54:::1::::|h[斯库尔的骨爪]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "我瞿李媚",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::54:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "亡者农药",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:8190::::::::54:::1::::|h[半藏之剑]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "我瞿李媚",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17414::::::::55:::1::::|h[圣典：坚韧祷言 II]|h|r",
						["count"] = 1,
					},
				}, -- [9]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13395::::::::55:::1::::|h[斯库尔的骨爪]|h|r",
						["count"] = 1,
					},
				}, -- [10]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::55:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [11]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17414::::::::55:::1::::|h[圣典：坚韧祷言 II]|h|r",
						["count"] = 1,
					},
				}, -- [12]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13003::::::::55:::1::::|h[亚历山大的战斧]|h|r",
						["count"] = 1,
					},
				}, -- [13]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18600::::::::55:::1::::|h[奥术光辉宝典]|h|r",
						["count"] = 1,
					},
				}, -- [14]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17414::::::::56:::1::::|h[圣典：坚韧祷言 II]|h|r",
						["count"] = 1,
					},
				}, -- [15]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
