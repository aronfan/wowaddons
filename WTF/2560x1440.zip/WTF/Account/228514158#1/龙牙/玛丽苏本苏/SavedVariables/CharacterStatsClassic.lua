
CharacterStatsClassicCharacterDB = {
	["selectedRightStatsCategory"] = 4,
	["selectedLeftStatsCategory"] = 1,
}
