
ExAE_Config = {
	["玛丽苏本苏@Enigma"] = {
		{
			["Finger0Slot"] = {
				["name"] = "纯源质指环",
				["link"] = "item:19382::::::::60:::::::",
			},
			["BackSlot"] = {
				["name"] = "纯净思想斗篷",
				["link"] = "item:19430:1888:::::::60:::::::",
			},
			["Trinket0Slot"] = {
				["name"] = "恢复宝石",
				["link"] = "item:19395::::::::60:::::::",
			},
			["TabardSlot"] = {
			},
			["FeetSlot"] = {
				["name"] = "预言之靴",
				["link"] = "item:16811:851:::::::60:::::::",
			},
			["NeckSlot"] = {
				["name"] = "金度的邪眼",
				["link"] = "item:19885::::::::60:::::::",
			},
			["Finger1Slot"] = {
				["name"] = "萨弗拉斯指环",
				["link"] = "item:19138::::::::60:::::::",
			},
			["ChestSlot"] = {
				["name"] = "卓越法袍",
				["link"] = "item:16923:1893:::::::60:::::::",
			},
			["Trinket1Slot"] = {
				["name"] = "埃雷萨拉斯皇家徽记",
				["link"] = "item:18469::::::::60:::11::::",
			},
			["ShoulderSlot"] = {
				["name"] = "卓越肩铠",
				["link"] = "item:16924::::::::60:::::::",
			},
			["MainHandSlot"] = {
				["name"] = "祈福",
				["link"] = "item:18608:2505:::::::60:::11::::",
			},
			["HandsSlot"] = {
				["name"] = "卓越护手",
				["link"] = "item:16920::::::::60:::::::",
			},
			["LegsSlot"] = {
				["name"] = "卓越护腿",
				["link"] = "item:16922:2590:::::::60:::::::",
			},
			["ShirtSlot"] = {
				["name"] = "主建筑师的衬衣",
				["link"] = "item:11840::::::::60:::1::::",
			},
			["WaistSlot"] = {
				["name"] = "卓越腰带",
				["link"] = "item:16925::::::::60:::::::",
			},
			["WristSlot"] = {
				["name"] = "卓越束腕",
				["link"] = "item:16926:2566:::::::60:::::::",
			},
			["HeadSlot"] = {
				["name"] = "卓越之环",
				["link"] = "item:16921:2590:::::::60:::::::",
			},
			["SecondaryHandSlot"] = {
			},
			["RangedSlot"] = {
				["name"] = "玛尔里之触",
				["link"] = "item:19927::::::::60:::::::",
			},
			["AmmoSlot"] = {
			},
		}, -- [1]
		["CurrentSetId"] = 1,
	},
}
