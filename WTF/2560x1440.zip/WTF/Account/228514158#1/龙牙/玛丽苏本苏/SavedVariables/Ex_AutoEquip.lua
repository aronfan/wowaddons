
ExAE_Config = {
	["玛丽苏本苏@Enigma"] = {
		{
			["Finger0Slot"] = {
				["name"] = "碧绿烈焰戒指",
				["link"] = "item:18395::::::::60:::1::::",
			},
			["BackSlot"] = {
				["name"] = "纯净思想斗篷",
				["link"] = "item:19430:1888:::::::60:::::::",
			},
			["Trinket0Slot"] = {
				["name"] = "暗月卡片：蓝龙",
				["link"] = "item:19288::::::::60:::11::::",
			},
			["TabardSlot"] = {
			},
			["FeetSlot"] = {
				["name"] = "预言之靴",
				["link"] = "item:16811:851:::::::60:::::::",
			},
			["NeckSlot"] = {
				["name"] = "龙魂坠饰",
				["link"] = "item:19371::::::::60:::::::",
			},
			["Finger1Slot"] = {
				["name"] = "萨弗拉斯指环",
				["link"] = "item:19138::::::::60:::::::",
			},
			["ChestSlot"] = {
				["name"] = "卓越法袍",
				["link"] = "item:16923:1893:::::::60:::::::",
			},
			["Trinket1Slot"] = {
				["name"] = "埃雷萨拉斯皇家徽记",
				["link"] = "item:18469::::::::60:::11::::",
			},
			["ShoulderSlot"] = {
				["name"] = "预言衬肩",
				["link"] = "item:16816::::::::60:::::::",
			},
			["MainHandSlot"] = {
				["name"] = "祈福",
				["link"] = "item:18608:2505:::::::60:::11::::",
			},
			["AmmoSlot"] = {
			},
			["RangedSlot"] = {
				["name"] = "噬骨铁针",
				["link"] = "item:13938::::::::60:::1::::",
			},
			["ShirtSlot"] = {
				["name"] = "主建筑师的衬衣",
				["link"] = "item:11840::::::::60:::1::::",
			},
			["SecondaryHandSlot"] = {
			},
			["HeadSlot"] = {
				["name"] = "卓越之环",
				["link"] = "item:16921:1483:::::::60:::::::",
			},
			["WristSlot"] = {
				["name"] = "卓越束腕",
				["link"] = "item:16926:1884:::::::60:::::::",
			},
			["WaistSlot"] = {
				["name"] = "预言束带",
				["link"] = "item:16817::::::::60:::::::",
			},
			["LegsSlot"] = {
				["name"] = "预言短裤",
				["link"] = "item:16814::::::::60:::::::",
			},
			["HandsSlot"] = {
				["name"] = "预言手套",
				["link"] = "item:16812:1887:::::::60:::::::",
			},
		}, -- [1]
		["CurrentSetId"] = 1,
	},
}
