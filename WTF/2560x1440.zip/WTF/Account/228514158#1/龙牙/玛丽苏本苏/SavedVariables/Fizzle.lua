
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["玛丽苏本苏 - 龙牙"] = "玛丽苏本苏 - 龙牙",
	},
	["profiles"] = {
		["玛丽苏本苏 - 龙牙"] = {
		},
	},
}
