
PowerSparkDB = {
	["default"] = {
		["timer"] = 682592.74,
	},
}
