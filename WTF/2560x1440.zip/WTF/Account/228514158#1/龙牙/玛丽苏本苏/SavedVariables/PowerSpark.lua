
PowerSparkDB = {
	["default"] = {
		["timer"] = 617638.696,
	},
}
