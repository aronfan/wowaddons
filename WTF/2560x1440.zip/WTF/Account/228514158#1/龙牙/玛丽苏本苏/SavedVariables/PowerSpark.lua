
PowerSparkDB = {
	["default"] = {
		["timer"] = 812663.596,
	},
}
