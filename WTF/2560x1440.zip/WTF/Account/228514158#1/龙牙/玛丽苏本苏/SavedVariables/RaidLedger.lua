
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1592053091,
			["items"] = {
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
