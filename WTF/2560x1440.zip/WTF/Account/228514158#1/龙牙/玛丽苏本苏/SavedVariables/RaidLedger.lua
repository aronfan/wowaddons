
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1587205997,
			["items"] = {
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19718::::::::60:::::::|h[原始哈卡莱直柱]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "刘鑫",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:20554::::::::60:::::::|h[设计图：黑暗符文胸甲]|h|r",
						["count"] = 1,
					},
				}, -- [2]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
