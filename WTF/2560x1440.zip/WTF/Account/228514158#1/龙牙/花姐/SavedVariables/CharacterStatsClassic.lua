
CharacterStatsClassicCharacterDB = {
	["selectedRightStatsCategory"] = 2,
	["selectedLeftStatsCategory"] = 1,
}
