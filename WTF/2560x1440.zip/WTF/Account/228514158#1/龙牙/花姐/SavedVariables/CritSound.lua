
CritSoundSwitch = {
	["spell"] = 1,
	["shield"] = 1,
	["swing"] = 1,
	["range"] = 1,
	["heal"] = 1,
}
CritSoundMode = 1
CritSoundAgingTime = 10
CritSoundBlackList = {
}
