
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002095,
							["damage_from"] = {
							},
							["targets"] = {
								["迷行"] = 932,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["last_event"] = 1593185226,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 932.002095,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 932.002095,
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["迷行"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 201,
										["g_amt"] = 0,
										["n_max"] = 201,
										["targets"] = {
											["迷行"] = 695,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 494,
										["n_min"] = 103,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 695,
										["c_max"] = 201,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 201,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 237,
										["targets"] = {
											["迷行"] = 237,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 237,
										["n_min"] = 237,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 237,
										["c_max"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.002095,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["end_time"] = 1593185231,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1593185223,
							["serial"] = "Player-4920-01D0BF72",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.008851,
							["damage_from"] = {
								["花姐"] = true,
								["刺骨利刃"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008851,
							["classe"] = "UNGROUPPLAYER",
							["dps_started"] = false,
							["total"] = 0.008851,
							["delay"] = 0,
							["friendlyfire"] = {
							},
							["nome"] = "迷行",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1321.008851,
							["end_time"] = 1593185231,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1593185231,
							["serial"] = "Player-4920-021E226D",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 7,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 7,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["activedamt"] = -1,
										["id"] = "偷袭",
										["targets"] = {
										},
										["actived_at"] = 1593185225,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["疾跑"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "疾跑",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 0,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["邪恶攻击"] = 1,
								["刺骨"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1593185231,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["buff_uptime"] = 8,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 7,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
				},
				["tempo_start"] = 1593185223,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					931.857614, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = -0.00252100000000155,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "23:27:12",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "迷行",
				["TotalElapsedCombatTime"] = 107912.076,
				["CombatEndedAt"] = 107912.076,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["花姐"] = 932.002095,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 107912.076,
				["combat_id"] = 7,
				["data_inicio"] = "23:27:04",
				["TimeData"] = {
				},
				["frags"] = {
					["迷行"] = 1,
				},
				["overall_added"] = true,
				["combat_counter"] = 178,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					932, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 107904.139,
				["contra"] = "迷行",
				["spells_cast_timeline"] = {
				},
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00483,
							["damage_from"] = {
								["花姐"] = true,
							},
							["targets"] = {
								["随风義"] = 3966,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["tipo"] = 1,
							["friendlyfire_total"] = 1,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3966.00483,
							["serial"] = "Player-4920-01D0BF72",
							["fight_component"] = true,
							["total"] = 3966.00483,
							["on_hold"] = false,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 1,
									},
									["total"] = 1,
								},
							},
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 425,
										["targets"] = {
											["随风義"] = 425,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 425,
										["n_min"] = 425,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 425,
										["c_max"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["速效毒药 VI"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 123,
										["targets"] = {
											["随风義"] = 513,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 513,
										["n_min"] = 67,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 513,
										["c_max"] = 0,
										["id"] = "速效毒药 VI",
										["r_dmg"] = 67,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_amt"] = 0,
										["r_amt"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 9,
										["b_amt"] = 0,
										["c_dmg"] = 1911,
										["g_amt"] = 0,
										["n_max"] = 161,
										["targets"] = {
											["随风義"] = 2353,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 442,
										["n_min"] = 66,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 2353,
										["c_max"] = 319,
										["MISS"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["c_min"] = 129,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 174,
										["targets"] = {
											["随风義"] = 675,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 675,
										["n_min"] = 163,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 675,
										["c_max"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1593183664,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593183657,
							["damage_taken"] = 1.00483,
							["start_time"] = 1593183646,
							["delay"] = 0,
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.004891,
							["damage_from"] = {
								["花姐"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004891,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.004891,
							["serial"] = "Player-4920-0278CD0C",
							["damage_taken"] = 3966.004891,
							["nome"] = "随风義",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1593183664,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1593183664,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 6,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["received"] = 50.001399,
							["resource"] = 0.001399,
							["targets"] = {
								["花姐"] = 50,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 0.001399,
							["fight_component"] = true,
							["total"] = 50.001399,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 50,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 50,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["flag_original"] = 1297,
							["last_event"] = 1593183657,
							["alternatepower"] = 0.001399,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.001399,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 6,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["activedamt"] = -1,
										["id"] = "偷袭",
										["targets"] = {
										},
										["actived_at"] = 1593183649,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["肾击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 4,
										["id"] = "肾击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 13,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["冲动"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 13,
										["id"] = "冲动",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 4,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["肾击"] = 1,
								["刺骨"] = 2,
								["冲动"] = 1,
								["邪恶攻击"] = 4,
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593183664,
							["nome"] = "花姐",
							["tipo"] = 4,
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 6,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
				},
				["CombatStartedAt"] = 107904.003,
				["tempo_start"] = 1593183646,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					3965.982079, -- [1]
					-0.003815, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 50,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "23:01:05",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "随风義",
				["TotalElapsedCombatTime"] = 106345.489,
				["CombatEndedAt"] = 106345.489,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["花姐"] = 3966.00483,
						}, -- [1]
					},
				},
				["end_time"] = 106345.489,
				["combat_id"] = 6,
				["spells_cast_timeline"] = {
				},
				["contra"] = "随风義",
				["frags"] = {
					["随风義"] = 1,
				},
				["combat_counter"] = 176,
				["data_inicio"] = "23:00:47",
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					3967, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 50,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 106327.058,
				["TimeData"] = {
				},
				["overall_added"] = true,
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004512,
							["damage_from"] = {
							},
							["targets"] = {
								["驚蟄"] = 2269,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2269.004512,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 2269.004512,
							["serial"] = "Player-4920-01D0BF72",
							["end_time"] = 1593183632,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 932,
										["g_amt"] = 0,
										["n_max"] = 246,
										["targets"] = {
											["驚蟄"] = 1635,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 703,
										["n_min"] = 106,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 1635,
										["c_max"] = 481,
										["IMMUNE"] = 7,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["c_min"] = 205,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["肾击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["驚蟄"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["IMMUNE"] = 1,
										["id"] = "肾击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["c_min"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["速效毒药 VI"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 127,
										["targets"] = {
											["驚蟄"] = 127,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 127,
										["n_min"] = 127,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 127,
										["c_max"] = 0,
										["id"] = "速效毒药 VI",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 220,
										["targets"] = {
											["驚蟄"] = 220,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 220,
										["n_min"] = 220,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 220,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 287,
										["targets"] = {
											["驚蟄"] = 287,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 287,
										["n_min"] = 287,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 287,
										["c_max"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593183625,
							["damage_taken"] = 0.004512,
							["start_time"] = 1593183612,
							["delay"] = 0,
							["classe"] = "ROGUE",
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.003697,
							["damage_from"] = {
								["花姐"] = true,
								["血尸陈酿"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003697,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.003697,
							["serial"] = "Player-4920-01D891D8",
							["damage_taken"] = 2812.003697,
							["nome"] = "驚蟄",
							["spells"] = {
								["_ActorTable"] = {
									["圣佑术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "圣佑术",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1593183632,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1593183632,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 5,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 5,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 5,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["activedamt"] = -1,
										["id"] = "偷袭",
										["targets"] = {
										},
										["actived_at"] = 1593183616,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 13,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["疾跑"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 13,
										["id"] = "疾跑",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 0,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["肾击"] = 1,
								["邪恶攻击"] = 1,
							},
							["nome"] = "花姐",
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593183625,
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 66888,
							["fight_component"] = true,
							["nome"] = "驚蟄",
							["enemy"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								["圣佑术"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 0,
							["serial"] = "Player-4920-01D891D8",
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 5,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
				},
				["CombatStartedAt"] = 106326.891,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					2268.998294, -- [1]
					-0.002211, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					2269, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "23:00:33",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "驚蟄",
				["TotalElapsedCombatTime"] = 106313.095,
				["CombatEndedAt"] = 106313.095,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "23:00:13",
				["end_time"] = 106313.095,
				["combat_id"] = 5,
				["frags"] = {
					["驚蟄"] = 1,
				},
				["contra"] = "驚蟄",
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 175,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["花姐"] = 2269.004512,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 106293.747,
				["TimeData"] = {
				},
				["tempo_start"] = 1593183612,
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002703,
							["damage_from"] = {
							},
							["targets"] = {
								["小美女王"] = 993,
							},
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 993.002703,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 993.002703,
							["serial"] = "Player-4920-01D0BF72",
							["end_time"] = 1593183425,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["速效毒药 VI"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 142,
										["targets"] = {
											["小美女王"] = 271,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 271,
										["n_min"] = 129,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 271,
										["c_max"] = 0,
										["id"] = "速效毒药 VI",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 263,
										["targets"] = {
											["小美女王"] = 394,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 394,
										["n_min"] = 131,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 394,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 328,
										["targets"] = {
											["小美女王"] = 328,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 328,
										["n_min"] = 328,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 328,
										["c_max"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["tipo"] = 1,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593183420,
							["damage_taken"] = 0.002703,
							["start_time"] = 1593183419,
							["delay"] = 0,
							["classe"] = "ROGUE",
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.002788,
							["damage_from"] = {
								["花姐"] = true,
								["怀旧恶魔"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002788,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.002788,
							["serial"] = "Player-4920-0205B410",
							["damage_taken"] = 1808.002788,
							["nome"] = "小美女王",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1593183425,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1593183425,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 4,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 4,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 4,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime"] = 0,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["activedamt"] = -1,
										["id"] = "偷袭",
										["targets"] = {
										},
										["actived_at"] = 1593183421,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "花姐",
							["grupo"] = true,
							["pets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1593183421,
							["classe"] = "ROGUE",
							["spell_cast"] = {
								["邪恶攻击"] = 1,
							},
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 4,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
				},
				["CombatStartedAt"] = 106293.613,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					992.996427, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					993, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:57:06",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "小美女王",
				["TotalElapsedCombatTime"] = 106106.493,
				["CombatEndedAt"] = 106106.493,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:57:00",
				["end_time"] = 106106.493,
				["combat_id"] = 4,
				["frags"] = {
					["小美女王"] = 1,
				},
				["contra"] = "小美女王",
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 174,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["花姐"] = 993.002703,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 106100.392,
				["TimeData"] = {
				},
				["tempo_start"] = 1593183419,
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006327,
							["damage_from"] = {
								["花姐"] = true,
							},
							["targets"] = {
								["马马嘟嘟骑"] = 6869,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["spec"] = 260,
							["friendlyfire_total"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6869.006327,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 1,
									},
									["total"] = 1,
								},
							},
							["fight_component"] = true,
							["total"] = 6869.006327,
							["on_hold"] = false,
							["last_event"] = 1593183321,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["闪电攻击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 360,
										["g_amt"] = 0,
										["n_max"] = 207,
										["targets"] = {
											["马马嘟嘟骑"] = 567,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 207,
										["n_min"] = 207,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 567,
										["c_max"] = 360,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 360,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["速效毒药 VI"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 141,
										["targets"] = {
											["马马嘟嘟骑"] = 560,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 560,
										["n_min"] = 88,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 560,
										["c_max"] = 0,
										["id"] = "速效毒药 VI",
										["r_dmg"] = 284,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_amt"] = 0,
										["r_amt"] = 3,
									},
									["!Melee"] = {
										["c_amt"] = 7,
										["b_amt"] = 0,
										["c_dmg"] = 2190,
										["g_amt"] = 0,
										["n_max"] = 239,
										["targets"] = {
											["马马嘟嘟骑"] = 3585,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1395,
										["n_min"] = 111,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 3585,
										["c_max"] = 468,
										["MISS"] = 4,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["c_min"] = 243,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 750,
										["g_amt"] = 0,
										["n_max"] = 292,
										["targets"] = {
											["马马嘟嘟骑"] = 2157,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1407,
										["n_min"] = 272,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2157,
										["c_max"] = 750,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 750,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["dps_started"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1.006327,
							["start_time"] = 1593183298,
							["delay"] = 0,
							["end_time"] = 1593183326,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.004069,
							["damage_from"] = {
								["花姐"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004069,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.004069,
							["serial"] = "Player-4920-01D7E2FF",
							["damage_taken"] = 6869.004069,
							["nome"] = "马马嘟嘟骑",
							["spells"] = {
								["_ActorTable"] = {
									["回春术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "回春术",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
									},
									["精灵之火"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "精灵之火",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
									},
									["愈合"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "愈合",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1593183326,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1593183326,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["activedamt"] = -1,
										["id"] = "偷袭",
										["targets"] = {
										},
										["actived_at"] = 1593183303,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["肾击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 4,
										["id"] = "肾击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 23,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["冲动"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "冲动",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["剑刃乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "剑刃乱舞",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["fight_component"] = true,
							["debuff_uptime"] = 4,
							["debuff_uptime_targets"] = {
							},
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["肾击"] = 1,
								["剑刃乱舞"] = 1,
								["冲动"] = 1,
								["邪恶攻击"] = 6,
							},
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1593183326,
							["nome"] = "花姐",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["fight_component"] = true,
							["nome"] = "马马嘟嘟骑",
							["enemy"] = true,
							["pets"] = {
							},
							["spell_cast"] = {
								["回春术"] = 2,
								["精灵之火"] = 1,
								["愈合"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 0,
							["serial"] = "Player-4920-01D7E2FF",
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 3,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
				},
				["CombatStartedAt"] = 106100.392,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					6869, -- [1]
					-0.018302, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					6870, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:55:27",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "马马嘟嘟骑",
				["TotalElapsedCombatTime"] = 106007.348,
				["CombatEndedAt"] = 106007.348,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:54:59",
				["end_time"] = 106007.348,
				["combat_id"] = 3,
				["frags"] = {
					["马马嘟嘟骑"] = 1,
				},
				["contra"] = "马马嘟嘟骑",
				["spells_cast_timeline"] = {
				},
				["combat_counter"] = 173,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["花姐"] = 6869.006327,
						}, -- [1]
					},
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 105979.723,
				["TimeData"] = {
				},
				["tempo_start"] = 1593183298,
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003944,
							["damage_from"] = {
								["花姐"] = true,
								["忧郁的小萱萱"] = true,
							},
							["targets"] = {
								["忧郁的小萱萱"] = 2034,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["spec"] = 260,
							["friendlyfire_total"] = 2,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2034.003944,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 2,
									},
									["total"] = 2,
								},
							},
							["fight_component"] = true,
							["total"] = 2034.003944,
							["on_hold"] = false,
							["last_event"] = 1593183141,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["忧郁的小萱萱"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 2,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["c_min"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["速效毒药 VI"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 133,
										["targets"] = {
											["忧郁的小萱萱"] = 133,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 133,
										["n_min"] = 133,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 133,
										["c_max"] = 0,
										["id"] = "速效毒药 VI",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 889,
										["g_amt"] = 0,
										["n_max"] = 106,
										["targets"] = {
											["忧郁的小萱萱"] = 1416,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 527,
										["DODGE"] = 1,
										["a_amt"] = 0,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 17,
										["r_amt"] = 0,
										["total"] = 1416,
										["c_max"] = 234,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["m_amt"] = 0,
										["BLOCK"] = 2,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 99,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 6,
										["MISS"] = 2,
										["b_dmg"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 336,
										["g_amt"] = 0,
										["n_max"] = 149,
										["targets"] = {
											["忧郁的小萱萱"] = 485,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 149,
										["n_min"] = 149,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 485,
										["c_max"] = 336,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 336,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["dps_started"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 124.003944,
							["start_time"] = 1593183127,
							["delay"] = 0,
							["end_time"] = 1593183148,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.007179,
							["damage_from"] = {
								["怀旧恶魔狗狗"] = true,
								["风霜烟沐"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["花姐"] = 122,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 122.007179,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 122.007179,
							["serial"] = "Player-4920-01D5381C",
							["damage_taken"] = 6062.007179,
							["nome"] = "忧郁的小萱萱",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 122,
										["targets"] = {
											["花姐"] = 122,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 122,
										["n_min"] = 122,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 122,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1593183148,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1593183139,
							["friendlyfire"] = {
							},
							["start_time"] = 1593183139,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["received"] = 2.003796,
							["resource"] = 0.003796,
							["targets"] = {
								["忧郁的小萱萱"] = 2,
							},
							["enemy"] = true,
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "UNGROUPPLAYER",
							["passiveover"] = 0.003796,
							["fight_component"] = true,
							["total"] = 2.003796,
							["nome"] = "忧郁的小萱萱",
							["spells"] = {
								["_ActorTable"] = {
									["盾牌专精"] = {
										["total"] = 2,
										["id"] = "盾牌专精",
										["totalover"] = 0,
										["targets"] = {
											["忧郁的小萱萱"] = 2,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["flag_original"] = 66888,
							["last_event"] = 1593183142,
							["alternatepower"] = 0.003796,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D5381C",
							["totalover"] = 0.003796,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime"] = 8,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 4,
										["id"] = "偷袭",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["肾击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 4,
										["id"] = "肾击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["偷袭"] = 1,
								["刺骨"] = 2,
								["肾击"] = 1,
								["邪恶攻击"] = 2,
							},
							["last_event"] = 1593183136,
							["debuff_uptime_targets"] = {
							},
							["classe"] = "ROGUE",
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
				},
				["CombatStartedAt"] = 105979.723,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 172,
				["playing_solo"] = true,
				["totals"] = {
					2155.985348, -- [1]
					0, -- [2]
					{
						2, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					2036, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:52:29",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "忧郁的小萱萱",
				["TotalElapsedCombatTime"] = 20.25,
				["CombatEndedAt"] = 105829.249,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["花姐"] = 2034.003944,
						}, -- [1]
					},
				},
				["end_time"] = 105829.249,
				["combat_id"] = 2,
				["data_inicio"] = "22:52:08",
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1593183127,
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 105808.667,
				["TimeData"] = {
				},
				["frags"] = {
					["忧郁的小萱萱"] = 1,
				},
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004615,
							["damage_from"] = {
								["花姐"] = true,
							},
							["targets"] = {
								["马马嘟嘟骑"] = 2307,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["spec"] = 260,
							["friendlyfire_total"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2307.004615,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 1,
									},
									["total"] = 1,
								},
							},
							["fight_component"] = true,
							["total"] = 2307.004615,
							["on_hold"] = false,
							["last_event"] = 1593183101,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 676,
										["g_amt"] = 0,
										["n_max"] = 249,
										["targets"] = {
											["马马嘟嘟骑"] = 1379,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 703,
										["n_min"] = 99,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 1379,
										["c_max"] = 459,
										["MISS"] = 2,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["c_min"] = 217,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["速效毒药 VI"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 110,
										["targets"] = {
											["马马嘟嘟骑"] = 110,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 110,
										["n_min"] = 110,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 110,
										["c_max"] = 0,
										["id"] = "速效毒药 VI",
										["r_dmg"] = 110,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 1,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 284,
										["targets"] = {
											["马马嘟嘟骑"] = 538,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 538,
										["n_min"] = 254,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 538,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 280,
										["targets"] = {
											["马马嘟嘟骑"] = 280,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 280,
										["n_min"] = 280,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 280,
										["c_max"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["dps_started"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1.004615,
							["start_time"] = 1593183095,
							["delay"] = 0,
							["end_time"] = 1593183106,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.007981,
							["damage_from"] = {
								["怀旧恶魔狗狗"] = true,
								["花姐"] = true,
								["风霜烟沐"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007981,
							["fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.007981,
							["serial"] = "Player-4920-01D7E2FF",
							["damage_taken"] = 3898.007981,
							["nome"] = "马马嘟嘟骑",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["on_hold"] = false,
							["end_time"] = 1593183106,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1593183106,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 1,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime"] = 3,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["activedamt"] = -1,
										["id"] = "偷袭",
										["targets"] = {
										},
										["actived_at"] = 1593183098,
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["肾击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 3,
										["id"] = "肾击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["pets"] = {
							},
							["fight_component"] = true,
							["spell_cast"] = {
								["肾击"] = 1,
								["邪恶攻击"] = 1,
							},
							["last_event"] = 1593183101,
							["debuff_uptime_targets"] = {
							},
							["classe"] = "ROGUE",
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 1,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
				},
				["tempo_start"] = 1593183095,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 171,
				["playing_solo"] = true,
				["totals"] = {
					2306.993323, -- [1]
					-0.008829, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:51:46",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "马马嘟嘟骑",
				["TotalElapsedCombatTime"] = 105786.765,
				["CombatEndedAt"] = 105786.765,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:51:36",
				["end_time"] = 105786.765,
				["combat_id"] = 1,
				["spells_cast_timeline"] = {
				},
				["contra"] = "马马嘟嘟骑",
				["frags"] = {
					["马马嘟嘟骑"] = 1,
				},
				["overall_added"] = true,
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					2308, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["start_time"] = 105775.989,
				["TimeData"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage"] = {
						{
							["花姐"] = 2307.004615,
						}, -- [1]
					},
				},
			}, -- [7]
		},
	},
	["last_version"] = "v1.13.4.209",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["nextreset"] = 1595080681,
		["last_version"] = 11,
	},
	["last_instance_id"] = 409,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 1592567850,
	["active_profile"] = "潇潇-龙牙",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = false,
			["useclasscolors"] = false,
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["openedfromcommand"] = false,
			["updatespeed"] = 0.2,
			["dividebyhundred"] = true,
			["showamount"] = false,
			["useplayercolor"] = true,
			["author"] = "Details! Team",
		},
	},
	["cached_talents"] = {
		["Player-4920-01D0BF72"] = {
			{
				132292, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [1]
			{
				132151, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [2]
			{
				132277, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [3]
			{
				132122, -- [1]
				3, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [4]
			{
				136147, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [5]
			{
				132306, -- [1]
				3, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [6]
			{
				132340, -- [1]
				1, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [7]
			{
				132354, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [8]
			{
				132109, -- [1]
				5, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [9]
			{
				132293, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [10]
			{
				132273, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [11]
			{
				135988, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [12]
			{
				132298, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [13]
			{
				136130, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136023, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [15]
			{
				132155, -- [1]
				3, -- [2]
				1, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [16]
			{
				136189, -- [1]
				2, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [17]
			{
				136047, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [18]
			{
				132090, -- [1]
				1, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [19]
			{
				132269, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [20]
			{
				132222, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [21]
			{
				136205, -- [1]
				2, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [22]
			{
				132336, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [23]
			{
				132307, -- [1]
				2, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [24]
			{
				132219, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [25]
			{
				135641, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [26]
			{
				132147, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [27]
			{
				133476, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [28]
			{
				132350, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [29]
			{
				135328, -- [1]
				5, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [30]
			{
				132938, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [31]
			{
				135882, -- [1]
				2, -- [2]
				6, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [32]
			{
				132275, -- [1]
				3, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [33]
			{
				136206, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [34]
			{
				136129, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [35]
			{
				132366, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [36]
			{
				132294, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [37]
			{
				135994, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [38]
			{
				132320, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [39]
			{
				136159, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [40]
			{
				136136, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [41]
			{
				132282, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [42]
			{
				136056, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [43]
			{
				132310, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [44]
			{
				135315, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [45]
			{
				132089, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [46]
			{
				136121, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [47]
			{
				136220, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [48]
			{
				136168, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [49]
			{
				135540, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [50]
			{
				136183, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [51]
		},
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["last_day"] = "09",
	["last_encounter"] = "熔岩爆发",
	["last_realversion"] = 142,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_id"] = 7,
	["savedStyles"] = {
	},
	["combat_counter"] = 185,
	["force_font_outline"] = "",
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.037144,
					["damage_from"] = {
						["花姐"] = true,
						["忧郁的小萱萱"] = true,
					},
					["targets"] = {
						["马马嘟嘟骑"] = 9176,
						["迷行"] = 932,
						["随风義"] = 3966,
						["小美女王"] = 993,
						["忧郁的小萱萱"] = 2034,
						["驚蟄"] = 2269,
					},
					["serial"] = "Player-4920-01D0BF72",
					["pets"] = {
					},
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 27,
								["b_amt"] = 0,
								["c_dmg"] = 6799,
								["g_amt"] = 0,
								["n_max"] = 263,
								["targets"] = {
									["马马嘟嘟骑"] = 4964,
									["迷行"] = 695,
									["随风義"] = 2353,
									["小美女王"] = 394,
									["忧郁的小萱萱"] = 1416,
									["驚蟄"] = 1635,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4658,
								["IMMUNE"] = 7,
								["a_amt"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 78,
								["r_amt"] = 0,
								["total"] = 11457,
								["c_max"] = 481,
								["MISS"] = 9,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["m_amt"] = 0,
								["BLOCK"] = 2,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 31,
								["b_dmg"] = 0,
								["DODGE"] = 1,
							},
							["刺骨"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 425,
								["targets"] = {
									["随风義"] = 425,
									["忧郁的小萱萱"] = 0,
									["迷行"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 425,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 425,
								["c_max"] = 0,
								["id"] = "刺骨",
								["r_dmg"] = 0,
								["DODGE"] = 3,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["肾击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["驚蟄"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "肾击",
								["r_dmg"] = 0,
								["IMMUNE"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["速效毒药 VI"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 142,
								["targets"] = {
									["马马嘟嘟骑"] = 670,
									["随风義"] = 513,
									["小美女王"] = 271,
									["忧郁的小萱萱"] = 133,
									["驚蟄"] = 127,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1714,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 15,
								["total"] = 1714,
								["c_max"] = 0,
								["id"] = "速效毒药 VI",
								["r_dmg"] = 461,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 15,
								["c_min"] = 0,
								["r_amt"] = 5,
							},
							["闪电攻击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 360,
								["g_amt"] = 0,
								["n_max"] = 284,
								["targets"] = {
									["马马嘟嘟骑"] = 1105,
									["驚蟄"] = 220,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 965,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1325,
								["c_max"] = 360,
								["id"] = "闪电攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 4,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["邪恶攻击"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1086,
								["g_amt"] = 0,
								["n_max"] = 328,
								["targets"] = {
									["马马嘟嘟骑"] = 2437,
									["迷行"] = 237,
									["随风義"] = 675,
									["小美女王"] = 328,
									["忧郁的小萱萱"] = 485,
									["驚蟄"] = 287,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3363,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 4449,
								["c_max"] = 750,
								["id"] = "邪恶攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 14,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 5,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 19370.037144,
					["friendlyfire"] = {
						["花姐"] = {
							["spells"] = {
								["剑类武器专精"] = 0,
							},
							["total"] = 5,
						},
					},
					["dps_started"] = false,
					["total"] = 19370.037144,
					["damage_taken"] = 127.037144,
					["last_event"] = 0,
					["nome"] = "花姐",
					["spec"] = 260,
					["grupo"] = true,
					["end_time"] = 1593183106,
					["last_dps"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1593182991,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [1]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.014251,
					["damage_from"] = {
						["怀旧恶魔狗狗"] = true,
						["花姐"] = true,
						["风霜烟沐"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.014251,
					["end_time"] = 1593183106,
					["fight_component"] = true,
					["total"] = 0.014251,
					["serial"] = "Player-4920-01D7E2FF",
					["last_dps"] = 0,
					["nome"] = "马马嘟嘟骑",
					["spells"] = {
						["_ActorTable"] = {
							["回春术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "回春术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["愈合"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "愈合",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["精灵之火"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "精灵之火",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 10767.014251,
					["start_time"] = 1593183103,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [2]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.009687,
					["damage_from"] = {
						["怀旧恶魔狗狗"] = true,
						["风霜烟沐"] = true,
						["花姐"] = true,
					},
					["targets"] = {
						["花姐"] = 122,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 122.009687,
					["end_time"] = 1593183149,
					["fight_component"] = true,
					["total"] = 122.009687,
					["serial"] = "Player-4920-01D5381C",
					["last_dps"] = 0,
					["nome"] = "忧郁的小萱萱",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 122,
								["targets"] = {
									["花姐"] = 122,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 122,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 122,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 6062.009687,
					["start_time"] = 1593183137,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [3]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.008738,
					["damage_from"] = {
						["花姐"] = true,
						["怀旧恶魔"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008738,
					["end_time"] = 1593183426,
					["fight_component"] = true,
					["total"] = 0.008738,
					["serial"] = "Player-4920-0205B410",
					["last_dps"] = 0,
					["nome"] = "小美女王",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 1808.008738,
					["start_time"] = 1593183423,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [4]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.009,
					["damage_from"] = {
						["花姐"] = true,
						["血尸陈酿"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.009,
					["end_time"] = 1593183633,
					["fight_component"] = true,
					["total"] = 0.009,
					["serial"] = "Player-4920-01D891D8",
					["last_dps"] = 0,
					["nome"] = "驚蟄",
					["spells"] = {
						["_ActorTable"] = {
							["圣佑术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "圣佑术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 2812.009,
					["start_time"] = 1593183630,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [5]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.012324,
					["damage_from"] = {
						["花姐"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.012324,
					["end_time"] = 1593183665,
					["fight_component"] = true,
					["total"] = 0.012324,
					["serial"] = "Player-4920-0278CD0C",
					["last_dps"] = 0,
					["nome"] = "随风義",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 3966.012324,
					["start_time"] = 1593183662,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [6]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.01637,
					["damage_from"] = {
						["花姐"] = true,
						["刺骨利刃"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.01637,
					["fight_component"] = true,
					["dps_started"] = false,
					["total"] = 0.01637,
					["delay"] = 0,
					["damage_taken"] = 1321.01637,
					["nome"] = "迷行",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1593185229,
					["serial"] = "Player-4920-021E226D",
					["end_time"] = 1593185232,
				}, -- [7]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 2.011929,
					["resource"] = 0.042297,
					["targets"] = {
						["忧郁的小萱萱"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.008133,
					["fight_component"] = true,
					["total"] = 2.011929,
					["nome"] = "忧郁的小萱萱",
					["spells"] = {
						["_ActorTable"] = {
							["盾牌专精"] = {
								["total"] = 2,
								["id"] = "盾牌专精",
								["totalover"] = 0,
								["targets"] = {
									["忧郁的小萱萱"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["totalover"] = 0.008133,
					["tipo"] = 3,
					["alternatepower"] = 0.011929,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D5381C",
					["flag_original"] = 66888,
				}, -- [1]
				{
					["received"] = 50.004883,
					["resource"] = 0.016075,
					["targets"] = {
						["花姐"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["classe"] = "ROGUE",
					["passiveover"] = 0.003484,
					["fight_component"] = true,
					["total"] = 50.004883,
					["nome"] = "花姐",
					["spells"] = {
						["_ActorTable"] = {
							["无情打击效果"] = {
								["total"] = 50,
								["id"] = "无情打击效果",
								["totalover"] = 0,
								["targets"] = {
									["花姐"] = 0,
								},
								["counter"] = 2,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["totalover"] = 0.003484,
					["tipo"] = 3,
					["alternatepower"] = 0.004883,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D0BF72",
					["flag_original"] = 1297,
				}, -- [2]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["偷袭"] = {
								["refreshamt"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = -6,
								["uptime"] = 4,
								["id"] = "偷袭",
								["actived_at"] = 9559102312,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["肾击"] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = "肾击",
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "ROGUE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["剑刃乱舞"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "剑刃乱舞",
								["uptime"] = 8,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冲动"] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "冲动",
								["uptime"] = 28,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["疾跑"] = {
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["appliedamt"] = 2,
								["id"] = "疾跑",
								["uptime"] = 21,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 19,
					["nome"] = "花姐",
					["spec"] = 260,
					["grupo"] = true,
					["spell_cast"] = {
						["剑刃乱舞"] = 1,
						["冲动"] = 2,
						["偷袭"] = 1,
						["刺骨"] = 5,
						["肾击"] = 5,
						["邪恶攻击"] = 16,
					},
					["buff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["buff_uptime"] = 57,
					["debuff_uptime_targets"] = {
					},
					["serial"] = "Player-4920-01D0BF72",
					["tipo"] = 4,
				}, -- [1]
				{
					["fight_component"] = true,
					["pets"] = {
					},
					["nome"] = "马马嘟嘟骑",
					["enemy"] = true,
					["spell_cast"] = {
						["回春术"] = 2,
						["愈合"] = 1,
						["精灵之火"] = 1,
					},
					["flag_original"] = 66888,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-01D7E2FF",
					["classe"] = "UNGROUPPLAYER",
				}, -- [2]
				{
					["fight_component"] = true,
					["pets"] = {
					},
					["nome"] = "驚蟄",
					["enemy"] = true,
					["spell_cast"] = {
						["圣佑术"] = 1,
					},
					["flag_original"] = 66888,
					["last_event"] = 0,
					["tipo"] = 4,
					["serial"] = "Player-4920-01D891D8",
					["classe"] = "UNGROUPPLAYER",
				}, -- [3]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1593183095,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["spells_cast_timeline"] = {
		},
		["combat_counter"] = 170,
		["totals"] = {
			20850.057863, -- [1]
			-0.009217, -- [2]
			{
				2.003796, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 50.001399,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "22:51:36",
		["end_time"] = 107912.076,
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			19370.029026, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 50.001399,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["frags"] = {
		},
		["hasSaved"] = true,
		["segments_added"] = {
			{
				["elapsed"] = 7.93700000000536,
				["type"] = 0,
				["name"] = "迷行",
				["clock"] = "23:27:04",
			}, -- [1]
			{
				["elapsed"] = 18.4309999999969,
				["type"] = 0,
				["name"] = "随风義",
				["clock"] = "23:00:47",
			}, -- [2]
			{
				["elapsed"] = 19.3479999999981,
				["type"] = 0,
				["name"] = "驚蟄",
				["clock"] = "23:00:13",
			}, -- [3]
			{
				["elapsed"] = 6.10099999999511,
				["type"] = 0,
				["name"] = "小美女王",
				["clock"] = "22:57:00",
			}, -- [4]
			{
				["elapsed"] = 27.625,
				["type"] = 0,
				["name"] = "马马嘟嘟骑",
				["clock"] = "22:54:59",
			}, -- [5]
			{
				["elapsed"] = 20.5819999999949,
				["type"] = 0,
				["name"] = "忧郁的小萱萱",
				["clock"] = "22:52:08",
			}, -- [6]
			{
				["elapsed"] = 10.775999999998,
				["type"] = 0,
				["name"] = "马马嘟嘟骑",
				["clock"] = "22:51:36",
			}, -- [7]
		},
		["data_fim"] = "23:27:12",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["start_time"] = 107801.276,
		["TimeData"] = {
		},
		["cleu_timeline"] = {
		},
	},
	["local_instances_config"] = {
		{
			["segment"] = -1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -349.866226196289,
					["x"] = 751.715698242188,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -171.866271972656,
					["x"] = 751.715698242188,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["character_data"] = {
		["logons"] = 59,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-4920-01D0BF72"] = 260,
	},
}
