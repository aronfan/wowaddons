
ExAE_Config = {
	["花姐@Enigma"] = {
		{
			["Finger0Slot"] = {
				["name"] = "暗淡的精灵戒指",
				["link"] = "item:18500::::::::60:::1::::",
			},
			["BackSlot"] = {
				["name"] = "部族之力",
				["link"] = "item:22712::::::::60:::::::",
			},
			["Trinket0Slot"] = {
				["name"] = "黑手饰物",
				["link"] = "item:13965::::::::60:::11::::",
			},
			["TabardSlot"] = {
			},
			["FeetSlot"] = {
				["name"] = "迅捷皮靴",
				["link"] = "item:15861::::::::60:::11::::",
			},
			["NeckSlot"] = {
				["name"] = "奥妮克希亚龙牙坠饰",
				["link"] = "item:18404::::::::60:::11::::",
			},
			["Finger1Slot"] = {
				["name"] = "古拉巴什狂暴者徽记",
				["link"] = "item:22722::::::::60:::::::",
			},
			["ChestSlot"] = {
				["name"] = "夜幕杀手胸甲",
				["link"] = "item:16820::::::::60:::::::",
			},
			["Trinket1Slot"] = {
				["name"] = "暗月卡片：漩涡",
				["link"] = "item:19289::::::::60:::11::::",
			},
			["ShoulderSlot"] = {
				["name"] = "赞达拉狂妄者衬肩",
				["link"] = "item:19835::::::::60:::11::::",
			},
			["MainHandSlot"] = {
				["name"] = "塞卡尔之握",
				["link"] = "item:19896::::::::60:::::::",
			},
			["HandsSlot"] = {
				["name"] = "夜幕杀手手套",
				["link"] = "item:16826::::::::60:::::::",
			},
			["LegsSlot"] = {
				["name"] = "夜幕杀手短裤",
				["link"] = "item:16822::::::::60:::::::",
			},
			["ShirtSlot"] = {
				["name"] = "刺客衬衣",
				["link"] = "item:2105::::::::60:::::::",
			},
			["WaistSlot"] = {
				["name"] = "夜幕杀手腰带",
				["link"] = "item:16827::::::::60:::::::",
			},
			["WristSlot"] = {
				["name"] = "赞达拉狂妄者护腕",
				["link"] = "item:19836::::::::60:::11::::",
			},
			["HeadSlot"] = {
				["name"] = "血牙头巾",
				["link"] = "item:16908::::::::60:::::::",
			},
			["SecondaryHandSlot"] = {
				["name"] = "娅尔罗之握",
				["link"] = "item:19910::::::::60:::::::",
			},
			["RangedSlot"] = {
				["name"] = "觅心弩",
				["link"] = "item:13040:663:::::::60:::1::::",
			},
			["AmmoSlot"] = {
			},
		}, -- [1]
		["CurrentSetId"] = 1,
	},
}
