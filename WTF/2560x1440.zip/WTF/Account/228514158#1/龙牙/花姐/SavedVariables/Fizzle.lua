
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["花姐 - 龙牙"] = "花姐 - 龙牙",
	},
	["profiles"] = {
		["花姐 - 龙牙"] = {
		},
	},
}
