
NugEnergyDB_Character = {
	["marks"] = {
		{
		}, -- [1]
		{
		}, -- [2]
		{
		}, -- [3]
		{
		}, -- [4]
		[0] = {
		},
	},
}
