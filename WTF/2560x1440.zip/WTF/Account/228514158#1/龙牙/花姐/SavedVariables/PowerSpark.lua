
PowerSparkDB = {
	["default"] = {
		["timer"] = 782546.741,
	},
}
