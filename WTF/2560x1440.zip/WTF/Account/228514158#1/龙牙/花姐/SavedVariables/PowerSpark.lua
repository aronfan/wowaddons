
PowerSparkDB = {
	["default"] = {
		["timer"] = 270949.352,
	},
}
