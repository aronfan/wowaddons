
PowerSparkDB = {
	["default"] = {
		["timer"] = 1728346.63,
	},
}
