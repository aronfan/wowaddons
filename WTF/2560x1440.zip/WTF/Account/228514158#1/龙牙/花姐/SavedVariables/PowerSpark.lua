
PowerSparkDB = {
	["default"] = {
		["timer"] = 107916.096,
	},
}
