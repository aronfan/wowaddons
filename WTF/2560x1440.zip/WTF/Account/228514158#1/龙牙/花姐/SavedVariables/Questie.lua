
QuestieConfigCharacter = {
}
