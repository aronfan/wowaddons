
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1587266718,
			["items"] = {
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
