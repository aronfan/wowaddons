
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1592560562,
			["items"] = {
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 100,
					["costcache"] = 1000000,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16863::::::::60:::::::|h[力量护手]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16829::::::::60:::::::|h[塞纳里奥长靴]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 200,
					["costcache"] = 2000000,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19142::::::::60:::::::|h[火焰符文魔典]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16847::::::::60:::::::|h[巨人追猎者护腿]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16814::::::::60:::::::|h[预言短裤]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "刚哥",
					["type"] = "DEBIT",
					["costtype"] = "GOLD",
					["cost"] = 45,
					["costcache"] = 450000,
					["detail"] = {
						["displayname"] = "补助: 其他",
					},
				}, -- [6]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17011::::::::60:::::::|h[熔岩之核]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17010::::::::60:::::::|h[炽热之核]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16851::::::::60:::::::|h[巨人追猎者腰带]|h|r",
						["count"] = 1,
					},
				}, -- [9]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 1500,
					["costcache"] = 15000000,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19147::::::::60:::::::|h[法术能量之戒]|h|r",
						["count"] = 1,
					},
				}, -- [10]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16826::::::::60:::::::|h[夜幕杀手手套]|h|r",
						["count"] = 1,
					},
				}, -- [11]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17011::::::::60:::::::|h[熔岩之核]|h|r",
						["count"] = 1,
					},
				}, -- [12]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16834::::::::60:::::::|h[塞纳里奥头盔]|h|r",
						["count"] = 1,
					},
				}, -- [13]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 100,
					["costcache"] = 1000000,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18829::::::::60:::::::|h[地核护肩]|h|r",
						["count"] = 1,
					},
				}, -- [14]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17011::::::::60:::::::|h[熔岩之核]|h|r",
						["count"] = 1,
					},
				}, -- [15]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16808::::::::60:::::::|h[恶魔之心角饰]|h|r",
						["count"] = 1,
					},
				}, -- [16]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18257::::::::60:::::::|h[配方：特效活力药水]|h|r",
						["count"] = 1,
					},
				}, -- [17]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16825::::::::60:::::::|h[夜幕杀手护腕]|h|r",
						["count"] = 1,
					},
				}, -- [18]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16836::::::::60:::::::|h[塞纳里奥肩甲]|h|r",
						["count"] = 1,
					},
				}, -- [19]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17010::::::::60:::::::|h[炽热之核]|h|r",
						["count"] = 1,
					},
				}, -- [20]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16807::::::::60:::::::|h[恶魔之心护肩]|h|r",
						["count"] = 1,
					},
				}, -- [21]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16834::::::::60:::::::|h[塞纳里奥头盔]|h|r",
						["count"] = 1,
					},
				}, -- [22]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16836::::::::60:::::::|h[塞纳里奥肩甲]|h|r",
						["count"] = 1,
					},
				}, -- [23]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16826::::::::60:::::::|h[夜幕杀手手套]|h|r",
						["count"] = 1,
					},
				}, -- [24]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16814::::::::60:::::::|h[预言短裤]|h|r",
						["count"] = 1,
					},
				}, -- [25]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16847::::::::60:::::::|h[巨人追猎者护腿]|h|r",
						["count"] = 1,
					},
				}, -- [26]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16829::::::::60:::::::|h[塞纳里奥长靴]|h|r",
						["count"] = 1,
					},
				}, -- [27]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16811::::::::60:::::::|h[预言之靴]|h|r",
						["count"] = 1,
					},
				}, -- [28]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16801::::::::60:::::::|h[奥术师手套]|h|r",
						["count"] = 1,
					},
				}, -- [29]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17011::::::::60:::::::|h[熔岩之核]|h|r",
						["count"] = 1,
					},
				}, -- [30]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17010::::::::60:::::::|h[炽热之核]|h|r",
						["count"] = 1,
					},
				}, -- [31]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18878::::::::60:::::::|h[巫术匕首]|h|r",
						["count"] = 1,
					},
				}, -- [32]
				{
					["beneficiary"] = "刚哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16922::::::::60:::::::|h[卓越护腿]|h|r",
						["count"] = 1,
					},
				}, -- [33]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16833::::::::60:::::::|h[塞纳里奥胸甲]|h|r",
						["count"] = 1,
					},
				}, -- [34]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16815::::::::60:::::::|h[预言法袍]|h|r",
						["count"] = 1,
					},
				}, -- [35]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16930::::::::60:::::::|h[复仇护腿]|h|r",
						["count"] = 1,
					},
				}, -- [36]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18815::::::::60:::::::|h[纯焰精华]|h|r",
						["count"] = 1,
					},
				}, -- [37]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:17106::::::::60:::::::|h[玛利斯达尔防御者]|h|r",
						["count"] = 1,
					},
				}, -- [38]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18878::::::::60:::::::|h[巫术匕首]|h|r",
						["count"] = 1,
					},
				}, -- [39]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16811::::::::60:::::::|h[预言之靴]|h|r",
						["count"] = 1,
					},
				}, -- [40]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16801::::::::60:::::::|h[奥术师手套]|h|r",
						["count"] = 1,
					},
				}, -- [41]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16808::::::::60:::::::|h[恶魔之心角饰]|h|r",
						["count"] = 1,
					},
				}, -- [42]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18646::::::::60:::::::|h[神圣之眼]|h|r",
						["count"] = 1,
					},
				}, -- [43]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18257::::::::60:::::::|h[配方：特效活力药水]|h|r",
						["count"] = 1,
					},
				}, -- [44]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
