
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1590331368,
			["items"] = {
				{
					["beneficiary"] = "大漂靓",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:12930::::::::60:::1::::|h[石楠之环]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "大漂靓",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18102::::::::60:::1::::|h[龙骑兵长靴]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "奈罗",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:12927::::::::60:::1::::|h[强击护肩]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "郎表哥",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:12930::::::::60:::1::::|h[石楠之环]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:12940::::::::60:::1::::|h[雷德的神圣控诉者]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "无常十号",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18102::::::::60:::1::::|h[龙骑兵长靴]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "无常十号",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:12953::::::1366:1556566272:60:::1::::|h[冰霜抗性之龙眼头巾]|h|r",
						["count"] = 1,
					},
				}, -- [7]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
