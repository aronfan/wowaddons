
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1589892940,
			["items"] = {
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17010::::::::60:::::::|h[炽热之核]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16797::::::::60:::::::|h[奥术师衬肩]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16836::::::::60:::::::|h[塞纳里奥肩甲]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16831::::::::60:::::::|h[塞纳里奥手套]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19147::::::::60:::::::|h[法术能量之戒]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17010::::::::60:::::::|h[炽热之核]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16817::::::::60:::::::|h[预言束带]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16828::::::::60:::::::|h[塞纳里奥腰带]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17011::::::::60:::::::|h[熔岩之核]|h|r",
						["count"] = 1,
					},
				}, -- [9]
				{
					["beneficiary"] = "见人就冰环",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16817::::::::60:::::::|h[预言束带]|h|r",
						["count"] = 1,
					},
				}, -- [10]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
