
WBT_DMFData = {
	["Remaining"] = 0,
}
