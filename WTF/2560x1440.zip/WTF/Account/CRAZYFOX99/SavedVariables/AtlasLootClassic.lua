
AtlasLootClassicDB = {
	["global"] = {
		["__addonrevision"] = 1050001,
	},
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "涛哥 - 龙牙",
	},
	["profiles"] = {
		["涛哥 - 龙牙"] = {
			["minimap"] = {
				["minimapPos"] = 191.821178857138,
			},
			["GUI"] = {
				["selected"] = {
					nil, -- [1]
					"BlackrockDepths", -- [2]
					18, -- [3]
					1, -- [4]
					0, -- [5]
				},
			},
		},
	},
}
