
VendorDb = {
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "Default",
	},
	["currentProfile"] = {
		["涛哥 - 龙牙"] = "Default",
	},
	["namespaces"] = {
		["Disenchant"] = {
		},
		["Scanner2"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 8,
				},
			},
			["realm"] = {
				["龙牙"] = {
					["version"] = 8,
				},
			},
			["factionrealm"] = {
				["Horde - 龙牙"] = {
					["oldSnipesMigrated"] = true,
					["version"] = 8,
				},
			},
		},
		["Statistic"] = {
		},
		["SearchTab"] = {
		},
		["TooltipHook"] = {
		},
		["Seller"] = {
			["profiles"] = {
				["Default"] = {
					["buyoutMod"] = {
						nil, -- [1]
						{
							["percent"] = 150,
							["modType"] = 1,
						}, -- [2]
						{
							["percent"] = 100,
							["modType"] = 1,
						}, -- [3]
						{
							["percent"] = 99,
							["modType"] = 1,
						}, -- [4]
						{
							["percent"] = 250,
							["modType"] = 1,
						}, -- [5]
						{
							["percent"] = 99,
							["modType"] = 1,
						}, -- [6]
					},
					["version"] = 5,
				},
			},
		},
		["Items"] = {
			["realms"] = {
				["龙牙 - 部落"] = {
				},
			},
			["servers"] = {
				["龙牙"] = {
				},
			},
			["factionrealm"] = {
				["Horde - 龙牙"] = {
					["version"] = 6,
				},
			},
			["realm"] = {
				["龙牙"] = {
					["version"] = 6,
				},
			},
		},
		["OwnAuctions"] = {
			["profiles"] = {
				["Default"] = {
					["itemTableCfg"] = {
						["selected"] = {
							1, -- [1]
							2, -- [2]
							10, -- [3]
							4, -- [4]
							5, -- [5]
							6, -- [6]
							7, -- [7]
							8, -- [8]
						},
					},
				},
			},
		},
		["Gatherer"] = {
			["global"] = {
				["statisticDb"] = {
					["realms"] = {
						["龙牙"] = {
							["Horde"] = {
							},
						},
					},
				},
			},
		},
		["ItemSettings"] = {
			["realm"] = {
				["龙牙"] = {
					["version"] = 1,
				},
			},
			["factionrealm"] = {
				["Horde - 龙牙"] = {
					["version"] = 1,
				},
			},
		},
		["Sniper"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 3,
				},
			},
			["realms"] = {
				["龙牙 - 部落"] = {
				},
			},
			["factionrealm"] = {
				["Horde - 龙牙"] = {
					["version"] = 3,
				},
			},
		},
		["AuctionHouse"] = {
			["profiles"] = {
				["Default"] = {
					["startTab"] = 1,
					["version"] = 2,
				},
			},
		},
	},
	["global"] = {
		["locale"] = "zhCN",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
AuctionMasterMiscDb = {
}
