
BugGrabberDB = {
	["lastSanitation"] = 3,
	["session"] = 13,
	["errors"] = {
	},
}
