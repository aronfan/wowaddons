
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["char"] = {
				["涛哥 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
			},
			["global"] = {
				["version"] = 2,
			},
		},
	},
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "潜行者",
	},
	["global"] = {
		["configVersion"] = 1,
		["addonVersion"] = "8.3.1",
	},
	["profiles"] = {
		["潜行者"] = {
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 0,
					["pages"] = {
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 80,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 160,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 200,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["pages"] = {
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["point"] = "TOP",
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["lockMode"] = true,
					["hidden"] = true,
					["alwaysShowText"] = true,
					["y"] = 0,
					["font"] = "Friz Quadrata TT",
					["padW"] = 2,
					["spacing"] = 1,
					["padH"] = 2,
					["x"] = 0,
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "CENTER",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["pet"] = {
					["y"] = -32,
					["x"] = 0,
					["point"] = "CENTER",
					["spacing"] = 6,
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
					["showInOverrideUI"] = false,
				},
			},
			["minimap"] = {
				["minimapPos"] = 201.540205731662,
			},
		},
	},
}
