
EasyFramesDB = {
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["player"] = {
				["showNameInsideFrame"] = true,
				["playerNameFontSize"] = 12,
			},
			["target"] = {
				["showNameInsideFrame"] = true,
				["targetNameFontSize"] = 12,
				["healthFormat"] = "1",
			},
		},
	},
}
