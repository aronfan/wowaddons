
GatherMate2DB = {
	["global"] = {
		["data_version"] = 5,
	},
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
GatherMate2HerbDB = {
}
GatherMate2MineDB = {
}
GatherMate2FishDB = {
}
GatherMate2GasDB = nil
GatherMate2TreasureDB = {
}
GatherMate2ArchaeologyDB = nil
GatherMate2LoggingDB = nil
