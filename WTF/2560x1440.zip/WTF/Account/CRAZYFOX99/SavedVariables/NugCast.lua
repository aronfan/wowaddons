
NugCastDB = {
	["nameplateCastbars"] = false,
	["barTexture"] = "Flat",
	["castColor"] = {
		1, -- [1]
		0.858823529411765, -- [2]
		0.0627450980392157, -- [3]
	},
}
