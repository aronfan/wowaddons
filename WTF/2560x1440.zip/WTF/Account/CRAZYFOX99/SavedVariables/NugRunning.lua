
NRunDB_Global = {
	["nptextureName"] = "Flat",
	["anchors"] = {
		["main"] = {
			["y"] = -24.888952255249,
			["x"] = 248.889068603516,
		},
		["secondary"] = {
			["y"] = -19.2000198364258,
			["x"] = -318.755767822266,
		},
	},
	["charspec"] = {
	},
	["textureName"] = "Flat",
}
NugRunningConfigCustom = {
	["ROGUE"] = {
	},
}
