
Postal3ClassicDB = {
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"涛哥|龙牙|Horde|60|ROGUE", -- [1]
			},
		},
	},
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "涛哥 - 龙牙",
	},
	["profiles"] = {
		["涛哥 - 龙牙"] = {
		},
	},
}
