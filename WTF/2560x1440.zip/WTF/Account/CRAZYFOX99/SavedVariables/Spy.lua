
SpyDB = {
	["kosData"] = {
		["龙牙"] = {
			["Horde"] = {
				["涛哥"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["龙牙"] = {
			["Horde"] = {
			},
		},
	},
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "涛哥 - 龙牙",
	},
	["profiles"] = {
		["涛哥 - 龙牙"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 827.466796875,
					["x"] = 1644.53356933594,
					["w"] = 159.999954223633,
					["h"] = 35.0000152587891,
				},
			},
			["Colors"] = {
				["Alert"] = {
					["Stealth Text"] = {
						["a"] = 1,
					},
					["Name Text"] = {
						["a"] = 1,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitNameCheck"] = true,
			["AppendUnitKoSCheck"] = true,
		},
	},
}
