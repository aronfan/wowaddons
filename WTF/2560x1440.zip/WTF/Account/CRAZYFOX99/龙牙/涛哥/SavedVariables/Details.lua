
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["combatId"] = 42,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002986,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3596,
								["安格弗将军"] = 15864,
							},
							["total"] = 19460.002986,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19460.002986,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1592255977,
							["friendlyfire_total"] = 0,
							["spec"] = 261,
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 420,
										["targets"] = {
											["铁怒预备兵"] = 3596,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3596,
										["n_min"] = 77,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 3596,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 18,
										["b_amt"] = 1,
										["c_dmg"] = 4819,
										["g_amt"] = 0,
										["n_max"] = 223,
										["targets"] = {
											["安格弗将军"] = 9441,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4622,
										["n_min"] = 35,
										["g_dmg"] = 0,
										["counter"] = 57,
										["MISS"] = 3,
										["total"] = 9441,
										["c_max"] = 436,
										["DODGE"] = 2,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 35,
										["n_amt"] = 34,
										["r_amt"] = 0,
										["c_min"] = 149,
									},
									["出血"] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 418,
										["g_amt"] = 0,
										["n_max"] = 220,
										["targets"] = {
											["安格弗将军"] = 2598,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2180,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 2598,
										["c_max"] = 418,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 171,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 418,
									},
									["还击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 620,
										["g_amt"] = 0,
										["n_max"] = 309,
										["targets"] = {
											["安格弗将军"] = 1516,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 896,
										["n_min"] = 278,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1516,
										["c_max"] = 620,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 620,
									},
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1296,
										["g_amt"] = 0,
										["n_max"] = 634,
										["targets"] = {
											["安格弗将军"] = 1930,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 634,
										["n_min"] = 634,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1930,
										["c_max"] = 1296,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 1296,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 191,
										["targets"] = {
											["安格弗将军"] = 191,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 191,
										["n_min"] = 191,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 191,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 188,
										["targets"] = {
											["安格弗将军"] = 188,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 188,
										["n_min"] = 188,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 188,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0D553",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255974,
							["damage_taken"] = 4250.002986,
							["start_time"] = 1592255911,
							["delay"] = 1592255956,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001973,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 4153,
								["花姐"] = 2722,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6875.001973,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592255977,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "安格弗将军",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1079,
										["g_amt"] = 0,
										["n_max"] = 632,
										["targets"] = {
											["涛哥"] = 4153,
											["花姐"] = 2722,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5796,
										["MISS"] = 2,
										["n_min"] = 344,
										["g_dmg"] = 0,
										["counter"] = 46,
										["DODGE"] = 26,
										["total"] = 6875,
										["c_max"] = 1079,
										["a_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 5,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 12,
										["r_amt"] = 0,
										["c_min"] = 1079,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 8,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 6875.001973,
							["serial"] = "Creature-0-5002-230-2163-9033-000067E4C1",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255974,
							["damage_taken"] = 22405.001973,
							["start_time"] = 1592255927,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002386,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 97,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 97.002386,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592255977,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "铁怒预备兵",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 97,
										["targets"] = {
											["涛哥"] = 97,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 97,
										["n_min"] = 97,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 97,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["a_amt"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 21,
										["MISS"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 17,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["MISS"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 97.002386,
							["serial"] = "Creature-0-5002-230-2163-8901-000167E4C1",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255921,
							["damage_taken"] = 3596.002386,
							["start_time"] = 1592255961,
							["delay"] = 1592255921,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006394,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6541,
							},
							["total"] = 6541.006394,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6541.006394,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 4,
									},
									["total"] = 4,
								},
							},
							["dps_started"] = false,
							["end_time"] = 1592255977,
							["friendlyfire_total"] = 4,
							["spec"] = 260,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["割裂"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 127,
										["targets"] = {
											["安格弗将军"] = 508,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 508,
										["n_min"] = 127,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 508,
										["c_max"] = 0,
										["id"] = "割裂",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 278,
										["targets"] = {
											["安格弗将军"] = 539,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 539,
										["n_min"] = 261,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 539,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 9,
										["b_amt"] = 1,
										["c_dmg"] = 2321,
										["g_amt"] = 0,
										["n_max"] = 198,
										["targets"] = {
											["安格弗将军"] = 3869,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1548,
										["n_min"] = 76,
										["g_dmg"] = 0,
										["counter"] = 23,
										["a_amt"] = 0,
										["total"] = 3869,
										["c_max"] = 385,
										["MISS"] = 2,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 147,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 150,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 936,
										["g_amt"] = 0,
										["n_max"] = 233,
										["targets"] = {
											["安格弗将军"] = 1625,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 689,
										["n_min"] = 225,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1625,
										["c_max"] = 483,
										["a_amt"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 453,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0BF72",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255974,
							["damage_taken"] = 2726.006394,
							["start_time"] = 1592255953,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003671,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003671,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.003671,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-5002-230-2163-8894-0000E7E5CA",
							["nome"] = "铁怒医师",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 8,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1592255977,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.003671,
							["start_time"] = 1592255977,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [5]
					},
				}, -- [1]
				{
					["combatId"] = 42,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 0.007195,
							["total_without_pet"] = 2300.007195,
							["total"] = 2300.007195,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.007195,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2300,
							},
							["totalover_without_pet"] = 0.007195,
							["healing_taken"] = 2300.007195,
							["end_time"] = 1592255977,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
							},
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 2000,
										["n_amt"] = 8,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 6,
										["overheal"] = 0,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 300,
										["n_amt"] = 6,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1592255964,
							["custom"] = 0,
							["last_event"] = 1592255965,
							["spec"] = 261,
							["totaldenied"] = 0.007195,
							["delay"] = 1592255965,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 42,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 25.007597,
							["resource"] = 0.007597,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 24.007597,
							["total"] = 25.007597,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.007597,
							["last_event"] = 1592255966,
							["spec"] = 260,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.007597,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 42,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["还击"] = {
										["activedamt"] = 0,
										["id"] = "还击",
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 4,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["activedamt"] = 0,
										["id"] = "出血",
										["targets"] = {
										},
										["uptime"] = 49,
										["appliedamt"] = 2,
										["refreshamt"] = 10,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["activedamt"] = 1,
										["id"] = "新近包扎",
										["targets"] = {
										},
										["uptime"] = 19,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 215,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["剑刃乱舞"] = {
										["activedamt"] = 1,
										["id"] = "剑刃乱舞",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["activedamt"] = 1,
										["id"] = "敏捷",
										["targets"] = {
										},
										["uptime"] = 79,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["急救"] = {
										["activedamt"] = 1,
										["id"] = "急救",
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["activedamt"] = 1,
										["id"] = "切割",
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["activedamt"] = 1,
										["id"] = "血牙",
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["再生"] = {
										["activedamt"] = 1,
										["id"] = "再生",
										["targets"] = {
										},
										["uptime"] = 79,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 92,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 4,
								["刺骨"] = 2,
								["出血"] = 12,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592255977,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒预备兵",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["射击"] = 1,
								["打击"] = 1,
								["断筋"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-2163-8901-000167E4C1",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "安格弗将军",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 8,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-2163-9033-000067E4C1",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 30,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 30,
									["appliedamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["refreshamt"] = 0,
								},
								["花姐"] = {
									["uptime"] = 0,
									["actived_at"] = 1592255972,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-5002-230-2163-9033-000067E4C1",
							["last_event"] = 1592255975,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["割裂"] = {
										["activedamt"] = 0,
										["id"] = "割裂",
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 16,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["消失"] = {
										["activedamt"] = 0,
										["id"] = "消失",
										["targets"] = {
										},
										["uptime"] = 0,
										["appliedamt"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 8,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["割裂"] = 1,
								["消失"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 6,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592255977,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒医师",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 8,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-2163-8894-0000E7E5CA",
							["classe"] = "UNKNOW",
						}, -- [6]
					},
				}, -- [4]
				{
					["combatId"] = 42,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 379319.601,
				["tempo_start"] = 1592255898,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32973, -- [1]
					2300, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					26005, -- [1]
					2300, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["data_fim"] = "05:19:37",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 7.38000000000466,
				["CombatEndedAt"] = 379176.833,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2300.007195,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["涛哥"] = 19460.002986,
							["花姐"] = 6541.006394,
						}, -- [1]
					},
				},
				["end_time"] = 379177.234,
				["combat_id"] = 42,
				["player_last_events"] = {
				},
				["overall_added"] = true,
				["combat_counter"] = 74,
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 36,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["data_inicio"] = "05:18:18",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["start_time"] = 379098.235,
				["TimeData"] = {
				},
				["contra"] = "安格弗将军",
			}, -- [1]
			{
				{
					["combatId"] = 41,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00611,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3532,
								["安格弗将军"] = 15869,
							},
							["total"] = 19401.00611,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19401.00611,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1592255537,
							["friendlyfire_total"] = 0,
							["spec"] = 261,
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["出血"] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 367,
										["g_amt"] = 0,
										["n_max"] = 215,
										["targets"] = {
											["安格弗将军"] = 2272,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1905,
										["n_min"] = 156,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 2272,
										["c_max"] = 367,
										["DODGE"] = 1,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 156,
										["n_amt"] = 10,
										["r_amt"] = 0,
										["c_min"] = 367,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 622,
										["targets"] = {
											["铁怒预备兵"] = 3532,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3532,
										["n_min"] = 76,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 3532,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 19,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 9,
										["b_amt"] = 1,
										["c_dmg"] = 2397,
										["g_amt"] = 0,
										["n_max"] = 221,
										["targets"] = {
											["安格弗将军"] = 7846,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5449,
										["n_min"] = 73,
										["g_dmg"] = 0,
										["counter"] = 61,
										["DODGE"] = 2,
										["total"] = 7846,
										["c_max"] = 402,
										["MISS"] = 7,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 172,
										["n_amt"] = 43,
										["r_amt"] = 0,
										["c_min"] = 150,
									},
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 657,
										["targets"] = {
											["安格弗将军"] = 1909,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1909,
										["n_min"] = 622,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1909,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 325,
										["targets"] = {
											["安格弗将军"] = 606,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 606,
										["n_min"] = 281,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 606,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2457,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2457,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 21,
										["total"] = 2457,
										["c_max"] = 0,
										["RESIST"] = 1,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 20,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 388,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 388,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 388,
										["c_max"] = 388,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 388,
									},
									["血牙"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 391,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 391,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 391,
										["c_max"] = 391,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 391,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0D553",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255535,
							["damage_taken"] = 4297.00611,
							["start_time"] = 1592255459,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001677,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 4297,
								["花姐"] = 3897,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 8194.001677,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592255537,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "安格弗将军",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1330,
										["g_amt"] = 0,
										["n_max"] = 706,
										["targets"] = {
											["涛哥"] = 4297,
											["花姐"] = 3897,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 6864,
										["MISS"] = 1,
										["n_min"] = 419,
										["g_dmg"] = 0,
										["counter"] = 45,
										["a_amt"] = 0,
										["total"] = 8194,
										["c_max"] = 1330,
										["DODGE"] = 31,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 1330,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 4,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["MISS"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 8194.001677,
							["serial"] = "Creature-0-4505-230-14773-9033-000067E309",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255535,
							["damage_taken"] = 22462.001677,
							["start_time"] = 1592255485,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007746,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007746,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.007746,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-4505-230-14773-8901-000167E309",
							["nome"] = "铁怒预备兵",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 19,
										["a_amt"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 18,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1592255537,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3532.007746,
							["start_time"] = 1592255537,
							["delay"] = 0,
							["last_event"] = 1592255482,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001657,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6593,
							},
							["total"] = 6593.001657,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6593.001657,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1592255537,
							["friendlyfire_total"] = 0,
							["spec"] = 260,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["偷袭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["IMMUNE"] = 1,
										["id"] = "偷袭",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1384,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 1384,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1384,
										["c_max"] = 1384,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 1384,
									},
									["!Melee"] = {
										["c_amt"] = 10,
										["b_amt"] = 2,
										["c_dmg"] = 2494,
										["g_amt"] = 0,
										["n_max"] = 191,
										["targets"] = {
											["安格弗将军"] = 3856,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1362,
										["n_min"] = 49,
										["g_dmg"] = 0,
										["counter"] = 26,
										["total"] = 3856,
										["c_max"] = 394,
										["MISS"] = 5,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 101,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 161,
									},
									["邪恶攻击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 527,
										["g_amt"] = 0,
										["n_max"] = 224,
										["targets"] = {
											["安格弗将军"] = 1353,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 826,
										["n_min"] = 191,
										["g_dmg"] = 0,
										["counter"] = 7,
										["DODGE"] = 1,
										["total"] = 1353,
										["c_max"] = 527,
										["a_amt"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 527,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0BF72",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255535,
							["damage_taken"] = 3897.001657,
							["start_time"] = 1592255507,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002655,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002655,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.002655,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-4505-230-14773-8894-000067E41B",
							["nome"] = "铁怒医师",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 8,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1592255537,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002655,
							["start_time"] = 1592255537,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [5]
					},
				}, -- [1]
				{
					["combatId"] = 41,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 217.003757,
							["total_without_pet"] = 2083.003757,
							["total"] = 2083.003757,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.003757,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2300,
							},
							["totalover_without_pet"] = 0.003757,
							["healing_taken"] = 2083.003757,
							["end_time"] = 1592255537,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
								["涛哥"] = 217,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 217,
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 1783,
										},
										["n_min"] = 33,
										["counter"] = 8,
										["overheal"] = 217,
										["total"] = 1783,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 1783,
										["n_amt"] = 8,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 6,
										["overheal"] = 0,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 300,
										["n_amt"] = 6,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1592255523,
							["custom"] = 0,
							["last_event"] = 1592255520,
							["spec"] = 261,
							["totaldenied"] = 0.003757,
							["delay"] = 1592255520,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 41,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 25.001522,
							["resource"] = 0.001522,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 68.001522,
							["total"] = 25.001522,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.001522,
							["last_event"] = 1592255527,
							["spec"] = 260,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.001522,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 41,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["还击"] = {
										["activedamt"] = 0,
										["id"] = "还击",
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["activedamt"] = 0,
										["id"] = "致命毒药 IV",
										["targets"] = {
										},
										["uptime"] = 64,
										["appliedamt"] = 2,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["activedamt"] = 0,
										["id"] = "出血",
										["targets"] = {
										},
										["uptime"] = 57,
										["appliedamt"] = 2,
										["refreshamt"] = 9,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["activedamt"] = 1,
										["id"] = "新近包扎",
										["targets"] = {
										},
										["uptime"] = 25,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 214,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["剑刃乱舞"] = {
										["activedamt"] = 1,
										["id"] = "剑刃乱舞",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["activedamt"] = 1,
										["id"] = "敏捷",
										["targets"] = {
										},
										["uptime"] = 78,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["急救"] = {
										["activedamt"] = 1,
										["id"] = "急救",
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["activedamt"] = 1,
										["id"] = "切割",
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["activedamt"] = 1,
										["id"] = "血牙",
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["再生"] = {
										["activedamt"] = 1,
										["id"] = "再生",
										["targets"] = {
										},
										["uptime"] = 78,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 158,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 2,
								["刺骨"] = 4,
								["出血"] = 12,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592255537,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒预备兵",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 2,
								["打击"] = 4,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4505-230-14773-8901-000167E309",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "安格弗将军",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 6,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4505-230-14773-9033-000067E309",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 30,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 30,
									["appliedamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4505-230-14773-9033-000067E309",
							["last_event"] = 1592255528,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["nome"] = "花姐",
							["buff_uptime_targets"] = {
							},
							["spec"] = 260,
							["grupo"] = true,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["buff_uptime"] = 17,
							["spell_cast"] = {
								["刺骨"] = 1,
								["偷袭"] = 1,
								["消失"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 7,
							},
							["last_event"] = 1592255526,
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4920-01D0BF72",
							["classe"] = "ROGUE",
						}, -- [5]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒医师",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 8,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4505-230-14773-8894-000067E41B",
							["classe"] = "UNKNOW",
						}, -- [6]
					},
				}, -- [4]
				{
					["combatId"] = 41,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 379097.668,
				["tempo_start"] = 1592255459,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					34188, -- [1]
					2083, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					25994, -- [1]
					2083, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["data_fim"] = "05:12:17",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 14.5699999999488,
				["CombatEndedAt"] = 378736.572,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2083.003757,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["涛哥"] = 19401.00611,
							["花姐"] = 6593.001657,
						}, -- [1]
					},
				},
				["end_time"] = 378737.389,
				["combat_id"] = 41,
				["player_last_events"] = {
				},
				["overall_added"] = true,
				["combat_counter"] = 73,
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 35,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["data_inicio"] = "05:10:59",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["start_time"] = 378659.375,
				["TimeData"] = {
				},
				["contra"] = "安格弗将军",
			}, -- [2]
			{
				{
					["combatId"] = 40,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00521,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 4066,
								["安格弗将军"] = 16933,
							},
							["total"] = 20999.00521,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20999.00521,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1592255099,
							["friendlyfire_total"] = 0,
							["spec"] = 261,
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1213,
										["g_amt"] = 0,
										["n_max"] = 761,
										["targets"] = {
											["安格弗将军"] = 2636,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1423,
										["n_min"] = 662,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2636,
										["c_max"] = 1213,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 1213,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 662,
										["targets"] = {
											["铁怒预备兵"] = 4066,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4066,
										["n_min"] = 50,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 4066,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 12,
										["b_amt"] = 1,
										["c_dmg"] = 3626,
										["g_amt"] = 0,
										["n_max"] = 234,
										["targets"] = {
											["安格弗将军"] = 8264,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4638,
										["DODGE"] = 1,
										["n_min"] = 50,
										["g_dmg"] = 0,
										["counter"] = 57,
										["a_amt"] = 0,
										["total"] = 8264,
										["c_max"] = 535,
										["MISS"] = 9,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 50,
										["n_amt"] = 34,
										["r_amt"] = 0,
										["c_min"] = 160,
									},
									["出血"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1398,
										["g_amt"] = 0,
										["n_max"] = 225,
										["targets"] = {
											["安格弗将军"] = 2838,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1440,
										["n_min"] = 173,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2838,
										["c_max"] = 537,
										["a_amt"] = 0,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["r_amt"] = 0,
										["c_min"] = 424,
									},
									["还击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 561,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 561,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 561,
										["c_max"] = 561,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 561,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2241,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2241,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 2241,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 198,
										["targets"] = {
											["安格弗将军"] = 198,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 198,
										["n_min"] = 198,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 198,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 195,
										["targets"] = {
											["安格弗将军"] = 195,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 195,
										["n_min"] = 195,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 195,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0D553",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255097,
							["damage_taken"] = 2326.00521,
							["start_time"] = 1592255026,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004213,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 2237,
								["花姐"] = 1254,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3491.004213,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592255099,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "安格弗将军",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1254,
										["g_amt"] = 0,
										["n_max"] = 800,
										["targets"] = {
											["涛哥"] = 2237,
											["花姐"] = 1254,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2237,
										["a_amt"] = 0,
										["n_min"] = 660,
										["g_dmg"] = 0,
										["counter"] = 41,
										["MISS"] = 3,
										["total"] = 3491,
										["c_max"] = 1254,
										["DODGE"] = 32,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 1254,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 8,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 3491.004213,
							["serial"] = "Creature-0-4999-230-26767-9033-000067E151",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255097,
							["damage_taken"] = 22315.004213,
							["start_time"] = 1592255051,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002009,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 89,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 89.002009,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592255099,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "铁怒预备兵",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 89,
										["targets"] = {
											["涛哥"] = 89,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 89,
										["a_amt"] = 0,
										["n_min"] = 89,
										["g_dmg"] = 0,
										["counter"] = 17,
										["DODGE"] = 12,
										["total"] = 89,
										["c_max"] = 0,
										["MISS"] = 3,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 89.002009,
							["serial"] = "Creature-0-4999-230-26767-8901-000167E151",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255049,
							["damage_taken"] = 4066.002009,
							["start_time"] = 1592255098,
							["delay"] = 1592255049,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00459,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 5382,
							},
							["total"] = 5382.00459,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5382.00459,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 2,
									},
									["total"] = 2,
								},
							},
							["dps_started"] = false,
							["end_time"] = 1592255099,
							["friendlyfire_total"] = 2,
							["spec"] = 260,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 283,
										["targets"] = {
											["安格弗将军"] = 283,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 283,
										["n_min"] = 283,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 283,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 6,
										["b_amt"] = 0,
										["c_dmg"] = 1754,
										["g_amt"] = 0,
										["n_max"] = 192,
										["targets"] = {
											["安格弗将军"] = 3575,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1821,
										["n_min"] = 73,
										["g_dmg"] = 0,
										["counter"] = 22,
										["total"] = 3575,
										["c_max"] = 445,
										["MISS"] = 3,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 13,
										["r_amt"] = 0,
										["c_min"] = 187,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 1,
										["c_dmg"] = 929,
										["g_amt"] = 0,
										["n_max"] = 218,
										["targets"] = {
											["安格弗将军"] = 1524,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 595,
										["n_min"] = 182,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1524,
										["c_max"] = 478,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 182,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 451,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0BF72",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592255097,
							["damage_taken"] = 1256.00459,
							["start_time"] = 1592255077,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005138,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005138,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.005138,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-4999-230-26767-8894-000067E267",
							["nome"] = "铁怒医师",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 5,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1592255099,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.005138,
							["start_time"] = 1592255099,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [5]
					},
				}, -- [1]
				{
					["combatId"] = 40,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 396.006612,
							["total_without_pet"] = 2089.006612,
							["total"] = 2089.006612,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.006612,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2089,
							},
							["totalover_without_pet"] = 0.006612,
							["healing_taken"] = 2089.006612,
							["end_time"] = 1592255099,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
								["涛哥"] = 396,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 96,
										},
										["n_max"] = 89,
										["targets"] = {
											["涛哥"] = 89,
										},
										["n_min"] = 89,
										["counter"] = 2,
										["overheal"] = 96,
										["total"] = 89,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 89,
										["n_amt"] = 2,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 2000,
										["n_amt"] = 8,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 300,
										},
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 6,
										["overheal"] = 300,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 0,
										["n_amt"] = 6,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1592255078,
							["custom"] = 0,
							["last_event"] = 1592255090,
							["spec"] = 261,
							["totaldenied"] = 0.006612,
							["delay"] = 1592255059,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 40,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 25.00596,
							["resource"] = 0.00596,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 34.00596,
							["total"] = 25.00596,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.00596,
							["last_event"] = 1592255090,
							["spec"] = 260,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.00596,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 40,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["还击"] = {
										["activedamt"] = 0,
										["id"] = "还击",
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["activedamt"] = 0,
										["id"] = "致命毒药 IV",
										["targets"] = {
										},
										["uptime"] = 56,
										["appliedamt"] = 2,
										["refreshamt"] = 4,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["activedamt"] = 0,
										["id"] = "出血",
										["targets"] = {
										},
										["uptime"] = 49,
										["appliedamt"] = 2,
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["activedamt"] = 1,
										["id"] = "新近包扎",
										["targets"] = {
										},
										["uptime"] = 17,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 245,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["急救"] = {
										["activedamt"] = 1,
										["id"] = "急救",
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["神圣力量"] = {
										["activedamt"] = 2,
										["id"] = "神圣力量",
										["targets"] = {
										},
										["uptime"] = 30,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["再生"] = {
										["activedamt"] = 1,
										["id"] = "再生",
										["targets"] = {
										},
										["uptime"] = 73,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["剑刃乱舞"] = {
										["activedamt"] = 1,
										["id"] = "剑刃乱舞",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["activedamt"] = 2,
										["id"] = "切割",
										["targets"] = {
										},
										["uptime"] = 24,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["activedamt"] = 1,
										["id"] = "敏捷",
										["targets"] = {
										},
										["uptime"] = 73,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["activedamt"] = 1,
										["id"] = "血牙",
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 128,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 2,
								["还击"] = 1,
								["刺骨"] = 3,
								["出血"] = 11,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592255099,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒预备兵",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 2,
								["断筋"] = 3,
								["打击"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-26767-8901-000167E151",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "安格弗将军",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 8,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-26767-9033-000067E151",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 40,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 40,
									["appliedamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["refreshamt"] = 0,
								},
								["花姐"] = {
									["uptime"] = 0,
									["actived_at"] = 1592255092,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4999-230-26767-9033-000067E151",
							["last_event"] = 1592255097,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["破甲"] = {
										["activedamt"] = 0,
										["id"] = "破甲",
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 15,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 8,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["破甲"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 5,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592255098,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒医师",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 5,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-26767-8894-000067E267",
							["classe"] = "UNKNOW",
						}, -- [6]
					},
				}, -- [4]
				{
					["combatId"] = 40,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 378658.773,
				["tempo_start"] = 1592255026,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					29961, -- [1]
					2089, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					26383, -- [1]
					2089, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["data_fim"] = "05:05:00",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 5.25,
				["CombatEndedAt"] = 378299.697,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2089.006612,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["涛哥"] = 20999.00521,
							["花姐"] = 5382.00459,
						}, -- [1]
					},
				},
				["end_time"] = 378299.763,
				["combat_id"] = 40,
				["player_last_events"] = {
				},
				["overall_added"] = true,
				["combat_counter"] = 72,
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 34,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["data_inicio"] = "05:03:47",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["start_time"] = 378226.754,
				["TimeData"] = {
				},
				["contra"] = "安格弗将军",
			}, -- [3]
			{
				{
					["combatId"] = 39,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.006524,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3837,
								["安格弗将军"] = 16246,
							},
							["total"] = 20083.006524,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20083.006524,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1592254656,
							["friendlyfire_total"] = 0,
							["spec"] = 261,
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["出血"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 844,
										["g_amt"] = 0,
										["n_max"] = 224,
										["targets"] = {
											["安格弗将军"] = 2843,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1999,
										["n_min"] = 177,
										["g_dmg"] = 0,
										["counter"] = 14,
										["DODGE"] = 1,
										["total"] = 2843,
										["c_max"] = 441,
										["a_amt"] = 0,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["r_amt"] = 0,
										["c_min"] = 403,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 611,
										["targets"] = {
											["铁怒预备兵"] = 3837,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3837,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 3837,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 20,
										["b_amt"] = 2,
										["c_dmg"] = 5313,
										["g_amt"] = 0,
										["n_max"] = 239,
										["targets"] = {
											["安格弗将军"] = 9274,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3961,
										["a_amt"] = 0,
										["n_min"] = 52,
										["g_dmg"] = 0,
										["counter"] = 57,
										["MISS"] = 6,
										["total"] = 9274,
										["c_max"] = 456,
										["DODGE"] = 2,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 204,
										["n_amt"] = 28,
										["r_amt"] = 0,
										["c_min"] = 146,
									},
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 611,
										["targets"] = {
											["安格弗将军"] = 1222,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1222,
										["n_min"] = 611,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1222,
										["c_max"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 352,
										["targets"] = {
											["安格弗将军"] = 620,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 620,
										["n_min"] = 268,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 620,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 1701,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1701,
										["n_min"] = 27,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 1701,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 15,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 205,
										["targets"] = {
											["安格弗将军"] = 205,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 205,
										["n_min"] = 205,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 205,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 195,
										["targets"] = {
											["安格弗将军"] = 381,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 381,
										["n_min"] = 186,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 381,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0D553",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254654,
							["damage_taken"] = 4614.006524,
							["start_time"] = 1592254592,
							["delay"] = 1592254630,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003461,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 4133,
								["花姐"] = 2666,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6799.003461,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592254656,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "安格弗将军",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 718,
										["targets"] = {
											["涛哥"] = 4133,
											["花姐"] = 2666,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 6799,
										["MISS"] = 1,
										["n_min"] = 473,
										["g_dmg"] = 0,
										["counter"] = 47,
										["a_amt"] = 0,
										["total"] = 6799,
										["c_max"] = 0,
										["DODGE"] = 31,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 4,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 6,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 8,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 6799.003461,
							["serial"] = "Creature-0-4502-230-23918-9033-000067DFA4",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254654,
							["damage_taken"] = 22291.003461,
							["start_time"] = 1592254599,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.006474,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 481,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 481.006474,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592254656,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "铁怒预备兵",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 16,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 106,
										["targets"] = {
											["涛哥"] = 481,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 481,
										["n_min"] = 89,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 481,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 5,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 481.006474,
							["serial"] = "Creature-0-4502-230-23918-8901-000167DFA4",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254597,
							["damage_taken"] = 3837.006474,
							["start_time"] = 1592254641,
							["delay"] = 1592254597,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002952,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002952,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.002952,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-4502-230-23918-8894-0000E7E09E",
							["nome"] = "铁怒医师",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1592254656,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.002952,
							["start_time"] = 1592254656,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007612,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6045,
							},
							["total"] = 6045.007612,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6045.007612,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 3,
									},
									["total"] = 3,
								},
							},
							["dps_started"] = false,
							["end_time"] = 1592254656,
							["friendlyfire_total"] = 3,
							["spec"] = 260,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["割裂"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 126,
										["targets"] = {
											["安格弗将军"] = 630,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 630,
										["n_min"] = 126,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 630,
										["c_max"] = 0,
										["id"] = "割裂",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 8,
										["b_amt"] = 0,
										["c_dmg"] = 1948,
										["g_amt"] = 0,
										["n_max"] = 182,
										["targets"] = {
											["安格弗将军"] = 3289,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1341,
										["DODGE"] = 3,
										["n_min"] = 73,
										["g_dmg"] = 0,
										["counter"] = 27,
										["a_amt"] = 0,
										["total"] = 3289,
										["c_max"] = 402,
										["MISS"] = 4,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 160,
									},
									["破甲"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = "破甲",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["绞喉"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 118,
										["targets"] = {
											["安格弗将军"] = 118,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 118,
										["n_min"] = 118,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 118,
										["c_max"] = 0,
										["id"] = "绞喉",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 222,
										["targets"] = {
											["安格弗将军"] = 222,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 222,
										["n_min"] = 222,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 222,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 971,
										["g_amt"] = 0,
										["n_max"] = 214,
										["targets"] = {
											["安格弗将军"] = 1786,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 815,
										["n_min"] = 194,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1786,
										["c_max"] = 504,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 467,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0BF72",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254654,
							["damage_taken"] = 2669.007612,
							["start_time"] = 1592254627,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [5]
					},
				}, -- [1]
				{
					["combatId"] = 39,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 0.005463,
							["total_without_pet"] = 2626.005463,
							["total"] = 2626.005463,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.005463,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2626,
							},
							["totalover_without_pet"] = 0.005463,
							["healing_taken"] = 2626.005463,
							["end_time"] = 1592254656,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
							},
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 76,
										["targets"] = {
											["涛哥"] = 76,
										},
										["n_min"] = 76,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 76,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 76,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 2000,
										["n_amt"] = 8,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 550,
										},
										["n_min"] = 50,
										["counter"] = 11,
										["overheal"] = 0,
										["total"] = 550,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 550,
										["n_amt"] = 11,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1592254632,
							["custom"] = 0,
							["last_event"] = 1592254656,
							["spec"] = 261,
							["totaldenied"] = 0.005463,
							["delay"] = 1592254639,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 39,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 25.008677,
							["resource"] = 0.008677,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 0.008677,
							["total"] = 25.008677,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.008677,
							["last_event"] = 1592254644,
							["spec"] = 260,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.008677,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 39,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["还击"] = {
										["activedamt"] = 0,
										["id"] = "还击",
										["targets"] = {
										},
										["uptime"] = 12,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["activedamt"] = 0,
										["id"] = "致命毒药 IV",
										["targets"] = {
										},
										["uptime"] = 48,
										["appliedamt"] = 2,
										["refreshamt"] = 6,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["activedamt"] = 0,
										["id"] = "出血",
										["targets"] = {
										},
										["uptime"] = 56,
										["appliedamt"] = 2,
										["refreshamt"] = 10,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["activedamt"] = 1,
										["id"] = "新近包扎",
										["targets"] = {
										},
										["uptime"] = 25,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 234,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["急救"] = {
										["activedamt"] = 1,
										["id"] = "急救",
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["神圣力量"] = {
										["activedamt"] = 1,
										["id"] = "神圣力量",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["再生"] = {
										["activedamt"] = 1,
										["id"] = "再生",
										["targets"] = {
										},
										["uptime"] = 80,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["剑刃乱舞"] = {
										["activedamt"] = 1,
										["id"] = "剑刃乱舞",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["activedamt"] = 1,
										["id"] = "切割",
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 1,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["activedamt"] = 1,
										["id"] = "敏捷",
										["targets"] = {
										},
										["uptime"] = 80,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["activedamt"] = 2,
										["id"] = "血牙",
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 2,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 141,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 2,
								["刺骨"] = 2,
								["出血"] = 14,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592254656,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒预备兵",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 1,
								["射击"] = 5,
								["打击"] = 2,
								["断筋"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4502-230-23918-8901-000167DFA4",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "安格弗将军",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 8,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4502-230-23918-9033-000067DFA4",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒医师",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 4,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4502-230-23918-8894-0000E7E09E",
							["classe"] = "UNKNOW",
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["割裂"] = {
										["activedamt"] = 0,
										["id"] = "割裂",
										["targets"] = {
										},
										["uptime"] = 10,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["绞喉"] = {
										["activedamt"] = 0,
										["id"] = "绞喉",
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 17,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 13,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["割裂"] = 1,
								["绞喉"] = 1,
								["破甲"] = 1,
								["消失"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 6,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592254654,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [5]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["花姐"] = {
									["uptime"] = 0,
									["actived_at"] = 1592254649,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4502-230-23918-9033-000067DFA4",
							["last_event"] = 1592254649,
						}, -- [6]
					},
				}, -- [4]
				{
					["combatId"] = 39,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 378226.119,
				["tempo_start"] = 1592254576,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					33408, -- [1]
					2626, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					26131, -- [1]
					2626, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["data_fim"] = "04:57:37",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 9.7160000000149,
				["CombatEndedAt"] = 377856.596,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2626.005463,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["涛哥"] = 20083.006524,
							["花姐"] = 6045.007612,
						}, -- [1]
					},
				},
				["end_time"] = 377857.129,
				["combat_id"] = 39,
				["player_last_events"] = {
				},
				["overall_added"] = true,
				["combat_counter"] = 71,
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 33,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["data_inicio"] = "04:56:17",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["start_time"] = 377777.12,
				["TimeData"] = {
				},
				["contra"] = "安格弗将军",
			}, -- [4]
			{
				{
					["combatId"] = 38,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003808,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3921,
								["安格弗将军"] = 17929,
							},
							["total"] = 21850.003808,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 21850.003808,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1592254109,
							["friendlyfire_total"] = 0,
							["spec"] = 261,
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 203,
										["targets"] = {
											["安格弗将军"] = 203,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 203,
										["n_min"] = 203,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 203,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 533,
										["targets"] = {
											["铁怒预备兵"] = 3921,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3921,
										["n_min"] = 45,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 3921,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 20,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 15,
										["b_amt"] = 1,
										["c_dmg"] = 4581,
										["g_amt"] = 0,
										["n_max"] = 224,
										["targets"] = {
											["安格弗将军"] = 8401,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3820,
										["DODGE"] = 1,
										["n_min"] = 45,
										["g_dmg"] = 0,
										["counter"] = 56,
										["MISS"] = 5,
										["total"] = 8401,
										["c_max"] = 447,
										["a_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 45,
										["n_amt"] = 32,
										["r_amt"] = 0,
										["c_min"] = 147,
									},
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 656,
										["targets"] = {
											["安格弗将军"] = 2448,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2448,
										["n_min"] = 533,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 2448,
										["c_max"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 277,
										["targets"] = {
											["安格弗将军"] = 277,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 277,
										["n_min"] = 277,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 277,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2754,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2754,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 21,
										["total"] = 2754,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 21,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["出血"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1081,
										["g_amt"] = 0,
										["n_max"] = 208,
										["targets"] = {
											["安格弗将军"] = 2642,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1561,
										["n_min"] = 168,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2642,
										["c_max"] = 388,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 340,
									},
									["血牙"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1204,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 1204,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1204,
										["c_max"] = 405,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 397,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0D553",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254107,
							["damage_taken"] = 4403.003808,
							["start_time"] = 1592254034,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005427,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 4314,
								["花姐"] = 4178,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 8492.005427,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592254109,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "安格弗将军",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 4054,
										["g_amt"] = 0,
										["n_max"] = 691,
										["targets"] = {
											["涛哥"] = 4314,
											["花姐"] = 4178,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4438,
										["a_amt"] = 0,
										["n_min"] = 535,
										["g_dmg"] = 0,
										["counter"] = 45,
										["MISS"] = 5,
										["total"] = 8492,
										["c_max"] = 1493,
										["DODGE"] = 27,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["r_amt"] = 0,
										["c_min"] = 1175,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 7,
										["a_amt"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 3,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 2,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 9,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 8492.005427,
							["serial"] = "Creature-0-5002-230-27611-9033-000067DBF4",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254107,
							["damage_taken"] = 22723.005427,
							["start_time"] = 1592254056,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002524,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 89,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 89.002524,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592254109,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "铁怒预备兵",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 89,
										["targets"] = {
											["涛哥"] = 89,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 89,
										["n_min"] = 89,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 89,
										["c_max"] = 0,
										["DODGE"] = 15,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 89.002524,
							["serial"] = "Creature-0-5002-230-27611-8901-0001E7DBF4",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254056,
							["damage_taken"] = 3921.002524,
							["start_time"] = 1592254108,
							["delay"] = 1592254056,
							["tipo"] = 1,
						}, -- [3]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005817,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["monster"] = true,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005817,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.005817,
							["classe"] = "UNKNOW",
							["serial"] = "Creature-0-5002-230-27611-8894-0000E7DE7F",
							["nome"] = "铁怒医师",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 7,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["friendlyfire"] = {
							},
							["end_time"] = 1592254109,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.005817,
							["start_time"] = 1592254109,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006718,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 4794,
							},
							["total"] = 4794.006718,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4794.006718,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 1,
									},
									["total"] = 1,
								},
							},
							["dps_started"] = false,
							["end_time"] = 1592254109,
							["friendlyfire_total"] = 1,
							["spec"] = 260,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["割裂"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 126,
										["targets"] = {
											["安格弗将军"] = 378,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 378,
										["n_min"] = 126,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 378,
										["c_max"] = 0,
										["id"] = "割裂",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 6,
										["b_amt"] = 0,
										["c_dmg"] = 2022,
										["g_amt"] = 0,
										["n_max"] = 174,
										["targets"] = {
											["安格弗将军"] = 2862,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 840,
										["a_amt"] = 0,
										["n_min"] = 74,
										["g_dmg"] = 0,
										["counter"] = 19,
										["DODGE"] = 1,
										["total"] = 2862,
										["c_max"] = 395,
										["MISS"] = 3,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["r_amt"] = 0,
										["c_min"] = 164,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 970,
										["g_amt"] = 0,
										["n_max"] = 202,
										["targets"] = {
											["安格弗将军"] = 1554,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 584,
										["n_min"] = 190,
										["g_dmg"] = 0,
										["counter"] = 7,
										["DODGE"] = 1,
										["total"] = 1554,
										["c_max"] = 492,
										["a_amt"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 478,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0BF72",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592254106,
							["damage_taken"] = 4179.006718,
							["start_time"] = 1592254085,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [5]
					},
				}, -- [1]
				{
					["combatId"] = 38,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 538.007322,
							["total_without_pet"] = 2248.007322,
							["total"] = 2248.007322,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.007322,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2300,
							},
							["totalover_without_pet"] = 0.007322,
							["healing_taken"] = 2248.007322,
							["end_time"] = 1592254109,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
								["涛哥"] = 538,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 86,
										},
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 86,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 0,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 52,
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 1948,
										},
										["n_min"] = 198,
										["counter"] = 8,
										["overheal"] = 52,
										["total"] = 1948,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 1948,
										["n_amt"] = 8,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 400,
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 14,
										["overheal"] = 400,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 300,
										["n_amt"] = 14,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1592254080,
							["custom"] = 0,
							["last_event"] = 1592254106,
							["spec"] = 261,
							["totaldenied"] = 0.007322,
							["delay"] = 1592254065,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 38,
					["tipo"] = 7,
					["_ActorTable"] = {
						{
							["received"] = 25.006218,
							["resource"] = 0.006218,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 0.006218,
							["total"] = 25.006218,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.006218,
							["last_event"] = 1592254100,
							["spec"] = 260,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.006218,
						}, -- [1]
					},
				}, -- [3]
				{
					["combatId"] = 38,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["还击"] = {
										["activedamt"] = 0,
										["id"] = "还击",
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["activedamt"] = 0,
										["id"] = "致命毒药 IV",
										["targets"] = {
										},
										["uptime"] = 63,
										["appliedamt"] = 2,
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["activedamt"] = 0,
										["id"] = "出血",
										["targets"] = {
										},
										["uptime"] = 51,
										["appliedamt"] = 2,
										["refreshamt"] = 9,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["activedamt"] = 1,
										["id"] = "新近包扎",
										["targets"] = {
										},
										["uptime"] = 18,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 216,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["急救"] = {
										["activedamt"] = 1,
										["id"] = "急救",
										["targets"] = {
										},
										["uptime"] = 8,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 2,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["再生"] = {
										["activedamt"] = 1,
										["id"] = "再生",
										["targets"] = {
										},
										["uptime"] = 75,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["剑刃乱舞"] = {
										["activedamt"] = 1,
										["id"] = "剑刃乱舞",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["activedamt"] = 1,
										["id"] = "切割",
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["神圣力量"] = {
										["activedamt"] = 1,
										["id"] = "神圣力量",
										["targets"] = {
										},
										["uptime"] = 3,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["activedamt"] = 2,
										["id"] = "血牙",
										["targets"] = {
										},
										["uptime"] = 14,
										["appliedamt"] = 2,
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["activedamt"] = 1,
										["id"] = "敏捷",
										["targets"] = {
										},
										["uptime"] = 75,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 138,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 1,
								["刺骨"] = 4,
								["出血"] = 11,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592254109,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["tipo"] = 4,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒预备兵",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 2,
								["打击"] = 3,
								["断筋"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-27611-8901-0001E7DBF4",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "安格弗将军",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 9,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-27611-9033-000067DBF4",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
								},
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 31,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 30,
									["appliedamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["refreshamt"] = 0,
								},
								["花姐"] = {
									["uptime"] = 1,
									["appliedamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-5002-230-27611-9033-000067DBF4",
							["last_event"] = 1592254105,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["nome"] = "铁怒医师",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 7,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-27611-8894-0000E7DE7F",
							["classe"] = "UNKNOW",
						}, -- [5]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["割裂"] = {
										["activedamt"] = 0,
										["id"] = "割裂",
										["targets"] = {
										},
										["uptime"] = 7,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 15,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 7,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["割裂"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 7,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592254107,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["tipo"] = 4,
						}, -- [6]
					},
				}, -- [4]
				{
					["combatId"] = 38,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 377776.737,
				["tempo_start"] = 1592254034,
				["last_events_tables"] = {
					{
						{
							{
								true, -- [1]
								"剑类武器专精", -- [2]
								1, -- [3]
								1592254086.91, -- [4]
								3883, -- [5]
								"花姐", -- [6]
								nil, -- [7]
								1, -- [8]
								true, -- [9]
							}, -- [1]
							{
								true, -- [1]
								"!Melee", -- [2]
								666, -- [3]
								1592254097.204, -- [4]
								3883, -- [5]
								"安格弗将军", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [2]
							{
								true, -- [1]
								"!Melee", -- [2]
								1386, -- [3]
								1592254102.733, -- [4]
								3217, -- [5]
								"安格弗将军", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [3]
							{
								true, -- [1]
								"!Melee", -- [2]
								633, -- [3]
								1592254103.933, -- [4]
								1831, -- [5]
								"安格弗将军", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [4]
							{
								4, -- [1]
								"破甲攻击", -- [2]
								1, -- [3]
								1592254105.366, -- [4]
								1198, -- [5]
								"安格弗将军", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [5]
							{
								true, -- [1]
								"!Melee", -- [2]
								1493, -- [3]
								1592254106.067, -- [4]
								1198, -- [5]
								"安格弗将军", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								295, -- [10]
							}, -- [6]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"花姐", -- [6]
							}, -- [7]
						}, -- [1]
						1592254106.583, -- [2]
						"花姐", -- [3]
						"ROGUE", -- [4]
						3883, -- [5]
						"1m 11s", -- [6]
						["dead_at"] = 71.2449999999954,
						["dead"] = true,
					}, -- [1]
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					35225, -- [1]
					2248, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					26645, -- [1]
					2248, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["data_fim"] = "04:48:30",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 5.25,
				["CombatEndedAt"] = 377308.817,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2248.007322,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["涛哥"] = 21850.003808,
							["花姐"] = 4794.006718,
						}, -- [1]
					},
				},
				["end_time"] = 377309.767,
				["combat_id"] = 38,
				["player_last_events"] = {
				},
				["overall_added"] = true,
				["combat_counter"] = 70,
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 32,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["data_inicio"] = "04:47:15",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["start_time"] = 377234.755,
				["TimeData"] = {
				},
				["contra"] = "安格弗将军",
			}, -- [5]
			{
				{
					["combatId"] = 37,
					["tipo"] = 2,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.004929,
							["damage_from"] = {
								["征服者派隆"] = true,
							},
							["targets"] = {
								["征服者派隆"] = 8403,
							},
							["total"] = 8403.004929,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 8403.004929,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["end_time"] = 1592253784,
							["friendlyfire_total"] = 0,
							["spec"] = 261,
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 7,
										["b_amt"] = 0,
										["c_dmg"] = 1656,
										["g_amt"] = 0,
										["n_max"] = 265,
										["targets"] = {
											["征服者派隆"] = 4370,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2714,
										["n_min"] = 83,
										["g_dmg"] = 0,
										["counter"] = 26,
										["total"] = 4370,
										["c_max"] = 440,
										["MISS"] = 2,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["r_amt"] = 0,
										["c_min"] = 172,
									},
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 718,
										["targets"] = {
											["征服者派隆"] = 1402,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1402,
										["n_min"] = 684,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1402,
										["c_max"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["出血"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 859,
										["g_amt"] = 0,
										["n_max"] = 264,
										["targets"] = {
											["征服者派隆"] = 1759,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 900,
										["n_min"] = 207,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1759,
										["c_max"] = 468,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["r_amt"] = 0,
										["c_min"] = 391,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["征服者派隆"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 0,
										["c_max"] = 0,
										["IMMUNE"] = 14,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 412,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["征服者派隆"] = 412,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 412,
										["c_max"] = 412,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 412,
									},
									["血牙"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 460,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["征服者派隆"] = 460,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 460,
										["c_max"] = 460,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 460,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0D553",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592253783,
							["damage_taken"] = 3025.004929,
							["start_time"] = 1592253756,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002247,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 3025,
								["花姐"] = 358,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3383.002247,
							["monster"] = true,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592253784,
							["friendlyfire_total"] = 0,
							["on_hold"] = false,
							["nome"] = "征服者派隆",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["火焰新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 517,
										["targets"] = {
											["花姐"] = 358,
											["涛哥"] = 1028,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1386,
										["n_min"] = 358,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1386,
										["c_max"] = 0,
										["id"] = "火焰新星",
										["r_dmg"] = 358,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 1,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 333,
										["targets"] = {
											["涛哥"] = 885,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 885,
										["n_min"] = 241,
										["g_dmg"] = 0,
										["counter"] = 14,
										["DODGE"] = 10,
										["total"] = 885,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 582,
										["targets"] = {
											["涛哥"] = 1112,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1112,
										["n_min"] = 530,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1112,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["total"] = 3383.002247,
							["serial"] = "Creature-0-4889-0-498-9026-00006786E4",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592253782,
							["damage_taken"] = 11399.002247,
							["start_time"] = 1592253761,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003675,
							["damage_from"] = {
								["花姐"] = true,
								["征服者派隆"] = true,
							},
							["targets"] = {
								["征服者派隆"] = 2996,
							},
							["total"] = 2996.003675,
							["pets"] = {
							},
							["on_hold"] = false,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 2996.003675,
							["boss_fight_component"] = true,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 1,
									},
									["total"] = 1,
								},
							},
							["dps_started"] = false,
							["end_time"] = 1592253784,
							["friendlyfire_total"] = 1,
							["spec"] = 260,
							["nome"] = "花姐",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
									["偷袭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["征服者派隆"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["IMMUNE"] = 1,
										["id"] = "偷袭",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 1136,
										["g_amt"] = 0,
										["n_max"] = 215,
										["targets"] = {
											["征服者派隆"] = 2774,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1638,
										["n_min"] = 84,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 2774,
										["c_max"] = 368,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["r_amt"] = 0,
										["c_min"] = 182,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 222,
										["targets"] = {
											["征服者派隆"] = 222,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 222,
										["n_min"] = 222,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 222,
										["c_max"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["r_amt"] = 0,
										["c_min"] = 0,
									},
								},
							},
							["grupo"] = true,
							["serial"] = "Player-4920-01D0BF72",
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592253782,
							["damage_taken"] = 359.003675,
							["start_time"] = 1592253766,
							["delay"] = 0,
							["tipo"] = 1,
						}, -- [3]
					},
				}, -- [1]
				{
					["combatId"] = 37,
					["tipo"] = 3,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 0.007321,
							["total_without_pet"] = 387.007321,
							["total"] = 387.007321,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.007321,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 387,
							},
							["totalover_without_pet"] = 0.007321,
							["healing_taken"] = 387.007321,
							["end_time"] = 1592253784,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
							},
							["nome"] = "涛哥",
							["spells"] = {
								["tipo"] = 3,
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 87,
										["targets"] = {
											["涛哥"] = 87,
										},
										["n_min"] = 87,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 87,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 87,
										["n_amt"] = 1,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 6,
										["overheal"] = 0,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["n_curado"] = 300,
										["n_amt"] = 6,
										["totaldenied"] = 0,
										["m_healed"] = 0,
										["absorbed"] = 0,
									},
								},
							},
							["grupo"] = true,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1592253770,
							["custom"] = 0,
							["last_event"] = 1592253775,
							["spec"] = 261,
							["totaldenied"] = 0.007321,
							["delay"] = 0,
							["tipo"] = 2,
						}, -- [1]
					},
				}, -- [2]
				{
					["combatId"] = 37,
					["tipo"] = 7,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["combatId"] = 37,
					["tipo"] = 9,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["buff_uptime_targets"] = {
							},
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 9,
							["pets"] = {
							},
							["spell_cast"] = {
								["偷袭"] = 1,
								["邪恶攻击"] = 1,
							},
							["classe"] = "ROGUE",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["潜行"] = {
										["activedamt"] = 1,
										["id"] = "潜行",
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["serial"] = "Player-4920-01D0BF72",
							["last_event"] = 1592253765,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["出血"] = {
										["activedamt"] = 0,
										["id"] = "出血",
										["targets"] = {
										},
										["uptime"] = 22,
										["appliedamt"] = 1,
										["refreshamt"] = 5,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["buff_uptime"] = 97,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["tipo"] = 9,
								["_ActorTable"] = {
									["敏捷"] = {
										["activedamt"] = 1,
										["id"] = "敏捷",
										["targets"] = {
										},
										["uptime"] = 28,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["activedamt"] = 1,
										["id"] = "切割",
										["targets"] = {
										},
										["uptime"] = 9,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["activedamt"] = 1,
										["id"] = "血牙",
										["targets"] = {
										},
										["uptime"] = 6,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["神圣力量"] = {
										["activedamt"] = 1,
										["id"] = "神圣力量",
										["targets"] = {
										},
										["uptime"] = 11,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["再生"] = {
										["activedamt"] = 1,
										["id"] = "再生",
										["targets"] = {
										},
										["uptime"] = 28,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["activedamt"] = 1,
										["id"] = "闪避",
										["targets"] = {
										},
										["uptime"] = 15,
										["appliedamt"] = 1,
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
							},
							["debuff_uptime"] = 22,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["闪避"] = 1,
								["刺骨"] = 2,
								["出血"] = 6,
								["切割"] = 1,
							},
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592253784,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["nome"] = "征服者派隆",
							["tipo"] = 4,
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["火焰新星"] = 2,
								["火焰冲击"] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4889-0-498-9026-00006786E4",
							["classe"] = "UNKNOW",
						}, -- [3]
					},
				}, -- [4]
				{
					["combatId"] = 37,
					["tipo"] = 2,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 377234.421,
				["tempo_start"] = 1592253756,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					14782, -- [1]
					387, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					11400, -- [1]
					387, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["debuff_uptime"] = 0,
						["cooldowns_defensive"] = 0,
						["interrupt"] = 0,
						["dispell"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["data_fim"] = "04:43:04",
				["cleu_timeline"] = {
				},
				["enemy"] = "征服者派隆",
				["TotalElapsedCombatTime"] = 376984.249,
				["CombatEndedAt"] = 376984.249,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 387.007321,
						}, -- [1]
					},
					["damage_section"] = {
					},
					["damage"] = {
						{
							["涛哥"] = 8403.004929,
							["花姐"] = 2996.003675,
						}, -- [1]
					},
				},
				["end_time"] = 376984.332,
				["combat_id"] = 37,
				["player_last_events"] = {
				},
				["overall_added"] = true,
				["combat_counter"] = 69,
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "东部王国",
					["encounter"] = "征服者派隆",
					["mapid"] = 0,
					["try_number"] = 1,
					["name"] = "征服者派隆",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["data_inicio"] = "04:42:36",
				["CombatSkillCache"] = {
				},
				["frags"] = {
					["征服者派隆"] = 1,
				},
				["start_time"] = 376956.325,
				["TimeData"] = {
				},
				["contra"] = "征服者派隆",
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 36,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008388,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3553,
								["安格弗将军"] = 14814,
							},
							["pets"] = {
							},
							["delay"] = 1592235387,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 18367.008388,
							["total"] = 18367.008388,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1592235424,
							["classe"] = "ROGUE",
							["nome"] = "涛哥",
							["boss_fight_component"] = true,
							["spec"] = 261,
							["grupo"] = true,
							["damage_taken"] = 3858.008388,
							["spells"] = {
								["_ActorTable"] = {
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 447,
										["targets"] = {
											["铁怒预备兵"] = 3553,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3553,
										["n_min"] = 73,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 3553,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 20,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 11,
										["b_amt"] = 1,
										["c_dmg"] = 2226,
										["g_amt"] = 0,
										["n_max"] = 283,
										["targets"] = {
											["安格弗将军"] = 8019,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5793,
										["c_min"] = 161,
										["n_min"] = 38,
										["a_amt"] = 0,
										["counter"] = 64,
										["r_amt"] = 0,
										["total"] = 8019,
										["c_max"] = 346,
										["DODGE"] = 5,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 38,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 39,
										["MISS"] = 6,
										["g_dmg"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 1404,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1404,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 1404,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 201,
										["targets"] = {
											["安格弗将军"] = 201,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 201,
										["n_min"] = 201,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 201,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 818,
										["targets"] = {
											["安格弗将军"] = 1839,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1839,
										["n_min"] = 364,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1839,
										["c_max"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["出血"] = {
										["c_amt"] = 2,
										["b_amt"] = 1,
										["c_dmg"] = 815,
										["g_amt"] = 0,
										["n_max"] = 288,
										["targets"] = {
											["安格弗将军"] = 3099,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2284,
										["n_min"] = 132,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 3099,
										["c_max"] = 447,
										["id"] = "出血",
										["r_dmg"] = 0,
										["c_min"] = 368,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 132,
										["n_amt"] = 10,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 252,
										["targets"] = {
											["安格弗将军"] = 252,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 252,
										["n_min"] = 252,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 252,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592235422,
							["friendlyfire"] = {
							},
							["start_time"] = 1592235357,
							["serial"] = "Player-4920-01D0D553",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00152,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 3657,
								["花姐"] = 2768,
							},
							["pets"] = {
							},
							["last_event"] = 1592235421,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 6425.00152,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 6425.00152,
							["classe"] = "UNKNOW",
							["damage_taken"] = 22405.00152,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 782,
										["targets"] = {
											["涛哥"] = 3657,
											["花姐"] = 2768,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 6425,
										["c_min"] = 0,
										["n_min"] = 581,
										["a_amt"] = 0,
										["counter"] = 44,
										["r_amt"] = 0,
										["total"] = 6425,
										["c_max"] = 0,
										["DODGE"] = 28,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 10,
										["MISS"] = 3,
										["g_dmg"] = 0,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 7,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["DODGE"] = 6,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "安格弗将军",
							["last_dps"] = 0,
							["end_time"] = 1592235424,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592235367,
							["serial"] = "Creature-0-4999-230-569-9033-0000679464",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007481,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 201,
							},
							["pets"] = {
							},
							["last_event"] = 1592235365,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 201.007481,
							["delay"] = 1592235365,
							["monster"] = true,
							["total"] = 201.007481,
							["classe"] = "UNKNOW",
							["damage_taken"] = 3553.007481,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 14,
										["c_min"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 0,
										["DODGE"] = 11,
										["MISS"] = 3,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["DODGE"] = 2,
										["MISS"] = 1,
									},
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 110,
										["targets"] = {
											["涛哥"] = 201,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 201,
										["n_min"] = 91,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 201,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒预备兵",
							["last_dps"] = 0,
							["end_time"] = 1592235424,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592235411,
							["serial"] = "Creature-0-4999-230-569-8901-0001679464",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005243,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 7591,
							},
							["pets"] = {
							},
							["delay"] = 0,
							["friendlyfire_total"] = 1,
							["raid_targets"] = {
							},
							["total_without_pet"] = 7591.005243,
							["total"] = 7591.005243,
							["tipo"] = 1,
							["dps_started"] = false,
							["end_time"] = 1592235424,
							["classe"] = "ROGUE",
							["nome"] = "花姐",
							["boss_fight_component"] = true,
							["spec"] = 260,
							["grupo"] = true,
							["damage_taken"] = 2769.005243,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 8,
										["b_amt"] = 1,
										["c_dmg"] = 2216,
										["g_amt"] = 0,
										["n_max"] = 220,
										["targets"] = {
											["安格弗将军"] = 5322,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3106,
										["n_min"] = 79,
										["g_dmg"] = 0,
										["counter"] = 33,
										["c_min"] = 162,
										["total"] = 5322,
										["c_max"] = 476,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 146,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 22,
										["MISS"] = 1,
										["DODGE"] = 2,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 277,
										["targets"] = {
											["安格弗将军"] = 277,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 277,
										["n_min"] = 277,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 277,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["邪恶攻击"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1566,
										["g_amt"] = 0,
										["n_max"] = 224,
										["targets"] = {
											["安格弗将军"] = 1992,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 426,
										["n_min"] = 202,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1992,
										["c_max"] = 538,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["c_min"] = 501,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592235418,
							["friendlyfire"] = {
								["花姐"] = {
									["total"] = 1,
									["spells"] = {
										["剑类武器专精"] = 1,
									},
								},
							},
							["start_time"] = 1592235384,
							["serial"] = "Player-4920-01D0BF72",
							["on_hold"] = false,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00478,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00478,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.00478,
							["classe"] = "UNKNOW",
							["damage_taken"] = 0.00478,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒医师",
							["last_dps"] = 0,
							["end_time"] = 1592235424,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592235424,
							["serial"] = "Creature-0-4999-230-569-8894-000067958B",
							["dps_started"] = false,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 36,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 230.001491,
							["total_without_pet"] = 2188.001491,
							["total"] = 2188.001491,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.001491,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2200,
							},
							["totalover_without_pet"] = 0.001491,
							["healing_taken"] = 2188.001491,
							["end_time"] = 1592235424,
							["last_event"] = 1592235417,
							["targets_overheal"] = {
								["涛哥"] = 230,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 118,
										},
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 118,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 2000,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 112,
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 188,
										},
										["n_min"] = 0,
										["counter"] = 6,
										["overheal"] = 112,
										["total"] = 188,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 188,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["spec"] = 261,
							["totaldenied"] = 0.001491,
							["custom"] = 0,
							["tipo"] = 2,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1592235402,
							["delay"] = 1592235397,
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 36,
					["_ActorTable"] = {
						{
							["received"] = 25.005168,
							["resource"] = 0.005168,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 204.005168,
							["total"] = 25.005168,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.005168,
							["flag_original"] = 1298,
							["tipo"] = 3,
							["last_event"] = 1592235397,
							["spec"] = 260,
							["alternatepower"] = 0.005168,
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 36,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["新近包扎"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "新近包扎",
										["uptime"] = 35,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["致命毒药 IV"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 4,
										["id"] = "致命毒药 IV",
										["uptime"] = 36,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["出血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 9,
										["id"] = "出血",
										["uptime"] = 56,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 240,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急救",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["再生"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "再生",
										["uptime"] = 80,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "敏捷",
										["uptime"] = 80,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["血牙"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "血牙",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["神圣力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "神圣力量",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 127,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 2,
								["刺骨"] = 3,
								["消失"] = 1,
								["出血"] = 12,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592235424,
							["pets"] = {
							},
							["nome"] = "涛哥",
							["serial"] = "Player-4920-01D0D553",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["战斗怒吼"] = 1,
								["射击"] = 2,
								["打击"] = 3,
								["断筋"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-569-8901-0001679464",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["破甲攻击"] = 7,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-569-9033-0000679464",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲",
										["uptime"] = 25,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 21,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["消失"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "消失",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 25,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["破甲"] = 1,
								["消失"] = 1,
								["邪恶攻击"] = 5,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592235424,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["真言术：韧"] = 6,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-569-8894-000067958B",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["花姐"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1592235410,
								},
							},
							["last_event"] = 1592235410,
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["serial"] = "Creature-0-4999-230-569-9033-0000679464",
							["damage_spellid"] = "破甲攻击",
							["nome"] = "破甲攻击",
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 36,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 376955.992,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32584, -- [1]
					2188, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "23:37:04",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 23.0599999999977,
				["CombatEndedAt"] = 358624.104,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "23:35:44",
				["end_time"] = 358624.538,
				["combat_id"] = 36,
				["combat_counter"] = 67,
				["tempo_start"] = 1592235344,
				["contra"] = "安格弗将军",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 31,
					["name"] = "安格弗将军",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					25959, -- [1]
					2188, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["涛哥"] = 18367.008388,
							["花姐"] = 7591.005243,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2188.001491,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 358544.523,
				["TimeData"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 35,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002529,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3369,
								["安格弗将军"] = 16647,
							},
							["delay"] = 1592234962,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 1728,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1728,
										["n_min"] = 27,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 1728,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 15,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 425,
										["targets"] = {
											["铁怒预备兵"] = 3369,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3369,
										["n_min"] = 74,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 3369,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 16,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 16,
										["b_amt"] = 1,
										["c_dmg"] = 4703,
										["g_amt"] = 0,
										["n_max"] = 268,
										["targets"] = {
											["安格弗将军"] = 8212,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3509,
										["c_min"] = 157,
										["n_min"] = 58,
										["MISS"] = 4,
										["counter"] = 50,
										["r_amt"] = 0,
										["total"] = 8212,
										["c_max"] = 474,
										["a_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 58,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 24,
										["DODGE"] = 4,
										["g_dmg"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 182,
										["targets"] = {
											["安格弗将军"] = 182,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 182,
										["n_min"] = 182,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 182,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 319,
										["targets"] = {
											["安格弗将军"] = 319,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 319,
										["n_min"] = 319,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 319,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1050,
										["g_amt"] = 0,
										["n_max"] = 655,
										["targets"] = {
											["安格弗将军"] = 2331,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1281,
										["n_min"] = 626,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 2331,
										["c_max"] = 1050,
										["c_min"] = 1050,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["a_amt"] = 0,
									},
									["出血"] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 1707,
										["g_amt"] = 0,
										["n_max"] = 263,
										["targets"] = {
											["安格弗将军"] = 3103,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1396,
										["n_min"] = 211,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 3103,
										["c_max"] = 468,
										["c_min"] = 403,
										["id"] = "出血",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
									["血牙"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 389,
										["g_amt"] = 0,
										["n_max"] = 199,
										["targets"] = {
											["安格弗将军"] = 772,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 383,
										["n_min"] = 184,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 772,
										["c_max"] = 389,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["c_min"] = 389,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20016.002529,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 20016.002529,
							["damage_taken"] = 3556.002529,
							["nome"] = "涛哥",
							["boss_fight_component"] = true,
							["spec"] = 261,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592234983,
							["custom"] = 0,
							["last_event"] = 1592234981,
							["on_hold"] = false,
							["start_time"] = 1592234926,
							["serial"] = "Player-4920-01D0D553",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006206,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 3281,
								["花姐"] = 2791,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6072.006206,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1592234983,
							["nome"] = "安格弗将军",
							["damage_taken"] = 22720.006206,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1118,
										["g_amt"] = 0,
										["n_max"] = 599,
										["targets"] = {
											["涛哥"] = 3281,
											["花姐"] = 2791,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4954,
										["c_min"] = 1118,
										["n_min"] = 314,
										["a_amt"] = 0,
										["counter"] = 38,
										["r_amt"] = 0,
										["total"] = 6072,
										["c_max"] = 1118,
										["DODGE"] = 22,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 10,
										["MISS"] = 4,
										["g_dmg"] = 0,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 6,
										["c_min"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["MISS"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 8,
										["a_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["DODGE"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 6072.006206,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1592234980,
							["on_hold"] = false,
							["start_time"] = 1592234938,
							["serial"] = "Creature-0-4504-230-12820-9033-00006792C6",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001465,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 275,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 275.001465,
							["delay"] = 1592234933,
							["monster"] = true,
							["end_time"] = 1592234983,
							["nome"] = "铁怒预备兵",
							["damage_taken"] = 3369.001465,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 96,
										["targets"] = {
											["涛哥"] = 275,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 275,
										["n_min"] = 87,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 275,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["DODGE"] = 11,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["MISS"] = 1,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 275.001465,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1592234933,
							["on_hold"] = false,
							["start_time"] = 1592234971,
							["serial"] = "Creature-0-4504-230-12820-8901-0000E792C6",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001803,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6073,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 11,
										["b_amt"] = 0,
										["c_dmg"] = 2720,
										["g_amt"] = 0,
										["n_max"] = 243,
										["targets"] = {
											["安格弗将军"] = 4209,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1489,
										["n_min"] = 73,
										["g_dmg"] = 0,
										["counter"] = 22,
										["total"] = 4209,
										["c_max"] = 411,
										["c_min"] = 151,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 10,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 235,
										["targets"] = {
											["安格弗将军"] = 235,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 235,
										["n_min"] = 235,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 235,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 1,
										["c_dmg"] = 1036,
										["g_amt"] = 0,
										["n_max"] = 207,
										["targets"] = {
											["安格弗将军"] = 1629,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 593,
										["n_min"] = 187,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1629,
										["c_max"] = 530,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["c_min"] = 506,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 187,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6073.001803,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 6073.001803,
							["damage_taken"] = 2791.001803,
							["nome"] = "花姐",
							["boss_fight_component"] = true,
							["spec"] = 260,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592234983,
							["custom"] = 0,
							["last_event"] = 1592234981,
							["on_hold"] = false,
							["start_time"] = 1592234958,
							["serial"] = "Player-4920-01D0BF72",
							["friendlyfire"] = {
							},
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002607,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.002607,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.002607,
							["classe"] = "UNKNOW",
							["damage_taken"] = 0.002607,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 5,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒医师",
							["last_dps"] = 0,
							["end_time"] = 1592234983,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592234983,
							["serial"] = "Creature-0-4504-230-12820-8894-0000E793D0",
							["dps_started"] = false,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 35,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["涛哥"] = 150,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 150.007302,
							["total_without_pet"] = 2735.007302,
							["total"] = 2735.007302,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.007302,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2785,
							},
							["totalover_without_pet"] = 0.007302,
							["healing_taken"] = 2735.007302,
							["end_time"] = 1592234983,
							["tipo"] = 2,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 85,
										["targets"] = {
											["涛哥"] = 85,
										},
										["n_min"] = 85,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 85,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 85,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 2000,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 150,
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 650,
										},
										["n_min"] = 50,
										["counter"] = 16,
										["overheal"] = 150,
										["total"] = 650,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 16,
										["n_curado"] = 650,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["spec"] = 261,
							["totaldenied"] = 0.007302,
							["custom"] = 0,
							["last_event"] = 1592234970,
							["classe"] = "ROGUE",
							["start_time"] = 1592234954,
							["delay"] = 1592234970,
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 35,
					["_ActorTable"] = {
						{
							["received"] = 25.00199,
							["resource"] = 0.00199,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 64.00199,
							["total"] = 25.00199,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.00199,
							["flag_original"] = 1298,
							["tipo"] = 3,
							["last_event"] = 1592234971,
							["spec"] = 260,
							["alternatepower"] = 0.00199,
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 35,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["还击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "还击",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["致命毒药 IV"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 4,
										["id"] = "致命毒药 IV",
										["uptime"] = 47,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["出血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 8,
										["id"] = "出血",
										["uptime"] = 43,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["新近包扎"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "新近包扎",
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 220,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急救",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["神圣力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "神圣力量",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["再生"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "再生",
										["uptime"] = 69,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["血牙"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 1,
										["id"] = "血牙",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "敏捷",
										["uptime"] = 69,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 117,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["刺骨"] = 4,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 1,
								["消失"] = 1,
								["出血"] = 11,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592234983,
							["pets"] = {
							},
							["nome"] = "涛哥",
							["serial"] = "Player-4920-01D0D553",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["射击"] = 3,
								["打击"] = 2,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4504-230-12820-8901-0000E792C6",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["破甲攻击"] = 8,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4504-230-12820-9033-00006792C6",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 15,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 10,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["破甲"] = 1,
								["邪恶攻击"] = 5,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592234981,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1592234959,
								},
								["花姐"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1592234975,
								},
							},
							["last_event"] = 1592234975,
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["serial"] = "Creature-0-4504-230-12820-9033-00006792C6",
							["damage_spellid"] = "破甲攻击",
							["nome"] = "破甲攻击",
						}, -- [5]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["真言术：韧"] = 5,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4504-230-12820-8894-0000E793D0",
							["boss_fight_component"] = true,
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 35,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 358544.005,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					32436, -- [1]
					2735, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "23:29:44",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 8.50699999998324,
				["CombatEndedAt"] = 358183.192,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "23:28:35",
				["end_time"] = 358183.794,
				["combat_id"] = 35,
				["combat_counter"] = 66,
				["tempo_start"] = 1592234914,
				["contra"] = "安格弗将军",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 30,
					["name"] = "安格弗将军",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					26089, -- [1]
					2735, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["涛哥"] = 20016.002529,
							["花姐"] = 6073.001803,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2735.007302,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 358114.788,
				["TimeData"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 34,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002262,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3587,
								["安格弗将军"] = 17606,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2430,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2430,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 2430,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 19,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 425,
										["targets"] = {
											["铁怒预备兵"] = 3587,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3587,
										["n_min"] = 33,
										["g_dmg"] = 0,
										["counter"] = 21,
										["total"] = 3587,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 21,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 12,
										["b_amt"] = 3,
										["c_dmg"] = 4100,
										["g_amt"] = 0,
										["n_max"] = 265,
										["targets"] = {
											["安格弗将军"] = 8831,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4731,
										["c_min"] = 154,
										["n_min"] = 33,
										["MISS"] = 4,
										["counter"] = 59,
										["r_amt"] = 0,
										["total"] = 8831,
										["c_max"] = 533,
										["DODGE"] = 3,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 160,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 38,
										["a_amt"] = 0,
										["g_dmg"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 181,
										["targets"] = {
											["安格弗将军"] = 181,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 181,
										["n_min"] = 181,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 181,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["还击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 535,
										["g_amt"] = 0,
										["n_max"] = 331,
										["targets"] = {
											["安格弗将军"] = 866,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 331,
										["n_min"] = 331,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 866,
										["c_max"] = 535,
										["id"] = "还击",
										["r_dmg"] = 0,
										["c_min"] = 535,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1572,
										["g_amt"] = 0,
										["n_max"] = 652,
										["targets"] = {
											["安格弗将军"] = 2224,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 652,
										["n_min"] = 652,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2224,
										["c_max"] = 1572,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["c_min"] = 1572,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["出血"] = {
										["c_amt"] = 2,
										["b_amt"] = 1,
										["c_dmg"] = 729,
										["g_amt"] = 0,
										["n_max"] = 259,
										["targets"] = {
											["安格弗将军"] = 2609,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1880,
										["n_min"] = 177,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2609,
										["c_max"] = 368,
										["id"] = "出血",
										["r_dmg"] = 0,
										["c_min"] = 361,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 177,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 258,
										["targets"] = {
											["安格弗将军"] = 465,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 465,
										["n_min"] = 207,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 465,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 21193.002262,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 21193.002262,
							["damage_taken"] = 3691.002262,
							["nome"] = "涛哥",
							["boss_fight_component"] = true,
							["spec"] = 261,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592234544,
							["custom"] = 0,
							["last_event"] = 1592234541,
							["on_hold"] = false,
							["start_time"] = 1592234466,
							["serial"] = "Player-4920-01D0D553",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007141,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 3691,
								["花姐"] = 1040,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4731.007141,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1592234544,
							["nome"] = "安格弗将军",
							["damage_taken"] = 22507.007141,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 581,
										["targets"] = {
											["涛哥"] = 3691,
											["花姐"] = 1040,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4731,
										["c_min"] = 0,
										["n_min"] = 324,
										["a_amt"] = 0,
										["counter"] = 43,
										["r_amt"] = 0,
										["total"] = 4731,
										["c_max"] = 0,
										["DODGE"] = 25,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 11,
										["MISS"] = 4,
										["g_dmg"] = 0,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["DODGE"] = 2,
										["a_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 4731.007141,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1592234541,
							["on_hold"] = false,
							["start_time"] = 1592234491,
							["serial"] = "Creature-0-5002-230-32370-9033-000067910E",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00672,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 1592234488,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00672,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.00672,
							["classe"] = "UNKNOW",
							["damage_taken"] = 3587.00672,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["DODGE"] = 3,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["DODGE"] = 14,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒预备兵",
							["last_dps"] = 0,
							["end_time"] = 1592234544,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592234544,
							["serial"] = "Creature-0-5002-230-32370-8901-000167910E",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008662,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 4901,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 1570,
										["g_amt"] = 0,
										["n_max"] = 237,
										["targets"] = {
											["安格弗将军"] = 3520,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1950,
										["c_min"] = 166,
										["n_min"] = 73,
										["a_amt"] = 0,
										["counter"] = 27,
										["r_amt"] = 0,
										["total"] = 3520,
										["c_max"] = 495,
										["MISS"] = 6,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 14,
										["DODGE"] = 2,
										["g_dmg"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 498,
										["g_amt"] = 0,
										["n_max"] = 237,
										["targets"] = {
											["安格弗将军"] = 1381,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 883,
										["n_min"] = 209,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1381,
										["c_max"] = 498,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["c_min"] = 498,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4901.008662,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 4901.008662,
							["damage_taken"] = 1040.008662,
							["nome"] = "花姐",
							["boss_fight_component"] = true,
							["spec"] = 260,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592234544,
							["custom"] = 0,
							["last_event"] = 1592234542,
							["on_hold"] = false,
							["start_time"] = 1592234514,
							["serial"] = "Player-4920-01D0BF72",
							["friendlyfire"] = {
							},
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004209,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.004209,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.004209,
							["classe"] = "UNKNOW",
							["damage_taken"] = 0.004209,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒医师",
							["last_dps"] = 0,
							["end_time"] = 1592234544,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592234544,
							["serial"] = "Creature-0-5002-230-32370-8894-0000E79219",
							["dps_started"] = false,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 34,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.003576,
							["total_without_pet"] = 2600.003576,
							["total"] = 2600.003576,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.003576,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2600,
							},
							["totalover_without_pet"] = 0.003576,
							["healing_taken"] = 2600.003576,
							["end_time"] = 1592234544,
							["tipo"] = 2,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 2000,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 600,
										},
										["n_min"] = 50,
										["counter"] = 12,
										["overheal"] = 0,
										["total"] = 600,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 12,
										["n_curado"] = 600,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["spec"] = 261,
							["totaldenied"] = 0.003576,
							["custom"] = 0,
							["last_event"] = 1592234540,
							["classe"] = "ROGUE",
							["start_time"] = 1592234514,
							["delay"] = 1592234502,
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 34,
					["_ActorTable"] = {
						{
							["received"] = 25.006292,
							["resource"] = 0.006292,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 114.006292,
							["total"] = 25.006292,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.006292,
							["flag_original"] = 1298,
							["tipo"] = 3,
							["last_event"] = 1592234527,
							["spec"] = 260,
							["alternatepower"] = 0.006292,
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 34,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["还击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "还击",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["致命毒药 IV"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 8,
										["id"] = "致命毒药 IV",
										["uptime"] = 60,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["出血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 9,
										["id"] = "出血",
										["uptime"] = 57,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["新近包扎"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "新近包扎",
										["uptime"] = 25,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 225,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["急救"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急救",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "敏捷",
										["uptime"] = 78,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["再生"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "再生",
										["uptime"] = 78,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["血牙"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "血牙",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 154,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["刺骨"] = 2,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 2,
								["还击"] = 2,
								["消失"] = 1,
								["出血"] = 11,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592234544,
							["pets"] = {
							},
							["nome"] = "涛哥",
							["serial"] = "Player-4920-01D0D553",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["打击"] = 3,
								["断筋"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-32370-8901-0001E7910E",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["破甲攻击"] = 4,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-32370-9033-000067910E",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 15,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 16,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["破甲"] = 1,
								["邪恶攻击"] = 5,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592234543,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1592234515,
								},
							},
							["last_event"] = 1592234515,
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["serial"] = "Creature-0-5002-230-32370-9033-000067910E",
							["damage_spellid"] = "破甲攻击",
							["nome"] = "破甲攻击",
						}, -- [5]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["真言术：韧"] = 6,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-5002-230-32370-8894-0000E79219",
							["boss_fight_component"] = true,
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 34,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 358114.338,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					30824.99508, -- [1]
					2600, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "23:22:25",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 13.3250000000116,
				["CombatEndedAt"] = 357744.65,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "23:21:07",
				["end_time"] = 357744.816,
				["combat_id"] = 34,
				["combat_counter"] = 65,
				["tempo_start"] = 1592234466,
				["contra"] = "安格弗将军",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 29,
					["name"] = "安格弗将军",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					26094, -- [1]
					2600, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["涛哥"] = 21193.002262,
							["花姐"] = 4901.008662,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2600.003576,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 357666.802,
				["TimeData"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 33,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001938,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3405,
								["安格弗将军"] = 16770,
							},
							["delay"] = 1592234090,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 1917,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1917,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 1917,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["n_amt"] = 16,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 403,
										["targets"] = {
											["铁怒预备兵"] = 3405,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3405,
										["n_min"] = 83,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 3405,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 12,
										["b_amt"] = 0,
										["c_dmg"] = 3970,
										["g_amt"] = 0,
										["n_max"] = 258,
										["targets"] = {
											["安格弗将军"] = 8201,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4231,
										["c_min"] = 157,
										["n_min"] = 81,
										["a_amt"] = 0,
										["counter"] = 56,
										["r_amt"] = 0,
										["total"] = 8201,
										["c_max"] = 538,
										["MISS"] = 7,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 32,
										["DODGE"] = 2,
										["g_dmg"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 211,
										["targets"] = {
											["安格弗将军"] = 211,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 211,
										["n_min"] = 211,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 211,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["还击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 662,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 662,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 662,
										["c_max"] = 662,
										["id"] = "还击",
										["r_dmg"] = 0,
										["c_min"] = 662,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["刺骨"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 2321,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 2321,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2321,
										["c_max"] = 1601,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["c_min"] = 720,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["出血"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 792,
										["g_amt"] = 0,
										["n_max"] = 280,
										["targets"] = {
											["安格弗将军"] = 2874,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2082,
										["n_min"] = 192,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2874,
										["c_max"] = 403,
										["id"] = "出血",
										["r_dmg"] = 0,
										["c_min"] = 389,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["血牙"] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 337,
										["g_amt"] = 0,
										["n_max"] = 247,
										["targets"] = {
											["安格弗将军"] = 584,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 247,
										["n_min"] = 247,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 584,
										["c_max"] = 337,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["c_min"] = 337,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 337,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20175.001938,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 20175.001938,
							["damage_taken"] = 2119.001938,
							["nome"] = "涛哥",
							["boss_fight_component"] = true,
							["spec"] = 261,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592234117,
							["custom"] = 0,
							["last_event"] = 1592234116,
							["on_hold"] = false,
							["start_time"] = 1592234058,
							["serial"] = "Player-4920-01D0D553",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004382,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 1686,
								["花姐"] = 3525,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5211.004382,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1592234117,
							["nome"] = "安格弗将军",
							["damage_taken"] = 22927.004382,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 715,
										["targets"] = {
											["涛哥"] = 1686,
											["花姐"] = 3525,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5211,
										["c_min"] = 0,
										["n_min"] = 333,
										["a_amt"] = 0,
										["counter"] = 40,
										["r_amt"] = 0,
										["total"] = 5211,
										["c_max"] = 0,
										["DODGE"] = 26,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 10,
										["MISS"] = 2,
										["g_dmg"] = 0,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 6,
										["c_min"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["MISS"] = 2,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 8,
										["a_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["DODGE"] = 3,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 5211.004382,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1592234115,
							["on_hold"] = false,
							["start_time"] = 1592234068,
							["serial"] = "Creature-0-4514-230-2491-9033-0000678F63",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001956,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 433,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 433.001956,
							["delay"] = 1592234070,
							["monster"] = true,
							["end_time"] = 1592234117,
							["nome"] = "铁怒预备兵",
							["damage_taken"] = 3405.001956,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 105,
										["targets"] = {
											["涛哥"] = 293,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 293,
										["n_min"] = 85,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 293,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 19,
										["c_min"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 0,
										["DODGE"] = 17,
										["MISS"] = 2,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 140,
										["targets"] = {
											["涛哥"] = 140,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 140,
										["n_min"] = 140,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 140,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 433.001956,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1592234070,
							["on_hold"] = false,
							["start_time"] = 1592234100,
							["serial"] = "Creature-0-4514-230-2491-8901-0000E78F63",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006741,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6157,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 7,
										["b_amt"] = 1,
										["c_dmg"] = 1860,
										["g_amt"] = 0,
										["n_max"] = 223,
										["targets"] = {
											["安格弗将军"] = 4449,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2589,
										["c_min"] = 152,
										["n_min"] = 84,
										["g_dmg"] = 0,
										["counter"] = 29,
										["r_amt"] = 0,
										["total"] = 4449,
										["c_max"] = 454,
										["a_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 182,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 18,
										["MISS"] = 2,
										["DODGE"] = 1,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1041,
										["g_amt"] = 0,
										["n_max"] = 231,
										["targets"] = {
											["安格弗将军"] = 1708,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 667,
										["n_min"] = 213,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1708,
										["c_max"] = 529,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["c_min"] = 512,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6157.006741,
							["friendlyfire_total"] = 1,
							["dps_started"] = false,
							["total"] = 6157.006741,
							["damage_taken"] = 3526.006741,
							["nome"] = "花姐",
							["boss_fight_component"] = true,
							["spec"] = 260,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592234117,
							["custom"] = 0,
							["last_event"] = 1592234114,
							["on_hold"] = false,
							["start_time"] = 1592234086,
							["serial"] = "Player-4920-01D0BF72",
							["friendlyfire"] = {
								["花姐"] = {
									["total"] = 1,
									["spells"] = {
										["剑类武器专精"] = 1,
									},
								},
							},
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008285,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008285,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.008285,
							["classe"] = "UNKNOW",
							["damage_taken"] = 0.008285,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒医师",
							["last_dps"] = 0,
							["end_time"] = 1592234117,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592234117,
							["serial"] = "Creature-0-4514-230-2491-8894-0000E79076",
							["dps_started"] = false,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 33,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["涛哥"] = 961,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 961.001206,
							["total_without_pet"] = 1863.001206,
							["total"] = 1863.001206,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.001206,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2057,
							},
							["totalover_without_pet"] = 0.001206,
							["healing_taken"] = 1863.001206,
							["end_time"] = 1592234117,
							["tipo"] = 2,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 179,
										},
										["n_max"] = 45,
										["targets"] = {
											["涛哥"] = 45,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 179,
										["total"] = 45,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 45,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 379,
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 1621,
										},
										["n_min"] = 0,
										["counter"] = 8,
										["overheal"] = 379,
										["total"] = 1621,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 1621,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 403,
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 197,
										},
										["n_min"] = 0,
										["counter"] = 12,
										["overheal"] = 403,
										["total"] = 197,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 12,
										["n_curado"] = 197,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["spec"] = 261,
							["totaldenied"] = 0.001206,
							["custom"] = 0,
							["last_event"] = 1592234115,
							["classe"] = "ROGUE",
							["start_time"] = 1592234098,
							["delay"] = 1592234099,
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 33,
					["_ActorTable"] = {
						{
							["received"] = 25.001164,
							["resource"] = 0.001164,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 130.001164,
							["total"] = 25.001164,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.001164,
							["flag_original"] = 1298,
							["tipo"] = 3,
							["last_event"] = 1592234098,
							["spec"] = 260,
							["alternatepower"] = 0.001164,
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 33,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["还击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "还击",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["致命毒药 IV"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 8,
										["id"] = "致命毒药 IV",
										["uptime"] = 49,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["出血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 9,
										["id"] = "出血",
										["uptime"] = 50,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["新近包扎"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "新近包扎",
										["uptime"] = 26,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 244,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急救",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["神圣力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = "神圣力量",
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["再生"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "再生",
										["uptime"] = 71,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 30,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["血牙"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "血牙",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "敏捷",
										["uptime"] = 71,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 131,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 2,
								["还击"] = 1,
								["刺骨"] = 2,
								["出血"] = 11,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592234117,
							["pets"] = {
							},
							["nome"] = "涛哥",
							["serial"] = "Player-4920-01D0D553",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["射击"] = 3,
								["打击"] = 2,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4514-230-2491-8901-0000678F63",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["破甲攻击"] = 8,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4514-230-2491-9033-0000678F63",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲",
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 16,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 18,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["破甲"] = 1,
								["邪恶攻击"] = 5,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592234116,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 5,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["花姐"] = {
									["uptime"] = 5,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1592234111,
								},
							},
							["last_event"] = 1592234111,
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["serial"] = "Creature-0-4514-230-2491-9033-0000678F63",
							["damage_spellid"] = "破甲攻击",
							["nome"] = "破甲攻击",
						}, -- [5]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["真言术：韧"] = 3,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4514-230-2491-8894-0000E79076",
							["boss_fight_component"] = true,
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 33,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 357666.202,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					31976, -- [1]
					1863, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "23:15:18",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 15.3690000000061,
				["CombatEndedAt"] = 357317.466,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "23:14:07",
				["end_time"] = 357317.699,
				["combat_id"] = 33,
				["combat_counter"] = 64,
				["tempo_start"] = 1592234046,
				["contra"] = "安格弗将军",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 28,
					["name"] = "安格弗将军",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					26333, -- [1]
					1863, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["涛哥"] = 20175.001938,
							["花姐"] = 6157.006741,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 1863.001206,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 357246.691,
				["TimeData"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
			}, -- [10]
			{
				{
					["tipo"] = 2,
					["combatId"] = 32,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00164,
							["damage_from"] = {
							},
							["targets"] = {
								["辛迪亚兄弟会"] = 1922,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["total"] = 1922.00164,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1922.00164,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1592233817,
							["spells"] = {
								["_ActorTable"] = {
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 81,
										["targets"] = {
											["辛迪亚兄弟会"] = 81,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 81,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 81,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["出血"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 506,
										["g_amt"] = 0,
										["n_max"] = 237,
										["targets"] = {
											["辛迪亚兄弟会"] = 743,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 237,
										["n_min"] = 237,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 743,
										["c_max"] = 506,
										["id"] = "出血",
										["r_dmg"] = 0,
										["c_min"] = 506,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 247,
										["g_amt"] = 0,
										["n_max"] = 271,
										["targets"] = {
											["辛迪亚兄弟会"] = 1098,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 851,
										["n_min"] = 105,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 1098,
										["c_max"] = 247,
										["c_min"] = 247,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.00164,
							["nome"] = "涛哥",
							["spec"] = 261,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592233811,
							["on_hold"] = false,
							["start_time"] = 1592233804,
							["serial"] = "Player-4920-01D0D553",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.006077,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006077,
							["last_event"] = 0,
							["fight_component"] = true,
							["total"] = 0.006077,
							["delay"] = 0,
							["classe"] = "UNGROUPPLAYER",
							["nome"] = "辛迪亚兄弟会",
							["spells"] = {
								["_ActorTable"] = {
									["疾跑"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "疾跑",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1922.006077,
							["end_time"] = 1592233817,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592233817,
							["serial"] = "Player-4920-01D891CD",
							["dps_started"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 32,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 32,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 32,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["activedamt"] = -1,
										["id"] = "偷袭",
										["targets"] = {
										},
										["actived_at"] = 1592233808,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									["致命毒药 IV"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 2,
										["id"] = "致命毒药 IV",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["出血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = "出血",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "敏捷",
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["再生"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "再生",
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 24,
							["nome"] = "涛哥",
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["出血"] = 2,
								["潜行"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1592233817,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["buff_uptime"] = 26,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["last_event"] = 0,
							["nome"] = "辛迪亚兄弟会",
							["enemy"] = true,
							["pets"] = {
							},
							["classe"] = "UNGROUPPLAYER",
							["tipo"] = 4,
							["spell_cast"] = {
								["疾跑"] = 1,
							},
							["serial"] = "Player-4920-01D891CD",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 32,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 357246.257,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					1922, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "23:10:18",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "辛迪亚兄弟会",
				["TotalElapsedCombatTime"] = 357017.501,
				["CombatEndedAt"] = 357017.501,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["涛哥"] = 1922.00164,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 357018.118,
				["combat_id"] = 32,
				["combat_counter"] = 63,
				["tempo_start"] = 1592233804,
				["spells_cast_timeline"] = {
				},
				["TimeData"] = {
				},
				["totals_grupo"] = {
					1922, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["data_inicio"] = "23:10:05",
				["start_time"] = 357005.114,
				["contra"] = "辛迪亚兄弟会",
				["frags"] = {
				},
			}, -- [11]
			{
				{
					["tipo"] = 2,
					["combatId"] = 31,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.002384,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3314,
								["安格弗将军"] = 16764,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2241,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2241,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 2241,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 387,
										["targets"] = {
											["铁怒预备兵"] = 3314,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3314,
										["n_min"] = 85,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 3314,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 19,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 14,
										["b_amt"] = 2,
										["c_dmg"] = 3539,
										["g_amt"] = 0,
										["n_max"] = 236,
										["targets"] = {
											["安格弗将军"] = 7835,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4296,
										["c_min"] = 150,
										["n_min"] = 33,
										["g_dmg"] = 0,
										["counter"] = 53,
										["r_amt"] = 0,
										["total"] = 7835,
										["c_max"] = 445,
										["MISS"] = 4,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 208,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 30,
										["a_amt"] = 0,
										["DODGE"] = 2,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 197,
										["targets"] = {
											["安格弗将军"] = 197,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 197,
										["n_min"] = 197,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 197,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 311,
										["targets"] = {
											["安格弗将军"] = 584,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 584,
										["n_min"] = 273,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 584,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1309,
										["g_amt"] = 0,
										["n_max"] = 751,
										["targets"] = {
											["安格弗将军"] = 2599,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1290,
										["n_min"] = 539,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2599,
										["c_max"] = 1309,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["c_min"] = 1309,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["出血"] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 1756,
										["g_amt"] = 0,
										["n_max"] = 201,
										["targets"] = {
											["安格弗将军"] = 2916,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1160,
										["n_min"] = 184,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 2916,
										["c_max"] = 543,
										["id"] = "出血",
										["r_dmg"] = 0,
										["c_min"] = 335,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 206,
										["targets"] = {
											["安格弗将军"] = 392,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 392,
										["n_min"] = 186,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 392,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20078.002384,
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["total"] = 20078.002384,
							["damage_taken"] = 3812.002384,
							["nome"] = "涛哥",
							["boss_fight_component"] = true,
							["spec"] = 261,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592233674,
							["custom"] = 0,
							["last_event"] = 1592233672,
							["on_hold"] = false,
							["start_time"] = 1592233602,
							["serial"] = "Player-4920-01D0D553",
							["friendlyfire"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005099,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 3812,
								["花姐"] = 652,
							},
							["pets"] = {
							},
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 4464.005099,
							["delay"] = 0,
							["monster"] = true,
							["end_time"] = 1592233674,
							["nome"] = "安格弗将军",
							["damage_taken"] = 22838.005099,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 658,
										["targets"] = {
											["涛哥"] = 3812,
											["花姐"] = 652,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4464,
										["c_min"] = 0,
										["n_min"] = 496,
										["MISS"] = 1,
										["counter"] = 41,
										["r_amt"] = 0,
										["total"] = 4464,
										["c_max"] = 0,
										["DODGE"] = 27,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 5,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 8,
										["a_amt"] = 0,
										["g_dmg"] = 0,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 10,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["DODGE"] = 5,
										["MISS"] = 2,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 4464.005099,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1592233671,
							["on_hold"] = false,
							["start_time"] = 1592233630,
							["serial"] = "Creature-0-4999-230-26802-9033-0000678C96",
							["dps_started"] = false,
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003444,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 1592233622,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003444,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.003444,
							["classe"] = "UNKNOW",
							["damage_taken"] = 3314.003444,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["MISS"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 0,
										["c_max"] = 0,
										["c_min"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["DODGE"] = 14,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒预备兵",
							["last_dps"] = 0,
							["end_time"] = 1592233674,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592233674,
							["serial"] = "Creature-0-4999-230-26802-8901-0001678C96",
							["dps_started"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003469,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6074,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 8,
										["b_amt"] = 1,
										["c_dmg"] = 2435,
										["g_amt"] = 0,
										["n_max"] = 221,
										["targets"] = {
											["安格弗将军"] = 3904,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1469,
										["n_min"] = 42,
										["g_dmg"] = 0,
										["counter"] = 23,
										["c_min"] = 151,
										["total"] = 3904,
										["c_max"] = 447,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 42,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 13,
										["DODGE"] = 1,
										["MISS"] = 1,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 995,
										["g_amt"] = 0,
										["n_max"] = 270,
										["targets"] = {
											["安格弗将军"] = 2170,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1175,
										["n_min"] = 199,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 2170,
										["c_max"] = 528,
										["c_min"] = 467,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["a_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6074.003469,
							["friendlyfire_total"] = 1,
							["dps_started"] = false,
							["total"] = 6074.003469,
							["damage_taken"] = 653.003469,
							["nome"] = "花姐",
							["boss_fight_component"] = true,
							["spec"] = 260,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1592233674,
							["custom"] = 0,
							["last_event"] = 1592233672,
							["on_hold"] = false,
							["start_time"] = 1592233650,
							["serial"] = "Player-4920-01D0BF72",
							["friendlyfire"] = {
								["花姐"] = {
									["total"] = 1,
									["spells"] = {
										["剑类武器专精"] = 1,
									},
								},
							},
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008444,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008444,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.008444,
							["classe"] = "UNKNOW",
							["damage_taken"] = 0.008444,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "铁怒医师",
							["last_dps"] = 0,
							["end_time"] = 1592233674,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592233674,
							["serial"] = "Creature-0-4999-230-26802-8894-0000678EB4",
							["dps_started"] = false,
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 31,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
								["涛哥"] = 391,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 391.006809,
							["total_without_pet"] = 2300.006809,
							["total"] = 2300.006809,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.006809,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2300,
							},
							["totalover_without_pet"] = 0.006809,
							["healing_taken"] = 2300.006809,
							["end_time"] = 1592233674,
							["tipo"] = 2,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 91,
										},
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 91,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 0,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 8,
										["n_curado"] = 2000,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 300,
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 12,
										["overheal"] = 300,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 12,
										["n_curado"] = 300,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["spec"] = 261,
							["totaldenied"] = 0.006809,
							["custom"] = 0,
							["last_event"] = 1592233662,
							["classe"] = "ROGUE",
							["start_time"] = 1592233639,
							["delay"] = 1592233662,
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 31,
					["_ActorTable"] = {
						{
							["received"] = 25.004094,
							["resource"] = 0.004094,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 0.004094,
							["total"] = 25.004094,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.004094,
							["flag_original"] = 1298,
							["tipo"] = 3,
							["last_event"] = 1592233666,
							["spec"] = 260,
							["alternatepower"] = 0.004094,
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 31,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["还击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "还击",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["致命毒药 IV"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 5,
										["id"] = "致命毒药 IV",
										["uptime"] = 57,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["出血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 8,
										["id"] = "出血",
										["uptime"] = 49,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["新近包扎"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "新近包扎",
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 220,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急救",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["神圣力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "神圣力量",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["再生"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "再生",
										["uptime"] = 72,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["血牙"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "血牙",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "敏捷",
										["uptime"] = 72,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 138,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["刺骨"] = 3,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 2,
								["消失"] = 1,
								["出血"] = 10,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592233674,
							["pets"] = {
							},
							["nome"] = "涛哥",
							["serial"] = "Player-4920-01D0D553",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["战斗怒吼"] = 2,
								["打击"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-26802-8901-0001678C96",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["破甲攻击"] = 10,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-26802-9033-0000678C96",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 22,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 22,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1592233651,
								},
								["花姐"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1592233657,
								},
							},
							["last_event"] = 1592233657,
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["serial"] = "Creature-0-4999-230-26802-9033-0000678C96",
							["damage_spellid"] = "破甲攻击",
							["nome"] = "破甲攻击",
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 15,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 6,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["破甲"] = 1,
								["邪恶攻击"] = 8,
								["闪避"] = 1,
							},
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["last_event"] = 1592233672,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["真言术：韧"] = 6,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4999-230-26802-8894-0000678EB4",
							["boss_fight_component"] = true,
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 31,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 357004.98,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					30616, -- [1]
					2300, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "23:07:55",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 9.73999999999069,
				["CombatEndedAt"] = 356874.54,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "23:06:43",
				["end_time"] = 356875.34,
				["combat_id"] = 31,
				["combat_counter"] = 62,
				["tempo_start"] = 1592233602,
				["contra"] = "安格弗将军",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 27,
					["name"] = "安格弗将军",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["totals_grupo"] = {
					26153, -- [1]
					2300, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["CombatSkillCache"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["涛哥"] = 20078.002384,
							["花姐"] = 6074.003469,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2300.006809,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["start_time"] = 356803.327,
				["TimeData"] = {
				},
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
			}, -- [12]
			{
				{
					["tipo"] = 2,
					["combatId"] = 30,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003349,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3566,
								["安格弗将军"] = 15758,
							},
							["serial"] = "Player-4920-01D0D553",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["on_hold"] = false,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 19324.003349,
							["classe"] = "ROGUE",
							["dps_started"] = false,
							["total"] = 19324.003349,
							["friendlyfire"] = {
							},
							["last_event"] = 1592228996,
							["nome"] = "涛哥",
							["spec"] = 261,
							["grupo"] = true,
							["last_dps"] = 0,
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1214,
										["g_amt"] = 0,
										["n_max"] = 773,
										["targets"] = {
											["安格弗将军"] = 2504,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1290,
										["n_min"] = 517,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2504,
										["c_max"] = 1214,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 1214,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 517,
										["targets"] = {
											["铁怒预备兵"] = 3566,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3566,
										["n_min"] = 75,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 3566,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 12,
										["b_amt"] = 0,
										["c_dmg"] = 3649,
										["g_amt"] = 0,
										["n_max"] = 238,
										["targets"] = {
											["安格弗将军"] = 7343,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3694,
										["g_dmg"] = 0,
										["n_min"] = 72,
										["a_amt"] = 0,
										["counter"] = 54,
										["DODGE"] = 4,
										["r_amt"] = 0,
										["c_max"] = 519,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["c_min"] = 149,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 29,
										["MISS"] = 7,
										["total"] = 7343,
									},
									["出血"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 339,
										["g_amt"] = 0,
										["n_max"] = 254,
										["targets"] = {
											["安格弗将军"] = 2695,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2356,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 2695,
										["c_max"] = 339,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 339,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 293,
										["targets"] = {
											["安格弗将军"] = 293,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 293,
										["n_min"] = 293,
										["g_dmg"] = 0,
										["counter"] = 3,
										["a_amt"] = 0,
										["total"] = 293,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "还击",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["r_amt"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2160,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2160,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 2160,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 369,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 369,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 369,
										["c_max"] = 369,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 369,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 206,
										["targets"] = {
											["安格弗将军"] = 394,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 394,
										["n_min"] = 188,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 394,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 4650.003349,
							["start_time"] = 1592228922,
							["delay"] = 0,
							["end_time"] = 1592228997,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002019,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 4569,
								["花姐"] = 3392,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "安格弗将军",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 7961.002019,
							["serial"] = "Creature-0-4993-230-24069-9033-0000677B56",
							["monster"] = true,
							["total"] = 7961.002019,
							["damage_taken"] = 22364.002019,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 2042,
										["g_amt"] = 0,
										["n_max"] = 567,
										["targets"] = {
											["涛哥"] = 4569,
											["花姐"] = 3392,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5919,
										["g_dmg"] = 0,
										["n_min"] = 298,
										["MISS"] = 1,
										["counter"] = 43,
										["DODGE"] = 23,
										["r_amt"] = 0,
										["c_max"] = 1105,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 5,
										["c_min"] = 937,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 12,
										["a_amt"] = 0,
										["total"] = 7961,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592228997,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592228995,
							["friendlyfire"] = {
							},
							["start_time"] = 1592228929,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003044,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 81,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "铁怒预备兵",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 81.003044,
							["serial"] = "Creature-0-4993-230-24069-8901-0001677B56",
							["monster"] = true,
							["total"] = 81.003044,
							["damage_taken"] = 3566.003044,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 81,
										["targets"] = {
											["涛哥"] = 81,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 81,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 81,
										["c_max"] = 0,
										["DODGE"] = 15,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592228997,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592228943,
							["friendlyfire"] = {
							},
							["start_time"] = 1592228982,
							["delay"] = 1592228943,
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008703,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6606,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["on_hold"] = false,
							["friendlyfire_total"] = 1,
							["raid_targets"] = {
							},
							["total_without_pet"] = 6606.008703,
							["classe"] = "ROGUE",
							["dps_started"] = false,
							["total"] = 6606.008703,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 1,
									},
									["total"] = 1,
								},
							},
							["last_event"] = 1592228995,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["last_dps"] = 0,
							["spells"] = {
								["_ActorTable"] = {
									["偷袭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["IMMUNE"] = 1,
										["id"] = "偷袭",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 282,
										["targets"] = {
											["安格弗将军"] = 779,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 779,
										["n_min"] = 243,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 779,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 6,
										["b_amt"] = 0,
										["c_dmg"] = 1718,
										["g_amt"] = 0,
										["n_max"] = 189,
										["targets"] = {
											["安格弗将军"] = 3198,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1480,
										["g_dmg"] = 0,
										["n_min"] = 79,
										["a_amt"] = 0,
										["counter"] = 25,
										["MISS"] = 5,
										["r_amt"] = 0,
										["c_max"] = 464,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 180,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 12,
										["DODGE"] = 1,
										["total"] = 3198,
									},
									["邪恶攻击"] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 2224,
										["g_amt"] = 0,
										["n_max"] = 213,
										["targets"] = {
											["安格弗将军"] = 2629,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 405,
										["n_min"] = 192,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2629,
										["c_max"] = 693,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 469,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3393.008703,
							["start_time"] = 1592228968,
							["delay"] = 0,
							["end_time"] = 1592228997,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.00562,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "铁怒医师",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00562,
							["serial"] = "Creature-0-4993-230-24069-8894-0000E77C6E",
							["monster"] = true,
							["total"] = 0.00562,
							["damage_taken"] = 0.00562,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592228997,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1592228997,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 30,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["targets_overheal"] = {
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.004258,
							["total_without_pet"] = 2500.004258,
							["total"] = 2500.004258,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.004258,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2500,
							},
							["totalover_without_pet"] = 0.004258,
							["healing_taken"] = 2500.004258,
							["end_time"] = 1592228997,
							["boss_fight_component"] = true,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 2000,
										["n_amt"] = 8,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 500,
										},
										["n_min"] = 50,
										["counter"] = 10,
										["overheal"] = 0,
										["total"] = 500,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 500,
										["n_amt"] = 10,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["start_time"] = 1592228980,
							["custom"] = 0,
							["last_event"] = 1592228980,
							["classe"] = "ROGUE",
							["totaldenied"] = 0.004258,
							["delay"] = 1592228980,
							["spec"] = 261,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 30,
					["_ActorTable"] = {
						{
							["received"] = 25.002477,
							["resource"] = 0.002477,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 44.002477,
							["total"] = 25.002477,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.002477,
							["tipo"] = 3,
							["spec"] = 260,
							["last_event"] = 1592228982,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.002477,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 30,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["还击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = "还击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 60,
										["id"] = "致命毒药 IV",
										["refreshamt"] = 7,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 53,
										["id"] = "出血",
										["refreshamt"] = 9,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 26,
										["id"] = "新近包扎",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 61,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["剑刃乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "剑刃乱舞",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["急救"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 9,
										["id"] = "急救",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "切割",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "血牙",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 145,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 3,
								["刺骨"] = 3,
								["出血"] = 12,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592228996,
							["tipo"] = 4,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["断筋"] = 1,
								["打击"] = 4,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4993-230-24069-8901-0001E77B56",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 6,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4993-230-24069-9033-0000677B56",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 7,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 7,
									["actived_at"] = 1592228968,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4993-230-24069-9033-0000677B56",
							["last_event"] = 1592228968,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 14,
										["id"] = "破甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 16,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 14,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["闪避"] = 1,
								["偷袭"] = 1,
								["消失"] = 1,
								["破甲"] = 1,
								["邪恶攻击"] = 6,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592228996,
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["debuff_uptime_targets"] = {
							},
						}, -- [5]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 6,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4993-230-24069-8894-0000E77C6E",
							["classe"] = "UNKNOW",
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 30,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 356802.842,
				["tempo_start"] = 1592228922,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 60,
				["totals"] = {
					33971.909915, -- [1]
					2500, -- [2]
					{
						-0.00552800000000175, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					25931, -- [1]
					2500, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "21:49:58",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 13.3250000000116,
				["CombatEndedAt"] = 352198.296,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:48:42",
				["end_time"] = 352198.58,
				["combat_id"] = 30,
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["overall_added"] = true,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 26,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 352122.568,
				["contra"] = "安格弗将军",
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2500.004258,
						}, -- [1]
					},
					["damage"] = {
						{
							["涛哥"] = 19324.003349,
							["花姐"] = 6606.008703,
						}, -- [1]
					},
				},
			}, -- [13]
			{
				{
					["tipo"] = 2,
					["combatId"] = 28,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001703,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
								["铁怒医师"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 4026,
								["安格弗将军"] = 21702,
							},
							["serial"] = "Player-4920-01D0D553",
							["pets"] = {
							},
							["spec"] = 261,
							["friendlyfire"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 25728.001703,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 25728.001703,
							["on_hold"] = false,
							["last_event"] = 1592228217,
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 789,
										["targets"] = {
											["安格弗将军"] = 2474,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2474,
										["n_min"] = 201,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2474,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 444,
										["targets"] = {
											["铁怒预备兵"] = 3869,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3869,
										["n_min"] = 80,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 3869,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 25,
										["b_amt"] = 4,
										["c_dmg"] = 6983,
										["g_amt"] = 0,
										["n_max"] = 293,
										["targets"] = {
											["铁怒预备兵"] = 157,
											["安格弗将军"] = 11757,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4931,
										["DODGE"] = 1,
										["n_min"] = 59,
										["g_dmg"] = 0,
										["counter"] = 74,
										["MISS"] = 13,
										["r_amt"] = 0,
										["c_max"] = 564,
										["b_dmg"] = 422,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["c_min"] = 146,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 33,
										["a_amt"] = 0,
										["total"] = 11914,
									},
									["出血"] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 2074,
										["g_amt"] = 0,
										["n_max"] = 286,
										["targets"] = {
											["安格弗将军"] = 3681,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1607,
										["n_min"] = 175,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 3681,
										["c_max"] = 478,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 371,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 318,
										["targets"] = {
											["安格弗将军"] = 915,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 915,
										["n_min"] = 295,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 915,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 318,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2430,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2430,
										["n_min"] = 27,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 2430,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 20,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 213,
										["targets"] = {
											["安格弗将军"] = 213,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 213,
										["n_min"] = 213,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 213,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 232,
										["targets"] = {
											["安格弗将军"] = 232,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 232,
										["n_min"] = 232,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 232,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1592228222,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 6116.001703,
							["start_time"] = 1592228142,
							["delay"] = 1592228183,
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007527,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 2359,
								["花姐"] = 2039,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 4398.007527,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 4398.007527,
							["serial"] = "Creature-0-4888-230-25091-9033-000067782E",
							["monster"] = true,
							["end_time"] = 1592228222,
							["boss_fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "安格弗将军",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1437,
										["g_amt"] = 0,
										["n_max"] = 666,
										["targets"] = {
											["涛哥"] = 2359,
											["花姐"] = 2039,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2961,
										["g_dmg"] = 0,
										["n_min"] = 515,
										["a_amt"] = 0,
										["counter"] = 50,
										["MISS"] = 4,
										["r_amt"] = 0,
										["c_max"] = 1437,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 5,
										["c_min"] = 1437,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 5,
										["DODGE"] = 35,
										["total"] = 4398,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 7,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 9,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1592228214,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 28373.007527,
							["start_time"] = 1592228167,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001909,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 3158,
								["花姐"] = 1149,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 4307.001909,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 4307.001909,
							["serial"] = "Creature-0-4888-230-25091-8901-000067782E",
							["monster"] = true,
							["end_time"] = 1592228222,
							["boss_fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "铁怒预备兵",
							["spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 659,
										["g_amt"] = 0,
										["n_max"] = 117,
										["targets"] = {
											["涛哥"] = 2464,
											["花姐"] = 1149,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2954,
										["g_dmg"] = 0,
										["n_min"] = 70,
										["a_amt"] = 0,
										["counter"] = 91,
										["MISS"] = 7,
										["r_amt"] = 0,
										["c_max"] = 236,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 5,
										["c_min"] = 200,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 30,
										["DODGE"] = 46,
										["total"] = 3613,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 176,
										["targets"] = {
											["涛哥"] = 493,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 493,
										["n_min"] = 147,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 493,
										["c_max"] = 0,
										["DODGE"] = 9,
										["id"] = "打击",
										["r_dmg"] = 0,
										["MISS"] = 2,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 14,
										["m_amt"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 105,
										["targets"] = {
											["涛哥"] = 201,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 201,
										["n_min"] = 96,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 201,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["MISS"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1592228437,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 4026.001909,
							["start_time"] = 1592228185,
							["delay"] = 1592228151,
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006896,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
								["铁怒医师"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6671,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["spec"] = 260,
							["friendlyfire"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6671.006896,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 6671.006896,
							["on_hold"] = false,
							["last_event"] = 1592228214,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["绞喉"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 118,
										["targets"] = {
											["安格弗将军"] = 472,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 472,
										["n_min"] = 118,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 472,
										["c_max"] = 0,
										["id"] = "绞喉",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 7,
										["b_amt"] = 1,
										["c_dmg"] = 1788,
										["g_amt"] = 0,
										["n_max"] = 236,
										["targets"] = {
											["安格弗将军"] = 4610,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2822,
										["DODGE"] = 2,
										["n_min"] = 73,
										["g_dmg"] = 0,
										["counter"] = 31,
										["a_amt"] = 0,
										["r_amt"] = 0,
										["c_max"] = 445,
										["b_dmg"] = 157,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 179,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 19,
										["MISS"] = 2,
										["total"] = 4610,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 959,
										["g_amt"] = 0,
										["n_max"] = 217,
										["targets"] = {
											["安格弗将军"] = 1589,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 630,
										["n_min"] = 204,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1589,
										["c_max"] = 488,
										["DODGE"] = 1,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 471,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1592228222,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 4124.006896,
							["start_time"] = 1592228179,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001757,
							["damage_from"] = {
							},
							["targets"] = {
								["涛哥"] = 599,
								["花姐"] = 936,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 1535.001757,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1535.001757,
							["serial"] = "Creature-0-4888-230-25091-8894-0000E77957",
							["monster"] = true,
							["end_time"] = 1592228222,
							["boss_fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "铁怒医师",
							["spells"] = {
								["_ActorTable"] = {
									["心灵震爆"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 438,
										["targets"] = {
											["涛哥"] = 438,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 438,
										["n_min"] = 438,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 438,
										["c_max"] = 0,
										["id"] = "心灵震爆",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["RESIST"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 11,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 272,
										["targets"] = {
											["花姐"] = 936,
											["涛哥"] = 161,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1097,
										["g_dmg"] = 0,
										["n_min"] = 161,
										["a_amt"] = 0,
										["counter"] = 13,
										["MISS"] = 1,
										["r_amt"] = 0,
										["c_max"] = 0,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 5,
										["DODGE"] = 6,
										["total"] = 1097,
									},
									["治疗术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "治疗术",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1592228221,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 0.001757,
							["start_time"] = 1592228200,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 28,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 580.004228,
							["total_without_pet"] = 1741.004228,
							["total"] = 1741.004228,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.004228,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 1966,
							},
							["totalover_without_pet"] = 0.004228,
							["healing_taken"] = 1741.004228,
							["end_time"] = 1592228222,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
								["涛哥"] = 580,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 105,
										},
										["n_max"] = 89,
										["targets"] = {
											["涛哥"] = 166,
										},
										["n_min"] = 77,
										["counter"] = 3,
										["overheal"] = 105,
										["total"] = 166,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 166,
										["n_amt"] = 3,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 475,
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 1275,
										},
										["n_min"] = 0,
										["counter"] = 7,
										["overheal"] = 475,
										["total"] = 1275,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 1275,
										["n_amt"] = 7,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 6,
										["overheal"] = 0,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 300,
										["n_amt"] = 6,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1592228212,
							["start_time"] = 1592228207,
							["custom"] = 0,
							["tipo"] = 2,
							["heal_enemy_amt"] = 0,
							["totaldenied"] = 0.004228,
							["delay"] = 1592228212,
							["spec"] = 261,
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorb"] = 0.002604,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
							},
							["heal_enemy_amt"] = 5805,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.002604,
							["healing_from"] = {
							},
							["classe"] = "UNKNOW",
							["totalover"] = 0.002604,
							["total_without_pet"] = 0.002604,
							["iniciar_hps"] = false,
							["start_time"] = 1592228222,
							["monster"] = true,
							["end_time"] = 1592228222,
							["healing_taken"] = 0.002604,
							["nome"] = "铁怒医师",
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["total"] = 0.002604,
							["delay"] = 0,
							["heal_enemy"] = {
								["治疗术"] = 5805,
							},
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["totaldenied"] = 0.002604,
							["serial"] = "Creature-0-4888-230-25091-8894-0000E77957",
							["last_event"] = 1592228209,
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorb"] = 0.006401,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
							},
							["heal_enemy_amt"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.006401,
							["healing_from"] = {
							},
							["classe"] = "UNKNOW",
							["totalover"] = 0.006401,
							["total_without_pet"] = 0.006401,
							["iniciar_hps"] = false,
							["start_time"] = 1592228222,
							["monster"] = true,
							["end_time"] = 1592228222,
							["healing_taken"] = 0.006401,
							["nome"] = "安格弗将军",
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["total"] = 0.006401,
							["delay"] = 0,
							["heal_enemy"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["totaldenied"] = 0.006401,
							["serial"] = "Creature-0-4888-230-25091-9033-000067782E",
							["last_event"] = 0,
						}, -- [3]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 28,
					["_ActorTable"] = {
						{
							["received"] = 25.008779,
							["resource"] = 0.008779,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 154.008779,
							["total"] = 25.008779,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.008779,
							["tipo"] = 3,
							["spec"] = 260,
							["last_event"] = 1592228192,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.008779,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 28,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["还击"] = {
										["appliedamt"] = 3,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 18,
										["id"] = "还击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 62,
										["id"] = "致命毒药 IV",
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 57,
										["id"] = "出血",
										["refreshamt"] = 10,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 36,
										["id"] = "新近包扎",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 210,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "急救",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["神圣力量"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 41,
										["id"] = "神圣力量",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 25,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 92,
										["id"] = "敏捷",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "切割",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "血牙",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["消失"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = "消失",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["剑刃乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "剑刃乱舞",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 8,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 173,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["急救"] = 1,
								["伺机待发"] = 1,
								["闪避"] = 2,
								["剑刃乱舞"] = 1,
								["切割"] = 1,
								["还击"] = 3,
								["刺骨"] = 6,
								["出血"] = 12,
								["消失"] = 2,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592228222,
							["tipo"] = 4,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 4,
								["射击"] = 3,
								["断筋"] = 4,
								["打击"] = 14,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4888-230-25091-8901-000067782E",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 9,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4888-230-25091-9033-000067782E",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 23,
										["id"] = "破甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["绞喉"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 15,
										["id"] = "绞喉",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 18,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 3,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 38,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["绞喉"] = 1,
								["破甲"] = 1,
								["消失"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 6,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592228215,
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["debuff_uptime_targets"] = {
							},
						}, -- [4]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["心灵震爆"] = 2,
								["真言术：韧"] = 11,
								["治疗术"] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4888-230-25091-8894-0000E77957",
							["classe"] = "UNKNOW",
						}, -- [5]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 0,
									["actived_at"] = 1592228199,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4888-230-25091-9033-000067782E",
							["last_event"] = 1592228199,
						}, -- [6]
						{
							["flag_original"] = 2632,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 2,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["花姐"] = {
									["uptime"] = 2,
									["appliedamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "眩晕",
							["tipo"] = 4,
							["damage_twin"] = "铁怒医师",
							["damage_spellid"] = "眩晕",
							["serial"] = "Creature-0-4888-230-25091-8894-0000E77957",
							["last_event"] = 1592228221,
						}, -- [7]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 28,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 351637.122,
				["tempo_start"] = 1592228130,
				["last_events_tables"] = {
					{
						{
							{
								true, -- [1]
								"!Melee", -- [2]
								70, -- [3]
								1592228197.497, -- [4]
								1844, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [1]
							{
								true, -- [1]
								"!Melee", -- [2]
								96, -- [3]
								1592228218.489, -- [4]
								1806, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [2]
							{
								true, -- [1]
								"!Melee", -- [2]
								219, -- [3]
								1592228219.255, -- [4]
								1710, -- [5]
								"铁怒医师", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [3]
							{
								true, -- [1]
								"!Melee", -- [2]
								94, -- [3]
								1592228219.539, -- [4]
								1710, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [4]
							{
								true, -- [1]
								"!Melee", -- [2]
								100, -- [3]
								1592228219.606, -- [4]
								1710, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [5]
							{
								true, -- [1]
								"!Melee", -- [2]
								225, -- [3]
								1592228219.706, -- [4]
								1710, -- [5]
								"铁怒医师", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [6]
							{
								4, -- [1]
								"眩晕", -- [2]
								1, -- [3]
								1592228219.722, -- [4]
								1491, -- [5]
								"铁怒医师", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [7]
							{
								true, -- [1]
								"!Melee", -- [2]
								94, -- [3]
								1592228220.324, -- [4]
								1491, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [8]
							{
								true, -- [1]
								"!Melee", -- [2]
								105, -- [3]
								1592228220.525, -- [4]
								1072, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [9]
							{
								true, -- [1]
								"!Melee", -- [2]
								96, -- [3]
								1592228220.525, -- [4]
								1072, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [10]
							{
								true, -- [1]
								"!Melee", -- [2]
								92, -- [3]
								1592228220.525, -- [4]
								1072, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [11]
							{
								4, -- [1]
								"眩晕", -- [2]
								1, -- [3]
								1592228220.525, -- [4]
								978, -- [5]
								"铁怒预备兵", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [12]
							{
								4, -- [1]
								"眩晕", -- [2]
								1, -- [3]
								1592228220.525, -- [4]
								978, -- [5]
								"铁怒预备兵", -- [6]
								false, -- [7]
								false, -- [8]
								false, -- [9]
								false, -- [10]
							}, -- [13]
							{
								true, -- [1]
								"!Melee", -- [2]
								272, -- [3]
								1592228221.257, -- [4]
								685, -- [5]
								"铁怒医师", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [14]
							{
								true, -- [1]
								"!Melee", -- [2]
								98, -- [3]
								1592228221.558, -- [4]
								685, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [15]
							{
								true, -- [1]
								"!Melee", -- [2]
								104, -- [3]
								1592228221.624, -- [4]
								685, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [16]
							{
								true, -- [1]
								"!Melee", -- [2]
								200, -- [3]
								1592228221.624, -- [4]
								685, -- [5]
								"铁怒预备兵", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [17]
							{
								true, -- [1]
								"!Melee", -- [2]
								220, -- [3]
								1592228221.724, -- [4]
								685, -- [5]
								"铁怒医师", -- [6]
								nil, -- [7]
								1, -- [8]
								false, -- [9]
								-1, -- [10]
							}, -- [18]
							{
								3, -- [1]
								0, -- [2]
								0, -- [3]
								0, -- [4]
								0, -- [5]
								"花姐", -- [6]
							}, -- [19]
						}, -- [1]
						1592228222.158, -- [2]
						"花姐", -- [3]
						"ROGUE", -- [4]
						3883, -- [5]
						"1m 31s", -- [6]
						["dead_at"] = 91.2249999999767,
						["dead"] = true,
					}, -- [1]
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 58,
				["totals"] = {
					42639, -- [1]
					1741, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					32399, -- [1]
					1741, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 1,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "21:37:03",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 23.5100000000093,
				["CombatEndedAt"] = 351418.608,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:35:31",
				["end_time"] = 351422.66,
				["combat_id"] = 28,
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["overall_added"] = true,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 25,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 351330.635,
				["contra"] = "安格弗将军",
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 1741.004228,
						}, -- [1]
					},
					["damage"] = {
						{
							["涛哥"] = 25728.001703,
							["花姐"] = 6671.006896,
						}, -- [1]
					},
				},
			}, -- [14]
			{
				{
					["tipo"] = 2,
					["combatId"] = 27,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3570,
								["安格弗将军"] = 14403,
							},
							["serial"] = "Player-4920-01D0D553",
							["pets"] = {
							},
							["spec"] = 261,
							["total"] = 17973.003,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 17973.003,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592227731,
							["friendlyfire"] = {
							},
							["last_event"] = 1592227729,
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 833,
										["targets"] = {
											["安格弗将军"] = 833,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 833,
										["n_min"] = 833,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 833,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 473,
										["targets"] = {
											["铁怒预备兵"] = 3570,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3570,
										["n_min"] = 81,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 3570,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 11,
										["b_amt"] = 1,
										["c_dmg"] = 3022,
										["g_amt"] = 0,
										["n_max"] = 250,
										["targets"] = {
											["安格弗将军"] = 6731,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3709,
										["n_min"] = 69,
										["g_dmg"] = 0,
										["counter"] = 50,
										["DODGE"] = 3,
										["total"] = 6731,
										["c_max"] = 519,
										["MISS"] = 9,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 69,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 154,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 27,
										["spellschool"] = 1,
										["r_amt"] = 0,
									},
									["出血"] = {
										["c_amt"] = 3,
										["b_amt"] = 1,
										["c_dmg"] = 1348,
										["g_amt"] = 0,
										["n_max"] = 254,
										["targets"] = {
											["安格弗将军"] = 3118,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1770,
										["n_min"] = 186,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 3118,
										["c_max"] = 529,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 380,
										["successful_casted"] = 0,
										["b_dmg"] = 227,
										["n_amt"] = 8,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 351,
										["targets"] = {
											["安格弗将军"] = 351,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 351,
										["n_min"] = 351,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 351,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2268,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2268,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 2268,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 426,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 426,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 426,
										["c_max"] = 426,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 426,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 473,
										["g_amt"] = 0,
										["n_max"] = 203,
										["targets"] = {
											["安格弗将军"] = 676,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 203,
										["n_min"] = 203,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 676,
										["c_max"] = 473,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 473,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592227660,
							["delay"] = 0,
							["damage_taken"] = 2777.003,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007967,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 2777,
								["花姐"] = 3242,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "安格弗将军",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 6019.007967,
							["serial"] = "Creature-0-4888-230-24380-9033-000067764E",
							["monster"] = true,
							["total"] = 6019.007967,
							["end_time"] = 1592227731,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1317,
										["g_amt"] = 0,
										["n_max"] = 765,
										["targets"] = {
											["涛哥"] = 2777,
											["花姐"] = 3242,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4702,
										["g_dmg"] = 0,
										["n_min"] = 588,
										["a_amt"] = 0,
										["counter"] = 40,
										["MISS"] = 3,
										["r_amt"] = 0,
										["c_max"] = 1317,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 6,
										["c_min"] = 1317,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 7,
										["DODGE"] = 23,
										["total"] = 6019,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 0,
										["c_max"] = 0,
										["a_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 7,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1592227729,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 22317.007967,
							["start_time"] = 1592227689,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.001775,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "铁怒预备兵",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001775,
							["serial"] = "Creature-0-4888-230-24380-8901-000167764E",
							["monster"] = true,
							["total"] = 0.001775,
							["damage_taken"] = 3570.001775,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 3,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 16,
										["MISS"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 14,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592227731,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592227680,
							["friendlyfire"] = {
							},
							["start_time"] = 1592227731,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006797,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 7914,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["spec"] = 260,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 2,
									},
									["total"] = 2,
								},
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7914.006797,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 7914.006797,
							["on_hold"] = false,
							["last_event"] = 1592227729,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["割裂"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 110,
										["targets"] = {
											["安格弗将军"] = 440,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 440,
										["n_min"] = 110,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 440,
										["c_max"] = 0,
										["id"] = "割裂",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["绞喉"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 118,
										["targets"] = {
											["安格弗将军"] = 236,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 236,
										["n_min"] = 118,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 236,
										["c_max"] = 0,
										["id"] = "绞喉",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 9,
										["b_amt"] = 0,
										["c_dmg"] = 3204,
										["g_amt"] = 0,
										["n_max"] = 195,
										["targets"] = {
											["安格弗将军"] = 5042,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1838,
										["g_dmg"] = 0,
										["n_min"] = 85,
										["a_amt"] = 0,
										["counter"] = 30,
										["MISS"] = 5,
										["r_amt"] = 0,
										["c_max"] = 474,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 196,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 14,
										["DODGE"] = 1,
										["total"] = 5042,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1098,
										["g_amt"] = 0,
										["n_max"] = 270,
										["targets"] = {
											["安格弗将军"] = 2196,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1098,
										["n_min"] = 194,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 2196,
										["c_max"] = 581,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 517,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1592227731,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3244.006797,
							["start_time"] = 1592227697,
							["delay"] = 0,
							["friendlyfire_total"] = 2,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007252,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "铁怒医师",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007252,
							["serial"] = "Creature-0-4888-230-24380-8894-0000677784",
							["monster"] = true,
							["total"] = 0.007252,
							["damage_taken"] = 0.007252,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592227731,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1592227731,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 27,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 1301.008561,
							["total_without_pet"] = 1493.008561,
							["total"] = 1493.008561,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.008561,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 1550,
							},
							["totalover_without_pet"] = 0.008561,
							["healing_taken"] = 1493.008561,
							["end_time"] = 1592227731,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
								["涛哥"] = 1301,
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 194,
										},
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["n_min"] = 0,
										["counter"] = 2,
										["overheal"] = 194,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 0,
										["n_amt"] = 2,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 807,
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 1193,
										},
										["n_min"] = 0,
										["counter"] = 8,
										["overheal"] = 807,
										["total"] = 1193,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 1193,
										["n_amt"] = 8,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["涛哥"] = 300,
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 12,
										["overheal"] = 300,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 300,
										["n_amt"] = 12,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1592227728,
							["start_time"] = 1592227698,
							["custom"] = 0,
							["tipo"] = 2,
							["heal_enemy_amt"] = 0,
							["totaldenied"] = 0.008561,
							["delay"] = 1592227675,
							["spec"] = 261,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 27,
					["_ActorTable"] = {
						{
							["received"] = 50.003441,
							["resource"] = 0.003441,
							["targets"] = {
								["花姐"] = 50,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 16.003441,
							["total"] = 50.003441,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 50,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 50,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.003441,
							["tipo"] = 3,
							["spec"] = 260,
							["last_event"] = 1592227721,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.003441,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 27,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["新近包扎"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 29,
										["id"] = "新近包扎",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 56,
										["id"] = "致命毒药 IV",
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 50,
										["id"] = "出血",
										["refreshamt"] = 9,
										["actived"] = false,
										["counter"] = 0,
									},
									["还击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = "还击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 162,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["血牙"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 12,
										["id"] = "血牙",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["剑刃乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "剑刃乱舞",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["急救"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "急救",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 11,
										["id"] = "切割",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									["神圣力量"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 28,
										["id"] = "神圣力量",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 71,
										["id"] = "敏捷",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 141,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["刺骨"] = 2,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 2,
								["还击"] = 1,
								["消失"] = 1,
								["出血"] = 11,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592227731,
							["tipo"] = 4,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 1,
								["打击"] = 3,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4888-230-24380-8901-000167764E",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 7,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4888-230-24380-9033-000067764E",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 30,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 30,
									["actived_at"] = 1592227723,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4888-230-24380-9033-000067764E",
							["last_event"] = 1592227723,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["绞喉"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 9,
										["id"] = "绞喉",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["割裂"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 8,
										["id"] = "割裂",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["破甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 19,
										["id"] = "破甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 17,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 36,
							["buff_uptime_targets"] = {
							},
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["绞喉"] = 1,
								["邪恶攻击"] = 7,
								["破甲"] = 1,
								["消失"] = 1,
								["割裂"] = 1,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592227729,
							["tipo"] = 4,
							["nome"] = "花姐",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["debuff_uptime_targets"] = {
							},
						}, -- [5]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4888-230-24380-8894-0000677784",
							["classe"] = "UNKNOW",
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 27,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 351330.334,
				["tempo_start"] = 1592227660,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 57,
				["totals"] = {
					31906, -- [1]
					1493, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 50,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					25889, -- [1]
					1493, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 50,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "21:28:51",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 17.3720000000321,
				["CombatEndedAt"] = 350931.025,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:27:40",
				["end_time"] = 350931.508,
				["combat_id"] = 27,
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["overall_added"] = true,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 24,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 350860.505,
				["contra"] = "安格弗将军",
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 1493.008561,
						}, -- [1]
					},
					["damage"] = {
						{
							["涛哥"] = 17973.003,
							["花姐"] = 7914.006797,
						}, -- [1]
					},
				},
			}, -- [15]
			{
				{
					["tipo"] = 2,
					["combatId"] = 26,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.003301,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3806,
								["安格弗将军"] = 16658,
							},
							["serial"] = "Player-4920-01D0D553",
							["pets"] = {
							},
							["spec"] = 261,
							["friendlyfire"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 20464.003301,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 20464.003301,
							["on_hold"] = false,
							["last_event"] = 1592227247,
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1302,
										["g_amt"] = 0,
										["n_max"] = 770,
										["targets"] = {
											["安格弗将军"] = 2072,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 770,
										["n_min"] = 770,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2072,
										["c_max"] = 1302,
										["a_amt"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 1302,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 447,
										["targets"] = {
											["铁怒预备兵"] = 3806,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3806,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 3806,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 19,
										["b_amt"] = 2,
										["c_dmg"] = 5350,
										["g_amt"] = 0,
										["n_max"] = 267,
										["targets"] = {
											["安格弗将军"] = 8579,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3229,
										["g_dmg"] = 0,
										["n_min"] = 72,
										["MISS"] = 4,
										["counter"] = 52,
										["a_amt"] = 0,
										["r_amt"] = 0,
										["c_max"] = 453,
										["b_dmg"] = 328,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["c_min"] = 153,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 25,
										["DODGE"] = 2,
										["total"] = 8579,
									},
									["出血"] = {
										["c_amt"] = 3,
										["b_amt"] = 1,
										["c_dmg"] = 1246,
										["g_amt"] = 0,
										["n_max"] = 266,
										["targets"] = {
											["安格弗将军"] = 2998,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1752,
										["n_min"] = 175,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2998,
										["c_max"] = 453,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 346,
										["successful_casted"] = 0,
										["b_dmg"] = 223,
										["n_amt"] = 8,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 369,
										["targets"] = {
											["安格弗将军"] = 369,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 369,
										["n_min"] = 369,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 369,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 2214,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2214,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 2214,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 196,
										["targets"] = {
											["安格弗将军"] = 196,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 196,
										["n_min"] = 196,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 196,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 230,
										["targets"] = {
											["安格弗将军"] = 230,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 230,
										["n_min"] = 230,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 230,
										["c_max"] = 0,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1592227249,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 5076.003301,
							["start_time"] = 1592227179,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00717,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 5076,
								["花姐"] = 3421,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 8497.00717,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 8497.00717,
							["serial"] = "Creature-0-4993-230-17535-9033-00006773BB",
							["monster"] = true,
							["end_time"] = 1592227249,
							["boss_fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "安格弗将军",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 764,
										["targets"] = {
											["涛哥"] = 5076,
											["花姐"] = 3421,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 8497,
										["g_dmg"] = 0,
										["n_min"] = 467,
										["a_amt"] = 0,
										["counter"] = 39,
										["MISS"] = 4,
										["r_amt"] = 0,
										["c_max"] = 0,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 13,
										["DODGE"] = 20,
										["total"] = 8497,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 6,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 8,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1592227247,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 22289.00717,
							["start_time"] = 1592227203,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003303,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "铁怒预备兵",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.003303,
							["serial"] = "Creature-0-4993-230-17535-8901-00006773BB",
							["monster"] = true,
							["total"] = 0.003303,
							["damage_taken"] = 3806.003303,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["断筋"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "断筋",
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 16,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["DODGE"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592227249,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1592227199,
							["friendlyfire"] = {
							},
							["start_time"] = 1592227249,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001829,
							["damage_from"] = {
								["花姐"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 5631,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["spec"] = 260,
							["friendlyfire"] = {
								["花姐"] = {
									["spells"] = {
										["剑类武器专精"] = 2,
									},
									["total"] = 2,
								},
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5631.001829,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 5631.001829,
							["on_hold"] = false,
							["last_event"] = 1592227238,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 240,
										["targets"] = {
											["安格弗将军"] = 717,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 717,
										["n_min"] = 238,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 717,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 1524,
										["g_amt"] = 0,
										["n_max"] = 229,
										["targets"] = {
											["安格弗将军"] = 3745,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2221,
										["n_min"] = 80,
										["g_dmg"] = 0,
										["counter"] = 25,
										["DODGE"] = 1,
										["total"] = 3745,
										["c_max"] = 465,
										["a_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["c_min"] = 315,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 18,
										["spellschool"] = 1,
										["r_amt"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 517,
										["g_amt"] = 0,
										["n_max"] = 237,
										["targets"] = {
											["安格弗将军"] = 1169,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 652,
										["n_min"] = 204,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1169,
										["c_max"] = 517,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 517,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1592227249,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3423.001829,
							["start_time"] = 1592227224,
							["delay"] = 1592227238,
							["friendlyfire_total"] = 2,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007603,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "铁怒医师",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007603,
							["serial"] = "Creature-0-4993-230-17535-8894-0000E7759B",
							["monster"] = true,
							["total"] = 0.007603,
							["damage_taken"] = 0.007603,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592227249,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1592227249,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 26,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 0.002933,
							["total_without_pet"] = 2491.002933,
							["total"] = 2491.002933,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.002933,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2491,
							},
							["totalover_without_pet"] = 0.002933,
							["healing_taken"] = 2491.002933,
							["end_time"] = 1592227249,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 96,
										["targets"] = {
											["涛哥"] = 191,
										},
										["n_min"] = 95,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 191,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 191,
										["n_amt"] = 2,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 2000,
										["n_amt"] = 8,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 300,
										},
										["n_min"] = 50,
										["counter"] = 6,
										["overheal"] = 0,
										["total"] = 300,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 300,
										["n_amt"] = 6,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1592227243,
							["start_time"] = 1592227219,
							["custom"] = 0,
							["tipo"] = 2,
							["heal_enemy_amt"] = 0,
							["totaldenied"] = 0.002933,
							["delay"] = 0,
							["spec"] = 261,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 26,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 26,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["新近包扎"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 30,
										["id"] = "新近包扎",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 54,
										["id"] = "致命毒药 IV",
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 47,
										["id"] = "出血",
										["refreshamt"] = 9,
										["actived"] = false,
										["counter"] = 0,
									},
									["还击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 3,
										["id"] = "还击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 142,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["血牙"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 6,
										["id"] = "血牙",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["剑刃乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "剑刃乱舞",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["急救"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "急救",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = "切割",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 1,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["神圣力量"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "神圣力量",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 70,
										["id"] = "敏捷",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 134,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["消失"] = 1,
								["剑刃乱舞"] = 1,
								["急救"] = 1,
								["切割"] = 1,
								["还击"] = 1,
								["刺骨"] = 3,
								["出血"] = 11,
								["闪避"] = 1,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592227249,
							["tipo"] = 4,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 2,
								["断筋"] = 1,
								["打击"] = 1,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4993-230-17535-8901-00006773BB",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 8,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4993-230-17535-9033-00006773BB",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 30,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 30,
									["appliedamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["refreshamt"] = 0,
								},
								["花姐"] = {
									["uptime"] = 0,
									["actived_at"] = 1592227236,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4993-230-17535-9033-00006773BB",
							["last_event"] = 1592227236,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 22,
										["id"] = "破甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 25,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 10,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["消失"] = {
										["appliedamt"] = 0,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 0,
										["id"] = "消失",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 22,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["破甲"] = 1,
								["消失"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 4,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592227249,
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["debuff_uptime_targets"] = {
							},
						}, -- [5]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 4,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4993-230-17535-8894-0000E7759B",
							["classe"] = "UNKNOW",
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 26,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 350859.871,
				["tempo_start"] = 1592227179,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 56,
				["totals"] = {
					34592, -- [1]
					2491, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					26097, -- [1]
					2491, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 0,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "21:20:50",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 19.8349999999627,
				["CombatEndedAt"] = 350449.496,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:19:40",
				["end_time"] = 350450.047,
				["combat_id"] = 26,
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["overall_added"] = true,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 23,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 350380.038,
				["contra"] = "安格弗将军",
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2491.002933,
						}, -- [1]
					},
					["damage"] = {
						{
							["涛哥"] = 20464.003301,
							["花姐"] = 5631.001829,
						}, -- [1]
					},
				},
			}, -- [16]
			{
				{
					["tipo"] = 2,
					["combatId"] = 25,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005649,
							["damage_from"] = {
								["铁怒预备兵"] = true,
								["安格弗将军"] = true,
							},
							["targets"] = {
								["铁怒预备兵"] = 3756,
								["安格弗将军"] = 15432,
							},
							["serial"] = "Player-4920-01D0D553",
							["pets"] = {
							},
							["spec"] = 261,
							["total"] = 19188.005649,
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 19188.005649,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1592226584,
							["friendlyfire"] = {
							},
							["last_event"] = 1592226583,
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 790,
										["targets"] = {
											["安格弗将军"] = 1415,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1415,
										["n_min"] = 625,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1415,
										["c_max"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["剑刃乱舞"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 433,
										["targets"] = {
											["铁怒预备兵"] = 3756,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3756,
										["n_min"] = 49,
										["g_dmg"] = 0,
										["counter"] = 18,
										["total"] = 3756,
										["c_max"] = 0,
										["id"] = "剑刃乱舞",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 18,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 14,
										["b_amt"] = 1,
										["c_dmg"] = 3945,
										["g_amt"] = 0,
										["n_max"] = 279,
										["targets"] = {
											["安格弗将军"] = 7593,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3648,
										["n_min"] = 49,
										["g_dmg"] = 0,
										["counter"] = 49,
										["total"] = 7593,
										["c_max"] = 501,
										["MISS"] = 8,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 49,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 150,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 27,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["出血"] = {
										["c_amt"] = 4,
										["b_amt"] = 1,
										["c_dmg"] = 1602,
										["g_amt"] = 0,
										["n_max"] = 270,
										["targets"] = {
											["安格弗将军"] = 3161,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1559,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 3161,
										["c_max"] = 504,
										["id"] = "出血",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 346,
										["successful_casted"] = 0,
										["b_dmg"] = 236,
										["n_amt"] = 7,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["还击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 301,
										["targets"] = {
											["安格弗将军"] = 301,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 301,
										["n_min"] = 301,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 301,
										["c_max"] = 0,
										["id"] = "还击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["致命毒药 IV"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 135,
										["targets"] = {
											["安格弗将军"] = 1998,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1998,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 1998,
										["c_max"] = 0,
										["id"] = "致命毒药 IV",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 16,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 356,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["安格弗将军"] = 356,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 356,
										["c_max"] = 356,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 356,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 414,
										["g_amt"] = 0,
										["n_max"] = 194,
										["targets"] = {
											["安格弗将军"] = 608,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 194,
										["n_min"] = 194,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 608,
										["c_max"] = 414,
										["id"] = "血牙",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 414,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1592226514,
							["delay"] = 0,
							["damage_taken"] = 6173.005649,
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007762,
							["damage_from"] = {
								["涛哥"] = true,
								["花姐"] = true,
							},
							["targets"] = {
								["涛哥"] = 5658,
								["花姐"] = 3336,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "安格弗将军",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 8994.007762,
							["serial"] = "Creature-0-4502-230-16586-9033-0000677190",
							["monster"] = true,
							["total"] = 8994.007762,
							["end_time"] = 1592226584,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 4,
										["b_amt"] = 0,
										["c_dmg"] = 4747,
										["g_amt"] = 0,
										["n_max"] = 720,
										["targets"] = {
											["涛哥"] = 5658,
											["花姐"] = 3336,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4247,
										["n_min"] = 469,
										["g_dmg"] = 0,
										["counter"] = 40,
										["a_amt"] = 0,
										["total"] = 8994,
										["c_max"] = 1474,
										["DODGE"] = 27,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["c_min"] = 906,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 7,
										["spellschool"] = 1,
										["r_amt"] = 0,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
											["花姐"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 0,
										["c_max"] = 0,
										["MISS"] = 1,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["DODGE"] = 4,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 6,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1592226582,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 22354.007762,
							["start_time"] = 1592226542,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.002382,
							["damage_from"] = {
								["涛哥"] = true,
							},
							["targets"] = {
								["涛哥"] = 515,
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["total"] = 515.002382,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 515.002382,
							["serial"] = "Creature-0-4502-230-16586-8901-0000E77190",
							["monster"] = true,
							["end_time"] = 1592226584,
							["boss_fight_component"] = true,
							["on_hold"] = false,
							["nome"] = "铁怒预备兵",
							["spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "战斗怒吼",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 110,
										["targets"] = {
											["涛哥"] = 515,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 515,
										["n_min"] = 87,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 515,
										["c_max"] = 0,
										["id"] = "射击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 5,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 11,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["涛哥"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["DODGE"] = 1,
										["id"] = "打击",
										["r_dmg"] = 0,
										["MISS"] = 1,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["m_amt"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1592226534,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3756.002382,
							["start_time"] = 1592226571,
							["delay"] = 1592226534,
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007027,
							["damage_from"] = {
								["安格弗将军"] = true,
							},
							["targets"] = {
								["安格弗将军"] = 6922,
							},
							["serial"] = "Player-4920-01D0BF72",
							["pets"] = {
							},
							["spec"] = 260,
							["friendlyfire"] = {
							},
							["classe"] = "ROGUE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6922.007027,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 6922.007027,
							["on_hold"] = false,
							["last_event"] = 1592226583,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["绞喉"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 118,
										["targets"] = {
											["安格弗将军"] = 354,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 354,
										["n_min"] = 118,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 354,
										["c_max"] = 0,
										["id"] = "绞喉",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["闪电攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 299,
										["targets"] = {
											["安格弗将军"] = 548,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 548,
										["n_min"] = 249,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 548,
										["c_max"] = 0,
										["id"] = "闪电攻击",
										["r_dmg"] = 0,
										["spellschool"] = 8,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 10,
										["b_amt"] = 1,
										["c_dmg"] = 2451,
										["g_amt"] = 0,
										["n_max"] = 216,
										["targets"] = {
											["安格弗将军"] = 4282,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1831,
										["n_min"] = 76,
										["g_dmg"] = 0,
										["counter"] = 27,
										["total"] = 4282,
										["c_max"] = 391,
										["MISS"] = 4,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["b_dmg"] = 76,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 158,
										["successful_casted"] = 0,
										["m_amt"] = 0,
										["n_amt"] = 13,
										["a_dmg"] = 0,
										["r_amt"] = 0,
									},
									["邪恶攻击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 535,
										["g_amt"] = 0,
										["n_max"] = 274,
										["targets"] = {
											["安格弗将军"] = 1738,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1203,
										["n_min"] = 227,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1738,
										["c_max"] = 535,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["spellschool"] = 1,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 535,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1592226584,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 3336.007027,
							["start_time"] = 1592226553,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
						}, -- [4]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.005775,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["dps_started"] = false,
							["nome"] = "铁怒医师",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005775,
							["serial"] = "Creature-0-4502-230-16586-8894-0000677303",
							["monster"] = true,
							["total"] = 0.005775,
							["damage_taken"] = 0.005775,
							["on_hold"] = false,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["真言术：韧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "真言术：韧",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 6,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_amt"] = 0,
										["r_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["end_time"] = 1592226584,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["friendlyfire"] = {
							},
							["start_time"] = 1592226584,
							["delay"] = 0,
							["classe"] = "UNKNOW",
						}, -- [5]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 25,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["涛哥"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "ROGUE",
							["totalover"] = 0.003211,
							["total_without_pet"] = 2550.003211,
							["total"] = 2550.003211,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0D553",
							["totalabsorb"] = 0.003211,
							["last_hps"] = 0,
							["targets"] = {
								["涛哥"] = 2550,
							},
							["totalover_without_pet"] = 0.003211,
							["healing_taken"] = 2550.003211,
							["end_time"] = 1592226584,
							["boss_fight_component"] = true,
							["targets_overheal"] = {
							},
							["nome"] = "涛哥",
							["spells"] = {
								["_ActorTable"] = {
									["急救"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 250,
										["targets"] = {
											["涛哥"] = 2000,
										},
										["n_min"] = 250,
										["counter"] = 8,
										["overheal"] = 0,
										["total"] = 2000,
										["c_max"] = 0,
										["id"] = "急救",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 2000,
										["n_amt"] = 8,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
									["血牙"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 50,
										["targets"] = {
											["涛哥"] = 550,
										},
										["n_min"] = 50,
										["counter"] = 11,
										["overheal"] = 0,
										["total"] = 550,
										["c_max"] = 0,
										["id"] = "血牙",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["n_curado"] = 550,
										["n_amt"] = 11,
										["m_healed"] = 0,
										["totaldenied"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 1592226566,
							["start_time"] = 1592226566,
							["custom"] = 0,
							["tipo"] = 2,
							["heal_enemy_amt"] = 0,
							["totaldenied"] = 0.003211,
							["delay"] = 1592226566,
							["spec"] = 261,
						}, -- [1]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 25,
					["_ActorTable"] = {
						{
							["received"] = 25.006312,
							["resource"] = 0.006312,
							["targets"] = {
								["花姐"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 20.006312,
							["total"] = 25.006312,
							["nome"] = "花姐",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["花姐"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["flag_original"] = 1298,
							["alternatepower"] = 0.006312,
							["tipo"] = 3,
							["spec"] = 260,
							["last_event"] = 1592226567,
							["serial"] = "Player-4920-01D0BF72",
							["totalover"] = 0.006312,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 25,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["还击"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 6,
										["id"] = "还击",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["致命毒药 IV"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 52,
										["id"] = "致命毒药 IV",
										["refreshamt"] = 8,
										["actived"] = false,
										["counter"] = 0,
									},
									["出血"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 48,
										["id"] = "出血",
										["refreshamt"] = 9,
										["actived"] = false,
										["counter"] = 0,
									},
									["新近包扎"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 26,
										["id"] = "新近包扎",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 137,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["剑刃乱舞"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "剑刃乱舞",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["急救"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 8,
										["id"] = "急救",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["切割"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 12,
										["id"] = "切割",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["血牙"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 11,
										["id"] = "血牙",
										["refreshamt"] = 1,
										["actived"] = false,
										["counter"] = 0,
									},
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["敏捷"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 70,
										["id"] = "敏捷",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 2,
										["targets"] = {
										},
										["activedamt"] = 2,
										["uptime"] = 19,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 132,
							["buff_uptime_targets"] = {
							},
							["spec"] = 261,
							["grupo"] = true,
							["spell_cast"] = {
								["急救"] = 1,
								["伺机待发"] = 1,
								["闪避"] = 2,
								["剑刃乱舞"] = 1,
								["切割"] = 1,
								["还击"] = 1,
								["刺骨"] = 2,
								["出血"] = 11,
								["消失"] = 1,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592226584,
							["tipo"] = 4,
							["nome"] = "涛哥",
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0D553",
							["debuff_uptime_targets"] = {
							},
						}, -- [1]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒预备兵",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 2,
								["射击"] = 5,
								["打击"] = 2,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4502-230-16586-8901-0000E77190",
							["classe"] = "UNKNOW",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["nome"] = "安格弗将军",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["破甲攻击"] = 6,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4502-230-16586-9033-0000677190",
							["classe"] = "UNKNOW",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 16,
										["id"] = "破甲",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["绞喉"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 0,
										["uptime"] = 9,
										["id"] = "绞喉",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 17,
							["classe"] = "ROGUE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["潜行"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 2,
										["id"] = "潜行",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
									["闪避"] = {
										["appliedamt"] = 1,
										["targets"] = {
										},
										["activedamt"] = 1,
										["uptime"] = 15,
										["id"] = "闪避",
										["refreshamt"] = 0,
										["actived"] = false,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 25,
							["nome"] = "花姐",
							["spec"] = 260,
							["grupo"] = true,
							["spell_cast"] = {
								["绞喉"] = 1,
								["破甲"] = 1,
								["消失"] = 1,
								["闪避"] = 1,
								["邪恶攻击"] = 6,
							},
							["boss_fight_component"] = true,
							["last_event"] = 1592226583,
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["serial"] = "Player-4920-01D0BF72",
							["debuff_uptime_targets"] = {
							},
						}, -- [4]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 1,
							["debuff_uptime_targets"] = {
								["涛哥"] = {
									["uptime"] = 0,
									["actived_at"] = 1592226554,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["refreshamt"] = 0,
								},
							},
							["boss_fight_component"] = true,
							["nome"] = "破甲攻击",
							["tipo"] = 4,
							["damage_twin"] = "安格弗将军",
							["damage_spellid"] = "破甲攻击",
							["serial"] = "Creature-0-4502-230-16586-9033-0000677190",
							["last_event"] = 1592226554,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["tipo"] = 4,
							["nome"] = "铁怒医师",
							["pets"] = {
							},
							["boss_fight_component"] = true,
							["spell_cast"] = {
								["真言术：韧"] = 6,
							},
							["last_event"] = 0,
							["monster"] = true,
							["serial"] = "Creature-0-4502-230-16586-8894-0000677303",
							["classe"] = "UNKNOW",
						}, -- [6]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 25,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["花姐"] = true,
					["涛哥"] = true,
				},
				["CombatStartedAt"] = 350379.455,
				["tempo_start"] = 1592226514,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 55,
				["totals"] = {
					35618.992276, -- [1]
					2550, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
					["frags_total"] = 0,
					["voidzone_damage"] = 0,
				},
				["totals_grupo"] = {
					26110, -- [1]
					2550, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[3] = 25,
						[6] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["cooldowns_defensive"] = 0,
						["dispell"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["cc_break"] = 0,
						["dead"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "21:09:45",
				["cleu_timeline"] = {
				},
				["enemy"] = "安格弗将军",
				["TotalElapsedCombatTime"] = 13.3630000000121,
				["CombatEndedAt"] = 349784.617,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:08:35",
				["end_time"] = 349784.983,
				["combat_id"] = 25,
				["frags"] = {
					["铁怒预备兵"] = 4,
					["安格弗将军"] = 1,
				},
				["overall_added"] = true,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石深渊",
					["encounter"] = "安格弗将军",
					["mapid"] = 230,
					["try_number"] = 22,
					["name"] = "安格弗将军",
					["id"] = 0,
					["ej_instance_id"] = 0,
					["diff"] = 16,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 349714.976,
				["contra"] = "安格弗将军",
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage_section"] = {
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["涛哥"] = 2550.003211,
						}, -- [1]
					},
					["damage"] = {
						{
							["涛哥"] = 19188.005649,
							["花姐"] = 6922.007027,
						}, -- [1]
					},
				},
			}, -- [17]
		},
	},
	["last_version"] = "v1.13.3.199",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["last_version"] = 11,
		["火焰冰激凌"] = {
			"火焰冰激凌", -- [1]
			"Interface\\EncounterJournal\\UI-EJ-BOSS-Grand Magus Telestra", -- [2]
			{
				0, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			}, -- [3]
			"Interface\\PetBattles\\Weather-Sunlight", -- [4]
			{
				0.1772721, -- [1]
				0.953125, -- [2]
				1, -- [3]
				0, -- [4]
			}, -- [5]
			{
				1, -- [1]
				1, -- [2]
				1, -- [3]
			}, -- [6]
			3, -- [7]
		},
		["nextreset"] = 1593500734,
	},
	["last_instance_id"] = 230,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 1592255689,
	["active_profile"] = "涛哥-龙牙",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 0.2,
			["animate"] = false,
			["showamount"] = false,
			["useplayercolor"] = false,
			["useclasscolors"] = false,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["enabled"] = true,
		},
	},
	["cached_talents"] = {
		["Player-4920-01D0D553"] = {
			{
				132292, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [1]
			{
				132151, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [2]
			{
				132277, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [3]
			{
				132122, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [4]
			{
				136147, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [5]
			{
				132306, -- [1]
				0, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [6]
			{
				132340, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [7]
			{
				132354, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [8]
			{
				132109, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [9]
			{
				132293, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [10]
			{
				132273, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [11]
			{
				135988, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [12]
			{
				132298, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [13]
			{
				136130, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136023, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [15]
			{
				132155, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [16]
			{
				136189, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [17]
			{
				136047, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [18]
			{
				132090, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [19]
			{
				132269, -- [1]
				5, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [20]
			{
				132222, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [21]
			{
				136205, -- [1]
				2, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [22]
			{
				132336, -- [1]
				1, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [23]
			{
				132307, -- [1]
				0, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [24]
			{
				132219, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [25]
			{
				135641, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [26]
			{
				132147, -- [1]
				4, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [27]
			{
				133476, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [28]
			{
				132350, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [29]
			{
				135328, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [30]
			{
				132938, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [31]
			{
				135882, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [32]
			{
				132275, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [33]
			{
				136206, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [34]
			{
				136129, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [35]
			{
				132366, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [36]
			{
				132294, -- [1]
				2, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [37]
			{
				135994, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [38]
			{
				132320, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [39]
			{
				136159, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [40]
			{
				136136, -- [1]
				1, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [41]
			{
				132282, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [42]
			{
				136056, -- [1]
				3, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [43]
			{
				132310, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [44]
			{
				135315, -- [1]
				3, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [45]
			{
				132089, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [46]
			{
				136121, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [47]
			{
				136220, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [48]
			{
				136168, -- [1]
				1, -- [2]
				5, -- [3]
				4, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [49]
			{
				135540, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [50]
			{
				136183, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [51]
		},
		["Player-4920-01D0BF72"] = {
			{
				132292, -- [1]
				0, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [1]
			{
				132151, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [2]
			{
				132277, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [3]
			{
				132122, -- [1]
				3, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [4]
			{
				136147, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [5]
			{
				132306, -- [1]
				3, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [6]
			{
				132340, -- [1]
				1, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [7]
			{
				132354, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				2, -- [7]
			}, -- [8]
			{
				132109, -- [1]
				5, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [9]
			{
				132293, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [10]
			{
				132273, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [11]
			{
				135988, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [12]
			{
				132298, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				1, -- [5]
				259, -- [6]
				3, -- [7]
			}, -- [13]
			{
				136130, -- [1]
				0, -- [2]
				6, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				5, -- [7]
			}, -- [14]
			{
				136023, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				259, -- [6]
				1, -- [7]
			}, -- [15]
			{
				132155, -- [1]
				3, -- [2]
				1, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [16]
			{
				136189, -- [1]
				2, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [17]
			{
				136047, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [18]
			{
				132090, -- [1]
				1, -- [2]
				2, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [19]
			{
				132269, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [20]
			{
				132222, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [21]
			{
				136205, -- [1]
				2, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [22]
			{
				132336, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [23]
			{
				132307, -- [1]
				2, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [24]
			{
				132219, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [25]
			{
				135641, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [26]
			{
				132147, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [27]
			{
				133476, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [28]
			{
				132350, -- [1]
				1, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [29]
			{
				135328, -- [1]
				5, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [30]
			{
				132938, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				2, -- [5]
				260, -- [6]
				5, -- [7]
			}, -- [31]
			{
				135882, -- [1]
				2, -- [2]
				6, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				2, -- [7]
			}, -- [32]
			{
				132275, -- [1]
				3, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				260, -- [6]
				3, -- [7]
			}, -- [33]
			{
				136206, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				260, -- [6]
				1, -- [7]
			}, -- [34]
			{
				136129, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [35]
			{
				132366, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [36]
			{
				132294, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [37]
			{
				135994, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [38]
			{
				132320, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [39]
			{
				136159, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [40]
			{
				136136, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [41]
			{
				132282, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [42]
			{
				136056, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [43]
			{
				132310, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [44]
			{
				135315, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				3, -- [7]
			}, -- [45]
			{
				132089, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [46]
			{
				136121, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [47]
			{
				136220, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				2, -- [7]
			}, -- [48]
			{
				136168, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [49]
			{
				135540, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				261, -- [6]
				5, -- [7]
			}, -- [50]
			{
				136183, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				261, -- [6]
				1, -- [7]
			}, -- [51]
		},
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["last_day"] = "16",
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["last_realversion"] = 142,
	["combat_id"] = 43,
	["savedStyles"] = {
	},
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_counter"] = 75,
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.207522,
					["damage_from"] = {
						["铁怒医师"] = true,
						["征服者派隆"] = true,
						["铁怒队长"] = true,
						["铁怒预备兵"] = true,
						["厄炉龙骑兵"] = true,
						["火焰驱逐者"] = true,
						["炽热火焰卫士"] = true,
						["安格弗将军"] = true,
					},
					["targets"] = {
						["给我一口奶喝"] = 0,
						["辛迪亚兄弟会"] = 1922,
						["征服者派隆"] = 8403,
						["铁怒预备兵"] = 128523,
						["安格弗将军"] = 552494,
						["炽热火焰卫士"] = 12532,
						["铁怒医师"] = 6738,
					},
					["on_hold"] = false,
					["pets"] = {
					},
					["serial"] = "Player-4920-01D0D553",
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 710612.207522,
					["boss_fight_component"] = true,
					["damage_taken"] = 185488.207522,
					["dps_started"] = false,
					["total"] = 710612.207522,
					["classe"] = "ROGUE",
					["end_time"] = 1592207086,
					["nome"] = "涛哥",
					["spells"] = {
						["_ActorTable"] = {
							["脚踢"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 123,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["炽热火焰卫士"] = 123,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 123,
								["c_max"] = 123,
								["id"] = "脚踢",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["速效毒药 VI"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 148,
								["targets"] = {
									["铁怒预备兵"] = 616,
									["安格弗将军"] = 35617,
									["炽热火焰卫士"] = 0,
									["铁怒医师"] = 611,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 36844,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 299,
								["total"] = 36844,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = "速效毒药 VI",
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 285,
								["m_crit"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["m_amt"] = 0,
								["RESIST"] = 1,
								["r_amt"] = 0,
								["IMMUNE"] = 13,
							},
							["鬼魅攻击"] = {
								["c_amt"] = 2,
								["b_amt"] = 1,
								["c_dmg"] = 1011,
								["g_amt"] = 0,
								["n_max"] = 294,
								["targets"] = {
									["安格弗将军"] = 3031,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2020,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 10,
								["total"] = 3031,
								["c_max"] = 540,
								["id"] = "鬼魅攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 190,
								["n_amt"] = 8,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["血牙"] = {
								["c_amt"] = 21,
								["b_amt"] = 5,
								["c_dmg"] = 8422,
								["g_amt"] = 0,
								["n_max"] = 258,
								["targets"] = {
									["铁怒预备兵"] = 559,
									["安格弗将军"] = 15760,
									["征服者派隆"] = 460,
									["铁怒医师"] = 475,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8832,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 68,
								["total"] = 17254,
								["c_max"] = 475,
								["id"] = "血牙",
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 3,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 974,
								["n_amt"] = 44,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["致命毒药 IV"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 135,
								["targets"] = {
									["征服者派隆"] = 0,
									["辛迪亚兄弟会"] = 81,
									["安格弗将军"] = 29943,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 30024,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 258,
								["total"] = 30024,
								["c_max"] = 0,
								["IMMUNE"] = 14,
								["id"] = "致命毒药 IV",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 242,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 2,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["剑刃乱舞"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1321,
								["targets"] = {
									["铁怒预备兵"] = 118849,
									["安格弗将军"] = 849,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 119698,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 566,
								["total"] = 119698,
								["c_max"] = 0,
								["id"] = "剑刃乱舞",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 566,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 512,
								["b_amt"] = 48,
								["c_dmg"] = 145134,
								["g_amt"] = 0,
								["n_max"] = 293,
								["targets"] = {
									["铁怒医师"] = 3094,
									["辛迪亚兄弟会"] = 1098,
									["铁怒预备兵"] = 4222,
									["安格弗将军"] = 270052,
									["炽热火焰卫士"] = 7770,
									["征服者派隆"] = 4370,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 145472,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1944,
								["a_amt"] = 0,
								["r_amt"] = 0,
								["c_max"] = 564,
								["MISS"] = 242,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 4461,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 48,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["c_min"] = 0,
								["n_amt"] = 1079,
								["DODGE"] = 63,
								["total"] = 290606,
							},
							["!Autoshot"] = {
								["c_amt"] = 7,
								["b_amt"] = 1,
								["c_dmg"] = 2690,
								["g_amt"] = 0,
								["n_max"] = 213,
								["targets"] = {
									["征服者派隆"] = 412,
									["安格弗将军"] = 7923,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 5645,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 36,
								["total"] = 8335,
								["c_max"] = 426,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 170,
								["n_amt"] = 29,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["还击"] = {
								["c_amt"] = 13,
								["b_amt"] = 2,
								["c_dmg"] = 7880,
								["g_amt"] = 0,
								["n_max"] = 399,
								["targets"] = {
									["铁怒预备兵"] = 972,
									["安格弗将军"] = 18076,
									["炽热火焰卫士"] = 300,
									["铁怒医师"] = 1153,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 12621,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 59,
								["total"] = 20501,
								["c_max"] = 754,
								["r_amt"] = 0,
								["id"] = "还击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 547,
								["n_amt"] = 41,
								["a_amt"] = 0,
								["DODGE"] = 3,
							},
							["刺骨"] = {
								["c_amt"] = 21,
								["b_amt"] = 2,
								["c_dmg"] = 26107,
								["g_amt"] = 0,
								["n_max"] = 833,
								["targets"] = {
									["铁怒医师"] = 372,
									["安格弗将军"] = 71000,
									["炽热火焰卫士"] = 1102,
									["征服者派隆"] = 1402,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 47769,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 107,
								["total"] = 73876,
								["c_max"] = 1601,
								["a_amt"] = 0,
								["id"] = "刺骨",
								["r_dmg"] = 0,
								["DODGE"] = 7,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 4,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 1585,
								["n_amt"] = 75,
								["a_dmg"] = 0,
								["r_amt"] = 0,
							},
							["出血"] = {
								["c_amt"] = 107,
								["b_amt"] = 17,
								["c_dmg"] = 44920,
								["g_amt"] = 0,
								["n_max"] = 299,
								["targets"] = {
									["铁怒医师"] = 1033,
									["辛迪亚兄弟会"] = 743,
									["铁怒预备兵"] = 3305,
									["安格弗将军"] = 100243,
									["炽热火焰卫士"] = 3063,
									["征服者派隆"] = 1759,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 65226,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 441,
								["total"] = 110146,
								["c_max"] = 543,
								["DODGE"] = 10,
								["id"] = "出血",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 11,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 3186,
								["n_amt"] = 313,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["凿击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 116,
								["g_amt"] = 0,
								["n_max"] = 58,
								["targets"] = {
									["给我一口奶喝"] = 0,
									["炽热火焰卫士"] = 174,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 58,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 174,
								["c_max"] = 116,
								["id"] = "凿击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["spec"] = 261,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592204704,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [1]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.18828,
					["damage_from"] = {
						["涛哥"] = true,
						["花姐"] = true,
					},
					["targets"] = {
						["涛哥"] = 157261,
						["花姐"] = 77340,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 234601.18828,
					["monster"] = true,
					["last_event"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592207086,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 37,
								["b_amt"] = 0,
								["c_dmg"] = 43153,
								["g_amt"] = 0,
								["n_max"] = 817,
								["targets"] = {
									["涛哥"] = 157261,
									["花姐"] = 77340,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 191448,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1428,
								["a_amt"] = 0,
								["r_amt"] = 0,
								["c_max"] = 1506,
								["DODGE"] = 871,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 95,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["c_min"] = 0,
								["n_amt"] = 338,
								["MISS"] = 87,
								["total"] = 234601,
							},
							["破甲攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
									["花姐"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 177,
								["DODGE"] = 138,
								["total"] = 0,
								["c_max"] = 0,
								["MISS"] = 20,
								["id"] = "破甲攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 19,
								["m_amt"] = 0,
								["successful_casted"] = 237,
								["c_min"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["b_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["total"] = 234601.18828,
					["serial"] = "Creature-0-5002-230-9519-9033-00006725BB",
					["nome"] = "安格弗将军",
					["damage_taken"] = 719380.18828,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1592205328,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [2]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.17567,
					["damage_from"] = {
						["涛哥"] = true,
					},
					["targets"] = {
						["涛哥"] = 16329,
						["花姐"] = 2032,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 18361.17567,
					["serial"] = "Creature-0-5002-230-9519-8901-00016725BB",
					["nome"] = "铁怒预备兵",
					["dps_started"] = false,
					["total"] = 18361.17567,
					["damage_taken"] = 128523.17567,
					["monster"] = true,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["战斗怒吼"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "战斗怒吼",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 37,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 8,
								["b_amt"] = 0,
								["c_dmg"] = 1464,
								["g_amt"] = 0,
								["n_max"] = 117,
								["targets"] = {
									["涛哥"] = 7811,
									["花姐"] = 1779,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8126,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 774,
								["a_amt"] = 0,
								["total"] = 9590,
								["c_max"] = 236,
								["DODGE"] = 601,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 32,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["c_min"] = 0,
								["n_amt"] = 90,
								["r_amt"] = 0,
								["MISS"] = 43,
							},
							["断筋"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 140,
								["targets"] = {
									["涛哥"] = 278,
									["花姐"] = 109,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 387,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 25,
								["MISS"] = 1,
								["total"] = 387,
								["c_max"] = 0,
								["DODGE"] = 19,
								["id"] = "断筋",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 25,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 176,
								["targets"] = {
									["涛哥"] = 1987,
									["花姐"] = 144,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2131,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 119,
								["DODGE"] = 93,
								["total"] = 2131,
								["c_max"] = 0,
								["a_dmg"] = 0,
								["id"] = "打击",
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 3,
								["m_amt"] = 0,
								["successful_casted"] = 120,
								["c_min"] = 0,
								["n_amt"] = 14,
								["r_amt"] = 0,
								["MISS"] = 9,
							},
							["射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 110,
								["targets"] = {
									["涛哥"] = 6253,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6253,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 69,
								["total"] = 6253,
								["c_max"] = 0,
								["id"] = "射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 69,
								["b_dmg"] = 0,
								["n_amt"] = 64,
								["a_dmg"] = 0,
								["MISS"] = 5,
							},
						},
						["tipo"] = 2,
					},
					["fight_component"] = true,
					["end_time"] = 1592207086,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1592206632,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [3]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.172537,
					["damage_from"] = {
						["涛哥"] = true,
					},
					["targets"] = {
						["花姐"] = 1205,
						["涛哥"] = 3352,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 4557.172537,
					["serial"] = "Creature-0-5002-230-9519-8894-00006726CE",
					["boss_fight_component"] = true,
					["dps_started"] = false,
					["total"] = 4557.172537,
					["last_dps"] = 0,
					["fight_component"] = true,
					["nome"] = "铁怒医师",
					["spells"] = {
						["_ActorTable"] = {
							["心灵震爆"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 476,
								["targets"] = {
									["涛哥"] = 2151,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2151,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 2151,
								["c_max"] = 0,
								["id"] = "心灵震爆",
								["r_dmg"] = 329,
								["r_amt"] = 1,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["RESIST"] = 2,
								["c_min"] = 0,
								["successful_casted"] = 8,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["真言术：韧"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "真言术：韧",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 178,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 272,
								["targets"] = {
									["涛哥"] = 1201,
									["花姐"] = 1205,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2406,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 29,
								["a_amt"] = 0,
								["total"] = 2406,
								["c_max"] = 0,
								["MISS"] = 1,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 11,
								["a_dmg"] = 0,
								["DODGE"] = 16,
							},
							["治疗术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 4,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["monster"] = true,
					["end_time"] = 1592207086,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 6738.172537,
					["start_time"] = 1592207037,
					["delay"] = 0,
					["on_hold"] = false,
				}, -- [4]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.004147,
					["damage_from"] = {
					},
					["targets"] = {
						["涛哥"] = 0,
						["残尘"] = 0,
						["老头子"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004147,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592207199,
					["delay"] = 0,
					["last_dps"] = 0,
					["nome"] = "给我一口奶喝",
					["spells"] = {
						["_ActorTable"] = {
							["火焰冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火焰冲击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰霜新星"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰霜新星",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
									["残尘"] = 0,
									["老头子"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["闪现术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "闪现术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰锥术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰锥术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.004147,
					["on_hold"] = false,
					["total"] = 0.004147,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592207196,
					["serial"] = "Player-4920-02789A12",
					["fight_component"] = true,
				}, -- [5]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.006414,
					["damage_from"] = {
					},
					["targets"] = {
						["涛哥"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006414,
					["friendlyfire_total"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592207199,
					["delay"] = 0,
					["last_dps"] = 0,
					["nome"] = "北极的影舞",
					["spells"] = {
						["_ActorTable"] = {
							["偷袭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "偷袭",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["出血"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "出血",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.006414,
					["on_hold"] = false,
					["total"] = 0.006414,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592207196,
					["serial"] = "Player-4920-02632CD1",
					["fight_component"] = true,
				}, -- [6]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.013035,
					["damage_from"] = {
						["涛哥"] = true,
					},
					["targets"] = {
						["涛哥"] = 2326,
					},
					["pets"] = {
					},
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 2326.013035,
					["tipo"] = 1,
					["dps_started"] = false,
					["fight_component"] = true,
					["total"] = 2326.013035,
					["damage_taken"] = 12532.013035,
					["classe"] = "UNKNOW",
					["nome"] = "炽热火焰卫士",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 377,
								["targets"] = {
									["涛哥"] = 1488,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1488,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 11,
								["total"] = 1488,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["DODGE"] = 5,
								["a_amt"] = 0,
							},
							["献祭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 304,
								["targets"] = {
									["涛哥"] = 838,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 838,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 838,
								["c_max"] = 0,
								["id"] = "献祭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 7,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火焰冲击",
								["r_dmg"] = 0,
								["RESIST"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["delay"] = 0,
					["monster"] = true,
					["end_time"] = 1592208316,
					["on_hold"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1592208277,
					["serial"] = "Creature-0-4516-230-16953-8910-0008E72758",
					["friendlyfire"] = {
					},
				}, -- [7]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.173002,
					["damage_from"] = {
						["铁怒医师"] = true,
						["铁怒预备兵"] = true,
						["安格弗将军"] = true,
						["花姐"] = true,
						["征服者派隆"] = true,
					},
					["targets"] = {
						["征服者派隆"] = 2996,
						["安格弗将军"] = 166886,
					},
					["pets"] = {
					},
					["delay"] = 0,
					["friendlyfire_total"] = 39,
					["raid_targets"] = {
					},
					["total_without_pet"] = 169882.173002,
					["nome"] = "花姐",
					["damage_taken"] = 80974.173002,
					["dps_started"] = false,
					["end_time"] = 1592211949,
					["classe"] = "ROGUE",
					["total"] = 169882.173002,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["绞喉"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 118,
								["targets"] = {
									["安格弗将军"] = 2596,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2596,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 22,
								["total"] = 2596,
								["c_max"] = 0,
								["id"] = "绞喉",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 22,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["破甲"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["安格弗将军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["c_min"] = 0,
								["id"] = "破甲",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 1,
							},
							["速效毒药 VI"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 151,
								["targets"] = {
									["安格弗将军"] = 3480,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3480,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 3480,
								["c_max"] = 0,
								["id"] = "速效毒药 VI",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 26,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["闪电攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 303,
								["targets"] = {
									["安格弗将军"] = 6602,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6602,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 26,
								["total"] = 6602,
								["c_max"] = 0,
								["id"] = "闪电攻击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 26,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["邪恶攻击"] = {
								["c_amt"] = 39,
								["b_amt"] = 2,
								["c_dmg"] = 19891,
								["g_amt"] = 0,
								["n_max"] = 274,
								["targets"] = {
									["征服者派隆"] = 222,
									["安格弗将军"] = 40384,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 20715,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 152,
								["total"] = 40606,
								["c_max"] = 693,
								["r_amt"] = 0,
								["id"] = "邪恶攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 10,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 369,
								["n_amt"] = 95,
								["DODGE"] = 8,
								["a_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 219,
								["b_amt"] = 17,
								["c_dmg"] = 60940,
								["g_amt"] = 0,
								["n_max"] = 243,
								["targets"] = {
									["征服者派隆"] = 2774,
									["安格弗将军"] = 109833,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 51667,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 728,
								["r_amt"] = 0,
								["total"] = 112607,
								["c_max"] = 495,
								["MISS"] = 78,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 1715,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 14,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 393,
								["DODGE"] = 24,
								["a_amt"] = 0,
							},
							["偷袭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
									["安格弗将军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "偷袭",
								["r_dmg"] = 0,
								["IMMUNE"] = 3,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["刺骨"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 1384,
								["g_amt"] = 0,
								["n_max"] = 651,
								["targets"] = {
									["安格弗将军"] = 2035,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 651,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 2035,
								["c_max"] = 1384,
								["id"] = "刺骨",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["割裂"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 127,
								["targets"] = {
									["安格弗将军"] = 1956,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1956,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 1956,
								["c_max"] = 0,
								["id"] = "割裂",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 16,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["扰乱"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒卫士"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "扰乱",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_dps"] = 0,
					["spec"] = 260,
					["tipo"] = 1,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
						["花姐"] = {
							["total"] = 39,
							["spells"] = {
								["剑类武器专精"] = 11,
							},
						},
					},
					["start_time"] = 1592211124,
					["serial"] = "Player-4920-01D0BF72",
					["on_hold"] = false,
				}, -- [8]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.012315,
					["damage_from"] = {
					},
					["targets"] = {
						["涛哥"] = 696,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_taken"] = 0.012315,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 696.012315,
					["serial"] = "Creature-0-4888-230-25091-8899-0002E7782F",
					["monster"] = true,
					["end_time"] = 1592228467,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "厄炉龙骑兵",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 303,
								["targets"] = {
									["涛哥"] = 303,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 303,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 303,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["DODGE"] = 2,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["r_amt"] = 0,
							},
							["射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 214,
								["targets"] = {
									["涛哥"] = 393,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 393,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 393,
								["c_max"] = 0,
								["id"] = "射击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 696.012315,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1592228452,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [9]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.012144,
					["damage_from"] = {
						["火焰驱逐者"] = true,
					},
					["targets"] = {
						["涛哥"] = 1264,
						["火焰驱逐者"] = 2,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_taken"] = 2.012144,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1266.012144,
					["serial"] = "Creature-0-4888-230-25091-8911-0001E7782F",
					["monster"] = true,
					["end_time"] = 1592228467,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "火焰驱逐者",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 409,
								["targets"] = {
									["涛哥"] = 1264,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1264,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1264,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 4,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["火焰驱逐者"] = 2,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 2,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 1266.012144,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1592228460,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [10]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.009015,
					["damage_from"] = {
					},
					["targets"] = {
						["涛哥"] = 1235,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_taken"] = 0.009015,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1235.009015,
					["serial"] = "Creature-0-4888-230-25091-8898-000167782F",
					["monster"] = true,
					["end_time"] = 1592228467,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "铁怒队长",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 279,
								["targets"] = {
									["涛哥"] = 1235,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1235,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1235,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["m_amt"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["total"] = 1235.009015,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1592228456,
					["delay"] = 0,
					["fight_component"] = true,
				}, -- [11]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.006193,
					["damage_from"] = {
					},
					["targets"] = {
						["奇迹贼"] = 0,
						["越狱无敌无畏"] = 0,
						["Az"] = 0,
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["monster"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006193,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["nome"] = "铁怒监军",
					["damage_taken"] = 0.006193,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["奇迹贼"] = 0,
									["越狱无敌无畏"] = 0,
									["Az"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["奇迹贼"] = 0,
									["越狱无敌无畏"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "打击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592232928,
					["serial"] = "Creature-0-4889-0-558-8889-00006747EE",
					["total"] = 0.006193,
				}, -- [12]
				{
					["flag_original"] = 1304,
					["totalabsorbed"] = 0.005759,
					["damage_from"] = {
					},
					["targets"] = {
						["铁怒监军"] = 0,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005759,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["重伤"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "重伤",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.005759,
					["total"] = 0.005759,
					["nome"] = "Az",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-0243BA72",
					["friendlyfire"] = {
					},
				}, -- [13]
				{
					["flag_original"] = 1304,
					["totalabsorbed"] = 0.002098,
					["damage_from"] = {
					},
					["targets"] = {
						["铁怒监军"] = 0,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002098,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["还击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "还击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["刺骨"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "刺骨",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["出血"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "出血",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["鬼魅攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "鬼魅攻击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.002098,
					["total"] = 0.002098,
					["nome"] = "奇迹贼",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-01D298FC",
					["friendlyfire"] = {
						["奇迹贼"] = {
							["total"] = 0,
							["spells"] = {
								["正义之手"] = 0,
							},
						},
					},
				}, -- [14]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.008923,
					["damage_from"] = {
					},
					["targets"] = {
						["青为天人"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008923,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["炎爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["青为天人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "炎爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.008923,
					["on_hold"] = false,
					["nome"] = "小苏打嘉年华",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-0214AFD6",
					["total"] = 0.008923,
				}, -- [15]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.004299,
					["damage_from"] = {
					},
					["targets"] = {
						["青为天人"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004299,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["炎爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["青为天人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "炎爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.004299,
					["on_hold"] = false,
					["nome"] = "大苏打阿瑟",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-0214AF67",
					["total"] = 0.004299,
				}, -- [16]
				{
					["flag_original"] = 1352,
					["totalabsorbed"] = 0.007174,
					["damage_from"] = {
					},
					["targets"] = {
						["青为天人"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.007174,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["炎爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["青为天人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "炎爆术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["点燃"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["青为天人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "点燃",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.007174,
					["on_hold"] = false,
					["nome"] = "小苏打的撒",
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-0214B028",
					["total"] = 0.007174,
				}, -- [17]
				{
					["flag_original"] = 1304,
					["totalabsorbed"] = 0.001241,
					["damage_from"] = {
					},
					["targets"] = {
						["铁怒狱卒"] = 0,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001241,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["嗜血"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒狱卒"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "嗜血",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["重伤"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒狱卒"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "重伤",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒狱卒"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["旋风斩"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒狱卒"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "旋风斩",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.001241,
					["total"] = 0.001241,
					["nome"] = "奥格揣玛步兵",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-026D34FC",
					["friendlyfire"] = {
						["奥格揣玛步兵"] = {
							["total"] = 0,
							["spells"] = {
								["风暴战斧"] = 0,
							},
						},
					},
				}, -- [18]
				{
					["flag_original"] = 1304,
					["totalabsorbed"] = 0.006636,
					["damage_from"] = {
					},
					["targets"] = {
						["征服者派隆"] = 0,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006636,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["速效毒药 VI"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "速效毒药 VI",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["出血"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "出血",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火球术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火球术",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["刺骨"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "刺骨",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["鬼魅攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "鬼魅攻击",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["致命毒药 IV"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["征服者派隆"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "致命毒药 IV",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.006636,
					["total"] = 0.006636,
					["nome"] = "Ergousun",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-01D91CB0",
					["friendlyfire"] = {
					},
				}, -- [19]
				{
					["flag_original"] = 1304,
					["totalabsorbed"] = 0.00835,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.00835,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.00835,
					["total"] = 0.00835,
					["nome"] = "莫小帥",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-01D30E8F",
					["friendlyfire"] = {
					},
				}, -- [20]
				{
					["flag_original"] = 1304,
					["totalabsorbed"] = 0.008114,
					["damage_from"] = {
					},
					["targets"] = {
						["铁怒监军"] = 0,
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008114,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["顺劈斩"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "顺劈斩",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["雷霆之怒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "雷霆之怒",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["复仇"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "复仇",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["撕裂"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["铁怒监军"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "撕裂",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.008114,
					["total"] = 0.008114,
					["nome"] = "越狱无敌无畏",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-02229916",
					["friendlyfire"] = {
					},
				}, -- [21]
				{
					["flag_original"] = 1304,
					["totalabsorbed"] = 0.008136,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008136,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1592232931,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.008136,
					["total"] = 0.008136,
					["nome"] = "灬紅顏灬",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1592232928,
					["serial"] = "Player-4920-024A43F3",
					["friendlyfire"] = {
					},
				}, -- [22]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.013087,
					["damage_from"] = {
						["涛哥"] = true,
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.013087,
					["damage_taken"] = 1922.013087,
					["dps_started"] = false,
					["end_time"] = 1592233818,
					["delay"] = 0,
					["fight_component"] = true,
					["nome"] = "辛迪亚兄弟会",
					["spells"] = {
						["_ActorTable"] = {
							["疾跑"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "疾跑",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1592233815,
					["serial"] = "Player-4920-01D891CD",
					["total"] = 0.013087,
				}, -- [23]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.004841,
					["boss_fight_component"] = true,
					["damage_from"] = {
					},
					["targets"] = {
						["莫小帥"] = 0,
						["越狱无敌无畏"] = 0,
						["灬紅顏灬"] = 0,
						["奥格揣玛步兵"] = 0,
					},
					["pets"] = {
					},
					["end_time"] = 1592253424,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004841,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["total"] = 0.004841,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["nome"] = "铁怒狱卒",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["钩网"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["越狱无敌无畏"] = 0,
									["莫小帥"] = 0,
									["奥格揣玛步兵"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "钩网",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["越狱无敌无畏"] = 0,
									["莫小帥"] = 0,
									["奥格揣玛步兵"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["盾击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["灬紅顏灬"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "盾击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["monster"] = true,
					["on_hold"] = false,
					["serial"] = "Creature-0-4889-0-558-8890-0000675AAC",
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.004841,
					["start_time"] = 1592253421,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [24]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.004776,
					["damage_from"] = {
						["涛哥"] = true,
						["花姐"] = true,
					},
					["targets"] = {
						["涛哥"] = 3025,
						["Ergousun"] = 0,
						["花姐"] = 358,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 3383.004776,
					["boss_fight_component"] = true,
					["monster"] = true,
					["dps_started"] = false,
					["total"] = 3383.004776,
					["end_time"] = 1592253424,
					["classe"] = "UNKNOW",
					["nome"] = "征服者派隆",
					["spells"] = {
						["tipo"] = 2,
						["_ActorTable"] = {
							["火焰新星"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 517,
								["targets"] = {
									["涛哥"] = 1028,
									["Ergousun"] = 0,
									["花姐"] = 358,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1386,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 1386,
								["c_max"] = 0,
								["id"] = "火焰新星",
								["r_dmg"] = 358,
								["RESIST"] = 1,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["r_amt"] = 1,
								["c_min"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 333,
								["targets"] = {
									["涛哥"] = 885,
									["Ergousun"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 885,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 885,
								["c_max"] = 0,
								["MISS"] = 1,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["DODGE"] = 10,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 582,
								["targets"] = {
									["涛哥"] = 1112,
									["Ergousun"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1112,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 1112,
								["c_max"] = 0,
								["id"] = "火焰冲击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["r_amt"] = 0,
								["c_min"] = 0,
							},
						},
					},
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["serial"] = "Creature-0-4889-0-558-9026-000067591B",
					["custom"] = 0,
					["tipo"] = 1,
					["last_dps"] = 0,
					["start_time"] = 1592253398,
					["delay"] = 0,
					["damage_taken"] = 11399.004776,
				}, -- [25]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1297,
					["healing_from"] = {
						["涛哥"] = true,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 8853.206512,
					["total_without_pet"] = 80208.206512,
					["total"] = 80208.206512,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01D0D553",
					["totalabsorb"] = 0.206512,
					["last_hps"] = 0,
					["targets"] = {
						["涛哥"] = 12002,
					},
					["totalover_without_pet"] = 0.206512,
					["healing_taken"] = 80208.206512,
					["fight_component"] = true,
					["end_time"] = 1592207086,
					["targets_overheal"] = {
						["涛哥"] = 1151,
					},
					["boss_fight_component"] = true,
					["nome"] = "涛哥",
					["spells"] = {
						["_ActorTable"] = {
							["血牙"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["涛哥"] = 3969,
								},
								["n_max"] = 50,
								["targets"] = {
									["涛哥"] = 14031,
								},
								["n_min"] = 0,
								["counter"] = 360,
								["overheal"] = 3969,
								["total"] = 14031,
								["c_max"] = 0,
								["id"] = "血牙",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 14031,
								["n_amt"] = 360,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							["神圣力量"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["涛哥"] = 1864,
								},
								["n_max"] = 125,
								["targets"] = {
									["涛哥"] = 3286,
								},
								["n_min"] = 0,
								["counter"] = 52,
								["overheal"] = 1864,
								["total"] = 3286,
								["c_max"] = 0,
								["id"] = "神圣力量",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 3286,
								["n_amt"] = 52,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							["急救"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["涛哥"] = 3020,
								},
								["n_max"] = 250,
								["targets"] = {
									["涛哥"] = 54980,
								},
								["n_min"] = 0,
								["counter"] = 232,
								["overheal"] = 3020,
								["total"] = 54980,
								["c_max"] = 0,
								["id"] = "急救",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 54980,
								["n_amt"] = 232,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							["治疗药水"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 1566,
								["targets"] = {
									["涛哥"] = 7911,
								},
								["n_min"] = 0,
								["counter"] = 6,
								["overheal"] = 0,
								["total"] = 7911,
								["c_max"] = 0,
								["id"] = "治疗药水",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 7911,
								["n_amt"] = 6,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["start_time"] = 1592206224,
					["custom"] = 0,
					["tipo"] = 2,
					["classe"] = "ROGUE",
					["totaldenied"] = 0.206512,
					["delay"] = 0,
					["spec"] = 261,
				}, -- [1]
				{
					["flag_original"] = 2632,
					["totalabsorb"] = 0.006456,
					["last_hps"] = 0,
					["healing_from"] = {
					},
					["targets"] = {
					},
					["serial"] = "Creature-0-4888-230-25091-8894-0000E77957",
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["targets_overheal"] = {
					},
					["healing_taken"] = 0.006456,
					["totalover"] = 0.006456,
					["total_without_pet"] = 0.006456,
					["totalover_without_pet"] = 0.006456,
					["start_time"] = 1592228220,
					["monster"] = true,
					["total"] = 0.006456,
					["heal_enemy_amt"] = 5805,
					["classe"] = "UNKNOW",
					["boss_fight_component"] = true,
					["targets_absorbs"] = {
					},
					["end_time"] = 1592228223,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["heal_enemy"] = {
						["治疗术"] = 5805,
					},
					["nome"] = "铁怒医师",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["totaldenied"] = 0.006456,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [2]
				{
					["flag_original"] = 68168,
					["totalabsorb"] = 0.008202,
					["last_hps"] = 0,
					["healing_from"] = {
					},
					["targets"] = {
					},
					["serial"] = "Creature-0-4888-230-25091-9033-000067782E",
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["targets_overheal"] = {
					},
					["healing_taken"] = 0.008202,
					["totalover"] = 0.008202,
					["total_without_pet"] = 0.008202,
					["totalover_without_pet"] = 0.008202,
					["start_time"] = 1592228220,
					["monster"] = true,
					["total"] = 0.008202,
					["heal_enemy_amt"] = 0,
					["classe"] = "UNKNOW",
					["boss_fight_component"] = true,
					["targets_absorbs"] = {
					},
					["end_time"] = 1592228223,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["heal_enemy"] = {
					},
					["nome"] = "安格弗将军",
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["totaldenied"] = 0.008202,
					["delay"] = 0,
					["tipo"] = 2,
				}, -- [3]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["received"] = 18.006882,
					["resource"] = 0.011458,
					["targets"] = {
						["涛哥"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["classe"] = "ROGUE",
					["passiveover"] = 0.005738,
					["total"] = 18.006882,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["恢复能量"] = {
								["total"] = 18,
								["id"] = "恢复能量",
								["totalover"] = 0,
								["targets"] = {
									["涛哥"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["totalover"] = 0.005738,
					["spec"] = 261,
					["tipo"] = 3,
					["last_event"] = 0,
					["alternatepower"] = 0.006882,
					["flag_original"] = 1297,
					["serial"] = "Player-4920-01D0D553",
					["nome"] = "涛哥",
				}, -- [1]
				{
					["received"] = 550.109559,
					["resource"] = 0.292638,
					["targets"] = {
						["花姐"] = 125,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["classe"] = "ROGUE",
					["passiveover"] = 0.002466,
					["total"] = 550.109559,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["无情打击效果"] = {
								["total"] = 550,
								["id"] = "无情打击效果",
								["totalover"] = 0,
								["targets"] = {
									["花姐"] = 125,
								},
								["counter"] = 22,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["totalover"] = 0.002466,
					["spec"] = 260,
					["tipo"] = 3,
					["last_event"] = 0,
					["alternatepower"] = 0.109559,
					["flag_original"] = 1298,
					["serial"] = "Player-4920-01D0BF72",
					["nome"] = "花姐",
				}, -- [2]
				{
					["received"] = 0.00658,
					["resource"] = 0.02326,
					["targets"] = {
						["曾经的王"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.00658,
					["total"] = 0.00658,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["生命分流"] = {
								["total"] = 0,
								["id"] = "生命分流",
								["totalover"] = 0,
								["targets"] = {
									["曾经的王"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["totalover"] = 0.00658,
					["alternatepower"] = 0.00658,
					["tipo"] = 3,
					["last_event"] = 0,
					["flag_original"] = 1304,
					["serial"] = "Player-4920-01DA8F20",
					["nome"] = "曾经的王",
				}, -- [3]
				{
					["received"] = 0.006997,
					["resource"] = 0.026117,
					["targets"] = {
						["小苏打的撒"] = 0,
					},
					["enemy"] = true,
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.006997,
					["total"] = 0.006997,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["元素大师"] = {
								["total"] = 0,
								["id"] = "元素大师",
								["totalover"] = 0,
								["targets"] = {
									["小苏打的撒"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["totalover"] = 0.006997,
					["alternatepower"] = 0.006997,
					["tipo"] = 3,
					["last_event"] = 0,
					["flag_original"] = 1352,
					["serial"] = "Player-4920-0214B028",
					["nome"] = "小苏打的撒",
				}, -- [4]
				{
					["received"] = 0.00852,
					["resource"] = 0.01696,
					["targets"] = {
						["奥格揣玛步兵"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.00852,
					["total"] = 0.00852,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["怒不可遏"] = {
								["total"] = 0,
								["id"] = "怒不可遏",
								["totalover"] = 0,
								["targets"] = {
									["奥格揣玛步兵"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["totalover"] = 0.00852,
					["alternatepower"] = 0.00852,
					["tipo"] = 3,
					["last_event"] = 0,
					["flag_original"] = 1304,
					["serial"] = "Player-4920-026D34FC",
					["nome"] = "奥格揣玛步兵",
				}, -- [5]
				{
					["received"] = 0.00197,
					["resource"] = 0.015198,
					["targets"] = {
						["Ergousun"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.00197,
					["total"] = 0.00197,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["能量爆发"] = {
								["total"] = 0,
								["id"] = "能量爆发",
								["totalover"] = 0,
								["targets"] = {
									["Ergousun"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["totalover"] = 0.00197,
					["alternatepower"] = 0.00197,
					["tipo"] = 3,
					["last_event"] = 0,
					["flag_original"] = 1304,
					["serial"] = "Player-4920-01D91CB0",
					["nome"] = "Ergousun",
				}, -- [6]
				{
					["received"] = 0.003703,
					["resource"] = 0.033771,
					["targets"] = {
						["越狱无敌无畏"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "UNGROUPPLAYER",
					["passiveover"] = 0.003703,
					["total"] = 0.003703,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["盾牌专精"] = {
								["total"] = 0,
								["id"] = "盾牌专精",
								["totalover"] = 0,
								["targets"] = {
									["越狱无敌无畏"] = 0,
								},
								["counter"] = 0,
							},
							["怒不可遏"] = {
								["total"] = 0,
								["id"] = "怒不可遏",
								["totalover"] = 0,
								["targets"] = {
									["越狱无敌无畏"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["totalover"] = 0.003703,
					["alternatepower"] = 0.003703,
					["tipo"] = 3,
					["last_event"] = 0,
					["flag_original"] = 1304,
					["serial"] = "Player-4920-02229916",
					["nome"] = "越狱无敌无畏",
				}, -- [7]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["新近包扎"] = {
								["refreshamt"] = 0,
								["activedamt"] = 29,
								["appliedamt"] = 33,
								["id"] = "新近包扎",
								["uptime"] = 925,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["还击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 51,
								["id"] = "还击",
								["uptime"] = 282,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["凿击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = "凿击",
								["uptime"] = 8,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["肾击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = "肾击",
								["uptime"] = 12,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["致命毒药 IV"] = {
								["refreshamt"] = 94,
								["activedamt"] = 1,
								["appliedamt"] = 28,
								["id"] = "致命毒药 IV",
								["uptime"] = 776,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["出血"] = {
								["refreshamt"] = 338,
								["activedamt"] = 1,
								["appliedamt"] = 74,
								["id"] = "出血",
								["uptime"] = 1911,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["偷袭"] = {
								["counter"] = 0,
								["appliedamt"] = 0,
								["activedamt"] = -3,
								["actived_at"] = 4776698223,
								["id"] = "偷袭",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 6408,
					["classe"] = "ROGUE",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["脚踢"] = {
								["id"] = "脚踢",
								["counter"] = 1,
								["targets"] = {
									["炽热火焰卫士"] = 1,
								},
								["interrompeu_oque"] = {
									["献祭"] = 1,
								},
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["闪避"] = {
								["refreshamt"] = 0,
								["activedamt"] = 49,
								["appliedamt"] = 49,
								["id"] = "闪避",
								["uptime"] = 667,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["急救"] = {
								["refreshamt"] = 0,
								["activedamt"] = 33,
								["appliedamt"] = 33,
								["id"] = "急救",
								["uptime"] = 237,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["鬼魅攻击"] = {
								["refreshamt"] = 0,
								["activedamt"] = 10,
								["appliedamt"] = 10,
								["id"] = "鬼魅攻击",
								["uptime"] = 70,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["血牙"] = {
								["refreshamt"] = 10,
								["activedamt"] = 57,
								["appliedamt"] = 57,
								["id"] = "血牙",
								["uptime"] = 361,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["神圣力量"] = {
								["refreshamt"] = 13,
								["activedamt"] = 39,
								["appliedamt"] = 39,
								["id"] = "神圣力量",
								["uptime"] = 579,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["再生"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "再生",
								["uptime"] = 825,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["强效石盾"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "强效石盾",
								["uptime"] = 53,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["潜行"] = {
								["counter"] = 0,
								["activedamt"] = 34,
								["appliedamt"] = 34,
								["id"] = "潜行",
								["uptime"] = 74,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["敏捷"] = {
								["counter"] = 0,
								["activedamt"] = 33,
								["appliedamt"] = 33,
								["id"] = "敏捷",
								["uptime"] = 2112,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["切割"] = {
								["counter"] = 0,
								["activedamt"] = 23,
								["appliedamt"] = 23,
								["id"] = "切割",
								["uptime"] = 276,
								["targets"] = {
								},
								["refreshamt"] = 1,
							},
							["进食充分"] = {
								["refreshamt"] = 0,
								["counter"] = 0,
								["activedamt"] = 5,
								["uptime"] = 79,
								["id"] = "进食充分",
								["appliedamt"] = 5,
								["targets"] = {
								},
								["actived_at"] = 6368862723,
							},
							["剑刃乱舞"] = {
								["refreshamt"] = 0,
								["activedamt"] = 33,
								["appliedamt"] = 33,
								["id"] = "剑刃乱舞",
								["uptime"] = 496,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["消失"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = "消失",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["疾跑"] = {
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "疾跑",
								["uptime"] = 15,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["巨人药剂"] = {
								["refreshamt"] = 0,
								["activedamt"] = 9,
								["appliedamt"] = 9,
								["id"] = "巨人药剂",
								["uptime"] = 564,
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["interrompeu_oque"] = {
						["献祭"] = 1,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 3914,
					["spec"] = 261,
					["boss_fight_component"] = true,
					["debuff_uptime_targets"] = {
					},
					["interrupt_targets"] = {
						["炽热火焰卫士"] = 1,
					},
					["grupo"] = true,
					["spell_cast"] = {
						["治疗药水"] = 6,
						["恢复能量"] = 1,
						["潜行"] = 1,
						["凿击"] = 2,
						["切割"] = 24,
						["还击"] = 59,
						["出血"] = 440,
						["脚踢"] = 1,
						["急救"] = 33,
						["伺机待发"] = 14,
						["鬼魅攻击"] = 10,
						["闪避"] = 49,
						["剑刃乱舞"] = 33,
						["肾击"] = 2,
						["消失"] = 33,
						["刺骨"] = 107,
						["疾跑"] = 1,
					},
					["nome"] = "涛哥",
					["pets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["serial"] = "Player-4920-01D0D553",
					["interrupt"] = 1.001641,
				}, -- [1]
				{
					["flag_original"] = 68168,
					["tipo"] = 4,
					["monster"] = true,
					["boss_fight_component"] = true,
					["pets"] = {
					},
					["nome"] = "安格弗将军",
					["classe"] = "UNKNOW",
					["spell_cast"] = {
						["破甲攻击"] = 237,
					},
					["serial"] = "Creature-0-5002-230-9519-9033-00006725BB",
					["last_event"] = 0,
				}, -- [2]
				{
					["fight_component"] = true,
					["monster"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "铁怒预备兵",
					["pets"] = {
					},
					["spell_cast"] = {
						["战斗怒吼"] = 37,
						["打击"] = 120,
						["断筋"] = 25,
						["射击"] = 69,
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-5002-230-9519-8901-0000E725BB",
					["flag_original"] = 2632,
				}, -- [3]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 593,
					["spellschool"] = 1,
					["debuff_uptime_targets"] = {
						["涛哥"] = {
							["uptime"] = 509,
							["appliedamt"] = 0,
							["activedamt"] = 11,
							["actived"] = false,
							["refreshamt"] = 0,
						},
						["花姐"] = {
							["uptime"] = 84,
							["refreshamt"] = 0,
							["activedamt"] = 12,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["nome"] = "破甲攻击",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "安格弗将军",
					["damage_spellid"] = "破甲攻击",
					["serial"] = "Creature-0-5002-230-9519-9033-00006725BB",
					["last_event"] = 0,
				}, -- [4]
				{
					["monster"] = true,
					["pets"] = {
					},
					["nome"] = "铁怒医师",
					["boss_fight_component"] = true,
					["spell_cast"] = {
						["心灵震爆"] = 8,
						["真言术：韧"] = 178,
						["治疗术"] = 4,
					},
					["flag_original"] = 2632,
					["tipo"] = 4,
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["serial"] = "Creature-0-5002-230-9519-8894-00006726CE",
					["fight_component"] = true,
				}, -- [5]
				{
					["fight_component"] = true,
					["last_event"] = 0,
					["nome"] = "给我一口奶喝",
					["enemy"] = true,
					["spell_cast"] = {
						["魔爆术"] = 0,
						["闪现术"] = 0,
						["寒冰箭"] = 0,
						["冰霜新星"] = 0,
					},
					["classe"] = "UNGROUPPLAYER",
					["tipo"] = 4,
					["pets"] = {
					},
					["serial"] = "Player-4920-02789A12",
					["flag_original"] = 66888,
				}, -- [6]
				{
					["fight_component"] = true,
					["last_event"] = 0,
					["nome"] = "北极的影舞",
					["enemy"] = true,
					["spell_cast"] = {
						["偷袭"] = 0,
						["出血"] = 0,
					},
					["classe"] = "UNGROUPPLAYER",
					["tipo"] = 4,
					["pets"] = {
					},
					["serial"] = "Player-4920-02632CD1",
					["flag_original"] = 1352,
				}, -- [7]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["破甲"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 18,
								["id"] = "破甲",
								["uptime"] = 330,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["割裂"] = {
								["refreshamt"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = "割裂",
								["uptime"] = 33,
								["targets"] = {
								},
								["counter"] = 0,
							},
							["绞喉"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 8,
								["id"] = "绞喉",
								["uptime"] = 76,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 589,
					["classe"] = "ROGUE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["切割"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "切割",
								["uptime"] = 13,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["闪避"] = {
								["counter"] = 0,
								["activedamt"] = 27,
								["appliedamt"] = 27,
								["id"] = "闪避",
								["uptime"] = 401,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["消失"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 1,
								["uptime"] = 0,
								["id"] = "消失",
								["appliedamt"] = 1,
								["targets"] = {
								},
								["actived_at"] = 1592213211,
							},
							["潜行"] = {
								["counter"] = 0,
								["activedamt"] = 21,
								["appliedamt"] = 21,
								["id"] = "潜行",
								["uptime"] = 110,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["呀啊啊啊啊"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "呀啊啊啊啊",
								["uptime"] = 65,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 439,
					["buff_uptime_targets"] = {
					},
					["spec"] = 260,
					["grupo"] = true,
					["spell_cast"] = {
						["割裂"] = 4,
						["破甲"] = 20,
						["邪恶攻击"] = 152,
						["绞喉"] = 8,
						["切割"] = 1,
						["偷袭"] = 3,
						["刺骨"] = 2,
						["闪避"] = 27,
						["消失"] = 18,
					},
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["last_event"] = 0,
					["pets"] = {
					},
					["nome"] = "花姐",
					["serial"] = "Player-4920-01D0BF72",
					["debuff_uptime_targets"] = {
					},
				}, -- [8]
				{
					["flag_original"] = 2632,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 10,
					["spellschool"] = 1,
					["nome"] = "眩晕",
					["debuff_uptime_targets"] = {
						["涛哥"] = {
							["uptime"] = 8,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["花姐"] = {
							["uptime"] = 2,
							["appliedamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["refreshamt"] = 0,
						},
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["damage_twin"] = "铁怒预备兵",
					["serial"] = "Creature-0-4505-230-22877-8901-0001E730E8",
					["damage_spellid"] = "眩晕",
					["boss_fight_component"] = true,
				}, -- [9]
				{
					["flag_original"] = 2632,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 14,
					["spellschool"] = 1,
					["nome"] = "断筋",
					["debuff_uptime_targets"] = {
						["花姐"] = {
							["uptime"] = 5,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
						["涛哥"] = {
							["uptime"] = 9,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["damage_twin"] = "铁怒预备兵",
					["serial"] = "Creature-0-4505-230-29246-8901-0001673EDA",
					["damage_spellid"] = "断筋",
					["boss_fight_component"] = true,
				}, -- [10]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "厄炉龙骑兵",
					["pets"] = {
					},
					["spell_cast"] = {
						["射击"] = 2,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4888-230-25091-8899-000167782E",
					["classe"] = "UNKNOW",
				}, -- [11]
				{
					["fight_component"] = true,
					["tipo"] = 4,
					["nome"] = "辛迪亚兄弟会",
					["enemy"] = true,
					["pets"] = {
					},
					["classe"] = "UNGROUPPLAYER",
					["last_event"] = 0,
					["flag_original"] = 66888,
					["serial"] = "Player-4920-01D891CD",
					["spell_cast"] = {
						["疾跑"] = 1,
					},
				}, -- [12]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "征服者派隆",
					["pets"] = {
					},
					["spell_cast"] = {
						["火焰新星"] = 2,
						["火焰冲击"] = 2,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4889-0-498-9026-00006786E4",
					["classe"] = "UNKNOW",
				}, -- [13]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "炽热火焰卫士",
					["pets"] = {
					},
					["spell_cast"] = {
						["献祭"] = 1,
						["火焰冲击"] = 1,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-5002-230-2163-8910-0007E7E4C1",
					["classe"] = "UNKNOW",
				}, -- [14]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1592206780,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["spells_cast_timeline"] = {
		},
		["combat_counter"] = 26,
		["totals"] = {
			1146919.848297, -- [1]
			80208.207564, -- [2]
			{
				-0.013204, -- [1]
				[0] = -0.011403,
				["alternatepower"] = 0,
				[3] = 568.107092,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 1.001641,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
			["frags_total"] = 0,
			["voidzone_damage"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "15:43:27",
		["end_time"] = 379348.659,
		["cleu_events"] = {
			["n"] = 1,
		},
		["totals_grupo"] = {
			880494.372756, -- [1]
			80208.201789, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[3] = 568.108237,
				[6] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["cooldowns_defensive"] = 0,
				["dispell"] = 0,
				["interrupt"] = 1.001641,
				["debuff_uptime"] = 0,
				["cc_break"] = 0,
				["dead"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["frags"] = {
		},
		["hasSaved"] = true,
		["segments_added"] = {
			{
				["elapsed"] = 29.0079999999725,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "05:22:00",
			}, -- [1]
			{
				["elapsed"] = 78.9990000000107,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "05:18:18",
			}, -- [2]
			{
				["elapsed"] = 78.0140000000247,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "05:10:59",
			}, -- [3]
			{
				["elapsed"] = 73.00900000002,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "05:03:47",
			}, -- [4]
			{
				["elapsed"] = 80.00900000002,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "04:56:17",
			}, -- [5]
			{
				["elapsed"] = 75.0119999999879,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "04:47:15",
			}, -- [6]
			{
				["elapsed"] = 28.0069999999832,
				["type"] = 0,
				["name"] = "征服者派隆",
				["clock"] = "04:42:36",
			}, -- [7]
			{
				["elapsed"] = 80.015000000014,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "23:35:44",
			}, -- [8]
			{
				["elapsed"] = 69.005999999994,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "23:28:35",
			}, -- [9]
			{
				["elapsed"] = 78.0139999999665,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "23:21:07",
			}, -- [10]
			{
				["elapsed"] = 71.0080000000307,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "23:14:07",
			}, -- [11]
			{
				["elapsed"] = 13.0040000000154,
				["type"] = 0,
				["name"] = "辛迪亚兄弟会",
				["clock"] = "23:10:05",
			}, -- [12]
			{
				["elapsed"] = 72.0130000000354,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "23:06:43",
			}, -- [13]
			{
				["elapsed"] = 76.0119999999879,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "21:48:42",
			}, -- [14]
			{
				["elapsed"] = 27.0029999999679,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "21:40:40",
			}, -- [15]
			{
				["elapsed"] = 92.0250000000233,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "21:35:31",
			}, -- [16]
			{
				["elapsed"] = 71.0030000000261,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "21:27:40",
			}, -- [17]
			{
				["elapsed"] = 70.00900000002,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "21:19:40",
			}, -- [18]
			{
				["elapsed"] = 70.0069999999832,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "21:08:35",
			}, -- [19]
			{
				["elapsed"] = 88.005999999994,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "19:14:09",
			}, -- [20]
			{
				["elapsed"] = 20.0119999999879,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "19:05:24",
			}, -- [21]
			{
				["elapsed"] = 75.015000000014,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "19:02:18",
			}, -- [22]
			{
				["elapsed"] = 92.0019999999786,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "18:54:06",
			}, -- [23]
			{
				["elapsed"] = 56.0109999999986,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "18:47:04",
			}, -- [24]
			{
				["elapsed"] = 81.0299999999697,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "18:34:36",
			}, -- [25]
			{
				["elapsed"] = 76.0030000000261,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "18:26:31",
			}, -- [26]
			{
				["elapsed"] = 82,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "17:59:25",
			}, -- [27]
			{
				["elapsed"] = 71.0080000000307,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "17:50:52",
			}, -- [28]
			{
				["elapsed"] = 70.0100000000093,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "17:37:21",
			}, -- [29]
			{
				["elapsed"] = 16.0200000000186,
				["type"] = 6,
				["name"] = "安格弗将军",
				["clock"] = "17:26:51",
			}, -- [30]
		},
		["data_fim"] = "05:22:29",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage_section"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage"] = {
			},
		},
		["start_time"] = 376665.255,
		["TimeData"] = {
		},
		["cleu_timeline"] = {
		},
	},
	["force_font_outline"] = "",
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = false,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -152.888854980469,
					["x"] = 625.844970703125,
					["w"] = 310.000213623047,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
	},
	["character_data"] = {
		["logons"] = 13,
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-4920-01D0D553"] = 261,
		["Player-4920-01D0BF72"] = 260,
	},
}
