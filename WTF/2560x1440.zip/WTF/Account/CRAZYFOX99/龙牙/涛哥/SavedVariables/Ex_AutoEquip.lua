
ExAE_Config = {
	["涛哥@Enigma"] = {
		["CurrentSetId"] = 0,
	},
}
