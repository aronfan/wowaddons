
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["涛哥 - 龙牙"] = "涛哥 - 龙牙",
	},
	["profiles"] = {
		["涛哥 - 龙牙"] = {
		},
	},
}
