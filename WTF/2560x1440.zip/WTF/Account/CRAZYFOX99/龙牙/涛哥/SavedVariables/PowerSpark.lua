
PowerSparkDB = {
	["default"] = {
		["timer"] = 379353.7,
	},
}
