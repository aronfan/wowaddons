
boomTimeSv = {
	["instance_timer_sv"] = {
		["locked"] = true,
		["on"] = true,
		["pos"] = {
			"BOTTOM", -- [1]
			nil, -- [2]
			"BOTTOM", -- [3]
			-315.022247314453, -- [4]
			1.77779114246368, -- [5]
		},
	},
	["target_warn_sv"] = {
		["Player-4920-02650AFE"] = {
			["on"] = true,
			["locked"] = false,
		},
		["Player-4920-01D0B369"] = {
			["on"] = true,
			["locked"] = false,
		},
		["Player-4913-0219F160"] = {
			["on"] = true,
			["locked"] = false,
		},
		["Player-4920-025D3DFB"] = {
			["on"] = true,
			["locked"] = false,
		},
		["Player-4920-01D0E17B"] = {
			["on"] = true,
			["locked"] = false,
		},
	},
}
