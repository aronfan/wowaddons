
BugGrabberDB = {
	["lastSanitation"] = 3,
	["session"] = 271,
	["errors"] = {
		{
			["message"] = "[ADDON_ACTION_BLOCKED] 插件 'WhisperPop' 尝试调用保护功能 'CompactRaidFrame6:Show()'。",
			["time"] = "2020/07/08 21:19:36",
			["stack"] = "Interface\\AddOns\\BugGrabber\\BugGrabber.lua:519: in function <Interface\\AddOns\\BugGrabber\\BugGrabber.lua:519>\n[C]: in function `Show'\nInterface\\FrameXML\\CompactUnitFrame.lua:353: in function `CompactUnitFrame_UpdateVisible'\nInterface\\FrameXML\\CompactUnitFrame.lua:286: in function `CompactUnitFrame_UpdateAll'\nInterface\\FrameXML\\CompactUnitFrame.lua:185: in function <Interface\\FrameXML\\CompactUnitFrame.lua:185>",
			["session"] = 264,
			["counter"] = 1,
		}, -- [1]
	},
}
