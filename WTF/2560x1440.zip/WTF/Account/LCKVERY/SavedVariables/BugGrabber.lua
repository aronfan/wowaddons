
BugGrabberDB = {
	["session"] = 82,
	["lastSanitation"] = 3,
	["errors"] = {
	},
}
