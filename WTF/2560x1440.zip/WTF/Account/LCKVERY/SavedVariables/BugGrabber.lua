
BugGrabberDB = {
	["session"] = 146,
	["lastSanitation"] = 3,
	["errors"] = {
	},
}
