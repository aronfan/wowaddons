
BugGrabberDB = {
	["lastSanitation"] = 3,
	["session"] = 1,
	["errors"] = {
	},
}
