
Combuctor_Sets = {
	["tackleColor"] = {
	},
	["leatherColor"] = {
	},
	["engineerColor"] = {
	},
	["herbColor"] = {
	},
	["inscribeColor"] = {
	},
	["soulColor"] = {
	},
	["locked"] = false,
	["quiverColor"] = {
	},
	["reagentColor"] = {
	},
	["gemColor"] = {
	},
	["enchantColor"] = {
	},
	["keyColor"] = {
	},
	["normalColor"] = {
	},
	["profiles"] = {
	},
	["mineColor"] = {
	},
	["version"] = "8.3.2",
	["global"] = {
		["inventory"] = {
			["enabled"] = true,
			["rules"] = {
				"all/normal", -- [1]
				"all/trade", -- [2]
				"all/reagent", -- [3]
				"all/keys", -- [4]
				"all/quiver", -- [5]
				"equip/armor", -- [6]
				"equip/weapon", -- [7]
				"equip/trinket", -- [8]
				"use/consume", -- [9]
				"use/enhance", -- [10]
				"trade/goods", -- [11]
				"trade/gem", -- [12]
				"trade/glyph", -- [13]
				"trade/recipe", -- [14]
				"all/souls", -- [15]
				"equip/ammo", -- [16]
			},
			["point"] = "TOPRIGHT",
			["hiddenBags"] = {
				[4] = false,
				[-2] = true,
			},
			["color"] = {
			},
			["hiddenRules"] = {
				["misc"] = true,
				["trade"] = true,
				["equip"] = true,
				["all"] = true,
				["quest"] = true,
				["use"] = true,
			},
			["width"] = 314.223205566406,
			["y"] = -93.6777102623464,
			["x"] = -203.847085918744,
			["borderColor"] = {
			},
			["height"] = 507.160888671875,
		},
		["vault"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["borderColor"] = {
			},
		},
		["guild"] = {
			["rules"] = {
				"all", -- [1]
				"all/normal", -- [2]
				"all/trade", -- [3]
				"all/reagent", -- [4]
				"all/keys", -- [5]
				"all/quiver", -- [6]
				"equip", -- [7]
				"equip/armor", -- [8]
				"equip/weapon", -- [9]
				"equip/trinket", -- [10]
				"use", -- [11]
				"use/consume", -- [12]
				"use/enhance", -- [13]
				"trade", -- [14]
				"trade/goods", -- [15]
				"trade/gem", -- [16]
				"trade/glyph", -- [17]
				"trade/recipe", -- [18]
				"quest", -- [19]
				"misc", -- [20]
			},
			["borderColor"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
			},
			["hiddenBags"] = {
			},
		},
		["bank"] = {
			["rules"] = {
				"all/normal", -- [1]
				"all/trade", -- [2]
				"all/reagent", -- [3]
				"all/keys", -- [4]
				"all/quiver", -- [5]
				"equip/armor", -- [6]
				"equip/weapon", -- [7]
				"equip/trinket", -- [8]
				"use/consume", -- [9]
				"use/enhance", -- [10]
				"trade/goods", -- [11]
				"trade/gem", -- [12]
				"trade/glyph", -- [13]
				"trade/recipe", -- [14]
				"all/souls", -- [15]
				"equip/ammo", -- [16]
			},
			["point"] = "TOPLEFT",
			["hiddenBags"] = {
			},
			["color"] = {
			},
			["hiddenRules"] = {
				["misc"] = true,
				["trade"] = true,
				["equip"] = true,
				["all"] = true,
				["quest"] = true,
				["use"] = true,
			},
			["width"] = 577.087890625,
			["y"] = -90.5431887779714,
			["x"] = 696.284545898438,
			["borderColor"] = {
			},
			["height"] = 533.976135253906,
			["showBags"] = true,
		},
	},
	["fridgeColor"] = {
	},
}
