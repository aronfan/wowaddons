
DominosDB = {
	["namespaces"] = {
		["ProgressBars"] = {
			["char"] = {
				["帆歌 - 寒冰之王"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["龙哥 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["啪啪 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
				["阿雅 - 龙牙"] = {
					["bars"] = {
						["exp"] = {
							["mode"] = "xp",
						},
					},
				},
			},
			["global"] = {
				["version"] = 2,
			},
		},
	},
	["global"] = {
		["configVersion"] = 1,
		["addonVersion"] = "8.3.1",
	},
	["profileKeys"] = {
		["帆歌 - 寒冰之王"] = "帆歌 - 寒冰之王",
		["龙哥 - 龙牙"] = "龙哥 - 龙牙",
		["啪啪 - 龙牙"] = "啪啪 - 龙牙",
		["阿雅 - 龙牙"] = "阿雅 - 龙牙",
	},
	["profiles"] = {
		["帆歌 - 寒冰之王"] = {
			["showgrid"] = true,
			["minimap"] = {
				["hide"] = true,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 40,
					["anchor"] = "6TR",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
							["page4"] = 3,
							["page2"] = 1,
							["page3"] = 2,
							["page5"] = 4,
							["berserker"] = 8,
							["battle"] = 6,
							["defensive"] = 7,
							["page6"] = 5,
						},
					},
					["padW"] = 2,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["anchor"] = "7BR",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["y"] = 200,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 20,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = -92,
					["anchor"] = "10TR",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["padW"] = 2,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 80,
					["anchor"] = "1TC",
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["padW"] = 2,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["showInOverrideUI"] = false,
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["y"] = 360,
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["numButtons"] = 20,
					["showInOverrideUI"] = false,
					["font"] = "Friz Quadrata TT",
					["padH"] = 2,
					["y"] = 0,
					["x"] = 0,
					["padW"] = 2,
					["spacing"] = 1,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["lockMode"] = true,
					["alwaysShowText"] = true,
					["texture"] = "blizzard",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -225,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = "5TL",
					["showInOverrideUI"] = false,
					["y"] = 120,
				},
				["pet"] = {
					["y"] = -57,
					["spacing"] = 6,
					["anchor"] = "4TC",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "5TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["linkedOpacity"] = true,
		},
		["龙哥 - 龙牙"] = {
			["showgrid"] = true,
			["minimap"] = {
				["hide"] = true,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 40,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["WARRIOR"] = {
							["page4"] = 3,
							["page2"] = 1,
							["page3"] = 2,
							["page5"] = 4,
							["berserker"] = 8,
							["battle"] = 6,
							["defensive"] = 7,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["shadowdance"] = 6,
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["anchor"] = "6TL",
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 40,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 34,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 120,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 80,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["anchor"] = "1TR",
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["padH"] = 2,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 240,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 280,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 320,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["numButtons"] = 12,
					["pages"] = {
						["HUNTER"] = {
						},
						["WARRIOR"] = {
						},
						["ROGUE"] = {
						},
					},
					["y"] = 360,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["y"] = 160,
					["font"] = "Friz Quadrata TT",
					["padH"] = 1,
					["anchor"] = "4TC",
					["display"] = {
						["border"] = true,
						["icon"] = false,
						["time"] = true,
					},
					["padW"] = 1,
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "TOP",
					["alwaysShowText"] = true,
					["columns"] = 20,
					["lockMode"] = true,
					["hidden"] = true,
					["display"] = {
						["value"] = true,
						["label"] = true,
						["max"] = true,
						["bonus"] = true,
					},
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = 0,
					["spacing"] = 1,
					["padH"] = 2,
					["x"] = 0,
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -225,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = "5TL",
					["showInOverrideUI"] = false,
					["y"] = 120,
				},
				["pet"] = {
					["y"] = 120,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["anchor"] = "5TC",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "5TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
			},
			["linkedOpacity"] = true,
		},
		["啪啪 - 龙牙"] = {
			["linkedOpacity"] = true,
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "6TL",
					["pages"] = {
						["HUNTER"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
						["ROGUE"] = {
							["page2"] = 1,
							["shadowdance"] = 6,
							["page5"] = 4,
							["page4"] = 3,
							["stealth"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["y"] = 40,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 40,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 34,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 120,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["padH"] = 2,
					["spacing"] = 4,
					["anchor"] = "1TR",
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
					["y"] = 80,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["spacing"] = 4,
					["anchor"] = "2BC",
					["padH"] = 2,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["pages"] = {
						["HUNTER"] = {
						},
						["ROGUE"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [10]
				["cast"] = {
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 1,
					["font"] = "Friz Quadrata TT",
					["y"] = 160,
					["anchor"] = "4TC",
					["padH"] = 1,
					["display"] = {
						["border"] = true,
						["time"] = true,
						["icon"] = false,
					},
					["texture"] = "blizzard",
				},
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["point"] = "TOP",
					["lockMode"] = true,
					["padW"] = 2,
					["spacing"] = 1,
					["numButtons"] = 20,
					["texture"] = "blizzard",
					["showInPetBattleUI"] = false,
					["columns"] = 20,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["y"] = 0,
					["font"] = "Friz Quadrata TT",
					["padH"] = 2,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["x"] = 0,
					["alwaysShowText"] = true,
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "5TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["pet"] = {
					["y"] = 120,
					["point"] = "BOTTOM",
					["spacing"] = 6,
					["anchor"] = "5TC",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["point"] = "CENTER",
					["spacing"] = 2,
				},
			},
			["minimap"] = {
				["hide"] = true,
			},
			["showgrid"] = true,
		},
		["阿雅 - 龙牙"] = {
			["linkedOpacity"] = true,
			["minimap"] = {
				["hide"] = true,
			},
			["frames"] = {
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 40,
					["spacing"] = 4,
					["anchor"] = "6TR",
					["pages"] = {
						["WARRIOR"] = {
							["berserker"] = 8,
							["page2"] = 1,
							["defensive"] = 7,
							["page5"] = 4,
							["page4"] = 3,
							["battle"] = 6,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [1]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["y"] = 200,
					["spacing"] = 4,
					["anchor"] = "7BR",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [2]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOMLEFT",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["x"] = 20,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [3]
				{
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["y"] = -92,
					["spacing"] = 4,
					["anchor"] = "10TR",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [4]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["padW"] = 2,
					["y"] = 80,
					["spacing"] = 4,
					["anchor"] = "1TC",
					["pages"] = {
						["WARRIOR"] = {
						},
					},
					["numButtons"] = 12,
					["padH"] = 2,
				}, -- [5]
				{
					["showInPetBattleUI"] = false,
					["padW"] = 2,
					["point"] = "BOTTOM",
					["spacing"] = 4,
					["padH"] = 2,
					["showInOverrideUI"] = false,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
				}, -- [6]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 240,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
				}, -- [7]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 280,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
				}, -- [8]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 320,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
				}, -- [9]
				{
					["showInPetBattleUI"] = false,
					["point"] = "BOTTOM",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["padW"] = 2,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["y"] = 360,
					["numButtons"] = 12,
					["pages"] = {
						["WARRIOR"] = {
						},
					},
				}, -- [10]
				["menu"] = {
					["y"] = 0,
					["x"] = -244,
					["point"] = "BOTTOMRIGHT",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["exp"] = {
					["showInPetBattleUI"] = false,
					["point"] = "TOP",
					["columns"] = 20,
					["alwaysShowText"] = true,
					["lockMode"] = true,
					["showInOverrideUI"] = false,
					["display"] = {
						["value"] = true,
						["bonus"] = true,
						["max"] = true,
						["label"] = true,
					},
					["padW"] = 2,
					["font"] = "Friz Quadrata TT",
					["y"] = 0,
					["spacing"] = 1,
					["padH"] = 2,
					["x"] = 0,
					["numButtons"] = 20,
					["texture"] = "blizzard",
				},
				["bags"] = {
					["showInPetBattleUI"] = false,
					["showInOverrideUI"] = false,
				},
				["vehicle"] = {
					["y"] = 120,
					["x"] = 224,
					["point"] = "BOTTOM",
					["anchor"] = "5TR",
					["showInOverrideUI"] = false,
					["showInPetBattleUI"] = false,
				},
				["pet"] = {
					["y"] = -57,
					["spacing"] = 6,
					["anchor"] = "4TC",
					["showInOverrideUI"] = false,
					["hidden"] = true,
					["showInPetBattleUI"] = false,
				},
				["class"] = {
					["showInPetBattleUI"] = false,
					["x"] = -225,
					["point"] = "BOTTOM",
					["spacing"] = 2,
					["anchor"] = "5TL",
					["showInOverrideUI"] = false,
					["y"] = 120,
				},
			},
			["showgrid"] = true,
		},
	},
}
