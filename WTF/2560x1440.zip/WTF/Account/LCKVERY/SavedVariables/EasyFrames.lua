
EasyFramesDB = {
	["profileKeys"] = {
		["帆歌 - 寒冰之王"] = "Default",
		["龙哥 - 龙牙"] = "Default",
		["啪啪 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["player"] = {
				["showGroupIndicator"] = false,
				["playerNameFontSize"] = 14,
				["portrait"] = "1",
				["showNameInsideFrame"] = true,
			},
			["general"] = {
				["classColored"] = false,
				["barTexture"] = "Flat",
			},
			["target"] = {
				["showNameInsideFrame"] = true,
				["targetNameFontSize"] = 14,
				["showTargetCastbar"] = true,
			},
			["pet"] = {
				["showName"] = false,
			},
		},
	},
}
