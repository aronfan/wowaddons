
EasyFramesDB = {
	["profileKeys"] = {
		["帆歌 - 寒冰之王"] = "Default",
		["龙哥 - 龙牙"] = "Default",
		["啪啪 - 龙牙"] = "Default",
		["阿雅 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["player"] = {
				["portrait"] = "1",
				["playerNameFontSize"] = 14,
				["showGroupIndicator"] = false,
				["showNameInsideFrame"] = true,
			},
			["general"] = {
				["classColored"] = false,
				["barTexture"] = "Flat",
			},
			["target"] = {
				["showNameInsideFrame"] = true,
				["targetNameFontSize"] = 14,
				["showTargetCastbar"] = true,
			},
			["pet"] = {
				["showName"] = false,
			},
		},
	},
}
