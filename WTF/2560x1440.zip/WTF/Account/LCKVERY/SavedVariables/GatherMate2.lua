
GatherMate2DB = {
	["profileKeys"] = {
		["帆歌 - 寒冰之王"] = "Default",
		["龙哥 - 龙牙"] = "Default",
		["啪啪 - 龙牙"] = "Default",
		["阿雅 - 龙牙"] = "Default",
	},
	["global"] = {
		["data_version"] = 5,
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
GatherMate2HerbDB = {
}
GatherMate2MineDB = {
	[1451] = {
		[6721400900] = 214,
		[5535157100] = 208,
		[4867626400] = 214,
		[4263838600] = 214,
		[2869226900] = 214,
		[3333416600] = 214,
		[4406930600] = 214,
	},
}
GatherMate2FishDB = {
}
GatherMate2GasDB = nil
GatherMate2TreasureDB = {
}
GatherMate2ArchaeologyDB = nil
GatherMate2LoggingDB = nil
