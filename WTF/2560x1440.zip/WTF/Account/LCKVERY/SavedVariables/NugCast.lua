
NugCastDB = {
	["castColor"] = {
		0.227450980392157, -- [1]
		1, -- [2]
		0.105882352941176, -- [3]
	},
	["barTexture"] = "Flat",
	["anchors"] = {
		["target"] = {
			["y"] = 100,
		},
	},
	["timeFont"] = "默认",
	["nameplateCastbars"] = false,
	["spellFont"] = "默认",
}
