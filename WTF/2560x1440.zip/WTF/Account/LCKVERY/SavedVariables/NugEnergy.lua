
NugEnergyDB = {
	["lowColor"] = {
		0.552941176470588, -- [1]
		0.12156862745098, -- [2]
		0.243137254901961, -- [3]
	},
	["fontName"] = "默认",
	["y"] = 124.400184631348,
	["x"] = -164.266906738281,
	["maxColor"] = {
		0.513725490196078, -- [1]
	},
	["height"] = 25,
	["point"] = "BOTTOM",
	["textureName"] = "Flat",
	["outOfCombatAlpha"] = 1,
	["twChangeColor"] = false,
	["hideText"] = true,
	["width"] = 80,
	["enableColorByPowerType"] = true,
}
