
NRunDB_Global = {
	["nptextureName"] = "Flat",
	["drEnabled"] = true,
	["anchors"] = {
		["main"] = {
			["y"] = -64.0001678466797,
			["x"] = 234.66650390625,
		},
		["secondary"] = {
			["x"] = 0,
		},
	},
	["charspec"] = {
	},
	["textureName"] = "Flat",
}
NugRunningConfigCustom = {
	["HUNTER"] = {
	},
	["WARRIOR"] = {
	},
	["ROGUE"] = {
	},
}
