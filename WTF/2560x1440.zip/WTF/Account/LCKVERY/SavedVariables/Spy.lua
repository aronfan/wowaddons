
SpyDB = {
	["kosData"] = {
		["龙牙"] = {
			["Horde"] = {
				["龙哥"] = {
				},
				["啪啪"] = {
				},
				["阿雅"] = {
				},
			},
		},
		["寒冰之王"] = {
			["Alliance"] = {
				["帆歌"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["龙牙"] = {
			["Horde"] = {
			},
		},
		["寒冰之王"] = {
			["Alliance"] = {
			},
		},
	},
	["profileKeys"] = {
		["帆歌 - 寒冰之王"] = "帆歌 - 寒冰之王",
		["龙哥 - 龙牙"] = "龙哥 - 龙牙",
		["啪啪 - 龙牙"] = "啪啪 - 龙牙",
		["阿雅 - 龙牙"] = "阿雅 - 龙牙",
	},
	["profiles"] = {
		["帆歌 - 寒冰之王"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindowVis"] = false,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
		},
		["龙哥 - 龙牙"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 825,
					["x"] = 1634.44470214844,
					["w"] = 159.999954223633,
					["h"] = 51.0000076293945,
				},
			},
			["Colors"] = {
				["Alert"] = {
					["Stealth Text"] = {
						["a"] = 1,
					},
					["Name Text"] = {
						["a"] = 1,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
			["MainWindowVis"] = false,
			["HideSpy"] = true,
		},
		["啪啪 - 龙牙"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 803.000061035156,
					["x"] = 1638.44445800781,
					["w"] = 160.000076293945,
					["h"] = 51.0000076293945,
				},
			},
			["Colors"] = {
				["Alert"] = {
					["Stealth Text"] = {
						["a"] = 1,
					},
					["Name Text"] = {
						["a"] = 1,
					},
				},
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["HideSpy"] = true,
			["AppendUnitNameCheck"] = true,
			["BarTexture"] = "Blizzard",
			["AppendUnitKoSCheck"] = true,
			["MainWindowVis"] = false,
		},
		["阿雅 - 龙牙"] = {
			["AppendUnitNameCheck"] = true,
			["MainWindowVis"] = false,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitKoSCheck"] = true,
		},
	},
}
