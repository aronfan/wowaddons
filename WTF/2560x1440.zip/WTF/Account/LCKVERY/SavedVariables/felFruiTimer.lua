
felFruiTimerDB = {
	["auto"] = 1,
	["ssouth3"] = false,
}
