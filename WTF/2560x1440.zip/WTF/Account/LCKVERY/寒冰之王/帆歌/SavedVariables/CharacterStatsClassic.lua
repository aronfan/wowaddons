
CharacterStatsClassicCharacterDB = {
	["selectedLeftStatsCategory"] = 5,
	["selectedRightStatsCategory"] = 2,
}
