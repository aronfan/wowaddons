
ExAE_Config = {
	["帆歌@Enigma"] = {
		{
			["Finger0Slot"] = {
			},
			["BackSlot"] = {
				["name"] = "徽记披风",
				["link"] = "item:3070::::::::6:::11::::",
			},
			["Trinket0Slot"] = {
			},
			["TabardSlot"] = {
			},
			["FeetSlot"] = {
				["name"] = "轻型锁甲靴",
				["link"] = "item:2395::::::::6:::14::::",
			},
			["NeckSlot"] = {
			},
			["Finger1Slot"] = {
			},
			["ChestSlot"] = {
				["name"] = "轻型锁甲",
				["link"] = "item:2392::::::::6:::14::::",
			},
			["Trinket1Slot"] = {
			},
			["ShoulderSlot"] = {
			},
			["MainHandSlot"] = {
				["name"] = "步兵剑",
				["link"] = "item:2488::::::::6:::14::::",
			},
			["AmmoSlot"] = {
			},
			["RangedSlot"] = {
			},
			["ShirtSlot"] = {
				["name"] = "新兵衬衣",
				["link"] = "item:38::::::::6:::::::",
			},
			["SecondaryHandSlot"] = {
				["name"] = "黑色尖头盾",
				["link"] = "item:1201::::::::6:::14::::",
			},
			["HeadSlot"] = {
			},
			["WristSlot"] = {
				["name"] = "轻型锁甲护腕",
				["link"] = "item:2396::::::::6:::14::::",
			},
			["WaistSlot"] = {
				["name"] = "轻型锁甲腰带",
				["link"] = "item:2393::::::::6:::14::::",
			},
			["LegsSlot"] = {
				["name"] = "轻型锁甲护腿",
				["link"] = "item:2394::::::::6:::14::::",
			},
			["HandsSlot"] = {
				["name"] = "轻型锁甲手套",
				["link"] = "item:2397::::::::6:::14::::",
			},
		}, -- [1]
		["CurrentSetId"] = 1,
	},
}
