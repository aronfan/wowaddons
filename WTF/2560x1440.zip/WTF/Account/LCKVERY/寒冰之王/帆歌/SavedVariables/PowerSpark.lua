
PowerSparkDB = {
	["default"] = {
		["timer"] = 2212348.345,
	},
}
