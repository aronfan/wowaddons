
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 163,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.004046,
							["damage_from"] = {
								["妩媚飒飒"] = true,
								["啪啪"] = true,
								["无常十号"] = true,
								["妖怪你别里跑"] = true,
								["窈窕淑"] = true,
							},
							["targets"] = {
								["无常十号"] = 12461,
							},
							["pets"] = {
								"大酋长雷德·黑手 <盖斯>", -- [1]
							},
							["end_time"] = 1588653785,
							["boss_fight_component"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7235.004046,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 12461.004046,
							["friendlyfire_total"] = 0,
							["damage_taken"] = 32402.004046,
							["nome"] = "盖斯",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 4,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 248,
										["targets"] = {
											["无常十号"] = 2581,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2581,
										["n_min"] = 105,
										["g_dmg"] = 0,
										["counter"] = 22,
										["total"] = 2581,
										["r_amt"] = 0,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 511,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 13,
										["DODGE"] = 7,
										["a_amt"] = 0,
									},
									["腐蚀酸液吐息"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 415,
										["targets"] = {
											["无常十号"] = 727,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 727,
										["n_min"] = 52,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 727,
										["c_max"] = 0,
										["id"] = "腐蚀酸液吐息",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["冰冻术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 742,
										["targets"] = {
											["无常十号"] = 1974,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1974,
										["n_min"] = 133,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1974,
										["c_max"] = 0,
										["id"] = "冰冻术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["击退"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["无常十号"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "击退",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["DODGE"] = 1,
									},
									["火息术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1116,
										["targets"] = {
											["无常十号"] = 1953,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1953,
										["n_min"] = 837,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1953,
										["c_max"] = 0,
										["id"] = "火息术",
										["r_dmg"] = 837,
										["r_amt"] = 1,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["召唤雷德·黑手"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "召唤雷德·黑手",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588653777,
							["on_hold"] = false,
							["start_time"] = 1588653691,
							["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.001933,
							["damage_from"] = {
								["盖斯"] = true,
								["大酋长雷德·黑手 <盖斯>"] = true,
							},
							["targets"] = {
								["盖斯"] = 2871,
								["大酋长雷德·黑手 <盖斯>"] = 4704,
							},
							["pets"] = {
							},
							["on_hold"] = false,
							["tipo"] = 1,
							["classe"] = "WARRIOR",
							["raid_targets"] = {
							},
							["total_without_pet"] = 7575.001933,
							["delay"] = 1588653711,
							["dps_started"] = false,
							["total"] = 7575.001933,
							["nome"] = "无常十号",
							["damage_taken"] = 12461.001933,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["英勇打击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 347,
										["g_amt"] = 0,
										["n_max"] = 191,
										["targets"] = {
											["盖斯"] = 191,
											["大酋长雷德·黑手 <盖斯>"] = 691,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 535,
										["n_min"] = 167,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 882,
										["c_max"] = 347,
										["id"] = "英勇打击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 347,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["盾牌猛击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 978,
										["g_amt"] = 0,
										["n_max"] = 313,
										["targets"] = {
											["盖斯"] = 699,
											["大酋长雷德·黑手 <盖斯>"] = 2025,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1746,
										["n_min"] = 280,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 2724,
										["c_max"] = 559,
										["r_amt"] = 0,
										["id"] = "盾牌猛击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["c_min"] = 419,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
									["复仇"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 95,
										["g_amt"] = 0,
										["n_max"] = 50,
										["targets"] = {
											["盖斯"] = 195,
											["大酋长雷德·黑手 <盖斯>"] = 226,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 326,
										["n_min"] = 31,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 421,
										["c_max"] = 95,
										["id"] = "复仇",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 95,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 4,
										["b_amt"] = 1,
										["c_dmg"] = 595,
										["g_amt"] = 14,
										["n_max"] = 112,
										["targets"] = {
											["盖斯"] = 1786,
											["大酋长雷德·黑手 <盖斯>"] = 1762,
											["大酋长雷德·黑手"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1912,
										["DODGE"] = 3,
										["n_min"] = 27,
										["MISS"] = 1,
										["counter"] = 47,
										["r_amt"] = 0,
										["total"] = 3548,
										["c_max"] = 179,
										["b_dmg"] = 27,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 107,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 22,
										["a_amt"] = 0,
										["g_dmg"] = 1041,
									},
									["破甲攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["盖斯"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "破甲攻击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["DODGE"] = 2,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588653781,
							["friendlyfire"] = {
							},
							["start_time"] = 1588653701,
							["serial"] = "Player-4920-020A7239",
							["end_time"] = 1588653785,
						}, -- [2]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007752,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
								["盖斯"] = 12220,
								["大酋长雷德·黑手 <盖斯>"] = 14719,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["!Autoshot"] = {
										["c_amt"] = 11,
										["b_amt"] = 2,
										["c_dmg"] = 8629,
										["g_amt"] = 0,
										["n_max"] = 416,
										["targets"] = {
											["盖斯"] = 7997,
											["大酋长雷德·黑手 <盖斯>"] = 8072,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 7440,
										["n_min"] = 257,
										["g_dmg"] = 0,
										["counter"] = 33,
										["total"] = 16069,
										["c_max"] = 887,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 715,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 565,
										["n_amt"] = 22,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["多重射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 527,
										["targets"] = {
											["盖斯"] = 951,
											["大酋长雷德·黑手 <盖斯>"] = 1467,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2418,
										["n_min"] = 448,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2418,
										["c_max"] = 0,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["瞄准射击"] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 1800,
										["g_amt"] = 0,
										["n_max"] = 811,
										["targets"] = {
											["盖斯"] = 2108,
											["大酋长雷德·黑手 <盖斯>"] = 4069,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4377,
										["n_min"] = 681,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 6177,
										["c_max"] = 1800,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1800,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 681,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 101,
										["targets"] = {
											["盖斯"] = 1164,
											["大酋长雷德·黑手 <盖斯>"] = 1111,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2275,
										["n_min"] = 51,
										["g_dmg"] = 0,
										["counter"] = 25,
										["total"] = 2275,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 255,
										["r_amt"] = 5,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 25,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["total"] = 26939.007752,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 26939.007752,
							["nome"] = "啪啪",
							["dps_started"] = false,
							["end_time"] = 1588653785,
							["damage_taken"] = 384.007752,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 254,
							["grupo"] = true,
							["last_dps"] = 0,
							["friendlyfire_total"] = 0,
							["custom"] = 0,
							["last_event"] = 1588653783,
							["on_hold"] = false,
							["start_time"] = 1588653694,
							["serial"] = "Player-4920-01D0E17B",
							["friendlyfire"] = {
							},
						}, -- [3]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004079,
							["damage_from"] = {
							},
							["targets"] = {
								["盖斯"] = 5469,
								["大酋长雷德·黑手 <盖斯>"] = 4728,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["last_event"] = 1588653783,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 10197.004079,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 10197.004079,
							["nome"] = "妩媚飒飒",
							["damage_taken"] = 0.004079,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 2122,
										["g_amt"] = 0,
										["n_max"] = 922,
										["targets"] = {
											["盖斯"] = 5469,
											["大酋长雷德·黑手 <盖斯>"] = 4728,
											["大酋长雷德·黑手"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 8075,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 43,
										["total"] = 10197,
										["c_max"] = 1176,
										["r_amt"] = 18,
										["id"] = "火球术",
										["r_dmg"] = 5289,
										["b_dmg"] = 0,
										["n_amt"] = 40,
										["m_crit"] = 0,
										["c_min"] = 946,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["大酋长雷德·黑手"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "冲击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 4,
										["IMMUNE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1588653785,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588653696,
							["serial"] = "Player-4920-01DC6F13",
							["on_hold"] = false,
						}, -- [4]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005834,
							["damage_from"] = {
							},
							["targets"] = {
								["盖斯"] = 6047,
								["大酋长雷德·黑手 <盖斯>"] = 4834,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["last_event"] = 1588653783,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 10881.005834,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 10881.005834,
							["nome"] = "窈窕淑",
							["damage_taken"] = 0.005834,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 339,
										["g_amt"] = 0,
										["n_max"] = 972,
										["targets"] = {
											["盖斯"] = 5197,
											["大酋长雷德·黑手 <盖斯>"] = 4834,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9692,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 45,
										["total"] = 10031,
										["c_max"] = 339,
										["r_amt"] = 17,
										["id"] = "火球术",
										["r_dmg"] = 4999,
										["b_dmg"] = 0,
										["n_amt"] = 43,
										["m_crit"] = 0,
										["c_min"] = 339,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["点燃"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 391,
										["targets"] = {
											["盖斯"] = 850,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 850,
										["n_min"] = 68,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 850,
										["c_max"] = 0,
										["id"] = "点燃",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["盖斯"] = 0,
											["大酋长雷德·黑手"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "冲击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 4,
										["IMMUNE"] = 2,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1588653785,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588653696,
							["serial"] = "Player-4920-01DC60BC",
							["on_hold"] = false,
						}, -- [5]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.002687,
							["damage_from"] = {
							},
							["targets"] = {
								["盖斯"] = 5795,
								["大酋长雷德·黑手 <盖斯>"] = 3466,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["last_event"] = 1588653779,
							["classe"] = "MAGE",
							["raid_targets"] = {
							},
							["total_without_pet"] = 9261.002687,
							["delay"] = 1588653761,
							["dps_started"] = false,
							["total"] = 9261.002687,
							["nome"] = "妖怪你别里跑",
							["damage_taken"] = 0.002687,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1247,
										["g_amt"] = 0,
										["n_max"] = 846,
										["targets"] = {
											["盖斯"] = 5621,
											["大酋长雷德·黑手 <盖斯>"] = 3466,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 7840,
										["n_min"] = 10,
										["g_dmg"] = 0,
										["counter"] = 45,
										["total"] = 9087,
										["c_max"] = 671,
										["r_amt"] = 19,
										["id"] = "火球术",
										["r_dmg"] = 5460,
										["b_dmg"] = 0,
										["n_amt"] = 42,
										["m_crit"] = 0,
										["c_min"] = 576,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["点燃"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 87,
										["targets"] = {
											["盖斯"] = 174,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 174,
										["n_min"] = 87,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 174,
										["c_max"] = 0,
										["id"] = "点燃",
										["r_dmg"] = 174,
										["r_amt"] = 2,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["大酋长雷德·黑手"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "冲击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 4,
										["IMMUNE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["end_time"] = 1588653785,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588653706,
							["serial"] = "Player-4920-01DC6F5E",
							["on_hold"] = false,
						}, -- [6]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.008114,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["boss_fight_component"] = true,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008114,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 0.008114,
							["damage_taken"] = 0.008114,
							["on_hold"] = false,
							["nome"] = "维克多·奈法里奥斯",
							["spells"] = {
								["_ActorTable"] = {
									["多彩混乱"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "多彩混乱",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 0,
							["last_dps"] = 0,
							["end_time"] = 1588653785,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588653785,
							["serial"] = "Creature-0-4504-229-31332-10162-000030E418",
							["dps_started"] = false,
						}, -- [7]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.0057,
							["damage_from"] = {
								["妩媚飒飒"] = true,
								["啪啪"] = true,
								["无常十号"] = true,
								["妖怪你别里跑"] = true,
								["窈窕淑"] = true,
							},
							["targets"] = {
								["无常十号"] = 5226,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["nome"] = "大酋长雷德·黑手 <盖斯>",
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5226.0057,
							["total"] = 5226.0057,
							["monster"] = true,
							["end_time"] = 1588653785,
							["damage_taken"] = 32451.0057,
							["ownerName"] = "盖斯",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["致死打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1041,
										["targets"] = {
											["无常十号"] = 1041,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1041,
										["n_min"] = 1041,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1041,
										["c_max"] = 0,
										["id"] = "致死打击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["顺劈斩"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["无常十号"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "顺劈斩",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["a_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 4,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 412,
										["targets"] = {
											["无常十号"] = 2830,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2830,
										["MISS"] = 1,
										["n_min"] = 77,
										["g_dmg"] = 0,
										["counter"] = 21,
										["r_amt"] = 0,
										["total"] = 2830,
										["c_max"] = 0,
										["b_dmg"] = 912,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 4,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 11,
										["a_amt"] = 0,
										["DODGE"] = 5,
									},
									["旋风斩"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "旋风斩",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["旋风斩效果"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 675,
										["targets"] = {
											["无常十号"] = 1355,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1355,
										["n_min"] = 139,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1355,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "旋风斩效果",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588653782,
							["on_hold"] = false,
							["start_time"] = 1588653729,
							["serial"] = "Creature-0-4504-229-31332-10429-000030EEA0",
							["friendlyfire_total"] = 0,
						}, -- [8]
						{
							["flag_original"] = -2147483648,
							["totalabsorbed"] = 0.003717,
							["damage_from"] = {
							},
							["targets"] = {
								["余人"] = 259,
								["Sanji"] = 442,
								["很随便"] = 175,
								["加尔摩"] = 370,
								["笨笨牛"] = 11,
								["玛拉卡斯"] = 117,
								["哎呀"] = 832,
								["鲸落"] = 123,
								["人体打桩机"] = 224,
								["胸大都是奶"] = 1632,
								["柳大炮"] = 164,
								["路五"] = 1571,
								["宝宝不吃面包"] = 790,
								["大丈夫萌大奶"] = 2090,
								["脸脸"] = 2078,
								["二营长"] = 173,
								["没了真没了"] = 511,
								["Xjilly"] = 73,
								["零零大"] = 1752,
								["山城亦雾都"] = 27,
								["无畏魂魄"] = 256,
								["天尊戒指"] = 1325,
								["高贵的甜甜圈"] = 62,
								["小恶魔提利昂"] = 577,
								["我是戒律牧"] = 311,
								["Tobu"] = 1876,
								["匪地主"] = 434,
								["后撤步哥憨子"] = 1746,
								["猛牛酸酸乳"] = 23,
								["狮子座丶伍月"] = 1195,
								["达芬奇密码"] = 123,
								["Mmint"] = 65,
								["还尼玛追"] = 235,
								["暴躁的肉包子"] = 170,
								["夏雨"] = 445,
								["小西几小脑斧"] = 100,
								["秋风兮"] = 490,
								["Natural"] = 1060,
								["牛大志"] = 1946,
								["盛产水水"] = 191,
								["一发直入魂"] = 1,
								["搓个螺旋丸"] = 550,
								["叨叨不喝酒"] = 92,
								["雪落"] = 1257,
								["弯弓射大雕"] = 334,
								["Underattack"] = 96,
								["老友记"] = 792,
								["滨崎歨"] = 540,
								["隐龟人"] = 161,
								["冻住别动"] = 195,
								["禅宁"] = 310,
								["野外小卖店"] = 369,
								["Lovein"] = 347,
								["白露时节"] = 14,
								["耶路撒冷之烬"] = 590,
								["云卷云舒的术"] = 122,
								["殺戮機器"] = 267,
								["抓过你的奶"] = 213,
								["Squanchy"] = 156,
								["黑又粗敲钟牛"] = 5,
								["逆苍天"] = 3,
								["佳佳布鲁根"] = 22,
								["野花开在坟头"] = 488,
								["揉揉"] = 106,
								["熊心壮痣"] = 518,
								["小霸霸"] = 534,
								["啪啪"] = 384,
								["鸡爷"] = 182,
								["疯疯"] = 475,
								["Owxue"] = 5,
								["隐藏的心"] = 186,
								["暗影长择"] = 1734,
								["小白兔白又白"] = 464,
								["出逃指南"] = 20,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 37576.003717,
							["damage_taken"] = 0.003717,
							["dps_started"] = true,
							["total"] = 37576.003717,
							["nome"] = "环境伤害 (高处坠落)",
							["delay"] = 1588854759,
							["timeMachine"] = 1,
							["spells"] = {
								["_ActorTable"] = {
									["Falling"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2078,
										["targets"] = {
											["余人"] = 259,
											["Sanji"] = 442,
											["很随便"] = 175,
											["加尔摩"] = 370,
											["笨笨牛"] = 11,
											["玛拉卡斯"] = 117,
											["哎呀"] = 832,
											["鲸落"] = 123,
											["人体打桩机"] = 224,
											["胸大都是奶"] = 1632,
											["柳大炮"] = 164,
											["路五"] = 1571,
											["宝宝不吃面包"] = 790,
											["大丈夫萌大奶"] = 2090,
											["脸脸"] = 2078,
											["二营长"] = 173,
											["没了真没了"] = 511,
											["Xjilly"] = 73,
											["零零大"] = 1752,
											["山城亦雾都"] = 27,
											["无畏魂魄"] = 256,
											["天尊戒指"] = 1325,
											["高贵的甜甜圈"] = 62,
											["小恶魔提利昂"] = 577,
											["我是戒律牧"] = 311,
											["Tobu"] = 1876,
											["匪地主"] = 434,
											["后撤步哥憨子"] = 1746,
											["猛牛酸酸乳"] = 23,
											["狮子座丶伍月"] = 1195,
											["达芬奇密码"] = 123,
											["Mmint"] = 65,
											["还尼玛追"] = 235,
											["暴躁的肉包子"] = 170,
											["夏雨"] = 445,
											["小西几小脑斧"] = 100,
											["秋风兮"] = 490,
											["Natural"] = 1060,
											["牛大志"] = 1946,
											["盛产水水"] = 191,
											["一发直入魂"] = 1,
											["搓个螺旋丸"] = 550,
											["叨叨不喝酒"] = 92,
											["雪落"] = 1257,
											["弯弓射大雕"] = 334,
											["Underattack"] = 96,
											["老友记"] = 792,
											["滨崎歨"] = 540,
											["隐龟人"] = 161,
											["冻住别动"] = 195,
											["禅宁"] = 310,
											["野外小卖店"] = 369,
											["Lovein"] = 347,
											["白露时节"] = 14,
											["耶路撒冷之烬"] = 590,
											["云卷云舒的术"] = 122,
											["殺戮機器"] = 267,
											["抓过你的奶"] = 213,
											["Squanchy"] = 156,
											["黑又粗敲钟牛"] = 5,
											["逆苍天"] = 3,
											["佳佳布鲁根"] = 22,
											["野花开在坟头"] = 488,
											["揉揉"] = 106,
											["熊心壮痣"] = 518,
											["小霸霸"] = 534,
											["啪啪"] = 384,
											["鸡爷"] = 182,
											["疯疯"] = 475,
											["Owxue"] = 5,
											["隐藏的心"] = 186,
											["暗影长择"] = 1734,
											["小白兔白又白"] = 464,
											["出逃指南"] = 20,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 37576,
										["n_min"] = 1,
										["g_dmg"] = 0,
										["counter"] = 93,
										["total"] = 37576,
										["c_max"] = 0,
										["id"] = "Falling",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 93,
										["a_dmg"] = 0,
										["spellschool"] = 3,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire"] = {
							},
							["last_event"] = 1588854759,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = true,
							["start_time"] = 1588854653,
							["serial"] = "",
							["classe"] = "UNKNOW",
						}, -- [9]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001081,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001081,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 0.001081,
							["classe"] = "DRUID",
							["delay"] = 0,
							["nome"] = "熊心壮痣",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 518.001081,
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["last_dps"] = 0,
							["start_time"] = 0,
							["serial"] = "Player-4920-01F83CA4",
							["on_hold"] = false,
						}, -- [10]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008959,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008959,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 0.008959,
							["classe"] = "MAGE",
							["delay"] = 0,
							["nome"] = "夏雨",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["damage_taken"] = 445.008959,
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["last_dps"] = 0,
							["start_time"] = 0,
							["serial"] = "Player-4920-01FC29F8",
							["on_hold"] = false,
						}, -- [11]
						{
							["flag_original"] = -2147483648,
							["totalabsorbed"] = 0.006243,
							["damage_from"] = {
							},
							["targets"] = {
								["奥格瑞玛步兵"] = 41,
								["殇痕"] = 26,
								["牛大志"] = 15,
								["四只松鼠"] = 15,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 97.006243,
							["damage_taken"] = 0.006243,
							["dps_started"] = true,
							["total"] = 97.006243,
							["last_event"] = 1588854722,
							["delay"] = 1588854722,
							["timeMachine"] = 2,
							["spells"] = {
								["_ActorTable"] = {
									["Fire"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 15,
										["targets"] = {
											["奥格瑞玛步兵"] = 41,
											["殇痕"] = 26,
											["牛大志"] = 15,
											["四只松鼠"] = 15,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 97,
										["n_min"] = 11,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 97,
										["c_max"] = 0,
										["id"] = "Fire",
										["r_dmg"] = 0,
										["c_min"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["a_amt"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 3,
									},
								},
								["tipo"] = 2,
							},
							["nome"] = "环境伤害 (火烧)",
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = true,
							["start_time"] = 1588854718,
							["serial"] = "",
							["classe"] = "UNKNOW",
						}, -- [12]
						{
							["flag_original"] = 1304,
							["totalabsorbed"] = 0.001645,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001645,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.001645,
							["classe"] = "UNGROUPPLAYER",
							["serial"] = "Player-4920-024951EA",
							["nome"] = "盛产水水",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 191.001645,
							["start_time"] = 0,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [13]
						{
							["flag_original"] = 1304,
							["totalabsorbed"] = 0.00458,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.00458,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.00458,
							["classe"] = "UNGROUPPLAYER",
							["serial"] = "Player-4920-0248961A",
							["nome"] = "Natural",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1060.00458,
							["start_time"] = 0,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [14]
						{
							["flag_original"] = 1304,
							["totalabsorbed"] = 0.007317,
							["damage_from"] = {
								["环境伤害 (火烧)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007317,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.007317,
							["classe"] = "UNGROUPPLAYER",
							["serial"] = "Player-4920-021AC75D",
							["nome"] = "四只松鼠",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 15.007317,
							["start_time"] = 0,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [15]
						{
							["flag_original"] = 1304,
							["totalabsorbed"] = 0.005567,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005567,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.005567,
							["classe"] = "UNGROUPPLAYER",
							["serial"] = "Player-4920-023C37FA",
							["nome"] = "天尊戒指",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 1325.005567,
							["start_time"] = 0,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [16]
						{
							["flag_original"] = 1304,
							["totalabsorbed"] = 0.007779,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007779,
							["on_hold"] = false,
							["dps_started"] = false,
							["total"] = 0.007779,
							["classe"] = "UNGROUPPLAYER",
							["serial"] = "Player-4920-01DAE788",
							["nome"] = "宝宝不吃面包",
							["spells"] = {
								["tipo"] = 2,
								["_ActorTable"] = {
								},
							},
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["damage_taken"] = 83.007779,
							["start_time"] = 0,
							["delay"] = 0,
							["last_event"] = 0,
						}, -- [17]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 163,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorb"] = 0.008785,
							["last_hps"] = 0,
							["healing_from"] = {
								["遂于而安"] = true,
								["无常十号"] = true,
							},
							["targets"] = {
								["无常十号"] = 97,
							},
							["delay"] = 1588653697,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.008785,
							["targets_overheal"] = {
							},
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.008785,
							["total_without_pet"] = 97.008785,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.008785,
							["healing_taken"] = 11466.008785,
							["total"] = 97.008785,
							["classe"] = "WARRIOR",
							["end_time"] = 1588653785,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["last_event"] = 1588653697,
							["heal_enemy"] = {
							},
							["nome"] = "无常十号",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588653784,
							["serial"] = "Player-4920-020A7239",
							["spells"] = {
								["_ActorTable"] = {
									["神圣力量"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 97,
										["targets"] = {
											["无常十号"] = 97,
										},
										["n_min"] = 97,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 97,
										["c_max"] = 0,
										["id"] = "神圣力量",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 97,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["totalabsorb"] = 0.002215,
							["last_hps"] = 0,
							["healing_from"] = {
							},
							["targets"] = {
								["无常十号"] = 13189,
							},
							["delay"] = 1588653763,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.002215,
							["targets_overheal"] = {
								["妩媚飒飒"] = 1203,
								["遂于而安"] = 1193,
								["无常十号"] = 3708,
								["妖怪你别里跑"] = 1211,
								["窈窕淑"] = 1186,
							},
							["heal_enemy_amt"] = 0,
							["totalover"] = 8501.002215,
							["total_without_pet"] = 11369.002215,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.002215,
							["healing_taken"] = 0.002215,
							["total"] = 11369.002215,
							["classe"] = "PRIEST",
							["end_time"] = 1588653785,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["last_event"] = 1588653763,
							["heal_enemy"] = {
							},
							["nome"] = "遂于而安",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588653743,
							["serial"] = "Player-4920-01DC68C3",
							["spells"] = {
								["_ActorTable"] = {
									["快速治疗"] = {
										["c_amt"] = 2,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["无常十号"] = 3469,
										},
										["n_max"] = 1280,
										["targets"] = {
											["无常十号"] = 10422,
										},
										["n_min"] = 236,
										["counter"] = 12,
										["overheal"] = 3469,
										["total"] = 10422,
										["c_max"] = 949,
										["id"] = "快速治疗",
										["targets_absorbs"] = {
										},
										["c_curado"] = 949,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 10,
										["n_curado"] = 9473,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
									["治疗祷言"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["妩媚飒飒"] = 1203,
											["遂于而安"] = 1193,
											["窈窕淑"] = 1186,
											["妖怪你别里跑"] = 1211,
											["无常十号"] = 239,
										},
										["n_max"] = 947,
										["targets"] = {
											["妩媚飒飒"] = 0,
											["遂于而安"] = 0,
											["窈窕淑"] = 0,
											["妖怪你别里跑"] = 0,
											["无常十号"] = 947,
										},
										["n_min"] = 947,
										["counter"] = 5,
										["overheal"] = 5032,
										["total"] = 947,
										["c_max"] = 0,
										["id"] = "治疗祷言",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["m_healed"] = 0,
										["c_min"] = 0,
										["totaldenied"] = 0,
										["n_amt"] = 5,
										["n_curado"] = 947,
										["m_amt"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
						}, -- [2]
						{
							["flag_original"] = 1300,
							["totalabsorb"] = 0.006441,
							["last_hps"] = 0,
							["healing_from"] = {
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.006441,
							["targets_overheal"] = {
							},
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.006441,
							["total_without_pet"] = 0.006441,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.006441,
							["healing_taken"] = 0.006441,
							["total"] = 0.006441,
							["classe"] = "MAGE",
							["end_time"] = 1588653785,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["last_event"] = 0,
							["heal_enemy"] = {
							},
							["nome"] = "妖怪你别里跑",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588653785,
							["serial"] = "Player-4920-01DC6F5E",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
						}, -- [3]
						{
							["flag_original"] = 1300,
							["totalabsorb"] = 0.004128,
							["last_hps"] = 0,
							["healing_from"] = {
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.004128,
							["targets_overheal"] = {
							},
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.004128,
							["total_without_pet"] = 0.004128,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.004128,
							["healing_taken"] = 0.004128,
							["total"] = 0.004128,
							["classe"] = "MAGE",
							["end_time"] = 1588653785,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["last_event"] = 0,
							["heal_enemy"] = {
							},
							["nome"] = "妩媚飒飒",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588653785,
							["serial"] = "Player-4920-01DC6F13",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
						}, -- [4]
						{
							["flag_original"] = 1300,
							["totalabsorb"] = 0.002391,
							["last_hps"] = 0,
							["healing_from"] = {
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.002391,
							["targets_overheal"] = {
							},
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.002391,
							["total_without_pet"] = 0.002391,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.002391,
							["healing_taken"] = 0.002391,
							["total"] = 0.002391,
							["classe"] = "MAGE",
							["end_time"] = 1588653785,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["last_event"] = 0,
							["heal_enemy"] = {
							},
							["nome"] = "窈窕淑",
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588653785,
							["serial"] = "Player-4920-01DC60BC",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
						}, -- [5]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 163,
					["_ActorTable"] = {
						{
							["received"] = 49.007044,
							["resource"] = 0.007044,
							["targets"] = {
								["无常十号"] = 49,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.007044,
							["total"] = 49.007044,
							["nome"] = "无常十号",
							["spells"] = {
								["_ActorTable"] = {
									["力量"] = {
										["total"] = 9,
										["id"] = "力量",
										["totalover"] = 0,
										["targets"] = {
											["无常十号"] = 9,
										},
										["counter"] = 9,
									},
									["盾牌专精"] = {
										["total"] = 8,
										["id"] = "盾牌专精",
										["totalover"] = 0,
										["targets"] = {
											["无常十号"] = 8,
										},
										["counter"] = 8,
									},
									["怒不可遏"] = {
										["total"] = 4,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["无常十号"] = 4,
										},
										["counter"] = 4,
									},
									["血性狂暴"] = {
										["total"] = 28,
										["id"] = "血性狂暴",
										["totalover"] = 0,
										["targets"] = {
											["无常十号"] = 28,
										},
										["counter"] = 14,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.007044,
							["flag_original"] = 1300,
							["last_event"] = 1588653778,
							["tipo"] = 3,
							["alternatepower"] = 0.007044,
							["serial"] = "Player-4920-020A7239",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["received"] = 1290.005479,
							["resource"] = 0.005479,
							["targets"] = {
								["妖怪你别里跑"] = 1290,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.005479,
							["total"] = 1290.005479,
							["nome"] = "妖怪你别里跑",
							["spells"] = {
								["_ActorTable"] = {
									["元素大师"] = {
										["total"] = 237,
										["id"] = "元素大师",
										["totalover"] = 0,
										["targets"] = {
											["妖怪你别里跑"] = 237,
										},
										["counter"] = 2,
									},
									["补充法力"] = {
										["total"] = 1053,
										["id"] = "补充法力",
										["totalover"] = 0,
										["targets"] = {
											["妖怪你别里跑"] = 1053,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.005479,
							["flag_original"] = 1300,
							["last_event"] = 1588653783,
							["tipo"] = 3,
							["alternatepower"] = 0.005479,
							["serial"] = "Player-4920-01DC6F5E",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["received"] = 1206.00112,
							["resource"] = 0.00112,
							["targets"] = {
								["窈窕淑"] = 1206,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.00112,
							["total"] = 1206.00112,
							["nome"] = "窈窕淑",
							["spells"] = {
								["_ActorTable"] = {
									["元素大师"] = {
										["total"] = 119,
										["id"] = "元素大师",
										["totalover"] = 0,
										["targets"] = {
											["窈窕淑"] = 119,
										},
										["counter"] = 1,
									},
									["补充法力"] = {
										["total"] = 1087,
										["id"] = "补充法力",
										["totalover"] = 0,
										["targets"] = {
											["窈窕淑"] = 1087,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.00112,
							["flag_original"] = 1300,
							["last_event"] = 1588653768,
							["tipo"] = 3,
							["alternatepower"] = 0.00112,
							["serial"] = "Player-4920-01DC60BC",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["received"] = 1379.003907,
							["resource"] = 0.003907,
							["targets"] = {
								["妩媚飒飒"] = 1379,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.003907,
							["total"] = 1379.003907,
							["nome"] = "妩媚飒飒",
							["spells"] = {
								["_ActorTable"] = {
									["元素大师"] = {
										["total"] = 236,
										["id"] = "元素大师",
										["totalover"] = 0,
										["targets"] = {
											["妩媚飒飒"] = 236,
										},
										["counter"] = 2,
									},
									["补充法力"] = {
										["total"] = 1143,
										["id"] = "补充法力",
										["totalover"] = 0,
										["targets"] = {
											["妩媚飒飒"] = 1143,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.003907,
							["flag_original"] = 1300,
							["last_event"] = 1588653784,
							["tipo"] = 3,
							["alternatepower"] = 0.003907,
							["serial"] = "Player-4920-01DC6F13",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["received"] = 847.004534,
							["resource"] = 0.004534,
							["targets"] = {
								["啪啪"] = 847,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "HUNTER",
							["passiveover"] = 190.004534,
							["total"] = 847.004534,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
									["恢复法力"] = {
										["total"] = 847,
										["id"] = "恢复法力",
										["totalover"] = 0,
										["targets"] = {
											["啪啪"] = 847,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.004534,
							["flag_original"] = 1297,
							["tipo"] = 3,
							["last_event"] = 1588653765,
							["spec"] = 254,
							["alternatepower"] = 0.004534,
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["received"] = 10.007361,
							["resource"] = 0.007361,
							["targets"] = {
								["路五"] = 10,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "UNGROUPPLAYER",
							["passiveover"] = 0.007361,
							["total"] = 10.007361,
							["nome"] = "路五",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["激怒"] = {
										["total"] = 10,
										["id"] = "激怒",
										["totalover"] = 0,
										["targets"] = {
											["路五"] = 10,
										},
										["counter"] = 1,
									},
								},
							},
							["flag_original"] = 1304,
							["last_event"] = 1588854625,
							["alternatepower"] = 0.007361,
							["tipo"] = 3,
							["serial"] = "Player-4920-01DDE332",
							["totalover"] = 0.007361,
						}, -- [6]
						{
							["received"] = 10.006263,
							["resource"] = 0.006263,
							["targets"] = {
								["兰亭序扛把子"] = 10,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "UNGROUPPLAYER",
							["passiveover"] = 0.006263,
							["total"] = 10.006263,
							["nome"] = "兰亭序扛把子",
							["spells"] = {
								["tipo"] = 7,
								["_ActorTable"] = {
									["激怒"] = {
										["total"] = 10,
										["id"] = "激怒",
										["totalover"] = 0,
										["targets"] = {
											["兰亭序扛把子"] = 10,
										},
										["counter"] = 1,
									},
								},
							},
							["flag_original"] = 1304,
							["last_event"] = 1588854731,
							["alternatepower"] = 0.006263,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D40550",
							["totalover"] = 0.006263,
						}, -- [7]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 163,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲攻击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "破甲攻击",
										["uptime"] = 53,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["挑战怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "挑战怒吼",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["嘲讽"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "嘲讽",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["dispell"] = 1.003684,
							["buff_uptime"] = 146,
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["血性狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "血性狂暴",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["盾墙"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "盾墙",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["神圣力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "神圣力量",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["精神错乱"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神错乱",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["伊森哈德之怒"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "伊森哈德之怒",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["dispell_spells"] = {
								["_ActorTable"] = {
									["盾牌猛击"] = {
										["targets"] = {
											["盖斯"] = 1,
										},
										["id"] = "盾牌猛击",
										["dispell_oque"] = {
											["多彩混乱"] = 1,
										},
										["dispell"] = 1,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["debuff_uptime"] = 62,
							["boss_fight_component"] = true,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["英勇打击"] = 4,
								["挑战怒吼"] = 1,
								["嘲讽"] = 1,
								["盾牌猛击"] = 8,
								["破甲攻击"] = 6,
								["复仇"] = 9,
								["盾墙"] = 1,
								["血性狂暴"] = 1,
							},
							["nome"] = "无常十号",
							["tipo"] = 4,
							["last_event"] = 1588653785,
							["debuff_uptime_targets"] = {
							},
							["dispell_targets"] = {
								["盖斯"] = 1,
							},
							["serial"] = "Player-4920-020A7239",
							["dispell_oque"] = {
								["多彩混乱"] = 1,
							},
						}, -- [1]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 14,
										["id"] = "火球术",
										["uptime"] = 66,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 188,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 66,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火球术"] = 19,
								["补充法力"] = 1,
							},
							["nome"] = "妩媚飒飒",
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588653785,
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "Player-4920-01DC6F13",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 12,
										["id"] = "火球术",
										["uptime"] = 70,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
									["点燃"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "点燃",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 94,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["冰甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰甲术",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 74,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火球术"] = 17,
								["补充法力"] = 1,
							},
							["nome"] = "妖怪你别里跑",
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588653785,
							["tipo"] = 4,
							["pets"] = {
							},
							["serial"] = "Player-4920-01DC6F5E",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1300,
							["nome"] = "花姐",
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
							},
							["tipo"] = 4,
							["buff_uptime"] = 188,
							["classe"] = "ROGUE",
							["last_event"] = 1588653785,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["精神错乱"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "精神错乱",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["潜行"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "潜行",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D0BF72",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 1300,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲虚弱"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲虚弱",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["猎人印记"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "猎人印记",
										["uptime"] = 91,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["冰霜陷阱光环"] = {
										["activedamt"] = -1,
										["id"] = "冰霜陷阱光环",
										["targets"] = {
										},
										["actived_at"] = 1588653720,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "毒蛇钉刺",
										["uptime"] = 78,
										["targets"] = {
										},
										["appliedamt"] = 6,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 225,
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "狂暴",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["急速射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急速射击",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["快速射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "快速射击",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 94,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 176,
							["buff_uptime_targets"] = {
							},
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["多重射击"] = 5,
								["狂暴"] = 1,
								["急速射击"] = 1,
								["毒蛇钉刺"] = 6,
								["瞄准射击"] = 7,
								["猎人印记"] = 1,
								["恢复法力"] = 1,
								["自动射击"] = 33,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588653785,
							["pets"] = {
							},
							["nome"] = "啪啪",
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 1300,
							["debuff_uptime"] = 76,
							["last_event"] = 1588653783,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 13,
										["id"] = "火球术",
										["uptime"] = 69,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
									["点燃"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "点燃",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "窈窕淑",
							["grupo"] = true,
							["pets"] = {
							},
							["classe"] = "MAGE",
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["spell_cast"] = {
								["火球术"] = 18,
								["补充法力"] = 1,
							},
							["serial"] = "Player-4920-01DC60BC",
							["boss_fight_component"] = true,
						}, -- [6]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "盖斯",
							["pets"] = {
								"大酋长雷德·黑手 <盖斯>", -- [1]
								"致死打击 <盖斯>", -- [2]
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["腐蚀酸液吐息"] = 1,
								["冰冻术"] = 2,
								["击退"] = 2,
								["火息术"] = 2,
								["召唤雷德·黑手"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
							["boss_fight_component"] = true,
						}, -- [7]
						{
							["flag_original"] = 1300,
							["dispell"] = 1.00671,
							["pets"] = {
							},
							["classe"] = "PRIEST",
							["dispell_targets"] = {
								["无常十号"] = 1,
							},
							["dispell_spells"] = {
								["_ActorTable"] = {
									["驱散魔法"] = {
										["targets"] = {
											["无常十号"] = 1,
										},
										["id"] = "驱散魔法",
										["dispell_oque"] = {
											["冰冻术"] = 1,
										},
										["dispell"] = 1,
										["counter"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["nome"] = "遂于而安",
							["boss_fight_component"] = true,
							["grupo"] = true,
							["spell_cast"] = {
								["驱散魔法"] = 1,
								["快速治疗"] = 12,
								["心灵专注"] = 1,
								["治疗祷言"] = 1,
							},
							["dispell_oque"] = {
								["冰冻术"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1588653785,
							["buff_uptime"] = 17,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["心灵专注"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "心灵专注",
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01DC68C3",
							["buff_uptime_targets"] = {
							},
						}, -- [8]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "维克多·奈法里奥斯",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["多彩混乱"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4504-229-31332-10162-000030E418",
							["boss_fight_component"] = true,
						}, -- [9]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 14,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["无常十号"] = {
									["uptime"] = 14,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588653743,
							["tipo"] = 4,
							["damage_twin"] = "盖斯",
							["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
							["damage_spellid"] = "冰冻术",
							["nome"] = "冰冻术",
						}, -- [10]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 30,
							["spellschool"] = 8,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["无常十号"] = {
									["uptime"] = 30,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588653747,
							["tipo"] = 4,
							["damage_twin"] = "盖斯",
							["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
							["damage_spellid"] = "腐蚀酸液吐息",
							["nome"] = "腐蚀酸液吐息",
						}, -- [11]
						{
							["flag_original"] = 68168,
							["tipo"] = 4,
							["ownerName"] = "盖斯",
							["nome"] = "大酋长雷德·黑手 <盖斯>",
							["pets"] = {
							},
							["last_event"] = 0,
							["spell_cast"] = {
								["致死打击"] = 1,
								["顺劈斩"] = 1,
								["旋风斩"] = 4,
							},
							["classe"] = "UNKNOW",
							["monster"] = true,
							["serial"] = "Creature-0-4504-229-31332-10429-000030EEA0",
							["boss_fight_component"] = true,
						}, -- [12]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 5,
							["spellschool"] = 1,
							["ownerName"] = "盖斯",
							["nome"] = "致死打击 <盖斯>",
							["tipo"] = 4,
							["serial"] = "Creature-0-4504-229-31332-10429-000030EEA0",
							["last_event"] = 1588653751,
							["damage_twin"] = "大酋长雷德·黑手",
							["debuff_uptime_targets"] = {
								["无常十号"] = {
									["uptime"] = 5,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["damage_spellid"] = "致死打击",
							["boss_fight_component"] = true,
						}, -- [13]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 163,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["吴建业"] = true,
					["无常十号"] = true,
					["窈窕淑"] = true,
					["妩媚飒飒"] = true,
					["啪啪"] = true,
					["遂于而安"] = true,
					["李大宝"] = true,
					["花姐"] = true,
					["妖怪你别里跑"] = true,
				},
				["CombatStartedAt"] = 1615454.518,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					114986.587929, -- [1]
					11466, -- [2]
					{
						68.998188, -- [1]
						[0] = 4721.988982,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 2,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["熊心壮痣"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							518, -- [3]
							1588775397.833, -- [4]
							4056, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
					["夏雨"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							355, -- [3]
							1588775405.024, -- [4]
							3600, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							90, -- [3]
							1588775439.836, -- [4]
							3599, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 3,
					},
					["啪啪"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							242, -- [3]
							1588775401.685, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							142, -- [3]
							1588775429.626, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 3,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "12:43:05",
				["cleu_timeline"] = {
				},
				["enemy"] = "维克多·奈法里奥斯",
				["TotalElapsedCombatTime"] = 62.3680000000168,
				["CombatEndedAt"] = 1615516.886,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["妩媚飒飒"] = 10197.004079,
							["啪啪"] = 26939.007752,
							["无常十号"] = 7575.001933,
							["妖怪你别里跑"] = 9261.002687,
							["窈窕淑"] = 10881.005834,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["妩媚飒飒"] = 0.004128,
							["遂于而安"] = 11369.002215,
							["无常十号"] = 97.008785,
							["妖怪你别里跑"] = 0.006441,
							["窈窕淑"] = 0.002391,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1615517.436,
				["combat_id"] = 163,
				["data_inicio"] = "12:41:31",
				["tempo_start"] = 1588653691,
				["contra"] = "盖斯",
				["spells_cast_timeline"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "黑石塔",
					["encounter"] = "维克多·奈法里奥斯",
					["mapid"] = 229,
					["try_number"] = 1,
					["name"] = "维克多·奈法里奥斯",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["combat_counter"] = 686,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					64853, -- [1]
					11466, -- [2]
					{
						49, -- [1]
						[0] = 4722,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 2,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 1615423.428,
				["TimeData"] = {
				},
				["frags"] = {
					["盖斯"] = 1,
					["大酋长雷德·黑手"] = 1,
				},
			}, -- [1]
			{
				{
					["tipo"] = 2,
					["combatId"] = 150,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001283,
							["damage_from"] = {
							},
							["targets"] = {
								["密林"] = 101,
							},
							["pets"] = {
							},
							["classe"] = "HUNTER",
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 101.001283,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1588652743,
							["spells"] = {
								["_ActorTable"] = {
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 101,
										["targets"] = {
											["密林"] = 101,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 101,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 101,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.001283,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588652741,
							["on_hold"] = false,
							["start_time"] = 1588652741,
							["serial"] = "Player-4920-01D0E17B",
							["total"] = 101.001283,
						}, -- [1]
						{
							["flag_original"] = 66888,
							["totalabsorbed"] = 0.006577,
							["damage_from"] = {
								["啪啪"] = true,
							},
							["targets"] = {
							},
							["enemy"] = true,
							["pets"] = {
							},
							["tipo"] = 1,
							["classe"] = "UNGROUPPLAYER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.006577,
							["fight_component"] = true,
							["dps_started"] = false,
							["end_time"] = 1588652743,
							["delay"] = 0,
							["friendlyfire_total"] = 0,
							["nome"] = "密林",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 101.006577,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 0,
							["on_hold"] = false,
							["start_time"] = 1588652743,
							["serial"] = "Player-4920-01D13EB0",
							["total"] = 0.006577,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 150,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 150,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 150,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 2,
							["tipo"] = 4,
							["last_event"] = 1588652743,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D0E17B",
							["classe"] = "HUNTER",
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 150,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["吴建业"] = true,
					["无常十号"] = true,
					["窈窕淑"] = true,
					["妩媚飒飒"] = true,
					["啪啪"] = true,
					["遂于而安"] = true,
					["李大宝"] = true,
					["花姐"] = true,
					["妖怪你别里跑"] = true,
				},
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					101, -- [1]
					-0.012146, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "12:25:44",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "密林",
				["TotalElapsedCombatTime"] = 1614475.286,
				["CombatEndedAt"] = 1614475.286,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 101.001283,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1614475.919,
				["combat_id"] = 150,
				["frags"] = {
					["密林"] = 1,
				},
				["data_inicio"] = "12:25:42",
				["spells_cast_timeline"] = {
				},
				["tempo_start"] = 1588652741,
				["contra"] = "密林",
				["CombatSkillCache"] = {
				},
				["combat_counter"] = 672,
				["start_time"] = 1614473.912,
				["TimeData"] = {
				},
				["totals_grupo"] = {
					101, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
			}, -- [2]
			{
				{
					["tipo"] = 2,
					["combatId"] = 149,
					["_ActorTable"] = {
						{
							["flag_original"] = -2147483648,
							["totalabsorbed"] = 0.008394,
							["damage_from"] = {
							},
							["targets"] = {
								["首席传送师"] = 388,
								["笨吖头"] = 238,
								["馬爷"] = 104,
								["六九号技师"] = 473,
								["一个小白"] = 50,
								["霸气香香包"] = 57,
								["萨尓霸罢"] = 36,
								["五十度灰"] = 224,
								["奶牛豆豆"] = 1568,
								["太昊"] = 11,
								["Dalex"] = 599,
								["Ybbabo"] = 59,
								["杜尔伯特"] = 87,
								["风龙之子"] = 260,
								["年迈的军师"] = 10,
								["绿光制造者"] = 245,
								["老实得很"] = 20,
								["七级糊涂"] = 57,
								["抓你当狗"] = 9,
								["Spicymaster"] = 133,
								["王政骁"] = 771,
								["Walks"] = 231,
								["给莫肌"] = 281,
								["小丶肉饼"] = 24,
								["毁己"] = 1319,
								["Thirdeye"] = 651,
								["托尼帕克"] = 102,
								["青山不老丶"] = 389,
								["啤酒花生乳瓜"] = 184,
								["暴风归来"] = 428,
								["胡萝卜丶"] = 324,
								["Noyaa"] = 31,
								["Paimon"] = 491,
								["归壹"] = 154,
								["猫沙利文"] = 478,
								["疯紫"] = 257,
								["风皇"] = 282,
								["蒙娜丽斌"] = 240,
								["风王"] = 294,
								["Comic"] = 140,
								["神之二传"] = 222,
								["佳佳大宝贝"] = 287,
								["雪中菲"] = 673,
								["偷芯的苹果"] = 7,
								["银狐坏少奶"] = 556,
								["风母"] = 310,
								["啪啪"] = 1630,
								["托尔"] = 18,
								["一大群法師"] = 674,
								["阿斯托尔福"] = 32,
								["恶魔狂想曲"] = 37,
							},
							["pets"] = {
							},
							["last_event"] = 1588652719,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 16145.008394,
							["classe"] = "UNKNOW",
							["dps_started"] = false,
							["end_time"] = 1588652741,
							["delay"] = 1588652719,
							["total"] = 16145.008394,
							["nome"] = "环境伤害 (高处坠落)",
							["spells"] = {
								["_ActorTable"] = {
									["Falling"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1568,
										["targets"] = {
											["首席传送师"] = 388,
											["笨吖头"] = 238,
											["馬爷"] = 104,
											["六九号技师"] = 473,
											["一个小白"] = 50,
											["霸气香香包"] = 57,
											["萨尓霸罢"] = 36,
											["五十度灰"] = 224,
											["奶牛豆豆"] = 1568,
											["太昊"] = 11,
											["Dalex"] = 599,
											["Ybbabo"] = 59,
											["杜尔伯特"] = 87,
											["风龙之子"] = 260,
											["年迈的军师"] = 10,
											["绿光制造者"] = 245,
											["老实得很"] = 20,
											["七级糊涂"] = 57,
											["抓你当狗"] = 9,
											["Spicymaster"] = 133,
											["王政骁"] = 771,
											["Walks"] = 231,
											["给莫肌"] = 281,
											["小丶肉饼"] = 24,
											["毁己"] = 1319,
											["Thirdeye"] = 651,
											["托尼帕克"] = 102,
											["青山不老丶"] = 389,
											["啤酒花生乳瓜"] = 184,
											["暴风归来"] = 428,
											["胡萝卜丶"] = 324,
											["Noyaa"] = 31,
											["Paimon"] = 491,
											["归壹"] = 154,
											["猫沙利文"] = 478,
											["疯紫"] = 257,
											["风皇"] = 282,
											["蒙娜丽斌"] = 240,
											["风王"] = 294,
											["Comic"] = 140,
											["神之二传"] = 222,
											["佳佳大宝贝"] = 287,
											["雪中菲"] = 673,
											["偷芯的苹果"] = 7,
											["银狐坏少奶"] = 556,
											["风母"] = 310,
											["啪啪"] = 1630,
											["托尔"] = 18,
											["一大群法師"] = 674,
											["阿斯托尔福"] = 32,
											["恶魔狂想曲"] = 37,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 16145,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 63,
										["total"] = 16145,
										["c_max"] = 0,
										["id"] = "Falling",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 63,
										["a_dmg"] = 0,
										["spellschool"] = 3,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.008394,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588652451,
							["serial"] = "",
							["fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007069,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["classe"] = "HUNTER",
							["last_event"] = 0,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.007069,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 0.007069,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1630.007069,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["end_time"] = 1588608688,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588608688,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 149,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 149,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 149,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["pets"] = {
							},
							["buff_uptime_targets"] = {
							},
							["buff_uptime"] = 12,
							["classe"] = "HUNTER",
							["tipo"] = 4,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["绿色骸骨战马"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "绿色骸骨战马",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强效敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强效敏捷",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D0E17B",
							["last_event"] = 1588608688,
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 149,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1614470.077,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					16144.426599, -- [1]
					0, -- [2]
					{
						-0.0151119999999985, -- [1]
						[0] = -0.00309600000002774,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "00:11:29",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "未知",
				["TotalElapsedCombatTime"] = 1570421.149,
				["CombatEndedAt"] = 1570421.149,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 0.007069,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1570421.149,
				["combat_id"] = 149,
				["data_inicio"] = "00:11:25",
				["frags"] = {
				},
				["tempo_start"] = 1588608685,
				["combat_counter"] = 669,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
					["啪啪"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							405, -- [3]
							1588608917.375, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							146, -- [3]
							1588650280.531, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							"Falling", -- [2]
							138, -- [3]
							1588650298.865, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
							true, -- [1]
							"Falling", -- [2]
							811, -- [3]
							1588652719.197, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 5,
					},
				},
				["start_time"] = 1570417.662,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [3]
			{
				{
					["tipo"] = 2,
					["combatId"] = 148,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006595,
							["damage_from"] = {
							},
							["targets"] = {
								["枯木剥皮者"] = 2020,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["end_time"] = 1588608522,
							["tipo"] = 1,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 832.006595,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 2020.006595,
							["spells"] = {
								["_ActorTable"] = {
									["猛禽一击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 235,
										["targets"] = {
											["枯木剥皮者"] = 235,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 235,
										["n_min"] = 235,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 235,
										["c_max"] = 0,
										["id"] = "猛禽一击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 311,
										["g_amt"] = 1,
										["n_max"] = 127,
										["targets"] = {
											["枯木剥皮者"] = 560,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 244,
										["n_min"] = 117,
										["g_dmg"] = 5,
										["counter"] = 8,
										["total"] = 560,
										["c_max"] = 311,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 311,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["MISS"] = 4,
									},
									["摔绊"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 37,
										["targets"] = {
											["枯木剥皮者"] = 37,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 37,
										["n_min"] = 37,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 37,
										["c_max"] = 0,
										["id"] = "摔绊",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.006595,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588608521,
							["friendlyfire"] = {
							},
							["start_time"] = 1588608492,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.0037,
							["damage_from"] = {
								["枯木剥皮者"] = true,
							},
							["targets"] = {
								["枯木剥皮者"] = 1188,
							},
							["pets"] = {
							},
							["damage_taken"] = 436.0037,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1188.0037,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 1188.0037,
							["delay"] = 0,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 142,
										["g_amt"] = 0,
										["n_max"] = 80,
										["targets"] = {
											["枯木剥皮者"] = 1188,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1046,
										["n_min"] = 70,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 1188,
										["c_max"] = 142,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 142,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 14,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588608522,
							["last_event"] = 1588608520,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588608492,
							["serial"] = "Pet-0-4504-0-187-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001395,
							["damage_from"] = {
								["机总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["机总 <啪啪>"] = 436,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 436.001395,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 436.001395,
							["end_time"] = 1588608522,
							["damage_taken"] = 2020.001395,
							["nome"] = "枯木剥皮者",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 64,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["机总"] = 0,
											["机总 <啪啪>"] = 436,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 372,
										["n_min"] = 30,
										["g_dmg"] = 0,
										["counter"] = 13,
										["r_amt"] = 0,
										["total"] = 436,
										["c_max"] = 64,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 30,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 64,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 10,
										["MISS"] = 1,
										["a_amt"] = 0,
									},
									["毒药"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["机总"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "毒药",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588608517,
							["on_hold"] = false,
							["start_time"] = 1588608495,
							["serial"] = "Creature-0-4504-0-187-2651-0000303D7E",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 148,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 148,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 148,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["摔绊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "摔绊",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 30,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 30,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强效敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强效敏捷",
										["uptime"] = 30,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 4,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["猛禽一击"] = 1,
								["摔绊"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1588608522,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0E17B",
							["buff_uptime"] = 90,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 6,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-187-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 148,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1570410.223,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					2455.987374, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					832, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "00:08:43",
				["cleu_timeline"] = {
				},
				["enemy"] = "枯木剥皮者",
				["TotalElapsedCombatTime"] = 30.0060000000522,
				["CombatEndedAt"] = 1570254.961,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 2020.006595,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1570254.961,
				["combat_id"] = 148,
				["data_inicio"] = "00:08:12",
				["tempo_start"] = 1588608492,
				["spells_cast_timeline"] = {
				},
				["contra"] = "枯木剥皮者",
				["combat_counter"] = 668,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 1570224.486,
				["TimeData"] = {
				},
				["frags"] = {
					["枯木剥皮者"] = 1,
				},
			}, -- [4]
			{
				{
					["tipo"] = 2,
					["combatId"] = 147,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.007683,
							["damage_from"] = {
								["啪啪"] = true,
								["机总 <啪啪>"] = true,
							},
							["targets"] = {
								["机总 <啪啪>"] = 3164,
								["啪啪"] = 355,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 3519.007683,
							["delay"] = 1588608228,
							["monster"] = true,
							["total"] = 3519.007683,
							["end_time"] = 1588608282,
							["damage_taken"] = 18376.007683,
							["nome"] = "沙德拉",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 2,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 355,
										["targets"] = {
											["机总 <啪啪>"] = 2364,
											["机总"] = 0,
											["啪啪"] = 355,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2719,
										["MISS"] = 1,
										["n_min"] = 263,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 2719,
										["r_amt"] = 0,
										["c_max"] = 0,
										["b_dmg"] = 543,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 9,
										["DODGE"] = 2,
										["a_amt"] = 0,
									},
									["毒药"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 80,
										["targets"] = {
											["机总"] = 0,
											["机总 <啪啪>"] = 800,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 800,
										["n_min"] = 80,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 800,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "毒药",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588608228,
							["on_hold"] = false,
							["start_time"] = 1588608239,
							["serial"] = "Creature-0-4504-0-187-2707-0000303B77",
							["fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.003758,
							["damage_from"] = {
								["沙德拉"] = true,
							},
							["targets"] = {
								["沙德拉"] = 18376,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["damage_taken"] = 355.003758,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 14267.003758,
							["classe"] = "HUNTER",
							["dps_started"] = false,
							["total"] = 18376.003758,
							["delay"] = 0,
							["end_time"] = 1588608282,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 106,
										["targets"] = {
											["沙德拉"] = 5191,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5191,
										["n_min"] = 105,
										["g_dmg"] = 0,
										["counter"] = 49,
										["total"] = 5191,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 49,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 359,
										["targets"] = {
											["沙德拉"] = 2097,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2097,
										["n_min"] = 332,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2097,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["瞄准射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 761,
										["targets"] = {
											["沙德拉"] = 1457,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1457,
										["n_min"] = 696,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1457,
										["c_max"] = 0,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 696,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["多重射击"] = {
										["c_amt"] = 3,
										["b_amt"] = 1,
										["c_dmg"] = 3720,
										["g_amt"] = 0,
										["n_max"] = 506,
										["targets"] = {
											["沙德拉"] = 5124,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1404,
										["n_min"] = 430,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 5124,
										["c_max"] = 1278,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1203,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 430,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["驱散射击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 398,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["沙德拉"] = 398,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 398,
										["c_max"] = 398,
										["id"] = "驱散射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 398,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["last_event"] = 1588608281,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588608088,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001961,
							["damage_from"] = {
								["沙德拉"] = true,
								["枯木剥皮者"] = true,
							},
							["targets"] = {
								["沙德拉"] = 4109,
							},
							["pets"] = {
							},
							["damage_taken"] = 3196.001961,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 4109.001961,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 4109.001961,
							["delay"] = 1588608152,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 6,
										["b_amt"] = 0,
										["c_dmg"] = 771,
										["g_amt"] = 0,
										["n_max"] = 128,
										["targets"] = {
											["沙德拉"] = 4109,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3338,
										["n_min"] = 61,
										["g_dmg"] = 0,
										["counter"] = 58,
										["r_amt"] = 0,
										["total"] = 4109,
										["c_max"] = 136,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 123,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 49,
										["DODGE"] = 2,
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588608282,
							["last_event"] = 1588608280,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588608167,
							["serial"] = "Pet-0-4504-0-187-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 147,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 147,
					["_ActorTable"] = {
						{
							["received"] = 899.001849,
							["resource"] = 0.001849,
							["targets"] = {
								["啪啪"] = 899,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "HUNTER",
							["passiveover"] = 0.001849,
							["total"] = 899.001849,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
									["恢复法力"] = {
										["total"] = 899,
										["id"] = "恢复法力",
										["totalover"] = 0,
										["targets"] = {
											["啪啪"] = 899,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.001849,
							["last_event"] = 1588608188,
							["alternatepower"] = 0.001849,
							["tipo"] = 3,
							["serial"] = "Player-4920-01D0E17B",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 147,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["眩晕"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "眩晕",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["震荡射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "震荡射击",
										["uptime"] = 50,
										["targets"] = {
										},
										["appliedamt"] = 12,
									},
									["猎人印记"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -1,
										["refreshamt"] = 0,
										["id"] = "猎人印记",
										["uptime"] = 95,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["驱散射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "驱散射击",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = -1,
										["refreshamt"] = 3,
										["id"] = "毒蛇钉刺",
										["uptime"] = 180,
										["targets"] = {
										},
										["appliedamt"] = 7,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["猎豹守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "猎豹守护",
										["uptime"] = 183,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 194,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强效敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强效敏捷",
										["uptime"] = 194,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 331,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["猎豹守护"] = 1,
								["毒蛇钉刺"] = 10,
								["自动射击"] = 6,
								["瞄准射击"] = 2,
								["多重射击"] = 6,
								["震荡射击"] = 12,
								["恢复法力"] = 1,
								["猎人印记"] = 1,
								["驱散射击"] = 1,
								["雄鹰守护"] = 1,
							},
							["nome"] = "啪啪",
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime"] = 582,
							["serial"] = "Player-4920-01D0E17B",
							["last_event"] = 1588608282,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 18,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-187-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 147,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["tempo_start"] = 1588608088,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					21894.99249, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 899,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					14267, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 899,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "00:04:42",
				["cleu_timeline"] = {
				},
				["enemy"] = "沙德拉",
				["TotalElapsedCombatTime"] = 1570014.781,
				["CombatEndedAt"] = 1570014.781,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 18376.003758,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1570014.781,
				["combat_id"] = 147,
				["data_inicio"] = "00:01:28",
				["overall_added"] = true,
				["frags"] = {
					["沙德拉"] = 1,
				},
				["TimeData"] = {
				},
				["combat_counter"] = 667,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 1569820.39,
				["contra"] = "沙德拉",
				["spells_cast_timeline"] = {
				},
			}, -- [5]
			{
				{
					["tipo"] = 2,
					["combatId"] = 146,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.005593,
							["damage_from"] = {
								["机总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["机总 <啪啪>"] = 10973,
								["啪啪"] = 319,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 11292.005593,
							["delay"] = 1588607945,
							["monster"] = true,
							["total"] = 11292.005593,
							["end_time"] = 1588607983,
							["damage_taken"] = 8886.005593,
							["nome"] = "沙德拉",
							["spells"] = {
								["_ActorTable"] = {
									["毒药"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 80,
										["targets"] = {
											["机总 <啪啪>"] = 960,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 960,
										["n_min"] = 80,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 960,
										["c_max"] = 0,
										["id"] = "毒药",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 12,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 3,
										["c_dmg"] = 1257,
										["g_amt"] = 0,
										["n_max"] = 351,
										["targets"] = {
											["机总 <啪啪>"] = 10013,
											["机总"] = 0,
											["啪啪"] = 319,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 9075,
										["n_min"] = 267,
										["g_dmg"] = 0,
										["counter"] = 35,
										["r_amt"] = 0,
										["total"] = 10332,
										["c_max"] = 688,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 921,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 569,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 30,
										["DODGE"] = 1,
										["MISS"] = 2,
									},
									["减速毒药"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["机总"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "减速毒药",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588607945,
							["on_hold"] = false,
							["start_time"] = 1588607913,
							["serial"] = "Creature-0-4504-0-187-2707-0000303B77",
							["fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.008325,
							["damage_from"] = {
								["沙德拉"] = true,
							},
							["targets"] = {
								["沙德拉"] = 8886,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["end_time"] = 1588607983,
							["tipo"] = 1,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6688.008325,
							["delay"] = 1588607967,
							["dps_started"] = false,
							["total"] = 8886.008325,
							["spells"] = {
								["_ActorTable"] = {
									["!Autoshot"] = {
										["c_amt"] = 2,
										["b_amt"] = 1,
										["c_dmg"] = 1737,
										["g_amt"] = 0,
										["n_max"] = 348,
										["targets"] = {
											["沙德拉"] = 3400,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1663,
										["n_min"] = 322,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 3400,
										["c_max"] = 915,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 822,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 326,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["奥术射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 208,
										["targets"] = {
											["沙德拉"] = 208,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 208,
										["n_min"] = 208,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 208,
										["c_max"] = 0,
										["id"] = "奥术射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 64,
									},
									["多重射击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1172,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["沙德拉"] = 1172,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 1172,
										["c_max"] = 1172,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1172,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 106,
										["targets"] = {
											["沙德拉"] = 1908,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1908,
										["n_min"] = 106,
										["g_dmg"] = 0,
										["counter"] = 19,
										["total"] = 1908,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 18,
										["spellschool"] = 8,
										["EVADE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 319.008325,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588607985,
							["friendlyfire"] = {
							},
							["start_time"] = 1588607915,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005881,
							["damage_from"] = {
								["沙德拉"] = true,
							},
							["targets"] = {
								["沙德拉"] = 2198,
							},
							["pets"] = {
							},
							["damage_taken"] = 10973.005881,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2198.005881,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 2198.005881,
							["delay"] = 1588607940,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 140,
										["g_amt"] = 0,
										["n_max"] = 124,
										["targets"] = {
											["沙德拉"] = 2198,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2058,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 34,
										["r_amt"] = 0,
										["total"] = 2198,
										["c_max"] = 140,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["c_min"] = 140,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 29,
										["a_amt"] = 0,
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588607983,
							["last_event"] = 1588608087,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588607918,
							["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 146,
					["_ActorTable"] = {
						{
							["flag_original"] = 1297,
							["totalabsorb"] = 0.007868,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["机总 <啪啪>"] = 6860,
							},
							["delay"] = 1588607930,
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
							},
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.007868,
							["total_without_pet"] = 6860.007868,
							["totalover_without_pet"] = 0.007868,
							["totaldenied"] = 0.007868,
							["healing_taken"] = 0.007868,
							["end_time"] = 1588607983,
							["classe"] = "HUNTER",
							["total"] = 6860.007868,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
									["治疗宠物"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 245,
										["targets"] = {
											["机总 <啪啪>"] = 6860,
										},
										["n_min"] = 245,
										["counter"] = 28,
										["overheal"] = 0,
										["total"] = 6860,
										["c_max"] = 0,
										["id"] = "治疗宠物",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 28,
										["n_curado"] = 6860,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["heal_enemy"] = {
							},
							["targets_absorbs"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588607930,
							["on_hold"] = false,
							["start_time"] = 1588607936,
							["serial"] = "Player-4920-01D0E17B",
							["spec"] = 254,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["healing_from"] = {
								["啪啪"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.001215,
							["total_without_pet"] = 0.001215,
							["total"] = 0.001215,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
							["totalabsorb"] = 0.001215,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.001215,
							["healing_taken"] = 6860.001215,
							["fight_component"] = true,
							["end_time"] = 1588607983,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["totaldenied"] = 0.001215,
							["targets_overheal"] = {
							},
							["custom"] = 0,
							["tipo"] = 2,
							["last_event"] = 0,
							["start_time"] = 1588607983,
							["delay"] = 0,
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 146,
					["_ActorTable"] = {
						{
							["received"] = 794.002442,
							["resource"] = 0.002442,
							["targets"] = {
								["啪啪"] = 794,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "HUNTER",
							["passiveover"] = 862.002442,
							["total"] = 794.002442,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
									["恢复法力"] = {
										["total"] = 794,
										["id"] = "恢复法力",
										["totalover"] = 0,
										["targets"] = {
											["啪啪"] = 794,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.002442,
							["alternatepower"] = 0.002442,
							["last_event"] = 1588607895,
							["tipo"] = 3,
							["spec"] = 254,
							["serial"] = "Player-4920-01D0E17B",
							["flag_original"] = 1297,
						}, -- [1]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 146,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["猎人印记"] = {
										["activedamt"] = -1,
										["id"] = "猎人印记",
										["targets"] = {
										},
										["actived_at"] = 1588607983,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = "毒蛇钉刺",
										["uptime"] = 55,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									["震荡射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "震荡射击",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["猎豹守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "猎豹守护",
										["uptime"] = 51,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 107,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强效敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强效敏捷",
										["uptime"] = 107,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["野性守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "野性守护",
										["uptime"] = 56,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 59,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["猎豹守护"] = 1,
								["毒蛇钉刺"] = 4,
								["自动射击"] = 7,
								["治疗宠物"] = 6,
								["奥术射击"] = 1,
								["震荡射击"] = 1,
								["多重射击"] = 1,
								["铁皮手雷"] = 1,
								["恢复法力"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1588607983,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0E17B",
							["buff_uptime"] = 321,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["last_event"] = 0,
							["spell_cast"] = {
								["低吼"] = 11,
							},
							["pets"] = {
							},
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
							["fight_component"] = true,
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 146,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1569819.156,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					20178, -- [1]
					6860, -- [2]
					{
						0, -- [1]
						[0] = 794,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					6688, -- [1]
					6860, -- [2]
					{
						0, -- [1]
						[0] = 794,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "23:59:44",
				["cleu_timeline"] = {
				},
				["enemy"] = "沙德拉",
				["TotalElapsedCombatTime"] = 6.48900000005961,
				["CombatEndedAt"] = 1569723.525,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 8886.008325,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["啪啪"] = 6860.007868,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1569715.837,
				["combat_id"] = 146,
				["data_inicio"] = "23:57:56",
				["tempo_start"] = 1588607876,
				["spells_cast_timeline"] = {
				},
				["contra"] = "沙德拉",
				["combat_counter"] = 666,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 1569608.466,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [6]
			{
				{
					["tipo"] = 2,
					["combatId"] = 145,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006619,
							["damage_from"] = {
								["机总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["机总 <啪啪>"] = 390,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 390.006619,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 390.006619,
							["end_time"] = 1588607829,
							["damage_taken"] = 3690.006619,
							["nome"] = "枯木巢穴守卫",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 48,
										["targets"] = {
											["机总"] = 0,
											["机总 <啪啪>"] = 390,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 390,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 12,
										["r_amt"] = 0,
										["total"] = 390,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 9,
										["MISS"] = 2,
										["a_amt"] = 0,
									},
									["毒药"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["机总"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "毒药",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588607822,
							["on_hold"] = false,
							["start_time"] = 1588607800,
							["serial"] = "Creature-0-4504-0-187-2686-00002E96CD",
							["fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.00162,
							["damage_from"] = {
							},
							["targets"] = {
								["漫步者维瑟哈特"] = 3102,
								["枯木血虫"] = 188,
								["枯木巢穴守卫"] = 3690,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["end_time"] = 1588607829,
							["tipo"] = 1,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 5629.00162,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 6980.00162,
							["spells"] = {
								["_ActorTable"] = {
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 345,
										["targets"] = {
											["漫步者维瑟哈特"] = 653,
											["枯木巢穴守卫"] = 688,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1341,
										["n_min"] = 319,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1341,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["瞄准射击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 3874,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["漫步者维瑟哈特"] = 1806,
											["枯木巢穴守卫"] = 2068,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3874,
										["c_max"] = 2068,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1806,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 106,
										["targets"] = {
											["漫步者维瑟哈特"] = 202,
											["枯木巢穴守卫"] = 212,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 414,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 414,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.00162,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588607827,
							["friendlyfire"] = {
							},
							["start_time"] = 1588607801,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003259,
							["damage_from"] = {
								["漫步者维瑟哈特"] = true,
								["未知目标"] = true,
								["枯木血虫"] = true,
								["枯木巢穴守卫"] = true,
							},
							["targets"] = {
								["漫步者维瑟哈特"] = 441,
								["枯木血虫"] = 188,
								["枯木巢穴守卫"] = 722,
							},
							["pets"] = {
							},
							["damage_taken"] = 629.003259,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1351.003259,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 1351.003259,
							["delay"] = 0,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 465,
										["g_amt"] = 0,
										["n_max"] = 129,
										["targets"] = {
											["漫步者维瑟哈特"] = 441,
											["枯木血虫"] = 188,
											["枯木巢穴守卫"] = 722,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 886,
										["n_min"] = 67,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 1351,
										["c_max"] = 160,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 152,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588607829,
							["last_event"] = 1588607827,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588607801,
							["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [3]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001961,
							["damage_from"] = {
								["机总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["机总 <啪啪>"] = 206,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 206.001961,
							["delay"] = 1588607812,
							["monster"] = true,
							["total"] = 206.001961,
							["end_time"] = 1588607829,
							["damage_taken"] = 3102.001961,
							["nome"] = "漫步者维瑟哈特",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 65,
										["targets"] = {
											["机总"] = 0,
											["机总 <啪啪>"] = 206,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 206,
										["n_min"] = 30,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 206,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 4,
										["spellschool"] = 1,
										["MISS"] = 3,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588607812,
							["on_hold"] = false,
							["start_time"] = 1588607824,
							["serial"] = "Creature-0-4504-0-187-8218-00002FF0BF",
							["fight_component"] = true,
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 145,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 145,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 145,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["猎人印记"] = {
										["activedamt"] = -1,
										["id"] = "猎人印记",
										["targets"] = {
										},
										["actived_at"] = 1588607823,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "毒蛇钉刺",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["震荡射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "震荡射击",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = "强击光环",
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强效敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强效敏捷",
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["野性守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "野性守护",
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 20,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["毒蛇钉刺"] = 2,
								["震荡射击"] = 1,
								["自动射击"] = 4,
								["瞄准射击"] = 2,
								["强击光环"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1588607829,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0E17B",
							["buff_uptime"] = 87,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 4,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 145,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1569533.988,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					7575.99735, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					5629, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "23:57:09",
				["cleu_timeline"] = {
				},
				["enemy"] = "漫步者维瑟哈特",
				["TotalElapsedCombatTime"] = 27.5379999999423,
				["CombatEndedAt"] = 1569561.526,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 6980.00162,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1569561.526,
				["combat_id"] = 145,
				["data_inicio"] = "23:56:41",
				["tempo_start"] = 1588607800,
				["spells_cast_timeline"] = {
				},
				["contra"] = "枯木巢穴守卫",
				["combat_counter"] = 665,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 1569533.186,
				["TimeData"] = {
				},
				["frags"] = {
					["漫步者维瑟哈特"] = 1,
					["枯木血虫"] = 2,
					["枯木巢穴守卫"] = 1,
				},
			}, -- [7]
			{
				{
					["tipo"] = 2,
					["combatId"] = 144,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004843,
							["damage_from"] = {
							},
							["targets"] = {
								["邪恶的枭兽"] = 2392,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["end_time"] = 1588607752,
							["tipo"] = 1,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1464.004843,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 2392.004843,
							["spells"] = {
								["_ActorTable"] = {
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 865,
										["g_amt"] = 0,
										["n_max"] = 397,
										["targets"] = {
											["邪恶的枭兽"] = 1262,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 397,
										["n_min"] = 397,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1262,
										["c_max"] = 865,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 865,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 101,
										["targets"] = {
											["邪恶的枭兽"] = 202,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 202,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 202,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.004843,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588607751,
							["friendlyfire"] = {
							},
							["start_time"] = 1588607733,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.004625,
							["damage_from"] = {
								["邪恶的枭兽"] = true,
							},
							["targets"] = {
								["邪恶的枭兽"] = 928,
							},
							["pets"] = {
							},
							["damage_taken"] = 259.004625,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 928.004625,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 928.004625,
							["delay"] = 0,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 312,
										["g_amt"] = 0,
										["n_max"] = 82,
										["targets"] = {
											["邪恶的枭兽"] = 928,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 616,
										["n_min"] = 71,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 928,
										["c_max"] = 163,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 149,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588607752,
							["last_event"] = 1588607751,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588607733,
							["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.003567,
							["damage_from"] = {
								["机总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["机总 <啪啪>"] = 259,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 259.003567,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 259.003567,
							["end_time"] = 1588607752,
							["damage_taken"] = 2392.003567,
							["nome"] = "邪恶的枭兽",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 73,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["机总"] = 0,
											["机总 <啪啪>"] = 259,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 186,
										["n_min"] = 33,
										["g_dmg"] = 0,
										["counter"] = 9,
										["r_amt"] = 0,
										["total"] = 259,
										["c_max"] = 73,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 73,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 5,
										["MISS"] = 1,
										["DODGE"] = 2,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588607750,
							["on_hold"] = false,
							["start_time"] = 1588607734,
							["serial"] = "Creature-0-4504-0-187-2927-000030389E",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 144,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 144,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 144,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "毒蛇钉刺",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"机总 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强效敏捷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强效敏捷",
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 6,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["毒蛇钉刺"] = 1,
								["自动射击"] = 2,
							},
							["tipo"] = 4,
							["last_event"] = 1588607752,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0E17B",
							["buff_uptime"] = 57,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "机总 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 4,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 144,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1569465.997,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					2651, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					1464, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "23:55:53",
				["cleu_timeline"] = {
				},
				["enemy"] = "邪恶的枭兽",
				["TotalElapsedCombatTime"] = 19.0169999999926,
				["CombatEndedAt"] = 1569485.014,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 2392.004843,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1569485.014,
				["combat_id"] = 144,
				["data_inicio"] = "23:55:33",
				["tempo_start"] = 1588607733,
				["spells_cast_timeline"] = {
				},
				["contra"] = "邪恶的枭兽",
				["combat_counter"] = 664,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 1569465.581,
				["TimeData"] = {
				},
				["frags"] = {
					["邪恶的枭兽"] = 1,
				},
			}, -- [8]
			{
				{
					["tipo"] = 2,
					["combatId"] = 131,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002902,
							["damage_from"] = {
								["朴不成"] = true,
								["莱斯·霜语"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 5954,
							},
							["pets"] = {
							},
							["end_time"] = 1588601327,
							["tipo"] = 1,
							["friendlyfire_total"] = 3,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5954.002902,
							["delay"] = 1588601316,
							["dps_started"] = false,
							["total"] = 5954.002902,
							["nome"] = "朴不成",
							["damage_taken"] = 750.002902,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["灼热武器"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["莱斯·霜语"] = 120,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 120,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 120,
										["c_max"] = 0,
										["id"] = "灼热武器",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["背刺"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 2387,
										["g_amt"] = 0,
										["n_max"] = 459,
										["targets"] = {
											["莱斯·霜语"] = 3282,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 895,
										["n_min"] = 436,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 3282,
										["c_max"] = 916,
										["id"] = "背刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 726,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 5,
										["b_amt"] = 0,
										["c_dmg"] = 1182,
										["g_amt"] = 2,
										["n_max"] = 188,
										["targets"] = {
											["莱斯·霜语"] = 2439,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1032,
										["g_dmg"] = 225,
										["n_min"] = 113,
										["a_amt"] = 0,
										["counter"] = 17,
										["total"] = 2439,
										["r_amt"] = 0,
										["c_max"] = 250,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 212,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 7,
										["MISS"] = 1,
										["DODGE"] = 1,
									},
									["脚踢"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 63,
										["targets"] = {
											["莱斯·霜语"] = 113,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 113,
										["n_min"] = 50,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 113,
										["c_max"] = 0,
										["id"] = "脚踢",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601316,
							["friendlyfire"] = {
								["朴不成"] = {
									["total"] = 3,
									["spells"] = {
										["风怒图腾"] = 3,
									},
								},
							},
							["start_time"] = 1588601306,
							["serial"] = "Player-4920-01F19A55",
							["classe"] = "ROGUE",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.001906,
							["damage_from"] = {
								["鲁总 <啪啪>"] = true,
								["啪啪"] = true,
								["朴不成"] = true,
								["像只猴的你"] = true,
								["幽魂无双"] = true,
								["琼琼宝贝"] = true,
							},
							["targets"] = {
								["朴不成"] = 747,
								["像只猴的你"] = 1517,
								["鲁总 <啪啪>"] = 563,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["nome"] = "莱斯·霜语",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2827.001906,
							["delay"] = 1588601317,
							["dps_started"] = false,
							["total"] = 2827.001906,
							["end_time"] = 1588601327,
							["damage_taken"] = 33569.001906,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["恐惧术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "恐惧术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["冰冻"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["朴不成"] = 0,
											["像只猴的你"] = 0,
											["鲁总"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "冰冻",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 13,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 403,
										["targets"] = {
											["朴不成"] = 747,
											["像只猴的你"] = 1000,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1747,
										["n_min"] = 68,
										["g_dmg"] = 0,
										["counter"] = 13,
										["r_amt"] = 0,
										["total"] = 1747,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 68,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 3,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 8,
										["a_amt"] = 0,
										["DODGE"] = 2,
									},
									["冰冻新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 563,
										["targets"] = {
											["鲁总 <啪啪>"] = 563,
											["像只猴的你"] = 517,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1080,
										["n_min"] = 517,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1080,
										["c_max"] = 0,
										["id"] = "冰冻新星",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588601317,
							["on_hold"] = false,
							["start_time"] = 1588601292,
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["monster"] = true,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003604,
							["damage_from"] = {
							},
							["targets"] = {
								["莱斯·霜语"] = 7061,
							},
							["pets"] = {
							},
							["end_time"] = 1588601327,
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 7061.003604,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 7061.003604,
							["nome"] = "幽魂无双",
							["damage_taken"] = 0.003604,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["炎爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1104,
										["targets"] = {
											["莱斯·霜语"] = 2632,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2632,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 2632,
										["c_max"] = 0,
										["id"] = "炎爆术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 476,
										["g_amt"] = 0,
										["n_max"] = 632,
										["targets"] = {
											["莱斯·霜语"] = 1108,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 632,
										["n_min"] = 632,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1108,
										["c_max"] = 476,
										["id"] = "火焰冲击",
										["r_dmg"] = 476,
										["r_amt"] = 1,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 476,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火球术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 626,
										["g_amt"] = 0,
										["n_max"] = 859,
										["targets"] = {
											["莱斯·霜语"] = 2927,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2301,
										["n_min"] = 13,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 2927,
										["c_max"] = 626,
										["id"] = "火球术",
										["r_dmg"] = 1183,
										["r_amt"] = 3,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 626,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["点燃"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 125,
										["targets"] = {
											["莱斯·霜语"] = 394,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 394,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 394,
										["c_max"] = 0,
										["id"] = "点燃",
										["r_dmg"] = 144,
										["r_amt"] = 2,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601318,
							["friendlyfire"] = {
							},
							["start_time"] = 1588601285,
							["serial"] = "Player-4920-01ECB17B",
							["classe"] = "MAGE",
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003893,
							["damage_from"] = {
								["像只猴的你"] = true,
								["莱斯·霜语"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 5507,
							},
							["pets"] = {
							},
							["end_time"] = 1588601327,
							["tipo"] = 1,
							["friendlyfire_total"] = 3,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5507.003893,
							["delay"] = 1588601315,
							["dps_started"] = false,
							["total"] = 5507.003893,
							["nome"] = "像只猴的你",
							["damage_taken"] = 1520.003893,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 359,
										["targets"] = {
											["莱斯·霜语"] = 696,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 696,
										["n_min"] = 337,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 696,
										["c_max"] = 0,
										["id"] = "嗜血",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 359,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 4,
										["b_amt"] = 1,
										["c_dmg"] = 2120,
										["g_amt"] = 1,
										["n_max"] = 315,
										["targets"] = {
											["莱斯·霜语"] = 4250,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1900,
										["n_min"] = 237,
										["g_dmg"] = 230,
										["counter"] = 12,
										["total"] = 4250,
										["c_max"] = 630,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 427,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 237,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["重伤"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 60,
										["targets"] = {
											["莱斯·霜语"] = 417,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 417,
										["n_min"] = 59,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 417,
										["c_max"] = 0,
										["id"] = "重伤",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["盾击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["莱斯·霜语"] = 40,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 40,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 40,
										["c_max"] = 0,
										["id"] = "盾击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["复仇"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 55,
										["targets"] = {
											["莱斯·霜语"] = 104,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 104,
										["n_min"] = 49,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 104,
										["c_max"] = 0,
										["id"] = "复仇",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601315,
							["friendlyfire"] = {
								["像只猴的你"] = {
									["total"] = 3,
									["spells"] = {
										["风怒图腾"] = 3,
									},
								},
							},
							["start_time"] = 1588601297,
							["serial"] = "Player-4920-01D50132",
							["classe"] = "WARRIOR",
						}, -- [4]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.007388,
							["damage_from"] = {
							},
							["targets"] = {
								["莱斯·霜语"] = 13886,
							},
							["delay"] = 1588601317,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["spells"] = {
								["_ActorTable"] = {
									["瞄准射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 993,
										["targets"] = {
											["莱斯·霜语"] = 2558,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2558,
										["n_min"] = 748,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2558,
										["c_max"] = 0,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 817,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Autoshot"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 2758,
										["g_amt"] = 0,
										["n_max"] = 496,
										["targets"] = {
											["莱斯·霜语"] = 7156,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4398,
										["n_min"] = 306,
										["g_dmg"] = 0,
										["counter"] = 14,
										["total"] = 7156,
										["c_max"] = 1001,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 855,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 11,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["多重射击"] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 1378,
										["g_amt"] = 0,
										["n_max"] = 553,
										["targets"] = {
											["莱斯·霜语"] = 2416,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1038,
										["n_min"] = 485,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2416,
										["c_max"] = 1378,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1378,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 553,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 98,
										["targets"] = {
											["莱斯·霜语"] = 762,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 762,
										["n_min"] = 74,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 762,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 370,
										["r_amt"] = 5,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 12892.007388,
							["nome"] = "啪啪",
							["dps_started"] = false,
							["total"] = 13886.007388,
							["damage_taken"] = 0.007388,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 254,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588601327,
							["custom"] = 0,
							["last_event"] = 1588601317,
							["friendlyfire"] = {
							},
							["start_time"] = 1588601296,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [5]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.00712,
							["damage_from"] = {
								["莱斯·霜语"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 994,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["tipo"] = 1,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 994.00712,
							["delay"] = 1588601316,
							["dps_started"] = false,
							["end_time"] = 1588601327,
							["nome"] = "鲁总 <啪啪>",
							["ownerName"] = "啪啪",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 2,
										["c_dmg"] = 0,
										["g_amt"] = 1,
										["n_max"] = 91,
										["targets"] = {
											["莱斯·霜语"] = 729,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 658,
										["n_min"] = 46,
										["g_dmg"] = 71,
										["counter"] = 11,
										["total"] = 729,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 97,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
									["爪击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 50,
										["targets"] = {
											["莱斯·霜语"] = 265,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 265,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 265,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 6,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 563.00712,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601316,
							["on_hold"] = false,
							["start_time"] = 1588601299,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["total"] = 994.00712,
						}, -- [6]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005714,
							["damage_from"] = {
								["环境伤害 (火烧)"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 1161,
								["老鼠"] = 226,
							},
							["delay"] = 1588601396,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["烈焰震击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 275,
										["targets"] = {
											["莱斯·霜语"] = 587,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 587,
										["n_min"] = 78,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 587,
										["c_max"] = 0,
										["id"] = "烈焰震击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 226,
										["targets"] = {
											["老鼠"] = 226,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 226,
										["n_min"] = 226,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 226,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["冰霜震击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 574,
										["targets"] = {
											["莱斯·霜语"] = 574,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 574,
										["n_min"] = 574,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 574,
										["c_max"] = 0,
										["id"] = "冰霜震击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 14.005714,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1387.005714,
							["nome"] = "琼琼宝贝",
							["dps_started"] = false,
							["total"] = 1387.005714,
							["on_hold"] = false,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 264,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588601445,
							["custom"] = 0,
							["last_event"] = 1588601396,
							["friendlyfire"] = {
							},
							["start_time"] = 1588601357,
							["serial"] = "Player-4920-01D6B7EB",
							["classe"] = "SHAMAN",
						}, -- [7]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 131,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["朴不成"] = 546,
								["像只猴的你"] = 100,
								["鲁总 <啪啪>"] = 314,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 960.008921,
							["total_without_pet"] = 3548.008921,
							["total"] = 3548.008921,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D6B7EB",
							["totalabsorb"] = 0.008921,
							["last_hps"] = 0,
							["targets"] = {
								["朴不成"] = 1526,
								["像只猴的你"] = 1807,
								["鲁总 <啪啪>"] = 1175,
							},
							["totalover_without_pet"] = 0.008921,
							["healing_taken"] = 0.008921,
							["end_time"] = 1588601327,
							["spec"] = 264,
							["healing_from"] = {
							},
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["治疗链"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["朴不成"] = 546,
											["像只猴的你"] = 100,
											["鲁总 <啪啪>"] = 314,
										},
										["n_max"] = 948,
										["targets"] = {
											["朴不成"] = 980,
											["像只猴的你"] = 1707,
											["鲁总 <啪啪>"] = 861,
										},
										["n_min"] = 32,
										["counter"] = 6,
										["overheal"] = 960,
										["total"] = 3548,
										["c_max"] = 0,
										["id"] = "治疗链",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 3548,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["totaldenied"] = 0.008921,
							["custom"] = 0,
							["last_event"] = 1588601319,
							["classe"] = "SHAMAN",
							["start_time"] = 1588601311,
							["delay"] = 1588601301,
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["healing_from"] = {
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.004473,
							["total_without_pet"] = 0.004473,
							["total"] = 0.004473,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0E17B",
							["totalabsorb"] = 0.004473,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.004473,
							["healing_taken"] = 0.004473,
							["end_time"] = 1588601327,
							["spec"] = 254,
							["targets_overheal"] = {
							},
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 0,
							["totaldenied"] = 0.004473,
							["custom"] = 0,
							["tipo"] = 2,
							["classe"] = "HUNTER",
							["start_time"] = 1588601327,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "PET",
							["totalover"] = 0.008073,
							["total_without_pet"] = 0.008073,
							["total"] = 0.008073,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["totalabsorb"] = 0.008073,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.008073,
							["healing_taken"] = 861.008073,
							["end_time"] = 1588601327,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["totaldenied"] = 0.008073,
							["targets_overheal"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 0,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1588601327,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.00643,
							["last_hps"] = 0,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.00643,
							["targets_overheal"] = {
							},
							["classe"] = "ROGUE",
							["totalover"] = 0.00643,
							["total_without_pet"] = 0.00643,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.00643,
							["heal_enemy_amt"] = 0,
							["total"] = 0.00643,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["healing_taken"] = 980.00643,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["end_time"] = 1588601327,
							["heal_enemy"] = {
							},
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588601327,
							["serial"] = "Player-4920-01F19A55",
							["nome"] = "朴不成",
						}, -- [4]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.007897,
							["last_hps"] = 0,
							["targets_overheal"] = {
								["像只猴的你"] = 20,
							},
							["targets"] = {
								["像只猴的你"] = 60,
							},
							["delay"] = 1588601315,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["像只猴的你"] = true,
								["琼琼宝贝"] = true,
							},
							["healing_taken"] = 1767.007897,
							["totalover"] = 20.007897,
							["total_without_pet"] = 60.007897,
							["totalover_without_pet"] = 0.007897,
							["totaldenied"] = 0.007897,
							["classe"] = "WARRIOR",
							["end_time"] = 1588601327,
							["targets_absorbs"] = {
							},
							["heal_enemy_amt"] = 0,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["像只猴的你"] = 20,
										},
										["n_max"] = 20,
										["targets"] = {
											["像只猴的你"] = 60,
										},
										["n_min"] = 20,
										["counter"] = 4,
										["overheal"] = 20,
										["total"] = 60,
										["c_max"] = 0,
										["id"] = "嗜血",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 60,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["total"] = 60.007897,
							["heal_enemy"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1588601315,
							["on_hold"] = false,
							["start_time"] = 1588601322,
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [5]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 131,
					["_ActorTable"] = {
						{
							["received"] = 149.001737,
							["resource"] = 0.001737,
							["targets"] = {
							},
							["pets"] = {
								"法力之泉图腾 IV <琼琼宝贝>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "SHAMAN",
							["passiveover"] = 0.001737,
							["total"] = 439.001737,
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.001737,
							["flag_original"] = 1298,
							["last_event"] = 0,
							["tipo"] = 3,
							["spec"] = 264,
							["alternatepower"] = 0.001737,
							["serial"] = "Player-4920-01D6B7EB",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["received"] = 0.001215,
							["resource"] = 0.001215,
							["targets"] = {
								["幽魂无双"] = 153,
								["琼琼宝贝"] = 149,
								["啪啪"] = 137,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["passiveover"] = 0.001215,
							["total"] = 439.001215,
							["ownerName"] = "琼琼宝贝",
							["nome"] = "法力之泉图腾 IV <琼琼宝贝>",
							["spells"] = {
								["_ActorTable"] = {
									["法力之泉"] = {
										["total"] = 439,
										["id"] = "法力之泉",
										["totalover"] = 0,
										["targets"] = {
											["幽魂无双"] = 153,
											["琼琼宝贝"] = 149,
											["啪啪"] = 137,
										},
										["counter"] = 35,
									},
								},
								["tipo"] = 7,
							},
							["totalover"] = 0.001215,
							["flag_original"] = 8466,
							["last_event"] = 1588601306,
							["tipo"] = 3,
							["alternatepower"] = 0.001215,
							["serial"] = "Creature-0-4889-289-12207-7416-00003021A0",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["received"] = 360.005045,
							["resource"] = 0.005045,
							["targets"] = {
								["幽魂无双"] = 207,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.005045,
							["total"] = 207.005045,
							["nome"] = "幽魂无双",
							["spells"] = {
								["_ActorTable"] = {
									["元素大师"] = {
										["total"] = 207,
										["id"] = "元素大师",
										["totalover"] = 0,
										["targets"] = {
											["幽魂无双"] = 207,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.005045,
							["flag_original"] = 1298,
							["last_event"] = 1588601298,
							["tipo"] = 3,
							["alternatepower"] = 0.005045,
							["serial"] = "Player-4920-01ECB17B",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["received"] = 137.006501,
							["resource"] = 0.006501,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "HUNTER",
							["passiveover"] = 412.006501,
							["total"] = 0.006501,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.006501,
							["flag_original"] = 1297,
							["last_event"] = 0,
							["tipo"] = 3,
							["spec"] = 254,
							["alternatepower"] = 0.006501,
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["received"] = 22.008142,
							["resource"] = 0.008142,
							["targets"] = {
								["像只猴的你"] = 22,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.008142,
							["total"] = 22.008142,
							["nome"] = "像只猴的你",
							["spells"] = {
								["_ActorTable"] = {
									["怒不可遏"] = {
										["total"] = 2,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 2,
										},
										["counter"] = 2,
									},
									["血性狂暴"] = {
										["total"] = 20,
										["id"] = "血性狂暴",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 20,
										},
										["counter"] = 11,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.008142,
							["flag_original"] = 1298,
							["last_event"] = 1588601323,
							["tipo"] = 3,
							["alternatepower"] = 0.008142,
							["serial"] = "Player-4920-01D50132",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["received"] = 25.006037,
							["resource"] = 0.006037,
							["targets"] = {
								["朴不成"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 0.006037,
							["total"] = 25.006037,
							["nome"] = "朴不成",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["朴不成"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.006037,
							["flag_original"] = 1298,
							["last_event"] = 1588601312,
							["tipo"] = 3,
							["alternatepower"] = 0.006037,
							["serial"] = "Player-4920-01F19A55",
							["boss_fight_component"] = true,
						}, -- [6]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 131,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["pets"] = {
							},
							["classe"] = "ROGUE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["脚踢"] = {
										["id"] = "脚踢",
										["counter"] = 2,
										["targets"] = {
											["莱斯·霜语"] = 2,
										},
										["interrompeu_oque"] = {
											["连发寒冰箭"] = 1,
											["恐惧术"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 3,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["疾跑"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "疾跑",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["连发寒冰箭"] = 1,
								["恐惧术"] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["interrupt_targets"] = {
								["莱斯·霜语"] = 2,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["脚踢"] = 2,
								["背刺"] = 4,
								["切割"] = 1,
							},
							["buff_uptime"] = 33,
							["tipo"] = 4,
							["last_event"] = 1588601327,
							["nome"] = "朴不成",
							["interrupt"] = 2.003637,
							["serial"] = "Player-4920-01F19A55",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲攻击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 4,
										["id"] = "破甲攻击",
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["重伤"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "重伤",
										["uptime"] = 29,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["嘲讽"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "嘲讽",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 109,
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "战斗怒吼",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["嗜血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "嗜血",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 3,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									["乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 3,
										["refreshamt"] = 2,
										["id"] = "乱舞",
										["uptime"] = 38,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									["血性狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "血性狂暴",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 64,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["嗜血"] = 2,
								["嘲讽"] = 2,
								["破甲攻击"] = 5,
								["复仇"] = 2,
								["盾击"] = 1,
								["血性狂暴"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588601327,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["烈焰震击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "烈焰震击",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 132,
							["classe"] = "SHAMAN",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["大地之力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "大地之力",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰霜抗性"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冰霜抗性",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["法力之泉"] = {
										["activedamt"] = 1,
										["id"] = "法力之泉",
										["targets"] = {
										},
										["actived_at"] = 1588601283,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 12,
							["buff_uptime_targets"] = {
							},
							["spec"] = 264,
							["grupo"] = true,
							["spell_cast"] = {
								["治疗链"] = 3,
								["烈焰震击"] = 1,
								["冰霜震击"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588601327,
							["pets"] = {
							},
							["nome"] = "琼琼宝贝",
							["serial"] = "Player-4920-01D6B7EB",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["炎爆术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "炎爆术",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["点燃"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "点燃",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "火球术",
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冲击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冲击",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 152,
							["classe"] = "MAGE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["法术反制"] = {
										["id"] = "法术反制",
										["counter"] = 1,
										["targets"] = {
											["莱斯·霜语"] = 1,
										},
										["interrompeu_oque"] = {
											["冰冻术"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["燃烧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 2,
										["id"] = "燃烧",
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["冰冻术"] = 1,
							},
							["debuff_uptime"] = 44,
							["boss_fight_component"] = true,
							["interrupt"] = 1.007839,
							["interrupt_targets"] = {
								["莱斯·霜语"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["炎爆术"] = 2,
								["火焰冲击"] = 2,
								["火球术"] = 4,
								["法术反制"] = 1,
							},
							["pets"] = {
							},
							["last_event"] = 1588601327,
							["tipo"] = 4,
							["nome"] = "幽魂无双",
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01ECB17B",
							["buff_uptime_targets"] = {
							},
						}, -- [4]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲虚弱"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲虚弱",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["猎人印记"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "猎人印记",
										["uptime"] = 34,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "毒蛇钉刺",
										["uptime"] = 30,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 125,
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "狂暴",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["急速射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "急速射击",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["快速射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "快速射击",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 71,
							["buff_uptime_targets"] = {
							},
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["狂暴"] = 1,
								["急速射击"] = 1,
								["毒蛇钉刺"] = 2,
								["猎人印记"] = 1,
								["自动射击"] = 14,
								["瞄准射击"] = 3,
								["多重射击"] = 3,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588601327,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["nome"] = "啪啪",
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 56,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["朴不成"] = {
									["uptime"] = 30,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
								["像只猴的你"] = {
									["uptime"] = 26,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588601322,
							["tipo"] = 4,
							["damage_twin"] = "莱斯·霜语",
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["damage_spellid"] = "冰冻",
							["nome"] = "冰冻",
						}, -- [6]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["last_event"] = 0,
							["spell_cast"] = {
								["突进"] = 1,
								["爪击"] = 7,
							},
							["pets"] = {
							},
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["boss_fight_component"] = true,
						}, -- [7]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "莱斯·霜语",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["恐惧术"] = 1,
								["冰冻新星"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["boss_fight_component"] = true,
						}, -- [8]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 8,
							["spellschool"] = 32,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["朴不成"] = {
									["uptime"] = 8,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588601299,
							["tipo"] = 4,
							["damage_twin"] = "莱斯·霜语",
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["damage_spellid"] = "恐惧术",
							["nome"] = "恐惧术",
						}, -- [9]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 10,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["像只猴的你"] = {
									["uptime"] = 10,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588601305,
							["tipo"] = 4,
							["damage_twin"] = "莱斯·霜语",
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["damage_spellid"] = "冰冻新星",
							["nome"] = "冰冻新星",
						}, -- [10]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 131,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
					["朴不成"] = true,
					["幽魂无双"] = true,
					["像只猴的你"] = true,
					["琼琼宝贝"] = true,
				},
				["CombatStartedAt"] = 1563016.419,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					36621.98996, -- [1]
					3608, -- [2]
					{
						22, -- [1]
						[0] = 646,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 3,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["琼琼宝贝"] = {
						{
							true, -- [1]
							"Fire", -- [2]
							14, -- [3]
							1588601425.28, -- [4]
							3910, -- [5]
							"环境伤害 (火烧)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "22:08:48",
				["cleu_timeline"] = {
				},
				["enemy"] = "莱斯·霜语",
				["TotalElapsedCombatTime"] = 34.8479999999981,
				["CombatEndedAt"] = 1563051.267,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:08:04",
				["end_time"] = 1563060.005,
				["combat_id"] = 131,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 13886.007388,
							["朴不成"] = 5954.002902,
							["像只猴的你"] = 5507.003893,
							["幽魂无双"] = 7061.003604,
							["琼琼宝贝"] = 1161.005714,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["朴不成"] = 0.00643,
							["像只猴的你"] = 60.007897,
							["琼琼宝贝"] = 3548.008921,
							["啪啪"] = 0.004473,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["tempo_start"] = 1588601283,
				["contra"] = "莱斯·霜语",
				["frags"] = {
					["莱斯·霜语"] = 1,
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "通灵学院",
					["encounter"] = "莱斯·霜语",
					["mapid"] = 289,
					["try_number"] = 2,
					["name"] = "莱斯·霜语",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["combat_counter"] = 651,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					32807, -- [1]
					3608, -- [2]
					{
						22, -- [1]
						[0] = 207,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 3,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 1563016.002,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [9]
			{
				{
					["tipo"] = 2,
					["combatId"] = 130,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007393,
							["damage_from"] = {
								["莱斯·霜语"] = true,
								["像只猴的你"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 6078,
							},
							["pets"] = {
							},
							["end_time"] = 1588601278,
							["tipo"] = 1,
							["friendlyfire_total"] = 5,
							["raid_targets"] = {
							},
							["total_without_pet"] = 6078.007393,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 6078.007393,
							["nome"] = "像只猴的你",
							["damage_taken"] = 2575.007393,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 592,
										["targets"] = {
											["莱斯·霜语"] = 936,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 936,
										["n_min"] = 344,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 936,
										["c_max"] = 0,
										["id"] = "嗜血",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["暗影箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 104,
										["targets"] = {
											["莱斯·霜语"] = 104,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 104,
										["n_min"] = 104,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 104,
										["c_max"] = 0,
										["id"] = "暗影箭",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 32,
									},
									["英勇打击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 893,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["莱斯·霜语"] = 893,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 893,
										["c_max"] = 893,
										["id"] = "英勇打击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 893,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["重伤"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 88,
										["targets"] = {
											["莱斯·霜语"] = 140,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 140,
										["n_min"] = 52,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 140,
										["c_max"] = 0,
										["id"] = "重伤",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["复仇"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 111,
										["g_amt"] = 0,
										["n_max"] = 54,
										["targets"] = {
											["莱斯·霜语"] = 165,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 54,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 165,
										["c_max"] = 111,
										["id"] = "复仇",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 111,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["盾击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 89,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["莱斯·霜语"] = 89,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 89,
										["c_max"] = 89,
										["id"] = "盾击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 89,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1928,
										["g_amt"] = 4,
										["n_max"] = 353,
										["targets"] = {
											["莱斯·霜语"] = 3751,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 639,
										["n_min"] = 286,
										["g_dmg"] = 1184,
										["counter"] = 9,
										["total"] = 3751,
										["c_max"] = 664,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 623,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601274,
							["friendlyfire"] = {
								["像只猴的你"] = {
									["total"] = 5,
									["spells"] = {
										["风怒图腾"] = 5,
									},
								},
							},
							["start_time"] = 1588601251,
							["serial"] = "Player-4920-01D50132",
							["classe"] = "WARRIOR",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008501,
							["damage_from"] = {
								["鲁总 <啪啪>"] = true,
								["朴不成"] = true,
								["幽魂无双"] = true,
								["像只猴的你"] = true,
								["琼琼宝贝"] = true,
							},
							["targets"] = {
								["啪啪"] = 891,
								["朴不成"] = 351,
								["像只猴的你"] = 2570,
								["鲁总 <啪啪>"] = 1995,
								["琼琼宝贝"] = 1763,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["nome"] = "莱斯·霜语",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 7570.008501,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 7570.008501,
							["end_time"] = 1588601278,
							["damage_taken"] = 16839.008501,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 2,
										["c_dmg"] = 394,
										["g_amt"] = 0,
										["n_max"] = 154,
										["targets"] = {
											["像只猴的你"] = 1049,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 655,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 1049,
										["c_max"] = 394,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 394,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 92,
										["n_amt"] = 6,
										["spellschool"] = 1,
										["a_amt"] = 0,
									},
									["冰冻新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 551,
										["targets"] = {
											["像只猴的你"] = 551,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 551,
										["n_min"] = 551,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 551,
										["c_max"] = 0,
										["id"] = "冰冻新星",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["击退"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 351,
										["targets"] = {
											["朴不成"] = 351,
											["像只猴的你"] = 189,
											["鲁总 <啪啪>"] = 230,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 770,
										["n_min"] = 189,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 770,
										["c_max"] = 0,
										["id"] = "击退",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["连发寒冰箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 895,
										["targets"] = {
											["啪啪"] = 891,
											["像只猴的你"] = 781,
											["鲁总 <啪啪>"] = 1765,
											["琼琼宝贝"] = 1763,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 5200,
										["n_min"] = 781,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 5200,
										["c_max"] = 0,
										["id"] = "连发寒冰箭",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["n_amt"] = 6,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["RESIST"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["冰冻"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["朴不成"] = 0,
											["像只猴的你"] = 0,
											["鲁总"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "冰冻",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 16,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588601275,
							["on_hold"] = false,
							["start_time"] = 1588601251,
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["monster"] = true,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.004253,
							["damage_from"] = {
							},
							["targets"] = {
								["莱斯·霜语"] = 5831,
							},
							["pets"] = {
							},
							["end_time"] = 1588601278,
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 5831.004253,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 5831.004253,
							["nome"] = "幽魂无双",
							["damage_taken"] = 0.004253,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["炎爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1084,
										["targets"] = {
											["莱斯·霜语"] = 2503,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2503,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2503,
										["c_max"] = 0,
										["id"] = "炎爆术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["灼烧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 376,
										["targets"] = {
											["莱斯·霜语"] = 737,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 737,
										["n_min"] = 361,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 737,
										["c_max"] = 0,
										["id"] = "灼烧",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火球术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 776,
										["targets"] = {
											["莱斯·霜语"] = 1658,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1658,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 1658,
										["c_max"] = 0,
										["id"] = "火球术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火焰冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 644,
										["targets"] = {
											["莱斯·霜语"] = 933,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 933,
										["n_min"] = 289,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 933,
										["c_max"] = 0,
										["id"] = "火焰冲击",
										["r_dmg"] = 289,
										["r_amt"] = 1,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601277,
							["friendlyfire"] = {
							},
							["start_time"] = 1588601257,
							["serial"] = "Player-4920-01ECB17B",
							["classe"] = "MAGE",
						}, -- [3]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.001711,
							["damage_from"] = {
								["莱斯·霜语"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 736,
							},
							["delay"] = 0,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001711,
							["nome"] = "啪啪",
							["dps_started"] = false,
							["total"] = 736.001711,
							["damage_taken"] = 891.001711,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 254,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588601278,
							["custom"] = 0,
							["last_event"] = 1588601277,
							["friendlyfire"] = {
							},
							["start_time"] = 1588601262,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [4]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003499,
							["damage_from"] = {
								["莱斯·霜语"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 736,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["tipo"] = 1,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 736.003499,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1588601278,
							["nome"] = "鲁总 <啪啪>",
							["ownerName"] = "啪啪",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 100,
										["targets"] = {
											["莱斯·霜语"] = 376,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 376,
										["n_min"] = 87,
										["g_dmg"] = 0,
										["counter"] = 6,
										["r_amt"] = 0,
										["total"] = 376,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 4,
										["a_amt"] = 0,
										["MISS"] = 1,
									},
									["爪击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 60,
										["targets"] = {
											["莱斯·霜语"] = 360,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 360,
										["n_min"] = 44,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 360,
										["c_max"] = 0,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 1995.003499,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601277,
							["on_hold"] = false,
							["start_time"] = 1588601262,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["total"] = 736.003499,
						}, -- [5]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002694,
							["damage_from"] = {
								["莱斯·霜语"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 433,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["烈焰震击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 275,
										["targets"] = {
											["莱斯·霜语"] = 433,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 433,
										["n_min"] = 79,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 433,
										["c_max"] = 0,
										["id"] = "烈焰震击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "SHAMAN",
							["raid_targets"] = {
							},
							["total_without_pet"] = 433.002694,
							["nome"] = "琼琼宝贝",
							["dps_started"] = false,
							["total"] = 433.002694,
							["damage_taken"] = 1763.002694,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 264,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588601278,
							["custom"] = 0,
							["last_event"] = 1588601274,
							["friendlyfire"] = {
							},
							["start_time"] = 1588601268,
							["serial"] = "Player-4920-01D6B7EB",
							["on_hold"] = false,
						}, -- [6]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008128,
							["damage_from"] = {
								["朴不成"] = true,
								["莱斯·霜语"] = true,
							},
							["targets"] = {
								["莱斯·霜语"] = 3761,
							},
							["pets"] = {
							},
							["end_time"] = 1588601283,
							["tipo"] = 1,
							["friendlyfire_total"] = 3,
							["raid_targets"] = {
							},
							["total_without_pet"] = 3761.008128,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 3761.008128,
							["nome"] = "朴不成",
							["damage_taken"] = 354.008128,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["灼热武器"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["莱斯·霜语"] = 40,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 40,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 40,
										["c_max"] = 0,
										["id"] = "灼热武器",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 561,
										["g_amt"] = 5,
										["n_max"] = 167,
										["targets"] = {
											["莱斯·霜语"] = 1710,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 554,
										["n_min"] = 116,
										["g_dmg"] = 595,
										["counter"] = 14,
										["r_amt"] = 0,
										["total"] = 1710,
										["c_max"] = 292,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 269,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 4,
										["MISS"] = 2,
										["DODGE"] = 1,
									},
									["背刺"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 944,
										["g_amt"] = 0,
										["n_max"] = 449,
										["targets"] = {
											["莱斯·霜语"] = 1830,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 886,
										["n_min"] = 437,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1830,
										["c_max"] = 944,
										["r_amt"] = 0,
										["id"] = "背刺",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 944,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 2,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 181,
										["targets"] = {
											["莱斯·霜语"] = 181,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 181,
										["n_min"] = 181,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 181,
										["c_max"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588601283,
							["friendlyfire"] = {
								["朴不成"] = {
									["total"] = 3,
									["spells"] = {
										["风怒图腾"] = 3,
									},
								},
							},
							["start_time"] = 1588601262,
							["serial"] = "Player-4920-01F19A55",
							["classe"] = "ROGUE",
						}, -- [7]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 130,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.006217,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["像只猴的你"] = 180,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["像只猴的你"] = true,
								["琼琼宝贝"] = true,
							},
							["healing_taken"] = 2508.006217,
							["totalover"] = 0.006217,
							["total_without_pet"] = 180.006217,
							["totalover_without_pet"] = 0.006217,
							["totaldenied"] = 0.006217,
							["classe"] = "WARRIOR",
							["end_time"] = 1588601278,
							["targets_absorbs"] = {
							},
							["heal_enemy_amt"] = 0,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 20,
										["targets"] = {
											["像只猴的你"] = 180,
										},
										["n_min"] = 20,
										["counter"] = 9,
										["overheal"] = 0,
										["total"] = 180,
										["c_max"] = 0,
										["id"] = "嗜血",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 9,
										["n_curado"] = 180,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["total"] = 180.006217,
							["heal_enemy"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1588601269,
							["on_hold"] = false,
							["start_time"] = 1588601256,
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [1]
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["琼琼宝贝"] = 12,
								["啪啪"] = 311,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 323.001152,
							["total_without_pet"] = 4434.001152,
							["total"] = 4434.001152,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D6B7EB",
							["totalabsorb"] = 0.001152,
							["last_hps"] = 0,
							["targets"] = {
								["琼琼宝贝"] = 873,
								["像只猴的你"] = 2328,
								["啪啪"] = 1178,
								["鲁总 <啪啪>"] = 378,
							},
							["totalover_without_pet"] = 0.001152,
							["healing_taken"] = 861.001152,
							["end_time"] = 1588601278,
							["spec"] = 264,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["次级治疗波"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1068,
										["targets"] = {
											["像只猴的你"] = 1068,
										},
										["n_min"] = 1068,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 1068,
										["c_max"] = 0,
										["id"] = "次级治疗波",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 1068,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
									["治疗链"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["琼琼宝贝"] = 12,
											["啪啪"] = 311,
										},
										["n_max"] = 887,
										["targets"] = {
											["琼琼宝贝"] = 861,
											["像只猴的你"] = 1260,
											["啪啪"] = 867,
											["鲁总 <啪啪>"] = 378,
										},
										["n_min"] = 258,
										["counter"] = 6,
										["overheal"] = 323,
										["total"] = 3366,
										["c_max"] = 0,
										["id"] = "治疗链",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 3366,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["totaldenied"] = 0.001152,
							["custom"] = 0,
							["last_event"] = 1588601273,
							["classe"] = "SHAMAN",
							["start_time"] = 1588601257,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 1297,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.006087,
							["total_without_pet"] = 0.006087,
							["total"] = 0.006087,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0E17B",
							["totalabsorb"] = 0.006087,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.006087,
							["healing_taken"] = 867.006087,
							["end_time"] = 1588601278,
							["spec"] = 254,
							["targets_overheal"] = {
							},
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 0,
							["totaldenied"] = 0.006087,
							["custom"] = 0,
							["tipo"] = 2,
							["classe"] = "HUNTER",
							["start_time"] = 1588601278,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 4369,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "PET",
							["totalover"] = 0.004115,
							["total_without_pet"] = 0.004115,
							["total"] = 0.004115,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["totalabsorb"] = 0.004115,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.004115,
							["healing_taken"] = 378.004115,
							["end_time"] = 1588601278,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["totaldenied"] = 0.004115,
							["targets_overheal"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 0,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1588601278,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [4]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 130,
					["_ActorTable"] = {
						{
							["received"] = 15.0012,
							["resource"] = 0.0012,
							["targets"] = {
								["像只猴的你"] = 15,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.0012,
							["total"] = 15.0012,
							["nome"] = "像只猴的你",
							["spells"] = {
								["_ActorTable"] = {
									["怒不可遏"] = {
										["total"] = 6,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 6,
										},
										["counter"] = 6,
									},
									["血性狂暴"] = {
										["total"] = 9,
										["id"] = "血性狂暴",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 9,
										},
										["counter"] = 9,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.0012,
							["flag_original"] = 1298,
							["last_event"] = 1588601272,
							["tipo"] = 3,
							["alternatepower"] = 0.0012,
							["serial"] = "Player-4920-01D50132",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["received"] = 333.002219,
							["resource"] = 0.002219,
							["targets"] = {
								["琼琼宝贝"] = 133,
							},
							["pets"] = {
								"法力之泉图腾 IV <琼琼宝贝>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "SHAMAN",
							["passiveover"] = 0.002219,
							["total"] = 496.002219,
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["法力澎湃"] = {
										["total"] = 133,
										["id"] = "法力澎湃",
										["totalover"] = 0,
										["targets"] = {
											["琼琼宝贝"] = 133,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.002219,
							["flag_original"] = 1298,
							["last_event"] = 1588601258,
							["tipo"] = 3,
							["spec"] = 264,
							["alternatepower"] = 0.002219,
							["serial"] = "Player-4920-01D6B7EB",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["received"] = 0.00534,
							["resource"] = 0.00534,
							["targets"] = {
								["琼琼宝贝"] = 200,
								["幽魂无双"] = 163,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["passiveover"] = 0.00534,
							["total"] = 363.00534,
							["ownerName"] = "琼琼宝贝",
							["nome"] = "法力之泉图腾 IV <琼琼宝贝>",
							["spells"] = {
								["_ActorTable"] = {
									["法力之泉"] = {
										["total"] = 363,
										["id"] = "法力之泉",
										["totalover"] = 0,
										["targets"] = {
											["琼琼宝贝"] = 200,
											["幽魂无双"] = 163,
										},
										["counter"] = 29,
									},
								},
								["tipo"] = 7,
							},
							["totalover"] = 0.00534,
							["flag_original"] = 8466,
							["last_event"] = 1588601282,
							["tipo"] = 3,
							["alternatepower"] = 0.00534,
							["serial"] = "Creature-0-4889-289-12207-7416-00003021A0",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["received"] = 163.003613,
							["resource"] = 0.003613,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.003613,
							["total"] = 0.003613,
							["nome"] = "幽魂无双",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.003613,
							["flag_original"] = 1298,
							["last_event"] = 0,
							["tipo"] = 3,
							["alternatepower"] = 0.003613,
							["serial"] = "Player-4920-01ECB17B",
							["boss_fight_component"] = true,
						}, -- [4]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 130,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲攻击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 4,
										["id"] = "破甲攻击",
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["重伤"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 5,
										["id"] = "重伤",
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["嘲讽"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "嘲讽",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["挫志怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "挫志怒吼",
										["uptime"] = 23,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 85,
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "战斗怒吼",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["嗜血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "嗜血",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["血性狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "血性狂暴",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 4,
										["refreshamt"] = 1,
										["id"] = "风怒图腾",
										["uptime"] = 6,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
									["盾牌格挡"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "盾牌格挡",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 5,
										["id"] = "乱舞",
										["uptime"] = 19,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["狂怒"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "狂怒",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 63,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["嗜血"] = 2,
								["复仇"] = 2,
								["英勇打击"] = 1,
								["挫志怒吼"] = 1,
								["破甲攻击"] = 6,
								["盾牌格挡"] = 1,
								["盾击"] = 1,
								["嘲讽"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588601278,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [1]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["烈焰震击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "烈焰震击",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 54,
							["classe"] = "SHAMAN",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["大地之力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "大地之力",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰霜抗性"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜抗性",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["法力之泉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "法力之泉",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 9,
							["buff_uptime_targets"] = {
							},
							["spec"] = 264,
							["grupo"] = true,
							["spell_cast"] = {
								["大地之力图腾"] = 1,
								["治疗链"] = 2,
								["抗寒图腾"] = 1,
								["烈焰震击"] = 1,
								["次级治疗波"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588601278,
							["pets"] = {
							},
							["nome"] = "琼琼宝贝",
							["serial"] = "Player-4920-01D6B7EB",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "火球术",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["炎爆术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "炎爆术",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冲击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冲击",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 81,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 29,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火球术"] = 2,
								["灼烧"] = 2,
								["炎爆术"] = 2,
								["火焰冲击"] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588601278,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01ECB17B",
							["nome"] = "幽魂无双",
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["生命的恩赐"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "生命的恩赐",
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 54,
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 20,
							["buff_uptime_targets"] = {
							},
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["生命的恩赐"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588601278,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["nome"] = "啪啪",
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "莱斯·霜语",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["击退"] = 1,
								["连发寒冰箭"] = 2,
								["冰冻新星"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 32,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["朴不成"] = {
									["uptime"] = 11,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1588601274,
								},
								["像只猴的你"] = {
									["uptime"] = 21,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1588601275,
								},
							},
							["last_event"] = 1588601275,
							["tipo"] = 4,
							["damage_twin"] = "莱斯·霜语",
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["damage_spellid"] = "冰冻",
							["nome"] = "冰冻",
						}, -- [6]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 9,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["像只猴的你"] = {
									["uptime"] = 9,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588601260,
							["tipo"] = 4,
							["damage_twin"] = "莱斯·霜语",
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["damage_spellid"] = "冰冻新星",
							["nome"] = "冰冻新星",
						}, -- [7]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 32,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["朴不成"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = -1,
									["actived"] = false,
									["actived_at"] = 1588601257,
								},
							},
							["last_event"] = 1588601257,
							["tipo"] = 4,
							["damage_twin"] = "莱斯·霜语",
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["damage_spellid"] = 0,
							["nome"] = "恐惧术",
						}, -- [8]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 24,
							["spellschool"] = 16,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["像只猴的你"] = {
									["uptime"] = 8,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
								["啪啪"] = {
									["uptime"] = 8,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
								["琼琼宝贝"] = {
									["uptime"] = 8,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1588601275,
								},
							},
							["last_event"] = 1588601275,
							["tipo"] = 4,
							["damage_twin"] = "莱斯·霜语",
							["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
							["damage_spellid"] = "连发寒冰箭",
							["nome"] = "连发寒冰箭",
						}, -- [9]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["last_event"] = 0,
							["spell_cast"] = {
								["爪击"] = 7,
							},
							["pets"] = {
							},
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["boss_fight_component"] = true,
						}, -- [10]
						{
							["flag_original"] = 1298,
							["nome"] = "朴不成",
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 31,
							["last_event"] = 1588601278,
							["spell_cast"] = {
								["剑刃乱舞"] = 1,
								["背刺"] = 4,
								["切割"] = 1,
								["冲动"] = 1,
								["疾跑"] = 1,
								["邪恶攻击"] = 1,
							},
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冲动"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冲动",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["疾跑"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "疾跑",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01F19A55",
							["tipo"] = 4,
						}, -- [11]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 130,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
					["朴不成"] = true,
					["幽魂无双"] = true,
					["像只猴的你"] = true,
					["琼琼宝贝"] = true,
				},
				["CombatStartedAt"] = 1562986.452,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					24409, -- [1]
					4614, -- [2]
					{
						15, -- [1]
						[0] = 496,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
					["朴不成"] = {
						{
							true, -- [1]
							"风怒图腾", -- [2]
							1, -- [3]
							1588601283.001, -- [4]
							2980, -- [5]
							"朴不成", -- [6]
							nil, -- [7]
							8, -- [8]
							true, -- [9]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "22:07:58",
				["cleu_timeline"] = {
				},
				["enemy"] = "莱斯·霜语",
				["TotalElapsedCombatTime"] = 23.8840000000782,
				["CombatEndedAt"] = 1563010.336,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:07:31",
				["end_time"] = 1563010.753,
				["combat_id"] = 130,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 736.001711,
							["朴不成"] = 3502.008128,
							["幽魂无双"] = 5831.004253,
							["像只猴的你"] = 6078.007393,
							["琼琼宝贝"] = 433.002694,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["像只猴的你"] = 180.006217,
							["琼琼宝贝"] = 4434.001152,
							["啪啪"] = 0.006087,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["tempo_start"] = 1588601251,
				["contra"] = "莱斯·霜语",
				["frags"] = {
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "通灵学院",
					["encounter"] = "莱斯·霜语",
					["mapid"] = 289,
					["try_number"] = 1,
					["name"] = "莱斯·霜语",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["combat_counter"] = 650,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					16111, -- [1]
					4614, -- [2]
					{
						15, -- [1]
						[0] = 133,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 1562983.749,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [10]
			{
				{
					["tipo"] = 2,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.004281,
							["damage_from"] = {
								["啪啪"] = true,
								["朴不成"] = true,
								["幽魂无双"] = true,
								["像只猴的你"] = true,
								["琼琼宝贝"] = true,
							},
							["targets"] = {
								["朴不成"] = 276,
								["像只猴的你"] = 5650,
								["琼琼宝贝"] = 2852,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["nome"] = "血骨傀儡",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 8778.004281,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 8778.004281,
							["end_time"] = 1588600885,
							["damage_taken"] = 30589.004281,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["击退"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 349,
										["targets"] = {
											["像只猴的你"] = 1075,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1075,
										["n_min"] = 214,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1075,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "击退",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 214,
										["n_amt"] = 4,
										["spellschool"] = 1,
										["a_amt"] = 0,
									},
									["打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 439,
										["targets"] = {
											["像只猴的你"] = 766,
											["琼琼宝贝"] = 439,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1205,
										["n_min"] = 335,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1205,
										["c_max"] = 0,
										["id"] = "打击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 4,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["a_amt"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 3,
										["c_dmg"] = 1160,
										["g_amt"] = 0,
										["n_max"] = 387,
										["targets"] = {
											["像只猴的你"] = 3409,
											["琼琼宝贝"] = 2413,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4662,
										["g_dmg"] = 0,
										["n_min"] = 99,
										["MISS"] = 2,
										["counter"] = 23,
										["total"] = 5822,
										["r_amt"] = 0,
										["c_max"] = 712,
										["b_dmg"] = 463,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 448,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 17,
										["a_amt"] = 0,
										["DODGE"] = 1,
									},
									["战争践踏"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 142,
										["targets"] = {
											["朴不成"] = 276,
											["像只猴的你"] = 400,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 676,
										["n_min"] = 127,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 676,
										["c_max"] = 0,
										["id"] = "战争践踏",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["n_amt"] = 5,
										["c_min"] = 0,
										["successful_casted"] = 3,
										["b_dmg"] = 0,
										["RESIST"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588600883,
							["on_hold"] = false,
							["start_time"] = 1588600820,
							["serial"] = "Creature-0-4889-289-12207-11622-0000300FDF",
							["monster"] = true,
						}, -- [1]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.006157,
							["damage_from"] = {
								["复活的构造体"] = true,
								["血骨傀儡"] = true,
							},
							["targets"] = {
								["复活的构造体"] = 2124,
								["血骨傀儡"] = 6091,
							},
							["pets"] = {
							},
							["end_time"] = 1588600885,
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 2124,
							},
							["total_without_pet"] = 8215.006157,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 8215.006157,
							["nome"] = "像只猴的你",
							["damage_taken"] = 11053.006157,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1183,
										["g_amt"] = 0,
										["n_max"] = 369,
										["targets"] = {
											["复活的构造体"] = 369,
											["血骨傀儡"] = 1699,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 885,
										["n_min"] = 251,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2068,
										["c_max"] = 661,
										["id"] = "嗜血",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 522,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1299,
										["g_amt"] = 5,
										["n_max"] = 316,
										["targets"] = {
											["复活的构造体"] = 1226,
											["血骨傀儡"] = 3446,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2309,
										["n_min"] = 187,
										["g_dmg"] = 1064,
										["counter"] = 21,
										["r_amt"] = 0,
										["total"] = 4672,
										["c_max"] = 473,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 392,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 10,
										["a_amt"] = 0,
										["DODGE"] = 2,
									},
									["暗影箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 115,
										["targets"] = {
											["复活的构造体"] = 107,
											["血骨傀儡"] = 216,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 323,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 323,
										["c_max"] = 0,
										["id"] = "暗影箭",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 32,
									},
									["复仇"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 51,
										["targets"] = {
											["复活的构造体"] = 136,
											["血骨傀儡"] = 42,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 178,
										["n_min"] = 38,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 178,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "复仇",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["spellschool"] = 1,
										["a_amt"] = 0,
									},
									["火舌攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 36,
										["targets"] = {
											["复活的构造体"] = 286,
											["血骨傀儡"] = 565,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 851,
										["n_min"] = 24,
										["g_dmg"] = 0,
										["counter"] = 32,
										["total"] = 851,
										["c_max"] = 0,
										["r_amt"] = 2,
										["id"] = "火舌攻击",
										["r_dmg"] = 48,
										["b_dmg"] = 0,
										["n_amt"] = 27,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["重伤"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["复活的构造体"] = 0,
											["血骨傀儡"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "重伤",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["IMMUNE"] = 5,
									},
									["拦截昏迷"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 51,
										["targets"] = {
											["血骨傀儡"] = 51,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 51,
										["n_min"] = 51,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 51,
										["c_max"] = 0,
										["id"] = "拦截昏迷",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["惩戒痛击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 72,
										["targets"] = {
											["血骨傀儡"] = 72,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 72,
										["n_min"] = 72,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 72,
										["c_max"] = 0,
										["id"] = "惩戒痛击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600883,
							["friendlyfire"] = {
							},
							["start_time"] = 1588600825,
							["serial"] = "Player-4920-01D50132",
							["classe"] = "WARRIOR",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006813,
							["damage_from"] = {
								["复活的构造体"] = true,
								["啪啪"] = true,
								["朴不成"] = true,
								["像只猴的你"] = true,
								["幽魂无双"] = true,
								["鲁总 <啪啪>"] = true,
							},
							["targets"] = {
								["朴不成"] = 1928,
								["像只猴的你"] = 5403,
								["复活的构造体"] = 4,
								["鲁总 <啪啪>"] = 486,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["nome"] = "复活的构造体",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 4,
							},
							["total_without_pet"] = 7821.006813,
							["delay"] = 1588600845,
							["dps_started"] = false,
							["total"] = 7821.006813,
							["end_time"] = 1588600885,
							["damage_taken"] = 15169.006813,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 3,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 421,
										["targets"] = {
											["像只猴的你"] = 4995,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4995,
										["n_min"] = 227,
										["g_dmg"] = 0,
										["counter"] = 15,
										["total"] = 4995,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 799,
										["n_amt"] = 15,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["横扫攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 517,
										["targets"] = {
											["朴不成"] = 1928,
											["鲁总 <啪啪>"] = 486,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2414,
										["n_min"] = 390,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2414,
										["c_max"] = 0,
										["id"] = "横扫攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["圆弧斩"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 408,
										["targets"] = {
											["像只猴的你"] = 408,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 408,
										["n_min"] = 408,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 408,
										["c_max"] = 0,
										["id"] = "圆弧斩",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["痛击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 2,
										["targets"] = {
											["复活的构造体"] = 4,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4,
										["n_min"] = 2,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = "痛击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["狂怒"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "狂怒",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588600845,
							["on_hold"] = false,
							["start_time"] = 1588600863,
							["serial"] = "Creature-0-4889-289-12207-10488-0003300FDF",
							["monster"] = true,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.00883,
							["damage_from"] = {
								["复活的构造体"] = true,
								["血骨傀儡"] = true,
								["朴不成"] = true,
							},
							["targets"] = {
								["复活的构造体"] = 3535,
								["血骨傀儡"] = 7599,
							},
							["pets"] = {
							},
							["end_time"] = 1588600885,
							["tipo"] = 1,
							["friendlyfire_total"] = 4,
							["raid_targets"] = {
								[128] = 3535,
							},
							["total_without_pet"] = 11134.00883,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 11134.00883,
							["nome"] = "朴不成",
							["damage_taken"] = 2208.00883,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 16,
										["b_amt"] = 1,
										["c_dmg"] = 3691,
										["g_amt"] = 5,
										["n_max"] = 148,
										["targets"] = {
											["复活的构造体"] = 1679,
											["血骨傀儡"] = 5452,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2890,
										["DODGE"] = 2,
										["n_min"] = 74,
										["g_dmg"] = 550,
										["counter"] = 56,
										["total"] = 7131,
										["r_amt"] = 0,
										["c_max"] = 299,
										["b_dmg"] = 74,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 186,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 27,
										["MISS"] = 5,
										["a_amt"] = 0,
									},
									["背刺"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 787,
										["g_amt"] = 0,
										["n_max"] = 445,
										["targets"] = {
											["血骨傀儡"] = 1610,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 823,
										["n_min"] = 378,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1610,
										["c_max"] = 787,
										["id"] = "背刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 787,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["肾击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["复活的构造体"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "肾击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
									["刺骨"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 697,
										["targets"] = {
											["复活的构造体"] = 697,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 697,
										["n_min"] = 697,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 697,
										["c_max"] = 0,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["灼热武器"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["复活的构造体"] = 80,
											["血骨傀儡"] = 160,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 240,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 240,
										["c_max"] = 0,
										["id"] = "灼热武器",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 765,
										["g_amt"] = 0,
										["n_max"] = 185,
										["targets"] = {
											["复活的构造体"] = 1079,
											["血骨傀儡"] = 377,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 691,
										["n_min"] = 161,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1456,
										["c_max"] = 388,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 377,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600884,
							["friendlyfire"] = {
								["朴不成"] = {
									["total"] = 4,
									["spells"] = {
										["风怒图腾"] = 4,
									},
								},
							},
							["start_time"] = 1588600825,
							["serial"] = "Player-4920-01F19A55",
							["classe"] = "ROGUE",
						}, -- [4]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.00871,
							["damage_from"] = {
							},
							["targets"] = {
								["复活的构造体"] = 4138,
								["血骨傀儡"] = 8152,
							},
							["delay"] = 1588600846,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["spells"] = {
								["_ActorTable"] = {
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 98,
										["targets"] = {
											["复活的构造体"] = 588,
											["血骨傀儡"] = 686,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1274,
										["n_min"] = 98,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 1274,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 13,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["!Autoshot"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 2471,
										["g_amt"] = 0,
										["n_max"] = 435,
										["targets"] = {
											["复活的构造体"] = 2163,
											["血骨傀儡"] = 3728,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3420,
										["n_min"] = 313,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 5891,
										["c_max"] = 941,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 755,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["瞄准射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 904,
										["targets"] = {
											["复活的构造体"] = 738,
											["血骨傀儡"] = 1678,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2416,
										["n_min"] = 738,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 2416,
										["c_max"] = 0,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["驱散射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["血骨傀儡"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "驱散射击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["IMMUNE"] = 1,
									},
									["多重射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 568,
										["targets"] = {
											["复活的构造体"] = 481,
											["血骨傀儡"] = 2060,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2541,
										["n_min"] = 433,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2541,
										["c_max"] = 0,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "HUNTER",
							["raid_targets"] = {
								[128] = 4138,
							},
							["total_without_pet"] = 12122.00871,
							["nome"] = "啪啪",
							["dps_started"] = false,
							["total"] = 12290.00871,
							["damage_taken"] = 0.00871,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 254,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588600885,
							["custom"] = 0,
							["last_event"] = 1588600884,
							["friendlyfire"] = {
							},
							["start_time"] = 1588600841,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [5]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.007924,
							["damage_from"] = {
								["血骨傀儡"] = true,
							},
							["targets"] = {
								["血骨傀儡"] = 138,
							},
							["delay"] = 1588600869,
							["pets"] = {
							},
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 138,
										["targets"] = {
											["血骨傀儡"] = 138,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 138,
										["n_min"] = 138,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 138,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "SHAMAN",
							["raid_targets"] = {
							},
							["total_without_pet"] = 138.007924,
							["nome"] = "琼琼宝贝",
							["dps_started"] = false,
							["total"] = 138.007924,
							["damage_taken"] = 2852.007924,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 264,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588600885,
							["custom"] = 0,
							["last_event"] = 1588600869,
							["friendlyfire"] = {
							},
							["start_time"] = 1588600884,
							["serial"] = "Player-4920-01D6B7EB",
							["on_hold"] = false,
						}, -- [6]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.001928,
							["damage_from"] = {
							},
							["targets"] = {
								["复活的构造体"] = 5368,
								["血骨傀儡"] = 8609,
							},
							["pets"] = {
							},
							["end_time"] = 1588600885,
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
								[128] = 5368,
							},
							["total_without_pet"] = 13977.001928,
							["delay"] = 1588600845,
							["dps_started"] = false,
							["total"] = 13977.001928,
							["nome"] = "幽魂无双",
							["damage_taken"] = 0.001928,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["点燃"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 303,
										["targets"] = {
											["复活的构造体"] = 606,
											["血骨傀儡"] = 342,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 948,
										["n_min"] = 171,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 948,
										["c_max"] = 0,
										["id"] = "点燃",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["灼烧"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 285,
										["g_amt"] = 0,
										["n_max"] = 373,
										["targets"] = {
											["血骨傀儡"] = 2436,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2151,
										["n_min"] = 340,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 2436,
										["c_max"] = 285,
										["id"] = "灼烧",
										["r_dmg"] = 285,
										["r_amt"] = 1,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 285,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火球术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 798,
										["targets"] = {
											["复活的构造体"] = 1636,
											["血骨傀儡"] = 2290,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3926,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 17,
										["total"] = 3926,
										["c_max"] = 0,
										["id"] = "火球术",
										["r_dmg"] = 592,
										["r_amt"] = 1,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 17,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["炎爆术"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1518,
										["g_amt"] = 0,
										["n_max"] = 1035,
										["targets"] = {
											["复活的构造体"] = 1926,
											["血骨傀儡"] = 1439,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1847,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 3365,
										["c_max"] = 1518,
										["id"] = "炎爆术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1518,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 855,
										["g_amt"] = 0,
										["n_max"] = 640,
										["targets"] = {
											["复活的构造体"] = 1200,
											["血骨傀儡"] = 2102,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2447,
										["n_min"] = 583,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 3302,
										["c_max"] = 855,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 855,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600883,
							["friendlyfire"] = {
							},
							["start_time"] = 1588600843,
							["serial"] = "Player-4920-01ECB17B",
							["classe"] = "MAGE",
						}, -- [7]
						{
							["flag_original"] = 16657,
							["totalabsorbed"] = 0.005292,
							["damage_from"] = {
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 1588600839,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005292,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.005292,
							["delay"] = 0,
							["friendlyfire"] = {
							},
							["nome"] = "冰冻陷阱 III",
							["spells"] = {
								["_ActorTable"] = {
									["冰冻陷阱效果"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["血骨傀儡"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "冰冻陷阱效果",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 16,
										["IMMUNE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.005292,
							["end_time"] = 1588600885,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588600885,
							["serial"] = "GameObject-0-4889-289-12207-164877-0000302007",
							["classe"] = "UNKNOW",
						}, -- [8]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.001432,
							["damage_from"] = {
								["复活的构造体"] = true,
							},
							["targets"] = {
								["复活的构造体"] = 168,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["tipo"] = 1,
							["classe"] = "PET",
							["raid_targets"] = {
								[128] = 168,
							},
							["total_without_pet"] = 168.001432,
							["delay"] = 1588600846,
							["dps_started"] = false,
							["end_time"] = 1588600885,
							["nome"] = "鲁总 <啪啪>",
							["ownerName"] = "啪啪",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 69,
										["targets"] = {
											["复活的构造体"] = 129,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 129,
										["n_min"] = 60,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 129,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["爪击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 39,
										["targets"] = {
											["复活的构造体"] = 39,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 39,
										["n_min"] = 39,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 39,
										["c_max"] = 0,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 486.001432,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600846,
							["on_hold"] = false,
							["start_time"] = 1588600883,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["total"] = 168.001432,
						}, -- [9]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.001352,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["像只猴的你"] = 360,
							},
							["delay"] = 1588600872,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["像只猴的你"] = true,
								["琼琼宝贝"] = true,
							},
							["healing_taken"] = 10024.001352,
							["totalover"] = 0.001352,
							["total_without_pet"] = 360.001352,
							["totalover_without_pet"] = 0.001352,
							["totaldenied"] = 0.001352,
							["classe"] = "WARRIOR",
							["end_time"] = 1588600885,
							["targets_absorbs"] = {
							},
							["heal_enemy_amt"] = 0,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 20,
										["targets"] = {
											["像只猴的你"] = 360,
										},
										["n_min"] = 20,
										["counter"] = 18,
										["overheal"] = 0,
										["total"] = 360,
										["c_max"] = 0,
										["id"] = "嗜血",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 18,
										["n_curado"] = 360,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["total"] = 360.001352,
							["heal_enemy"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1588600872,
							["on_hold"] = false,
							["start_time"] = 1588600842,
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [1]
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["朴不成"] = 272,
								["琼琼宝贝"] = 193,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 465.002007,
							["total_without_pet"] = 13438.002007,
							["total"] = 13438.002007,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D6B7EB",
							["totalabsorb"] = 0.002007,
							["last_hps"] = 0,
							["targets"] = {
								["朴不成"] = 2336,
								["像只猴的你"] = 9664,
								["琼琼宝贝"] = 1903,
							},
							["totalover_without_pet"] = 0.002007,
							["healing_taken"] = 1710.002007,
							["end_time"] = 1588600885,
							["spec"] = 264,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["次级治疗波"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1162,
										["targets"] = {
											["朴不成"] = 1134,
											["像只猴的你"] = 5536,
											["琼琼宝贝"] = 1162,
										},
										["n_min"] = 1058,
										["counter"] = 7,
										["overheal"] = 0,
										["total"] = 7832,
										["c_max"] = 0,
										["id"] = "次级治疗波",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 7,
										["n_curado"] = 7832,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
									["治疗波"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1208,
										["targets"] = {
											["像只猴的你"] = 2373,
										},
										["n_min"] = 1165,
										["counter"] = 2,
										["overheal"] = 0,
										["total"] = 2373,
										["c_max"] = 0,
										["id"] = "治疗波",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 2373,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
									["治疗链"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["朴不成"] = 272,
											["琼琼宝贝"] = 193,
										},
										["n_max"] = 878,
										["targets"] = {
											["朴不成"] = 930,
											["像只猴的你"] = 1755,
											["琼琼宝贝"] = 548,
										},
										["n_min"] = 180,
										["counter"] = 6,
										["overheal"] = 465,
										["total"] = 3233,
										["c_max"] = 0,
										["id"] = "治疗链",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 3233,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["totaldenied"] = 0.002007,
							["custom"] = 0,
							["last_event"] = 1588600877,
							["classe"] = "SHAMAN",
							["start_time"] = 1588600842,
							["delay"] = 1588600866,
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.008849,
							["last_hps"] = 0,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.008849,
							["targets_overheal"] = {
							},
							["classe"] = "ROGUE",
							["totalover"] = 0.008849,
							["total_without_pet"] = 0.008849,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.008849,
							["heal_enemy_amt"] = 0,
							["total"] = 0.008849,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["healing_taken"] = 2064.008849,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["end_time"] = 1588600885,
							["heal_enemy"] = {
							},
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588600885,
							["serial"] = "Player-4920-01F19A55",
							["nome"] = "朴不成",
						}, -- [3]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["received"] = 738.006529,
							["resource"] = 0.006529,
							["targets"] = {
								["琼琼宝贝"] = 385,
							},
							["pets"] = {
								"法力之泉图腾 IV <琼琼宝贝>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "SHAMAN",
							["passiveover"] = 0.006529,
							["total"] = 1360.006529,
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["法力澎湃"] = {
										["total"] = 385,
										["id"] = "法力澎湃",
										["totalover"] = 0,
										["targets"] = {
											["琼琼宝贝"] = 385,
										},
										["counter"] = 3,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.006529,
							["flag_original"] = 1298,
							["last_event"] = 1588600878,
							["tipo"] = 3,
							["spec"] = 264,
							["alternatepower"] = 0.006529,
							["serial"] = "Player-4920-01D6B7EB",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["received"] = 0.002195,
							["resource"] = 0.002195,
							["targets"] = {
								["幽魂无双"] = 274,
								["琼琼宝贝"] = 353,
								["啪啪"] = 348,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["passiveover"] = 0.002195,
							["total"] = 975.002195,
							["ownerName"] = "琼琼宝贝",
							["nome"] = "法力之泉图腾 IV <琼琼宝贝>",
							["spells"] = {
								["_ActorTable"] = {
									["法力之泉"] = {
										["total"] = 975,
										["id"] = "法力之泉",
										["totalover"] = 0,
										["targets"] = {
											["幽魂无双"] = 274,
											["琼琼宝贝"] = 353,
											["啪啪"] = 348,
										},
										["counter"] = 78,
									},
								},
								["tipo"] = 7,
							},
							["totalover"] = 0.002195,
							["flag_original"] = 8466,
							["last_event"] = 1588600875,
							["tipo"] = 3,
							["alternatepower"] = 0.002195,
							["serial"] = "Creature-0-4889-289-12207-7416-0000301FF1",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["received"] = 348.003976,
							["resource"] = 0.003976,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "HUNTER",
							["passiveover"] = 642.003976,
							["total"] = 0.003976,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.003976,
							["flag_original"] = 1297,
							["last_event"] = 0,
							["tipo"] = 3,
							["spec"] = 254,
							["alternatepower"] = 0.003976,
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["received"] = 24.006597,
							["resource"] = 0.006597,
							["targets"] = {
								["像只猴的你"] = 24,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.006597,
							["total"] = 24.006597,
							["nome"] = "像只猴的你",
							["spells"] = {
								["_ActorTable"] = {
									["怒不可遏"] = {
										["total"] = 4,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 4,
										},
										["counter"] = 4,
									},
									["血性狂暴"] = {
										["total"] = 20,
										["id"] = "血性狂暴",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 20,
										},
										["counter"] = 11,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.006597,
							["flag_original"] = 1298,
							["last_event"] = 1588600871,
							["tipo"] = 3,
							["alternatepower"] = 0.006597,
							["serial"] = "Player-4920-01D50132",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["received"] = 553.002103,
							["resource"] = 0.002103,
							["targets"] = {
								["幽魂无双"] = 279,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.002103,
							["total"] = 279.002103,
							["nome"] = "幽魂无双",
							["spells"] = {
								["_ActorTable"] = {
									["元素大师"] = {
										["total"] = 279,
										["id"] = "元素大师",
										["totalover"] = 0,
										["targets"] = {
											["幽魂无双"] = 279,
										},
										["counter"] = 3,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.002103,
							["flag_original"] = 1298,
							["last_event"] = 1588600885,
							["tipo"] = 3,
							["alternatepower"] = 0.002103,
							["serial"] = "Player-4920-01ECB17B",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["received"] = 25.001601,
							["resource"] = 0.001601,
							["targets"] = {
								["朴不成"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 0.001601,
							["total"] = 25.001601,
							["nome"] = "朴不成",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 0,
										["targets"] = {
											["朴不成"] = 25,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.001601,
							["flag_original"] = 1298,
							["last_event"] = 1588600845,
							["tipo"] = 3,
							["alternatepower"] = 0.001601,
							["serial"] = "Player-4920-01F19A55",
							["boss_fight_component"] = true,
						}, -- [6]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 123,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["嘲讽"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "嘲讽",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
									["挫志怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "挫志怒吼",
										["uptime"] = 30,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["破甲攻击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "破甲攻击",
										["uptime"] = 48,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["拦截昏迷"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "拦截昏迷",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["惩戒痛击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "惩戒痛击",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 132,
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 3,
										["refreshamt"] = 2,
										["id"] = "乱舞",
										["uptime"] = 35,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									["嗜血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 5,
										["refreshamt"] = 0,
										["id"] = "嗜血",
										["uptime"] = 40,
										["targets"] = {
										},
										["appliedamt"] = 5,
									},
									["盾牌格挡"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "盾牌格挡",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["战斗怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "战斗怒吼",
										["uptime"] = 25,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["狂怒"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "狂怒",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["狂暴姿态"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "狂暴姿态",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["防御姿态"] = {
										["activedamt"] = 1,
										["id"] = "防御姿态",
										["targets"] = {
										},
										["actived_at"] = 1588600885,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["战斗姿态"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "战斗姿态",
										["uptime"] = 4,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["血性狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "血性狂暴",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 95,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["嗜血"] = 5,
								["破甲攻击"] = 4,
								["盾牌格挡"] = 2,
								["防御姿态"] = 1,
								["狂暴姿态"] = 1,
								["拦截"] = 1,
								["惩戒痛击"] = 1,
								["挫志怒吼"] = 1,
								["嘲讽"] = 4,
								["复仇"] = 5,
								["战斗姿态"] = 1,
								["血性狂暴"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588600885,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [1]
						{
							["flag_original"] = 1047,
							["nome"] = "琼琼宝贝",
							["buff_uptime_targets"] = {
							},
							["spec"] = 264,
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 130,
							["pets"] = {
							},
							["last_event"] = 1588600885,
							["classe"] = "SHAMAN",
							["spell_cast"] = {
								["次级治疗波"] = 7,
								["治疗波"] = 2,
								["治疗链"] = 2,
								["石肤图腾"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 65,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["石肤术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "石肤术",
										["uptime"] = 65,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["法力之泉"] = {
										["activedamt"] = 1,
										["id"] = "法力之泉",
										["targets"] = {
										},
										["actived_at"] = 1588600820,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D6B7EB",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["炎爆术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "炎爆术",
										["uptime"] = 24,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["点燃"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "点燃",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = "火球术",
										["uptime"] = 27,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
									["冲击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冲击",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 220,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 65,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术光辉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术光辉",
										["uptime"] = 65,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 65,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["燃烧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "燃烧",
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["节能施法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 4,
										["refreshamt"] = 0,
										["id"] = "节能施法",
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 61,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火球术"] = 5,
								["灼烧"] = 7,
								["炎爆术"] = 2,
								["火焰冲击"] = 5,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588600885,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01ECB17B",
							["nome"] = "幽魂无双",
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["猎人印记"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "猎人印记",
										["uptime"] = 36,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冰霜陷阱光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冰霜陷阱光环",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = "毒蛇钉刺",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 142,
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["快速射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "快速射击",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 65,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 65,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 84,
							["buff_uptime_targets"] = {
							},
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["冰霜陷阱"] = 1,
								["瞄准射击"] = 3,
								["驱散射击"] = 1,
								["毒蛇钉刺"] = 5,
								["自动射击"] = 12,
								["冰冻陷阱"] = 1,
								["多重射击"] = 4,
								["猎人印记"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588600885,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["nome"] = "啪啪",
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["nome"] = "朴不成",
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 31,
							["last_event"] = 1588600872,
							["spell_cast"] = {
								["剑刃乱舞"] = 1,
								["背刺"] = 3,
								["切割"] = 1,
								["肾击"] = 1,
								["刺骨"] = 1,
								["邪恶攻击"] = 6,
							},
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 4,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 4,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01F19A55",
							["tipo"] = 4,
						}, -- [5]
						{
							["flag_original"] = 2632,
							["last_event"] = 0,
							["nome"] = "血骨傀儡",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["打击"] = 4,
								["击退"] = 4,
								["战争践踏"] = 3,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4889-289-12207-11622-0000300FDF",
							["boss_fight_component"] = true,
						}, -- [6]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "复活的构造体",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["横扫攻击"] = 1,
								["圆弧斩"] = 1,
								["痛击"] = 2,
								["狂怒"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4889-289-12207-10488-0003300FDF",
							["boss_fight_component"] = true,
						}, -- [7]
						{
							["flag_original"] = 2632,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 22,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["朴不成"] = {
									["uptime"] = 10,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
								["像只猴的你"] = {
									["uptime"] = 12,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588600877,
							["tipo"] = 4,
							["damage_twin"] = "血骨傀儡",
							["serial"] = "Creature-0-4889-289-12207-11622-0000300FDF",
							["damage_spellid"] = "战争践踏",
							["nome"] = "战争践踏",
						}, -- [8]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["last_event"] = 0,
							["spell_cast"] = {
								["爪击"] = 1,
							},
							["pets"] = {
							},
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
							["boss_fight_component"] = true,
						}, -- [9]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 123,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
					["朴不成"] = true,
					["幽魂无双"] = true,
					["像只猴的你"] = true,
					["琼琼宝贝"] = true,
				},
				["CombatStartedAt"] = 1562614.057,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					62353, -- [1]
					13798, -- [2]
					{
						24, -- [1]
						[0] = 1639,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "22:01:26",
				["cleu_timeline"] = {
				},
				["enemy"] = "血骨傀儡",
				["TotalElapsedCombatTime"] = 4.07300000009127,
				["CombatEndedAt"] = 1562618.13,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:00:21",
				["end_time"] = 1562618.28,
				["combat_id"] = 123,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 12290.00871,
							["朴不成"] = 11134.00883,
							["像只猴的你"] = 8215.006157,
							["幽魂无双"] = 13977.001928,
							["琼琼宝贝"] = 138.007924,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["朴不成"] = 0.008849,
							["像只猴的你"] = 360.001352,
							["琼琼宝贝"] = 13438.002007,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["tempo_start"] = 1588600820,
				["contra"] = "血骨傀儡",
				["frags"] = {
					["复活的构造体"] = 1,
					["血骨傀儡"] = 1,
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "通灵学院",
					["encounter"] = "血骨傀儡",
					["mapid"] = 289,
					["try_number"] = 1,
					["name"] = "血骨傀儡",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["combat_counter"] = 643,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					45590, -- [1]
					13798, -- [2]
					{
						24, -- [1]
						[0] = 664,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 1562553.275,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [11]
			{
				{
					["tipo"] = 2,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002451,
							["damage_from"] = {
								["像只猴的你"] = true,
								["传令官基尔图诺斯"] = true,
							},
							["targets"] = {
								["传令官基尔图诺斯"] = 2313,
							},
							["pets"] = {
							},
							["end_time"] = 1588600232,
							["tipo"] = 1,
							["friendlyfire_total"] = 1,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2313.002451,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 2313.002451,
							["nome"] = "像只猴的你",
							["damage_taken"] = 10525.002451,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 359,
										["g_amt"] = 0,
										["n_max"] = 217,
										["targets"] = {
											["传令官基尔图诺斯"] = 1216,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 857,
										["MISS"] = 2,
										["n_min"] = 90,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 1216,
										["r_amt"] = 0,
										["c_max"] = 181,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 178,
										["m_crit"] = 0,
										["PARRY"] = 7,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 6,
										["DODGE"] = 3,
										["a_amt"] = 0,
									},
									["嗜血"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 303,
										["targets"] = {
											["传令官基尔图诺斯"] = 303,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 303,
										["n_min"] = 303,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 303,
										["c_max"] = 0,
										["id"] = "嗜血",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["复仇"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 47,
										["targets"] = {
											["传令官基尔图诺斯"] = 110,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 110,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 110,
										["c_max"] = 0,
										["id"] = "复仇",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["火舌攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 32,
										["targets"] = {
											["传令官基尔图诺斯"] = 222,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 222,
										["n_min"] = 31,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 222,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "火舌攻击",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["重伤"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 51,
										["targets"] = {
											["传令官基尔图诺斯"] = 204,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 204,
										["n_min"] = 51,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 204,
										["c_max"] = 0,
										["id"] = "重伤",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["暗影箭"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 111,
										["targets"] = {
											["传令官基尔图诺斯"] = 111,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 111,
										["n_min"] = 111,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 111,
										["c_max"] = 0,
										["id"] = "暗影箭",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 32,
									},
									["英勇打击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 147,
										["targets"] = {
											["传令官基尔图诺斯"] = 147,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 147,
										["n_min"] = 147,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 147,
										["c_max"] = 0,
										["id"] = "英勇打击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600230,
							["friendlyfire"] = {
								["像只猴的你"] = {
									["total"] = 1,
									["spells"] = {
										["风怒图腾"] = 1,
									},
								},
							},
							["start_time"] = 1588600186,
							["serial"] = "Player-4920-01D50132",
							["classe"] = "WARRIOR",
						}, -- [1]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.0031,
							["damage_from"] = {
								["啪啪"] = true,
								["朴不成"] = true,
								["像只猴的你"] = true,
								["幽魂无双"] = true,
								["鲁总 <啪啪>"] = true,
							},
							["targets"] = {
								["像只猴的你"] = 10524,
								["幽魂无双"] = 1557,
								["鲁总 <啪啪>"] = 943,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["nome"] = "传令官基尔图诺斯",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 13024.0031,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 13024.0031,
							["end_time"] = 1588600232,
							["damage_taken"] = 29749.0031,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 5,
										["c_dmg"] = 930,
										["g_amt"] = 0,
										["n_max"] = 799,
										["targets"] = {
											["像只猴的你"] = 9686,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 8756,
										["MISS"] = 1,
										["n_min"] = 380,
										["g_dmg"] = 0,
										["counter"] = 20,
										["total"] = 9686,
										["r_amt"] = 0,
										["c_max"] = 930,
										["b_dmg"] = 2130,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 930,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 16,
										["DODGE"] = 1,
										["a_amt"] = 0,
									},
									["缴械"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "缴械",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["拍翼"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "拍翼",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["基尔图诺斯变形"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "基尔图诺斯变形",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["刺穿护甲"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "刺穿护甲",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["飞扑"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1557,
										["targets"] = {
											["像只猴的你"] = 838,
											["幽魂无双"] = 1557,
											["鲁总 <啪啪>"] = 943,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3338,
										["n_min"] = 838,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 3338,
										["c_max"] = 0,
										["id"] = "飞扑",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588600229,
							["on_hold"] = false,
							["start_time"] = 1588600190,
							["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
							["monster"] = true,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.002131,
							["damage_from"] = {
								["朴不成"] = true,
							},
							["targets"] = {
								["传令官基尔图诺斯"] = 9924,
							},
							["pets"] = {
							},
							["end_time"] = 1588600232,
							["tipo"] = 1,
							["friendlyfire_total"] = 2,
							["raid_targets"] = {
							},
							["total_without_pet"] = 9924.002131,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 9924.002131,
							["nome"] = "朴不成",
							["damage_taken"] = 2.002131,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 13,
										["b_amt"] = 0,
										["c_dmg"] = 2009,
										["g_amt"] = 7,
										["n_max"] = 136,
										["targets"] = {
											["传令官基尔图诺斯"] = 5070,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2499,
										["a_amt"] = 0,
										["n_min"] = 38,
										["g_dmg"] = 562,
										["counter"] = 62,
										["total"] = 5070,
										["r_amt"] = 0,
										["c_max"] = 273,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 92,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 32,
										["DODGE"] = 2,
										["MISS"] = 7,
									},
									["灼热武器"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["传令官基尔图诺斯"] = 240,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 240,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 240,
										["c_max"] = 0,
										["id"] = "灼热武器",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火舌攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 22,
										["targets"] = {
											["传令官基尔图诺斯"] = 548,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 548,
										["n_min"] = 21,
										["g_dmg"] = 0,
										["counter"] = 26,
										["total"] = 548,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "火舌攻击",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 25,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["RESIST"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["刺骨"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 797,
										["g_amt"] = 0,
										["n_max"] = 237,
										["targets"] = {
											["传令官基尔图诺斯"] = 1034,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 237,
										["n_min"] = 237,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1034,
										["c_max"] = 797,
										["id"] = "刺骨",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 797,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["背刺"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 2073,
										["g_amt"] = 0,
										["n_max"] = 288,
										["targets"] = {
											["传令官基尔图诺斯"] = 2711,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 638,
										["n_min"] = 146,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 2711,
										["c_max"] = 856,
										["id"] = "背刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 413,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 3,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["邪恶攻击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 321,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["传令官基尔图诺斯"] = 321,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 321,
										["c_max"] = 161,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 160,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600230,
							["friendlyfire"] = {
								["朴不成"] = {
									["total"] = 2,
									["spells"] = {
										["风怒图腾"] = 2,
									},
								},
							},
							["start_time"] = 1588600187,
							["serial"] = "Player-4920-01F19A55",
							["classe"] = "ROGUE",
						}, -- [3]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.001851,
							["damage_from"] = {
							},
							["targets"] = {
								["传令官基尔图诺斯"] = 8606,
							},
							["delay"] = 0,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["传令官基尔图诺斯"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["r_amt"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 0,
										["DODGE"] = 1,
										["MISS"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 98,
										["targets"] = {
											["传令官基尔图诺斯"] = 1274,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1274,
										["n_min"] = 98,
										["g_dmg"] = 0,
										["counter"] = 13,
										["total"] = 1274,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 13,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["!Autoshot"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 1245,
										["g_amt"] = 0,
										["n_max"] = 316,
										["targets"] = {
											["传令官基尔图诺斯"] = 2231,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 986,
										["n_min"] = 135,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 2231,
										["c_max"] = 495,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 357,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["瞄准射击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1634,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["传令官基尔图诺斯"] = 1634,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1634,
										["c_max"] = 873,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 761,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["多重射击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 1471,
										["g_amt"] = 0,
										["n_max"] = 232,
										["targets"] = {
											["传令官基尔图诺斯"] = 1703,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 232,
										["n_min"] = 232,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1703,
										["c_max"] = 1012,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 459,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["猛禽一击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["传令官基尔图诺斯"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "猛禽一击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 6842.001851,
							["nome"] = "啪啪",
							["dps_started"] = false,
							["total"] = 8606.001851,
							["damage_taken"] = 0.001851,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 254,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588600232,
							["custom"] = 0,
							["last_event"] = 1588600230,
							["friendlyfire"] = {
							},
							["start_time"] = 1588600188,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [4]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.006553,
							["damage_from"] = {
								["传令官基尔图诺斯"] = true,
							},
							["targets"] = {
								["传令官基尔图诺斯"] = 1764,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["tipo"] = 1,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1764.006553,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1588600232,
							["nome"] = "鲁总 <啪啪>",
							["ownerName"] = "啪啪",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 4,
										["n_max"] = 96,
										["targets"] = {
											["传令官基尔图诺斯"] = 1488,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1311,
										["n_min"] = 7,
										["g_dmg"] = 177,
										["counter"] = 28,
										["r_amt"] = 0,
										["total"] = 1488,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 7,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 21,
										["a_amt"] = 0,
										["MISS"] = 2,
									},
									["爪击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 33,
										["g_amt"] = 0,
										["n_max"] = 46,
										["targets"] = {
											["传令官基尔图诺斯"] = 276,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 243,
										["n_min"] = 19,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 276,
										["c_max"] = 33,
										["r_amt"] = 0,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 33,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 9,
										["spellschool"] = 1,
										["a_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 943.006553,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600230,
							["on_hold"] = false,
							["start_time"] = 1588600188,
							["serial"] = "Pet-0-4504-0-4505-10737-0100AE9C78",
							["total"] = 1764.006553,
						}, -- [5]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005371,
							["damage_from"] = {
								["传令官基尔图诺斯"] = true,
							},
							["targets"] = {
								["传令官基尔图诺斯"] = 8906,
							},
							["pets"] = {
							},
							["end_time"] = 1588600232,
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 8906.005371,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 8906.005371,
							["nome"] = "幽魂无双",
							["damage_taken"] = 1557.005371,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 921,
										["g_amt"] = 0,
										["n_max"] = 633,
										["targets"] = {
											["传令官基尔图诺斯"] = 1554,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 633,
										["n_min"] = 633,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1554,
										["c_max"] = 921,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 921,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["冲击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["传令官基尔图诺斯"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "冲击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 4,
										["IMMUNE"] = 3,
									},
									["炎爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 1037,
										["targets"] = {
											["传令官基尔图诺斯"] = 1441,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1441,
										["n_min"] = 101,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 1441,
										["c_max"] = 0,
										["id"] = "炎爆术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火球术"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 2498,
										["g_amt"] = 0,
										["n_max"] = 793,
										["targets"] = {
											["传令官基尔图诺斯"] = 4186,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1688,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 12,
										["total"] = 4186,
										["c_max"] = 1283,
										["id"] = "火球术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1215,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 10,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["灼烧"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 359,
										["targets"] = {
											["传令官基尔图诺斯"] = 359,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 359,
										["n_min"] = 359,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 359,
										["c_max"] = 0,
										["id"] = "灼烧",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["点燃"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 427,
										["targets"] = {
											["传令官基尔图诺斯"] = 1366,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1366,
										["n_min"] = 256,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 1366,
										["c_max"] = 0,
										["id"] = "点燃",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600229,
							["friendlyfire"] = {
							},
							["start_time"] = 1588600197,
							["serial"] = "Player-4920-01ECB17B",
							["classe"] = "MAGE",
						}, -- [6]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["朴不成"] = 37,
							},
							["pets"] = {
								"治疗之泉图腾 IV <琼琼宝贝>", -- [1]
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 2631.006899,
							["total_without_pet"] = 12430.006899,
							["total"] = 13285.006899,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D6B7EB",
							["totalabsorb"] = 0.006899,
							["last_hps"] = 0,
							["targets"] = {
								["朴不成"] = 2091,
								["像只猴的你"] = 9924,
								["幽魂无双"] = 1285,
								["鲁总 <啪啪>"] = 22,
							},
							["totalover_without_pet"] = 0.006899,
							["healing_taken"] = 0.006899,
							["end_time"] = 1588600232,
							["spec"] = 264,
							["healing_from"] = {
							},
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["次级治疗波"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1142,
										["targets"] = {
											["朴不成"] = 1082,
											["像只猴的你"] = 1142,
											["幽魂无双"] = 1062,
										},
										["n_min"] = 1062,
										["counter"] = 3,
										["overheal"] = 0,
										["total"] = 3286,
										["c_max"] = 0,
										["id"] = "次级治疗波",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 3286,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
									["治疗链"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["朴不成"] = 37,
										},
										["n_max"] = 859,
										["targets"] = {
											["朴不成"] = 859,
											["像只猴的你"] = 565,
										},
										["n_min"] = 565,
										["counter"] = 2,
										["overheal"] = 37,
										["total"] = 1424,
										["c_max"] = 0,
										["id"] = "治疗链",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 2,
										["n_curado"] = 1424,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
									["治疗波"] = {
										["c_amt"] = 2,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 1356,
										["targets"] = {
											["像只猴的你"] = 7720,
										},
										["n_min"] = 1127,
										["counter"] = 5,
										["overheal"] = 0,
										["total"] = 7720,
										["c_max"] = 2037,
										["id"] = "治疗波",
										["targets_absorbs"] = {
										},
										["c_curado"] = 4027,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 3,
										["n_curado"] = 3693,
										["c_min"] = 1990,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["totaldenied"] = 0.006899,
							["custom"] = 0,
							["last_event"] = 1588600229,
							["classe"] = "SHAMAN",
							["start_time"] = 1588600186,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["flag_original"] = 8466,
							["targets_overheal"] = {
								["治疗之泉图腾 IV <琼琼宝贝>"] = 494,
								["啪啪"] = 491,
								["朴不成"] = 380,
								["幽魂无双"] = 269,
								["琼琼宝贝"] = 491,
								["鲁总 <啪啪>"] = 469,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 2594.005965,
							["total_without_pet"] = 855.005965,
							["total"] = 855.005965,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Creature-0-4889-289-12207-3908-0000301D68",
							["totalabsorb"] = 0.005965,
							["last_hps"] = 0,
							["targets"] = {
								["朴不成"] = 113,
								["像只猴的你"] = 497,
								["幽魂无双"] = 223,
								["鲁总 <啪啪>"] = 22,
							},
							["totalover_without_pet"] = 0.005965,
							["healing_taken"] = 0.005965,
							["end_time"] = 1588600232,
							["ownerName"] = "琼琼宝贝",
							["nome"] = "治疗之泉图腾 IV <琼琼宝贝>",
							["spells"] = {
								["_ActorTable"] = {
									["治疗之泉"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["治疗之泉图腾 IV <琼琼宝贝>"] = 494,
											["啪啪"] = 491,
											["朴不成"] = 380,
											["幽魂无双"] = 269,
											["琼琼宝贝"] = 491,
											["鲁总 <啪啪>"] = 469,
										},
										["n_max"] = 23,
										["targets"] = {
											["治疗之泉图腾 IV <琼琼宝贝>"] = 0,
											["琼琼宝贝"] = 0,
											["啪啪"] = 0,
											["朴不成"] = 113,
											["幽魂无双"] = 223,
											["像只猴的你"] = 497,
											["鲁总 <啪啪>"] = 22,
										},
										["n_min"] = 0,
										["counter"] = 154,
										["overheal"] = 2594,
										["total"] = 855,
										["c_max"] = 0,
										["id"] = "治疗之泉",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 154,
										["n_curado"] = 855,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["totaldenied"] = 0.005965,
							["healing_from"] = {
							},
							["last_event"] = 1588600228,
							["custom"] = 0,
							["tipo"] = 2,
							["classe"] = "PET",
							["start_time"] = 1588600186,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.007621,
							["last_hps"] = 0,
							["targets_overheal"] = {
							},
							["targets"] = {
								["像只猴的你"] = 20,
							},
							["delay"] = 0,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["治疗之泉图腾 IV <琼琼宝贝>"] = true,
								["像只猴的你"] = true,
								["琼琼宝贝"] = true,
							},
							["healing_taken"] = 9944.007621,
							["totalover"] = 0.007621,
							["total_without_pet"] = 20.007621,
							["totalover_without_pet"] = 0.007621,
							["totaldenied"] = 0.007621,
							["classe"] = "WARRIOR",
							["end_time"] = 1588600232,
							["targets_absorbs"] = {
							},
							["heal_enemy_amt"] = 0,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 20,
										["targets"] = {
											["像只猴的你"] = 20,
										},
										["n_min"] = 20,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 20,
										["c_max"] = 0,
										["id"] = "嗜血",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 1,
										["n_curado"] = 20,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["total"] = 20.007621,
							["heal_enemy"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1588600231,
							["on_hold"] = false,
							["start_time"] = 1588600231,
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [3]
						{
							["flag_original"] = 1300,
							["healing_from"] = {
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 0.002026,
							["total_without_pet"] = 0.002026,
							["total"] = 0.002026,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D0E17B",
							["totalabsorb"] = 0.002026,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.002026,
							["healing_taken"] = 0.002026,
							["end_time"] = 1588600232,
							["spec"] = 254,
							["targets_overheal"] = {
							},
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["last_event"] = 0,
							["totaldenied"] = 0.002026,
							["custom"] = 0,
							["tipo"] = 2,
							["classe"] = "HUNTER",
							["start_time"] = 1588600232,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 4369,
							["healing_from"] = {
								["治疗之泉图腾 IV <琼琼宝贝>"] = true,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["classe"] = "PET",
							["totalover"] = 0.002045,
							["total_without_pet"] = 0.002045,
							["total"] = 0.002045,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Pet-0-4504-0-4505-10737-0100AE9C78",
							["totalabsorb"] = 0.002045,
							["last_hps"] = 0,
							["targets"] = {
							},
							["totalover_without_pet"] = 0.002045,
							["healing_taken"] = 22.002045,
							["end_time"] = 1588600232,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["totaldenied"] = 0.002045,
							["targets_overheal"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 0,
							["heal_enemy_amt"] = 0,
							["start_time"] = 1588600232,
							["delay"] = 0,
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.001544,
							["last_hps"] = 0,
							["healing_from"] = {
								["治疗之泉图腾 IV <琼琼宝贝>"] = true,
								["琼琼宝贝"] = true,
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.001544,
							["targets_overheal"] = {
							},
							["classe"] = "MAGE",
							["totalover"] = 0.001544,
							["total_without_pet"] = 0.001544,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.001544,
							["heal_enemy_amt"] = 0,
							["total"] = 0.001544,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["healing_taken"] = 1285.001544,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["end_time"] = 1588600232,
							["heal_enemy"] = {
							},
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588600232,
							["serial"] = "Player-4920-01ECB17B",
							["nome"] = "幽魂无双",
						}, -- [6]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.004716,
							["last_hps"] = 0,
							["healing_from"] = {
								["治疗之泉图腾 IV <琼琼宝贝>"] = true,
								["琼琼宝贝"] = true,
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.004716,
							["targets_overheal"] = {
							},
							["classe"] = "ROGUE",
							["totalover"] = 0.004716,
							["total_without_pet"] = 0.004716,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.004716,
							["heal_enemy_amt"] = 0,
							["total"] = 0.004716,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["healing_taken"] = 2054.004716,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["end_time"] = 1588600232,
							["heal_enemy"] = {
							},
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588600232,
							["serial"] = "Player-4920-01F19A55",
							["nome"] = "朴不成",
						}, -- [7]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["received"] = 12.00728,
							["resource"] = 0.00728,
							["targets"] = {
								["像只猴的你"] = 12,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.00728,
							["total"] = 12.00728,
							["nome"] = "像只猴的你",
							["spells"] = {
								["_ActorTable"] = {
									["怒不可遏"] = {
										["total"] = 3,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 3,
										},
										["counter"] = 3,
									},
									["血性狂暴"] = {
										["total"] = 9,
										["id"] = "血性狂暴",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 9,
										},
										["counter"] = 9,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.00728,
							["flag_original"] = 1298,
							["last_event"] = 1588600211,
							["tipo"] = 3,
							["alternatepower"] = 0.00728,
							["serial"] = "Player-4920-01D50132",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["received"] = 252.001841,
							["resource"] = 0.001841,
							["targets"] = {
								["琼琼宝贝"] = 252,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "SHAMAN",
							["passiveover"] = 0.001841,
							["total"] = 252.001841,
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["法力澎湃"] = {
										["total"] = 252,
										["id"] = "法力澎湃",
										["totalover"] = 0,
										["targets"] = {
											["琼琼宝贝"] = 252,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.001841,
							["flag_original"] = 1298,
							["last_event"] = 1588600213,
							["tipo"] = 3,
							["spec"] = 264,
							["alternatepower"] = 0.001841,
							["serial"] = "Player-4920-01D6B7EB",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["received"] = 25.00599,
							["resource"] = 0.00599,
							["targets"] = {
								["朴不成"] = 25,
							},
							["pets"] = {
							},
							["powertype"] = 3,
							["classe"] = "ROGUE",
							["passiveover"] = 0.00599,
							["total"] = 25.00599,
							["nome"] = "朴不成",
							["spells"] = {
								["_ActorTable"] = {
									["无情打击效果"] = {
										["total"] = 25,
										["id"] = "无情打击效果",
										["totalover"] = 25,
										["targets"] = {
											["朴不成"] = 25,
										},
										["counter"] = 2,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 25.00599,
							["flag_original"] = 1298,
							["last_event"] = 1588600228,
							["tipo"] = 3,
							["alternatepower"] = 0.00599,
							["serial"] = "Player-4920-01F19A55",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["received"] = 312.005194,
							["resource"] = 0.005194,
							["targets"] = {
								["幽魂无双"] = 312,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.005194,
							["total"] = 312.005194,
							["nome"] = "幽魂无双",
							["spells"] = {
								["_ActorTable"] = {
									["元素大师"] = {
										["total"] = 312,
										["id"] = "元素大师",
										["totalover"] = 0,
										["targets"] = {
											["幽魂无双"] = 312,
										},
										["counter"] = 3,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.005194,
							["flag_original"] = 1298,
							["last_event"] = 1588600224,
							["tipo"] = 3,
							["alternatepower"] = 0.005194,
							["serial"] = "Player-4920-01ECB17B",
							["boss_fight_component"] = true,
						}, -- [4]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 115,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲攻击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 4,
										["id"] = "破甲攻击",
										["uptime"] = 39,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["重伤"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = "重伤",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["嘲讽"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "嘲讽",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 124,
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "战斗怒吼",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["赞扎之魂"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "赞扎之魂",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["嗜血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "嗜血",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["血性狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "血性狂暴",
										["uptime"] = 8,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["盾牌格挡"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "盾牌格挡",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = "乱舞",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["狂怒"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "狂怒",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 63,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 1,
								["嘲讽"] = 3,
								["英勇打击"] = 1,
								["破甲攻击"] = 6,
								["复仇"] = 4,
								["盾牌格挡"] = 2,
								["嗜血"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588600232,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [1]
						{
							["flag_original"] = 1047,
							["nome"] = "琼琼宝贝",
							["buff_uptime_targets"] = {
							},
							["spec"] = 264,
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 92,
							["pets"] = {
							},
							["last_event"] = 1588600232,
							["classe"] = "SHAMAN",
							["spell_cast"] = {
								["次级治疗波"] = 3,
								["治疗链"] = 1,
								["风之优雅图腾"] = 1,
								["治疗波"] = 5,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["治疗之泉"] = {
										["activedamt"] = 1,
										["id"] = "治疗之泉",
										["targets"] = {
										},
										["actived_at"] = 1588600186,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["大地之力"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "大地之力",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["风之优雅"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "风之优雅",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D6B7EB",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "火球术",
										["uptime"] = 20,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["炎爆术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "炎爆术",
										["uptime"] = 12,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["侦测魔法"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "侦测魔法",
										["uptime"] = 24,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["点燃"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = "点燃",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 196,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["法力护盾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "法力护盾",
										["uptime"] = 21,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术智慧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术智慧",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["燃烧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 6,
										["id"] = "燃烧",
										["uptime"] = 37,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 65,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["法力护盾"] = 1,
								["炎爆术"] = 1,
								["侦测魔法"] = 1,
								["灼烧"] = 1,
								["火球术"] = 4,
								["火焰冲击"] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588600232,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01ECB17B",
							["nome"] = "幽魂无双",
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲虚弱"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "破甲虚弱",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["猎人印记"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "猎人印记",
										["uptime"] = 44,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "毒蛇钉刺",
										["uptime"] = 39,
										["targets"] = {
										},
										["appliedamt"] = 3,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 92,
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 46,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 90,
							["buff_uptime_targets"] = {
							},
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["毒蛇钉刺"] = 3,
								["瞄准射击"] = 2,
								["自动射击"] = 8,
								["多重射击"] = 3,
								["猛禽一击"] = 1,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588600232,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["nome"] = "啪啪",
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["nome"] = "朴不成",
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 63,
							["last_event"] = 1588600229,
							["spell_cast"] = {
								["剑刃乱舞"] = 1,
								["背刺"] = 6,
								["切割"] = 2,
								["刺骨"] = 2,
								["冲动"] = 1,
								["邪恶攻击"] = 2,
							},
							["classe"] = "ROGUE",
							["pets"] = {
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["剑刃乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "剑刃乱舞",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["冲动"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "冲动",
										["uptime"] = 15,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 31,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01F19A55",
							["tipo"] = 4,
						}, -- [5]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["last_event"] = 0,
							["spell_cast"] = {
								["爪击"] = 12,
							},
							["pets"] = {
							},
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-4505-10737-0100AE9C78",
							["boss_fight_component"] = true,
						}, -- [6]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "传令官基尔图诺斯",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["基尔图诺斯变形"] = 1,
								["缴械"] = 2,
								["拍翼"] = 1,
								["刺穿护甲"] = 1,
								["飞扑"] = 2,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
							["boss_fight_component"] = true,
						}, -- [7]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 20,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["像只猴的你"] = {
									["uptime"] = 20,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588600228,
							["tipo"] = 4,
							["damage_twin"] = "传令官基尔图诺斯",
							["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
							["damage_spellid"] = "缴械",
							["nome"] = "缴械",
						}, -- [8]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 4,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["幽魂无双"] = {
									["uptime"] = 2,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
								["像只猴的你"] = {
									["uptime"] = 2,
									["refreshamt"] = 0,
									["activedamt"] = 0,
									["actived"] = false,
									["appliedamt"] = 0,
								},
							},
							["last_event"] = 1588600230,
							["tipo"] = 4,
							["damage_twin"] = "传令官基尔图诺斯",
							["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
							["damage_spellid"] = "飞扑",
							["nome"] = "飞扑",
						}, -- [9]
						{
							["flag_original"] = 68168,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 9,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["boss_debuff"] = true,
							["monster"] = true,
							["debuff_uptime"] = 0,
							["spellschool"] = 1,
							["boss_fight_component"] = true,
							["debuff_uptime_targets"] = {
								["像只猴的你"] = {
									["uptime"] = 0,
									["refreshamt"] = 0,
									["appliedamt"] = 0,
									["activedamt"] = 1,
									["actived"] = true,
									["actived_at"] = 1588600220,
								},
							},
							["last_event"] = 1588600220,
							["tipo"] = 4,
							["damage_twin"] = "传令官基尔图诺斯",
							["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
							["damage_spellid"] = "刺穿护甲",
							["nome"] = "刺穿护甲",
						}, -- [10]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 115,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
					["朴不成"] = true,
					["幽魂无双"] = true,
					["像只猴的你"] = true,
					["琼琼宝贝"] = true,
				},
				["CombatStartedAt"] = 1561921.505,
				["tempo_start"] = 1588600186,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["combat_counter"] = 635,
				["totals"] = {
					42773, -- [1]
					13305, -- [2]
					{
						12, -- [1]
						[0] = 564,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "21:50:32",
				["pvp"] = true,
				["cleu_timeline"] = {
				},
				["enemy"] = "传令官基尔图诺斯",
				["TotalElapsedCombatTime"] = 42.5039999999572,
				["CombatEndedAt"] = 1561964.009,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["朴不成"] = 9924.002131,
							["像只猴的你"] = 2313.002451,
							["幽魂无双"] = 8906.005371,
							["啪啪"] = 8606.001851,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["啪啪"] = 0.002026,
							["朴不成"] = 0.004716,
							["像只猴的你"] = 20.007621,
							["幽魂无双"] = 0.001544,
							["琼琼宝贝"] = 13285.006899,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1561964.792,
				["combat_id"] = 115,
				["spells_cast_timeline"] = {
				},
				["overall_added"] = true,
				["frags"] = {
					["传令官基尔图诺斯"] = 1,
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "通灵学院",
					["encounter"] = "传令官基尔图诺斯",
					["mapid"] = 289,
					["try_number"] = 1,
					["name"] = "传令官基尔图诺斯",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					27988, -- [1]
					12450, -- [2]
					{
						12, -- [1]
						[0] = 564,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 25,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 1561918.786,
				["TimeData"] = {
				},
				["data_inicio"] = "21:49:46",
			}, -- [12]
			{
				{
					["tipo"] = 2,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.003038,
							["damage_from"] = {
								["詹迪斯·巴罗夫"] = true,
								["像只猴的你"] = true,
							},
							["targets"] = {
								["詹迪斯·巴罗夫"] = 3421,
								["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 1519,
							},
							["pets"] = {
							},
							["end_time"] = 1588600000,
							["tipo"] = 1,
							["friendlyfire_total"] = 1,
							["raid_targets"] = {
							},
							["total_without_pet"] = 4940.003038,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 4940.003038,
							["nome"] = "像只猴的你",
							["damage_taken"] = 2163.003038,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 1,
										["c_dmg"] = 945,
										["g_amt"] = 3,
										["n_max"] = 346,
										["targets"] = {
											["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 1519,
											["詹迪斯·巴罗夫"] = 2492,
											["詹迪斯·巴罗夫的幻象"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2403,
										["n_min"] = 192,
										["g_dmg"] = 663,
										["counter"] = 17,
										["r_amt"] = 0,
										["total"] = 4011,
										["c_max"] = 491,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 272,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 454,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 9,
										["a_amt"] = 0,
										["DODGE"] = 2,
									},
									["嗜血"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 410,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 764,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 764,
										["n_min"] = 354,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 764,
										["c_max"] = 0,
										["id"] = "嗜血",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["重伤"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "重伤",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["IMMUNE"] = 1,
									},
									["!Autoshot"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 113,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 113,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 113,
										["n_min"] = 113,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 113,
										["c_max"] = 0,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["复仇"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 52,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 52,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 52,
										["n_min"] = 52,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 52,
										["c_max"] = 0,
										["id"] = "复仇",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588599999,
							["friendlyfire"] = {
								["像只猴的你"] = {
									["total"] = 1,
									["spells"] = {
										["风怒图腾"] = 1,
									},
								},
							},
							["start_time"] = 1588599955,
							["serial"] = "Player-4920-01D50132",
							["classe"] = "WARRIOR",
						}, -- [1]
						{
							["flag_original"] = 2632,
							["totalabsorbed"] = 0.007995,
							["damage_from"] = {
								["火焰新星图腾 V <琼琼宝贝>"] = true,
								["啪啪"] = true,
								["朴不成"] = true,
								["像只猴的你"] = true,
								["幽魂无双"] = true,
								["鲁总 <啪啪>"] = true,
							},
							["targets"] = {
								["朴不成"] = 447,
								["像只猴的你"] = 2162,
								["琼琼宝贝"] = 42,
							},
							["pets"] = {
								"詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>", -- [1]
							},
							["classe"] = "UNKNOW",
							["nome"] = "詹迪斯·巴罗夫",
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 2162.007995,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 2651.007995,
							["end_time"] = 1588600000,
							["damage_taken"] = 30229.007995,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["召唤幻象"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "召唤幻象",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 246,
										["targets"] = {
											["像只猴的你"] = 2162,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2162,
										["n_min"] = 77,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 2162,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 77,
										["n_amt"] = 11,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["放逐术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "放逐术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588599999,
							["on_hold"] = false,
							["start_time"] = 1588599958,
							["serial"] = "Creature-0-4889-289-12207-10503-0000300FDF",
							["monster"] = true,
						}, -- [2]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.008518,
							["damage_from"] = {
							},
							["targets"] = {
								["詹迪斯·巴罗夫"] = 11039,
								["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 1031,
							},
							["delay"] = 0,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["spells"] = {
								["_ActorTable"] = {
									["瞄准射击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 2264,
										["g_amt"] = 0,
										["n_max"] = 914,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 3178,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 914,
										["n_min"] = 914,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 3178,
										["c_max"] = 2264,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 2264,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Autoshot"] = {
										["c_amt"] = 2,
										["b_amt"] = 1,
										["c_dmg"] = 1685,
										["g_amt"] = 0,
										["n_max"] = 461,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 4586,
											["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 600,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 3501,
										["n_min"] = 293,
										["g_dmg"] = 0,
										["counter"] = 11,
										["total"] = 5186,
										["c_max"] = 947,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 738,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 312,
										["n_amt"] = 9,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["多重射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 566,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 566,
											["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 431,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 997,
										["n_min"] = 431,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 997,
										["c_max"] = 0,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 98,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 784,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 784,
										["n_min"] = 98,
										["g_dmg"] = 0,
										["counter"] = 8,
										["total"] = 784,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 10145.008518,
							["nome"] = "啪啪",
							["dps_started"] = false,
							["total"] = 12070.008518,
							["damage_taken"] = 0.008518,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 254,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588600000,
							["custom"] = 0,
							["last_event"] = 1588599996,
							["friendlyfire"] = {
							},
							["start_time"] = 1588599962,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005815,
							["damage_from"] = {
								["朴不成"] = true,
								["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = true,
							},
							["targets"] = {
								["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 1695,
								["通灵魔"] = 121,
								["詹迪斯·巴罗夫"] = 6291,
							},
							["pets"] = {
							},
							["end_time"] = 1588600041,
							["tipo"] = 1,
							["friendlyfire_total"] = 2,
							["raid_targets"] = {
							},
							["total_without_pet"] = 8107.005815,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 8107.005815,
							["nome"] = "朴不成",
							["damage_taken"] = 449.005815,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["灼热武器"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 40,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 200,
											["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 40,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 240,
										["n_min"] = 40,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 240,
										["c_max"] = 0,
										["id"] = "灼热武器",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["脚踢"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 62,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 62,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 62,
										["n_min"] = 62,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 62,
										["c_max"] = 0,
										["id"] = "脚踢",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 10,
										["b_amt"] = 0,
										["c_dmg"] = 2821,
										["g_amt"] = 2,
										["n_max"] = 190,
										["targets"] = {
											["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 1181,
											["通灵魔"] = 121,
											["詹迪斯·巴罗夫"] = 4708,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2954,
										["n_min"] = 96,
										["g_dmg"] = 235,
										["counter"] = 40,
										["r_amt"] = 0,
										["total"] = 6010,
										["c_max"] = 377,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 218,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 21,
										["MISS"] = 5,
										["DODGE"] = 2,
									},
									["邪恶攻击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 260,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 1321,
											["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 474,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1795,
										["n_min"] = 151,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 1795,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "邪恶攻击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 9,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588600041,
							["friendlyfire"] = {
								["朴不成"] = {
									["total"] = 2,
									["spells"] = {
										["风怒图腾"] = 2,
									},
								},
							},
							["start_time"] = 1588599962,
							["serial"] = "Player-4920-01F19A55",
							["classe"] = "ROGUE",
						}, -- [4]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003092,
							["damage_from"] = {
							},
							["targets"] = {
								["詹迪斯·巴罗夫"] = 1925,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["tipo"] = 1,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1925.003092,
							["delay"] = 1588599988,
							["dps_started"] = false,
							["end_time"] = 1588600000,
							["nome"] = "鲁总 <啪啪>",
							["ownerName"] = "啪啪",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 1,
										["c_dmg"] = 256,
										["g_amt"] = 2,
										["n_max"] = 128,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 1649,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1197,
										["n_min"] = 61,
										["g_dmg"] = 196,
										["counter"] = 17,
										["r_amt"] = 0,
										["total"] = 1649,
										["c_max"] = 256,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 61,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["c_min"] = 256,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 11,
										["MISS"] = 2,
										["a_amt"] = 0,
									},
									["爪击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 73,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 276,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 276,
										["n_min"] = 41,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 276,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 1,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["a_amt"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.003092,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588599988,
							["on_hold"] = false,
							["start_time"] = 1588599975,
							["serial"] = "Pet-0-4504-0-4505-10737-0100AE9C78",
							["total"] = 1925.003092,
						}, -- [5]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005328,
							["damage_from"] = {
							},
							["targets"] = {
								["詹迪斯·巴罗夫"] = 9008,
								["老鼠"] = 267,
							},
							["pets"] = {
							},
							["end_time"] = 1588600000,
							["tipo"] = 1,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 9275.005328,
							["delay"] = 1588599989,
							["dps_started"] = false,
							["total"] = 9275.005328,
							["nome"] = "幽魂无双",
							["damage_taken"] = 0.005328,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["c_amt"] = 3,
										["b_amt"] = 0,
										["c_dmg"] = 3676,
										["g_amt"] = 0,
										["n_max"] = 17,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 3791,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 115,
										["n_min"] = 16,
										["g_dmg"] = 0,
										["counter"] = 10,
										["total"] = 3791,
										["c_max"] = 1288,
										["id"] = "火球术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1156,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["火焰冲击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 956,
										["g_amt"] = 0,
										["n_max"] = 578,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 1534,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 578,
										["n_min"] = 578,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 1534,
										["c_max"] = 956,
										["id"] = "火焰冲击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 956,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
									["魔爆术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 281,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 1600,
											["老鼠"] = 267,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1867,
										["n_min"] = 205,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 1867,
										["c_max"] = 0,
										["id"] = "魔爆术",
										["r_dmg"] = 205,
										["r_amt"] = 1,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 7,
										["a_dmg"] = 0,
										["spellschool"] = 64,
									},
									["点燃"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 489,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 2083,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 2083,
										["n_min"] = 231,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 2083,
										["c_max"] = 0,
										["id"] = "点燃",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["on_hold"] = false,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588599989,
							["friendlyfire"] = {
							},
							["start_time"] = 1588599977,
							["serial"] = "Player-4920-01ECB17B",
							["classe"] = "MAGE",
						}, -- [6]
						{
							["flag_original"] = 8776,
							["totalabsorbed"] = 0.008922,
							["damage_from"] = {
								["朴不成"] = true,
								["像只猴的你"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["朴不成"] = 447,
								["琼琼宝贝"] = 42,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["tipo"] = 1,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 489.008922,
							["delay"] = 0,
							["dps_started"] = false,
							["end_time"] = 1588600000,
							["nome"] = "詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>",
							["ownerName"] = "詹迪斯·巴罗夫",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 67,
										["g_amt"] = 0,
										["n_max"] = 30,
										["targets"] = {
											["朴不成"] = 447,
											["琼琼宝贝"] = 42,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 422,
										["DODGE"] = 19,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 47,
										["total"] = 489,
										["r_amt"] = 0,
										["c_max"] = 44,
										["b_dmg"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["c_min"] = 23,
										["m_crit"] = 0,
										["PARRY"] = 4,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["spellschool"] = 1,
										["n_amt"] = 18,
										["a_amt"] = 0,
										["MISS"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 4245.008922,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588599999,
							["on_hold"] = false,
							["start_time"] = 1588599983,
							["serial"] = "Creature-0-4889-289-12207-11439-0007301CAB",
							["total"] = 489.008922,
						}, -- [7]
						{
							["flag_original"] = 2600,
							["totalabsorbed"] = 0.001912,
							["damage_from"] = {
								["幽魂无双"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["last_event"] = 0,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.001912,
							["boss_fight_component"] = true,
							["dps_started"] = false,
							["total"] = 0.001912,
							["delay"] = 0,
							["friendlyfire"] = {
							},
							["nome"] = "老鼠",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 267.001912,
							["end_time"] = 1588600000,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588600000,
							["serial"] = "Creature-0-4889-289-12207-4075-0007B00FE0",
							["classe"] = "UNKNOW",
						}, -- [8]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.008111,
							["damage_from"] = {
								["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = true,
							},
							["targets"] = {
								["詹迪斯·巴罗夫"] = 470,
							},
							["delay"] = 1588599988,
							["pets"] = {
								"火焰新星图腾 V <琼琼宝贝>", -- [1]
							},
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["friendlyfire_total"] = 0,
							["classe"] = "SHAMAN",
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.008111,
							["nome"] = "琼琼宝贝",
							["dps_started"] = false,
							["total"] = 470.008111,
							["damage_taken"] = 42.008111,
							["tipo"] = 1,
							["boss_fight_component"] = true,
							["spec"] = 264,
							["grupo"] = true,
							["last_dps"] = 0,
							["end_time"] = 1588600000,
							["custom"] = 0,
							["last_event"] = 1588599988,
							["friendlyfire"] = {
							},
							["start_time"] = 1588599999,
							["serial"] = "Player-4920-01D6B7EB",
							["on_hold"] = false,
						}, -- [9]
						{
							["flag_original"] = 8466,
							["totalabsorbed"] = 0.006259,
							["damage_from"] = {
							},
							["targets"] = {
								["詹迪斯·巴罗夫"] = 470,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["tipo"] = 1,
							["classe"] = "PET",
							["raid_targets"] = {
							},
							["total_without_pet"] = 470.006259,
							["delay"] = 1588599988,
							["dps_started"] = false,
							["end_time"] = 1588600000,
							["nome"] = "火焰新星图腾 V <琼琼宝贝>",
							["ownerName"] = "琼琼宝贝",
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["火焰新星"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 470,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 470,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 470,
										["n_min"] = 470,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 470,
										["c_max"] = 0,
										["id"] = "火焰新星",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 4,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 0.006259,
							["friendlyfire"] = {
							},
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588599988,
							["on_hold"] = false,
							["start_time"] = 1588599999,
							["serial"] = "Creature-0-4889-289-12207-7845-0000301CB1",
							["total"] = 470.006259,
						}, -- [10]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.004006,
							["last_hps"] = 0,
							["targets_overheal"] = {
								["像只猴的你"] = 20,
							},
							["targets"] = {
								["像只猴的你"] = 100,
							},
							["delay"] = 1588599966,
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["healing_from"] = {
								["像只猴的你"] = true,
								["琼琼宝贝"] = true,
							},
							["healing_taken"] = 3664.004006,
							["totalover"] = 20.004006,
							["total_without_pet"] = 100.004006,
							["totalover_without_pet"] = 0.004006,
							["totaldenied"] = 0.004006,
							["classe"] = "WARRIOR",
							["end_time"] = 1588600000,
							["targets_absorbs"] = {
							},
							["heal_enemy_amt"] = 0,
							["boss_fight_component"] = true,
							["spells"] = {
								["_ActorTable"] = {
									["嗜血"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["像只猴的你"] = 20,
										},
										["n_max"] = 20,
										["targets"] = {
											["像只猴的你"] = 100,
										},
										["n_min"] = 0,
										["counter"] = 6,
										["overheal"] = 20,
										["total"] = 100,
										["c_max"] = 0,
										["id"] = "嗜血",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 6,
										["n_curado"] = 100,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["total"] = 100.004006,
							["heal_enemy"] = {
							},
							["tipo"] = 2,
							["custom"] = 0,
							["last_event"] = 1588599997,
							["on_hold"] = false,
							["start_time"] = 1588599984,
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [1]
						{
							["flag_original"] = 1298,
							["targets_overheal"] = {
								["像只猴的你"] = 125,
							},
							["pets"] = {
							},
							["iniciar_hps"] = false,
							["heal_enemy_amt"] = 0,
							["totalover"] = 125.008291,
							["total_without_pet"] = 4716.008291,
							["total"] = 4716.008291,
							["targets_absorbs"] = {
							},
							["heal_enemy"] = {
							},
							["on_hold"] = false,
							["serial"] = "Player-4920-01D6B7EB",
							["totalabsorb"] = 0.008291,
							["last_hps"] = 0,
							["targets"] = {
								["朴不成"] = 1152,
								["像只猴的你"] = 3689,
							},
							["totalover_without_pet"] = 0.008291,
							["healing_taken"] = 0.008291,
							["end_time"] = 1588600000,
							["spec"] = 264,
							["healing_from"] = {
							},
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["治疗链"] = {
										["c_amt"] = 0,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
											["像只猴的你"] = 125,
										},
										["n_max"] = 880,
										["targets"] = {
											["朴不成"] = 1152,
											["像只猴的你"] = 1694,
										},
										["n_min"] = 562,
										["counter"] = 4,
										["overheal"] = 125,
										["total"] = 2846,
										["c_max"] = 0,
										["id"] = "治疗链",
										["targets_absorbs"] = {
										},
										["c_curado"] = 0,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 4,
										["n_curado"] = 2846,
										["c_min"] = 0,
										["absorbed"] = 0,
									},
									["治疗波"] = {
										["c_amt"] = 1,
										["totalabsorb"] = 0,
										["targets_overheal"] = {
										},
										["n_max"] = 0,
										["targets"] = {
											["像只猴的你"] = 1870,
										},
										["n_min"] = 0,
										["counter"] = 1,
										["overheal"] = 0,
										["total"] = 1870,
										["c_max"] = 1870,
										["id"] = "治疗波",
										["targets_absorbs"] = {
										},
										["c_curado"] = 1870,
										["m_crit"] = 0,
										["totaldenied"] = 0,
										["m_amt"] = 0,
										["m_healed"] = 0,
										["n_amt"] = 0,
										["n_curado"] = 0,
										["c_min"] = 1870,
										["absorbed"] = 0,
									},
								},
								["tipo"] = 3,
							},
							["grupo"] = true,
							["tipo"] = 2,
							["totaldenied"] = 0.008291,
							["custom"] = 0,
							["last_event"] = 1588599994,
							["classe"] = "SHAMAN",
							["start_time"] = 1588599988,
							["delay"] = 1588599973,
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["flag_original"] = 1298,
							["totalabsorb"] = 0.004235,
							["last_hps"] = 0,
							["healing_from"] = {
								["琼琼宝贝"] = true,
							},
							["targets"] = {
							},
							["delay"] = 0,
							["pets"] = {
							},
							["totalover_without_pet"] = 0.004235,
							["targets_overheal"] = {
							},
							["classe"] = "ROGUE",
							["totalover"] = 0.004235,
							["total_without_pet"] = 0.004235,
							["iniciar_hps"] = false,
							["totaldenied"] = 0.004235,
							["heal_enemy_amt"] = 0,
							["total"] = 0.004235,
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 3,
							},
							["healing_taken"] = 1152.004235,
							["boss_fight_component"] = true,
							["targets_absorbs"] = {
							},
							["grupo"] = true,
							["end_time"] = 1588600000,
							["heal_enemy"] = {
							},
							["last_event"] = 0,
							["custom"] = 0,
							["tipo"] = 2,
							["on_hold"] = false,
							["start_time"] = 1588600000,
							["serial"] = "Player-4920-01F19A55",
							["nome"] = "朴不成",
						}, -- [3]
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["received"] = 482.00756,
							["resource"] = 0.00756,
							["targets"] = {
								["琼琼宝贝"] = 119,
							},
							["pets"] = {
								"法力之泉图腾 IV <琼琼宝贝>", -- [1]
							},
							["powertype"] = 0,
							["classe"] = "SHAMAN",
							["passiveover"] = 0.00756,
							["total"] = 1204.00756,
							["nome"] = "琼琼宝贝",
							["spells"] = {
								["_ActorTable"] = {
									["法力澎湃"] = {
										["total"] = 119,
										["id"] = "法力澎湃",
										["totalover"] = 0,
										["targets"] = {
											["琼琼宝贝"] = 119,
										},
										["counter"] = 1,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.00756,
							["flag_original"] = 1298,
							["last_event"] = 1588599974,
							["tipo"] = 3,
							["spec"] = 264,
							["alternatepower"] = 0.00756,
							["serial"] = "Player-4920-01D6B7EB",
							["boss_fight_component"] = true,
						}, -- [1]
						{
							["received"] = 0.006268,
							["resource"] = 0.006268,
							["targets"] = {
								["幽魂无双"] = 363,
								["啪啪"] = 359,
								["琼琼宝贝"] = 363,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "PET",
							["passiveover"] = 0.006268,
							["total"] = 1085.006268,
							["ownerName"] = "琼琼宝贝",
							["nome"] = "法力之泉图腾 IV <琼琼宝贝>",
							["spells"] = {
								["_ActorTable"] = {
									["法力之泉"] = {
										["total"] = 1085,
										["id"] = "法力之泉",
										["totalover"] = 0,
										["targets"] = {
											["幽魂无双"] = 363,
											["啪啪"] = 359,
											["琼琼宝贝"] = 363,
										},
										["counter"] = 87,
									},
								},
								["tipo"] = 7,
							},
							["totalover"] = 0.006268,
							["flag_original"] = 8466,
							["last_event"] = 1588600013,
							["tipo"] = 3,
							["alternatepower"] = 0.006268,
							["serial"] = "Creature-0-4889-289-12207-7416-0000301C93",
							["boss_fight_component"] = true,
						}, -- [2]
						{
							["received"] = 359.003183,
							["resource"] = 0.003183,
							["targets"] = {
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "HUNTER",
							["passiveover"] = 430.003183,
							["total"] = 0.003183,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.003183,
							["flag_original"] = 1297,
							["last_event"] = 0,
							["tipo"] = 3,
							["spec"] = 254,
							["alternatepower"] = 0.003183,
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [3]
						{
							["received"] = 675.003003,
							["resource"] = 0.003003,
							["targets"] = {
								["幽魂无双"] = 312,
							},
							["pets"] = {
							},
							["powertype"] = 0,
							["classe"] = "MAGE",
							["passiveover"] = 0.003003,
							["total"] = 312.003003,
							["nome"] = "幽魂无双",
							["spells"] = {
								["_ActorTable"] = {
									["元素大师"] = {
										["total"] = 312,
										["id"] = "元素大师",
										["totalover"] = 0,
										["targets"] = {
											["幽魂无双"] = 312,
										},
										["counter"] = 3,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.003003,
							["flag_original"] = 1298,
							["last_event"] = 1588599977,
							["tipo"] = 3,
							["alternatepower"] = 0.003003,
							["serial"] = "Player-4920-01ECB17B",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["received"] = 28.006552,
							["resource"] = 0.006552,
							["targets"] = {
								["像只猴的你"] = 28,
							},
							["pets"] = {
							},
							["powertype"] = 1,
							["classe"] = "WARRIOR",
							["passiveover"] = 0.006552,
							["total"] = 28.006552,
							["nome"] = "像只猴的你",
							["spells"] = {
								["_ActorTable"] = {
									["怒不可遏"] = {
										["total"] = 8,
										["id"] = "怒不可遏",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 8,
										},
										["counter"] = 8,
									},
									["血性狂暴"] = {
										["total"] = 20,
										["id"] = "血性狂暴",
										["totalover"] = 0,
										["targets"] = {
											["像只猴的你"] = 20,
										},
										["counter"] = 11,
									},
								},
								["tipo"] = 7,
							},
							["grupo"] = true,
							["totalover"] = 0.006552,
							["flag_original"] = 1298,
							["last_event"] = 1588600000,
							["tipo"] = 3,
							["alternatepower"] = 0.006552,
							["serial"] = "Player-4920-01D50132",
							["boss_fight_component"] = true,
						}, -- [5]
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 113,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["破甲攻击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 4,
										["id"] = "破甲攻击",
										["uptime"] = 38,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["嘲讽"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "嘲讽",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 93,
							["classe"] = "WARRIOR",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["战斗怒吼"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 1,
										["id"] = "战斗怒吼",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["嗜血"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "嗜血",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["神圣力量"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "神圣力量",
										["uptime"] = 5,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["盾牌格挡"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "盾牌格挡",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["乱舞"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "乱舞",
										["uptime"] = 16,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["血性狂暴"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "血性狂暴",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 41,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["战斗怒吼"] = 1,
								["嗜血"] = 2,
								["嘲讽"] = 1,
								["破甲攻击"] = 6,
								["盾牌格挡"] = 1,
								["复仇"] = 1,
								["血性狂暴"] = 1,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588600000,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01D50132",
							["nome"] = "像只猴的你",
						}, -- [1]
						{
							["flag_original"] = 1047,
							["nome"] = "琼琼宝贝",
							["buff_uptime_targets"] = {
							},
							["spec"] = 264,
							["grupo"] = true,
							["boss_fight_component"] = true,
							["buff_uptime"] = 90,
							["pets"] = {
							},
							["last_event"] = 1588600000,
							["classe"] = "SHAMAN",
							["spell_cast"] = {
								["灼热图腾"] = 1,
								["治疗波"] = 1,
								["石肤图腾"] = 1,
								["治疗链"] = 2,
								["火焰新星图腾"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["石肤术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "石肤术",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["法力之泉"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "法力之泉",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D6B7EB",
							["tipo"] = 4,
						}, -- [2]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "火球术",
										["uptime"] = 17,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["点燃"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 2,
										["id"] = "点燃",
										["uptime"] = 11,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["冲击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "冲击",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 148,
							["classe"] = "MAGE",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["银色黎明委任徽章"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "银色黎明委任徽章",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["喝水"] = {
										["activedamt"] = 1,
										["id"] = "喝水",
										["targets"] = {
										},
										["actived_at"] = 1588599955,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = true,
										["appliedamt"] = 1,
									},
									["魔甲术"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "魔甲术",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["奥术智慧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "奥术智慧",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["燃烧"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "燃烧",
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 30,
							["debuff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["火球术"] = 3,
								["魔爆术"] = 9,
								["火焰冲击"] = 2,
							},
							["tipo"] = 4,
							["buff_uptime_targets"] = {
							},
							["last_event"] = 1588600000,
							["boss_fight_component"] = true,
							["pets"] = {
							},
							["serial"] = "Player-4920-01ECB17B",
							["nome"] = "幽魂无双",
						}, -- [3]
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["猎人印记"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "猎人印记",
										["uptime"] = 32,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["毒蛇钉刺"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 1,
										["id"] = "毒蛇钉刺",
										["uptime"] = 26,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime"] = 90,
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 45,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 58,
							["buff_uptime_targets"] = {
							},
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["冰霜陷阱"] = 1,
								["毒蛇钉刺"] = 3,
								["自动射击"] = 11,
								["猎人印记"] = 1,
								["瞄准射击"] = 2,
								["多重射击"] = 2,
							},
							["debuff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588600000,
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["nome"] = "啪啪",
							["serial"] = "Player-4920-01D0E17B",
							["boss_fight_component"] = true,
						}, -- [4]
						{
							["flag_original"] = 1298,
							["buff_uptime"] = 33,
							["classe"] = "ROGUE",
							["interrupt_spells"] = {
								["_ActorTable"] = {
									["脚踢"] = {
										["id"] = "脚踢",
										["counter"] = 1,
										["targets"] = {
											["詹迪斯·巴罗夫"] = 1,
										},
										["interrompeu_oque"] = {
											["血之诅咒"] = 1,
										},
									},
								},
								["tipo"] = 9,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["风怒图腾"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 2,
										["refreshamt"] = 0,
										["id"] = "风怒图腾",
										["uptime"] = 1,
										["targets"] = {
										},
										["appliedamt"] = 2,
									},
									["切割"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "切割",
										["uptime"] = 18,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["闪避"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "闪避",
										["uptime"] = 14,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["interrompeu_oque"] = {
								["血之诅咒"] = 1,
							},
							["nome"] = "朴不成",
							["interrupt_targets"] = {
								["詹迪斯·巴罗夫"] = 1,
							},
							["grupo"] = true,
							["spell_cast"] = {
								["脚踢"] = 1,
								["邪恶攻击"] = 10,
								["切割"] = 1,
								["闪避"] = 1,
							},
							["buff_uptime_targets"] = {
							},
							["tipo"] = 4,
							["last_event"] = 1588600000,
							["pets"] = {
							},
							["interrupt"] = 1.00323,
							["serial"] = "Player-4920-01F19A55",
							["boss_fight_component"] = true,
						}, -- [5]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["last_event"] = 0,
							["spell_cast"] = {
								["突进"] = 1,
								["低吼"] = 4,
								["爪击"] = 6,
							},
							["pets"] = {
							},
							["classe"] = "PET",
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-4505-10737-0100AE9C78",
							["boss_fight_component"] = true,
						}, -- [6]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "詹迪斯·巴罗夫",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["召唤幻象"] = 1,
								["放逐术"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4889-289-12207-10503-0000300FDF",
							["boss_fight_component"] = true,
						}, -- [7]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 113,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
					["朴不成"] = true,
					["幽魂无双"] = true,
					["像只猴的你"] = true,
					["琼琼宝贝"] = true,
				},
				["CombatStartedAt"] = 1561693.92,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["totals"] = {
					37512.994604, -- [1]
					4816, -- [2]
					{
						28, -- [1]
						[0] = 1516,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["player_last_events"] = {
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "party",
				["hasSaved"] = true,
				["data_fim"] = "21:46:41",
				["cleu_timeline"] = {
				},
				["enemy"] = "詹迪斯·巴罗夫",
				["TotalElapsedCombatTime"] = 38.9660000000149,
				["CombatEndedAt"] = 1561732.886,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "21:45:56",
				["end_time"] = 1561733.069,
				["combat_id"] = 113,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 12070.008518,
							["朴不成"] = 7986.005815,
							["幽魂无双"] = 9275.005328,
							["像只猴的你"] = 4940.003038,
							["琼琼宝贝"] = 470.008111,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
							["朴不成"] = 0.004235,
							["像只猴的你"] = 100.004006,
							["琼琼宝贝"] = 4716.008291,
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["tempo_start"] = 1588599955,
				["contra"] = "詹迪斯·巴罗夫",
				["frags"] = {
					["老鼠"] = 1,
					["詹迪斯·巴罗夫"] = 1,
				},
				["is_boss"] = {
					["diff_string"] = "normal",
					["index"] = 1,
					["zone"] = "通灵学院",
					["encounter"] = "詹迪斯·巴罗夫",
					["mapid"] = 289,
					["try_number"] = 1,
					["name"] = "詹迪斯·巴罗夫",
					["diff"] = 16,
					["ej_instance_id"] = 0,
					["id"] = 0,
				},
				["combat_counter"] = 633,
				["CombatSkillCache"] = {
				},
				["totals_grupo"] = {
					32470, -- [1]
					4816, -- [2]
					{
						28, -- [1]
						[0] = 431,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 1,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["start_time"] = 1561688.065,
				["TimeData"] = {
				},
				["spells_cast_timeline"] = {
				},
			}, -- [13]
			{
				{
					["tipo"] = 2,
					["combatId"] = 93,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.006021,
							["damage_from"] = {
							},
							["targets"] = {
								["山脊巡行者"] = 1677,
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["damage_taken"] = 0.006021,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 581.006021,
							["classe"] = "HUNTER",
							["dps_started"] = false,
							["total"] = 1677.006021,
							["delay"] = 0,
							["end_time"] = 1588596162,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
									["猛禽一击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 581,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["山脊巡行者"] = 581,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 581,
										["c_max"] = 581,
										["id"] = "猛禽一击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 581,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["last_event"] = 1588596162,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588596149,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.008127,
							["damage_from"] = {
								["山脊巡行者"] = true,
							},
							["targets"] = {
								["山脊巡行者"] = 1096,
							},
							["pets"] = {
							},
							["damage_taken"] = 102.008127,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1096.008127,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 1096.008127,
							["delay"] = 0,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 141,
										["g_amt"] = 0,
										["n_max"] = 82,
										["targets"] = {
											["山脊巡行者"] = 762,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 621,
										["n_min"] = 71,
										["g_dmg"] = 0,
										["counter"] = 9,
										["total"] = 762,
										["c_max"] = 141,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 141,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 8,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["爪击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 104,
										["g_amt"] = 0,
										["n_max"] = 62,
										["targets"] = {
											["山脊巡行者"] = 334,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 230,
										["n_min"] = 53,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 334,
										["c_max"] = 104,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 104,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588596162,
							["last_event"] = 1588596160,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588596149,
							["serial"] = "Pet-0-4504-0-4491-10737-0300AE9C78",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.003103,
							["damage_from"] = {
								["鲁总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["鲁总 <啪啪>"] = 102,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 102.003103,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 102.003103,
							["end_time"] = 1588596162,
							["damage_taken"] = 1677.003103,
							["nome"] = "山脊巡行者",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 2,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 20,
										["targets"] = {
											["鲁总"] = 0,
											["鲁总 <啪啪>"] = 102,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 102,
										["n_min"] = 14,
										["g_dmg"] = 0,
										["counter"] = 9,
										["r_amt"] = 0,
										["total"] = 102,
										["c_max"] = 0,
										["spellschool"] = 1,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["b_dmg"] = 29,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["PARRY"] = 2,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_dmg"] = 0,
										["n_amt"] = 6,
										["a_amt"] = 0,
										["MISS"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588596160,
							["on_hold"] = false,
							["start_time"] = 1588596153,
							["serial"] = "Creature-0-4504-0-4491-2731-00002FE6DF",
							["fight_component"] = true,
						}, -- [3]
						{
							["flag_original"] = 1298,
							["totalabsorbed"] = 0.005883,
							["damage_from"] = {
								["复活的保卫者"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["damage_taken"] = 600.005883,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005883,
							["classe"] = "ROGUE",
							["dps_started"] = false,
							["total"] = 0.005883,
							["delay"] = 0,
							["end_time"] = 1588598578,
							["nome"] = "朴不成",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["last_event"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588598578,
							["serial"] = "Player-4920-01F19A55",
							["on_hold"] = false,
						}, -- [4]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 93,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 93,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 93,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "啪啪",
							["grupo"] = true,
							["buff_uptime_targets"] = {
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["last_event"] = 1588596162,
							["buff_uptime"] = 26,
							["tipo"] = 4,
							["spell_cast"] = {
								["猛禽一击"] = 1,
							},
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 13,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D0E17B",
							["classe"] = "HUNTER",
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 2,
								["爪击"] = 5,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-4491-10737-0300AE9C78",
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 93,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["tempo_start"] = 1588596149,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					1778.921648, -- [1]
					0, -- [2]
					{
						-0.00892499999999963, -- [1]
						[0] = -0.0143719999999998,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					581, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "20:42:43",
				["cleu_timeline"] = {
				},
				["enemy"] = "山脊巡行者",
				["TotalElapsedCombatTime"] = 1557895.431,
				["CombatEndedAt"] = 1557895.431,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 1677.006021,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1557895.431,
				["combat_id"] = 93,
				["data_inicio"] = "20:42:30",
				["overall_added"] = true,
				["frags"] = {
					["山脊巡行者"] = 1,
				},
				["TimeData"] = {
				},
				["combat_counter"] = 611,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
					["朴不成"] = {
						{
							true, -- [1]
							"暗影震击", -- [2]
							600, -- [3]
							1588598576.732, -- [4]
							3243, -- [5]
							"复活的保卫者", -- [6]
							nil, -- [7]
							32, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
						}, -- [2]
						{
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 2,
					},
				},
				["start_time"] = 1557882.439,
				["contra"] = "山脊巡行者",
				["spells_cast_timeline"] = {
				},
			}, -- [14]
			{
				{
					["tipo"] = 2,
					["combatId"] = 92,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004728,
							["damage_from"] = {
								["环境伤害 (高处坠落)"] = true,
								["山脊巡行者"] = true,
							},
							["targets"] = {
								["火烟食人魔法师"] = 1568,
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["end_time"] = 1588595541,
							["tipo"] = 1,
							["classe"] = "HUNTER",
							["raid_targets"] = {
							},
							["total_without_pet"] = 1021.004728,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 1568.004728,
							["spells"] = {
								["_ActorTable"] = {
									["猛禽一击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 555,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["火烟食人魔法师"] = 555,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 555,
										["c_max"] = 555,
										["id"] = "猛禽一击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 555,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 2,
										["n_max"] = 161,
										["targets"] = {
											["火烟食人魔法师"] = 462,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 448,
										["n_min"] = 132,
										["g_dmg"] = 14,
										["counter"] = 6,
										["total"] = 462,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 3,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
									["摔绊"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["火烟食人魔法师"] = 4,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = "摔绊",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 667.004728,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["friendlyfire_total"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["last_event"] = 1588595540,
							["friendlyfire"] = {
							},
							["start_time"] = 1588595534,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.005038,
							["damage_from"] = {
								["火烟食人魔法师"] = true,
							},
							["targets"] = {
								["火烟食人魔法师"] = 547,
							},
							["pets"] = {
							},
							["damage_taken"] = 29.005038,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 547.005038,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 547.005038,
							["delay"] = 0,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 84,
										["targets"] = {
											["火烟食人魔法师"] = 318,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 318,
										["n_min"] = 77,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 318,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["爪击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 63,
										["targets"] = {
											["火烟食人魔法师"] = 229,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 229,
										["n_min"] = 54,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 229,
										["c_max"] = 0,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588595541,
							["last_event"] = 1588595539,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588595534,
							["serial"] = "Pet-0-4504-0-4491-10737-0300AE9C78",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.002284,
							["damage_from"] = {
								["鲁总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["鲁总 <啪啪>"] = 29,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 29.002284,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 29.002284,
							["end_time"] = 1588595541,
							["damage_taken"] = 1568.002284,
							["nome"] = "火烟食人魔法师",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 29,
										["targets"] = {
											["鲁总 <啪啪>"] = 29,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 29,
										["n_min"] = 29,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 29,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588595538,
							["on_hold"] = false,
							["start_time"] = 1588595538,
							["serial"] = "Creature-0-4504-0-4491-2720-00003000A4",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 92,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 92,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 92,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["强化摔绊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "强化摔绊",
										["uptime"] = 2,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["摔绊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "摔绊",
										["uptime"] = 3,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 5,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["猛禽一击"] = 1,
								["摔绊"] = 1,
							},
							["tipo"] = 4,
							["last_event"] = 1588595541,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0E17B",
							["buff_uptime"] = 14,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 1,
								["爪击"] = 4,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-4491-10737-0300AE9C78",
							["classe"] = "PET",
						}, -- [2]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 92,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1557882.039,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					1596.934529, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					1021, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "20:32:22",
				["cleu_timeline"] = {
				},
				["enemy"] = "火烟食人魔法师",
				["TotalElapsedCombatTime"] = 1557274.04,
				["CombatEndedAt"] = 1557274.04,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 1568.004728,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1557274.04,
				["combat_id"] = 92,
				["data_inicio"] = "20:32:15",
				["tempo_start"] = 1588595534,
				["spells_cast_timeline"] = {
				},
				["contra"] = "火烟食人魔法师",
				["combat_counter"] = 610,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
					["啪啪"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							527, -- [3]
							1588595625.139, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							89, -- [3]
							1588595832.01, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							"Falling", -- [2]
							32, -- [3]
							1588596114.361, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
							true, -- [1]
							"!Melee", -- [2]
							19, -- [3]
							1588596148.872, -- [4]
							4522, -- [5]
							"山脊巡行者", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 5,
					},
				},
				["start_time"] = 1557267.183,
				["TimeData"] = {
				},
				["frags"] = {
					["火烟食人魔法师"] = 1,
				},
			}, -- [15]
			{
				{
					["tipo"] = 2,
					["combatId"] = 91,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.00694,
							["damage_from"] = {
							},
							["targets"] = {
								["啪啪"] = 36,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["total"] = 36.00694,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 36.00694,
							["delay"] = 1588593254,
							["fight_component"] = true,
							["end_time"] = 1588595534,
							["monster"] = true,
							["damage_taken"] = 0.00694,
							["nome"] = "山脊巡行者",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 19,
										["targets"] = {
											["啪啪"] = 36,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 36,
										["n_min"] = 17,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 36,
										["c_max"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588593254,
							["on_hold"] = false,
							["start_time"] = 1588595505,
							["serial"] = "Creature-0-4504-0-4491-2731-00002F2DA1",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1297,
							["totalabsorbed"] = 0.005955,
							["damage_from"] = {
								["山脊巡行者"] = true,
								["火烟食人魔法师"] = true,
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
							},
							["pets"] = {
							},
							["damage_taken"] = 80.005955,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 0.005955,
							["classe"] = "HUNTER",
							["dps_started"] = false,
							["total"] = 0.005955,
							["delay"] = 0,
							["end_time"] = 1588593227,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["last_event"] = 0,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588593227,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [2]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 91,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 91,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 91,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["nome"] = "啪啪",
							["grupo"] = true,
							["pets"] = {
							},
							["last_event"] = 1588593227,
							["classe"] = "HUNTER",
							["tipo"] = 4,
							["buff_uptime"] = 30,
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["绿色骸骨战马"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "绿色骸骨战马",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["serial"] = "Player-4920-01D0E17B",
							["buff_uptime_targets"] = {
							},
						}, -- [1]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 91,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1557266.767,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					35.9003929999996, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = -0.00882100000001174,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					0, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = false,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "19:53:47",
				["cleu_timeline"] = {
				},
				["enemy"] = "山脊巡行者",
				["TotalElapsedCombatTime"] = 10.9440000001341,
				["CombatEndedAt"] = 1554998.654,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 0.005955,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1554959.724,
				["combat_id"] = 91,
				["data_inicio"] = "19:53:37",
				["tempo_start"] = 1588593217,
				["spells_cast_timeline"] = {
				},
				["contra"] = "山脊巡行者",
				["combat_counter"] = 609,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
					["啪啪"] = {
						{
							true, -- [1]
							"!Melee", -- [2]
							19, -- [3]
							1588593254.543, -- [4]
							4522, -- [5]
							"山脊巡行者", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							16, -- [3]
							1588595529.746, -- [4]
							4522, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							"!Melee", -- [2]
							28, -- [3]
							1588595533.6, -- [4]
							4522, -- [5]
							"火烟食人魔法师", -- [6]
							nil, -- [7]
							1, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 4,
					},
				},
				["start_time"] = 1554949.546,
				["TimeData"] = {
				},
				["frags"] = {
				},
			}, -- [16]
			{
				{
					["tipo"] = 2,
					["combatId"] = 90,
					["_ActorTable"] = {
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.004705,
							["damage_from"] = {
							},
							["targets"] = {
								["滚烫的雏龙"] = 1704,
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["damage_taken"] = 0.004705,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 899.004705,
							["classe"] = "HUNTER",
							["dps_started"] = false,
							["total"] = 1704.004705,
							["delay"] = 0,
							["end_time"] = 1588593126,
							["nome"] = "啪啪",
							["spells"] = {
								["_ActorTable"] = {
									["猛禽一击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 255,
										["targets"] = {
											["滚烫的雏龙"] = 484,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 484,
										["n_min"] = 229,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 484,
										["c_max"] = 0,
										["id"] = "猛禽一击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 254,
										["g_amt"] = 1,
										["n_max"] = 152,
										["targets"] = {
											["滚烫的雏龙"] = 411,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 152,
										["n_min"] = 152,
										["g_dmg"] = 5,
										["counter"] = 7,
										["total"] = 411,
										["c_max"] = 254,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 254,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["MISS"] = 4,
									},
									["摔绊"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 4,
										["targets"] = {
											["滚烫的雏龙"] = 4,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 4,
										["n_min"] = 4,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 4,
										["c_max"] = 0,
										["id"] = "摔绊",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["grupo"] = true,
							["last_event"] = 1588593125,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1588593116,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.007724,
							["damage_from"] = {
								["滚烫的雏龙"] = true,
							},
							["targets"] = {
								["滚烫的雏龙"] = 805,
							},
							["pets"] = {
							},
							["damage_taken"] = 169.007724,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 805.007724,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 805.007724,
							["delay"] = 0,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 149,
										["g_amt"] = 0,
										["n_max"] = 79,
										["targets"] = {
											["滚烫的雏龙"] = 590,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 441,
										["n_min"] = 66,
										["g_dmg"] = 0,
										["counter"] = 7,
										["total"] = 590,
										["c_max"] = 149,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 149,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 6,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["爪击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 58,
										["targets"] = {
											["滚烫的雏龙"] = 215,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 215,
										["n_min"] = 48,
										["g_dmg"] = 0,
										["counter"] = 4,
										["total"] = 215,
										["c_max"] = 0,
										["id"] = "爪击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 4,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1588593126,
							["last_event"] = 1588593125,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1588593116,
							["serial"] = "Pet-0-4504-0-4491-10737-0300AE9C78",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.008271,
							["damage_from"] = {
								["鲁总 <啪啪>"] = true,
								["啪啪"] = true,
							},
							["targets"] = {
								["鲁总 <啪啪>"] = 169,
							},
							["pets"] = {
							},
							["friendlyfire_total"] = 0,
							["dps_started"] = false,
							["classe"] = "UNKNOW",
							["raid_targets"] = {
							},
							["total_without_pet"] = 169.008271,
							["delay"] = 0,
							["monster"] = true,
							["total"] = 169.008271,
							["end_time"] = 1588593126,
							["damage_taken"] = 1704.008271,
							["nome"] = "滚烫的雏龙",
							["spells"] = {
								["_ActorTable"] = {
									["火球术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 169,
										["targets"] = {
											["鲁总"] = 0,
											["鲁总 <啪啪>"] = 169,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 169,
										["n_min"] = 169,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 169,
										["c_max"] = 0,
										["id"] = "火球术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["n_amt"] = 1,
										["c_min"] = 0,
										["successful_casted"] = 2,
										["b_dmg"] = 0,
										["RESIST"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["tipo"] = 1,
							["last_dps"] = 0,
							["friendlyfire"] = {
							},
							["custom"] = 0,
							["last_event"] = 1588593124,
							["on_hold"] = false,
							["start_time"] = 1588593119,
							["serial"] = "Creature-0-4504-0-4491-2725-00002FFB6B",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 90,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 90,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 90,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["摔绊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "摔绊",
										["uptime"] = 7,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"鲁总 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["雄鹰守护"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "雄鹰守护",
										["uptime"] = 10,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 7,
							["buff_uptime_targets"] = {
							},
							["grupo"] = true,
							["spell_cast"] = {
								["猛禽一击"] = 2,
								["摔绊"] = 1,
							},
							["nome"] = "啪啪",
							["tipo"] = 4,
							["debuff_uptime_targets"] = {
							},
							["buff_uptime"] = 20,
							["serial"] = "Player-4920-01D0E17B",
							["last_event"] = 1588593126,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "鲁总 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 1,
								["爪击"] = 5,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4504-0-4491-10737-0300AE9C78",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "滚烫的雏龙",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["火球术"] = 2,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4504-0-4491-2725-00002FFB6B",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 90,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["CombatStartedAt"] = 1554948.647,
				["overall_added"] = true,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					1872.996393, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					899, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "19:52:06",
				["cleu_timeline"] = {
				},
				["enemy"] = "滚烫的雏龙",
				["TotalElapsedCombatTime"] = 1554858.689,
				["CombatEndedAt"] = 1554858.689,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 1704.004705,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["end_time"] = 1554858.689,
				["combat_id"] = 90,
				["data_inicio"] = "19:51:56",
				["tempo_start"] = 1588593116,
				["spells_cast_timeline"] = {
				},
				["contra"] = "滚烫的雏龙",
				["combat_counter"] = 608,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
				},
				["start_time"] = 1554848.597,
				["TimeData"] = {
				},
				["frags"] = {
					["滚烫的雏龙"] = 1,
				},
			}, -- [17]
		},
	},
	["last_version"] = "v1.13.3.199",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["nextreset"] = 1590065236,
		["last_version"] = 11,
		["啪啪"] = {
			"啪啪", -- [1]
			"Interface\\EncounterJournal\\UI-EJ-BOSS-Vazruden", -- [2]
			{
				0, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			}, -- [3]
			"Interface\\PetBattles\\Weather-ArcaneStorm", -- [4]
			{
				0.129609375, -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
			}, -- [5]
			{
				1, -- [1]
				1, -- [2]
				1, -- [3]
			}, -- [6]
			3, -- [7]
		},
	},
	["last_instance_id"] = 229,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 1588652776,
	["active_profile"] = "龙哥-龙牙",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["updatespeed"] = 0.2,
			["showamount"] = false,
			["animate"] = false,
			["useplayercolor"] = false,
			["useclasscolors"] = false,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
			},
			["enabled"] = true,
		},
	},
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["last_day"] = "07",
	["cached_talents"] = {
		["Player-4920-01D0E17B"] = {
			{
				136076, -- [1]
				5, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [1]
			{
				136080, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [2]
			{
				132150, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [3]
			{
				132159, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [4]
			{
				134355, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				3, -- [7]
			}, -- [5]
			{
				132163, -- [1]
				0, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [6]
			{
				132242, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [7]
			{
				132120, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				1, -- [7]
			}, -- [8]
			{
				132091, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [9]
			{
				132179, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [10]
			{
				134297, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [11]
			{
				132121, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [12]
			{
				132111, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				1, -- [7]
			}, -- [13]
			{
				136006, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [14]
			{
				134296, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [15]
			{
				132127, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				1, -- [7]
			}, -- [16]
			{
				135860, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [17]
			{
				135865, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [18]
			{
				132212, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [19]
			{
				132312, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [20]
			{
				135130, -- [1]
				1, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [21]
			{
				132218, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [22]
			{
				132327, -- [1]
				3, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [23]
			{
				132204, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [24]
			{
				132271, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [25]
			{
				132153, -- [1]
				1, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [26]
			{
				132330, -- [1]
				3, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [27]
			{
				132169, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [28]
			{
				135615, -- [1]
				5, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [29]
			{
				132329, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [30]
			{
				134154, -- [1]
				3, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [31]
			{
				135942, -- [1]
				3, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [32]
			{
				132269, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [33]
			{
				136100, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [34]
			{
				132277, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [35]
			{
				132309, -- [1]
				2, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [36]
			{
				136106, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [37]
			{
				136223, -- [1]
				4, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [38]
			{
				132369, -- [1]
				1, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [39]
			{
				132149, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [40]
			{
				132219, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [41]
			{
				132293, -- [1]
				0, -- [2]
				4, -- [3]
				4, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [42]
			{
				135881, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [43]
			{
				132336, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [44]
			{
				136047, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135125, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [46]
		},
	},
	["last_encounter"] = "哈卡",
	["last_realversion"] = 142,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["combat_id"] = 163,
	["savedStyles"] = {
	},
	["combat_counter"] = 691,
	["force_font_outline"] = "",
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.081545,
					["damage_from"] = {
						["多彩雏龙"] = true,
						["狂爪火鳞龙人"] = true,
						["大酋长雷德·黑手 <盖斯>"] = true,
						["黑手驭龙者"] = true,
						["黑手精英"] = true,
						["狂爪龙人"] = true,
						["多彩龙人"] = true,
						["盖斯"] = true,
					},
					["targets"] = {
						["狂爪龙人"] = 4157,
						["大酋长雷德·黑手 <盖斯>"] = 4704,
						["狂爪火鳞龙人"] = 2404,
						["黑手精英"] = 1015,
						["多彩龙人"] = 14544,
						["盖斯"] = 2871,
					},
					["pets"] = {
					},
					["damage_taken"] = 34011.081545,
					["tipo"] = 1,
					["classe"] = "WARRIOR",
					["raid_targets"] = {
					},
					["total_without_pet"] = 29695.081545,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 29695.081545,
					["nome"] = "无常十号",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 20,
								["b_amt"] = 5,
								["c_dmg"] = 3319,
								["g_amt"] = 16,
								["n_max"] = 114,
								["targets"] = {
									["狂爪龙人"] = 2168,
									["大酋长雷德·黑手 <盖斯>"] = 1762,
									["大酋长雷德·黑手"] = 0,
									["黑手精英"] = 782,
									["多彩龙人"] = 8372,
									["狂爪火鳞龙人"] = 1022,
									["盖斯"] = 1786,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 11369,
								["n_min"] = 0,
								["g_dmg"] = 1204,
								["counter"] = 186,
								["total"] = 15892,
								["r_amt"] = 0,
								["c_max"] = 194,
								["a_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 202,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 10,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 132,
								["DODGE"] = 6,
								["MISS"] = 2,
							},
							["盾牌猛击"] = {
								["c_amt"] = 8,
								["b_amt"] = 4,
								["c_dmg"] = 4395,
								["g_amt"] = 0,
								["n_max"] = 313,
								["targets"] = {
									["狂爪龙人"] = 1724,
									["大酋长雷德·黑手 <盖斯>"] = 2025,
									["狂爪火鳞龙人"] = 1193,
									["黑手精英"] = 233,
									["多彩龙人"] = 5597,
									["盖斯"] = 699,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 7076,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 39,
								["total"] = 11471,
								["r_amt"] = 0,
								["c_max"] = 616,
								["DODGE"] = 2,
								["id"] = "盾牌猛击",
								["r_dmg"] = 0,
								["b_dmg"] = 1272,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 3,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 25,
								["a_amt"] = 0,
								["MISS"] = 1,
							},
							["嘲讽"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["狂爪火鳞龙人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "嘲讽",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["挫志怒吼"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["多彩雏龙"] = 0,
									["多彩龙人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "挫志怒吼",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["破甲攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["盖斯"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "破甲攻击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 2,
							},
							["复仇"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 273,
								["g_amt"] = 0,
								["n_max"] = 51,
								["targets"] = {
									["狂爪龙人"] = 173,
									["大酋长雷德·黑手 <盖斯>"] = 226,
									["狂爪火鳞龙人"] = 100,
									["多彩龙人"] = 575,
									["盖斯"] = 195,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 996,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 27,
								["total"] = 1269,
								["c_max"] = 95,
								["id"] = "复仇",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 23,
								["a_dmg"] = 0,
								["MISS"] = 1,
							},
							["!Autoshot"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 92,
								["targets"] = {
									["狂爪火鳞龙人"] = 89,
									["狂爪龙人"] = 92,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 181,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 181,
								["c_max"] = 0,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["英勇打击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 347,
								["g_amt"] = 0,
								["n_max"] = 191,
								["targets"] = {
									["盖斯"] = 191,
									["大酋长雷德·黑手 <盖斯>"] = 691,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 535,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 882,
								["c_max"] = 347,
								["id"] = "英勇打击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["on_hold"] = false,
					["end_time"] = 1588652858,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652502,
					["serial"] = "Player-4920-020A7239",
					["friendlyfire_total"] = 0,
				}, -- [1]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.025385,
					["damage_from"] = {
						["无常十号"] = true,
						["妩媚飒飒"] = true,
						["狼 <啪啪>"] = true,
						["遂于而安"] = true,
						["窈窕淑"] = true,
						["妖怪你别里跑"] = true,
						["啪啪"] = true,
					},
					["targets"] = {
						["吴建业"] = 1380,
						["狼 <啪啪>"] = 1455,
						["窈窕淑"] = 2391,
						["妖怪你别里跑"] = 2472,
						["妩媚飒飒"] = 2466,
						["啪啪"] = 852,
						["遂于而安"] = 1404,
						["李大宝"] = 1941,
						["花姐"] = 571,
						["无常十号"] = 3553,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 18485.025385,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 18485.025385,
					["classe"] = "UNKNOW",
					["friendlyfire"] = {
					},
					["nome"] = "狂爪火鳞龙人",
					["spells"] = {
						["_ActorTable"] = {
							["火焰新星"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 431,
								["targets"] = {
									["无常十号"] = 376,
									["狼 <啪啪>"] = 431,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 807,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 807,
								["c_max"] = 0,
								["id"] = "火焰新星",
								["r_dmg"] = 807,
								["r_amt"] = 2,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["烈焰风暴"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 941,
								["targets"] = {
									["吴建业"] = 820,
									["李大宝"] = 1345,
									["妩媚飒飒"] = 1856,
									["狼 <啪啪>"] = 801,
									["遂于而安"] = 862,
									["无常十号"] = 1981,
									["妖怪你别里跑"] = 1933,
									["窈窕淑"] = 1899,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 11497,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 49,
								["total"] = 11497,
								["c_max"] = 0,
								["id"] = "烈焰风暴",
								["r_dmg"] = 2595,
								["r_amt"] = 7,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 47,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["RESIST"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 231,
								["targets"] = {
									["无常十号"] = 918,
									["啪啪"] = 852,
									["狼 <啪啪>"] = 223,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1993,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 14,
								["total"] = 1993,
								["r_amt"] = 0,
								["c_max"] = 0,
								["a_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 11,
								["MISS"] = 1,
								["DODGE"] = 1,
							},
							["连珠火球"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 610,
								["targets"] = {
									["吴建业"] = 560,
									["窈窕淑"] = 492,
									["妖怪你别里跑"] = 539,
									["妩媚飒飒"] = 610,
									["啪啪"] = 0,
									["遂于而安"] = 542,
									["李大宝"] = 596,
									["花姐"] = 571,
									["无常十号"] = 278,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4188,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 9,
								["total"] = 4188,
								["c_max"] = 0,
								["id"] = "连珠火球",
								["r_dmg"] = 278,
								["r_amt"] = 1,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 8,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["fight_component"] = true,
					["end_time"] = 1588652858,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 21557.025385,
					["start_time"] = 1588652799,
					["serial"] = "Creature-0-4504-229-31332-10083-0000B0E418",
					["monster"] = true,
				}, -- [2]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.017001,
					["damage_from"] = {
						["狂爪龙人"] = true,
						["无常十号"] = true,
						["妩媚飒飒"] = true,
						["狼 <啪啪>"] = true,
						["遂于而安"] = true,
						["窈窕淑"] = true,
						["妖怪你别里跑"] = true,
						["啪啪"] = true,
					},
					["targets"] = {
						["狂爪龙人"] = 10,
						["无常十号"] = 4975,
						["妖怪你别里跑"] = 3709,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 8694.017001,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 8694.017001,
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["nome"] = "狂爪龙人",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 6,
								["c_dmg"] = 433,
								["g_amt"] = 0,
								["n_max"] = 512,
								["targets"] = {
									["妖怪你别里跑"] = 3016,
									["无常十号"] = 4735,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 7318,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 45,
								["total"] = 7751,
								["r_amt"] = 0,
								["c_max"] = 433,
								["DODGE"] = 6,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 636,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 5,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 31,
								["a_amt"] = 0,
								["MISS"] = 2,
							},
							["凝视"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "凝视",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["破甲攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["无常十号"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["r_amt"] = 0,
								["c_max"] = 0,
								["a_amt"] = 0,
								["id"] = "破甲攻击",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 6,
								["a_dmg"] = 0,
								["n_amt"] = 0,
								["MISS"] = 1,
								["DODGE"] = 1,
							},
							["打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 693,
								["targets"] = {
									["妖怪你别里跑"] = 693,
									["无常十号"] = 240,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 933,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 933,
								["c_max"] = 0,
								["id"] = "打击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 240,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 2,
								["targets"] = {
									["狂爪龙人"] = 10,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 10,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 10,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 5,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["狂怒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "狂怒",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["end_time"] = 1588652858,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 43696.017001,
					["start_time"] = 1588652787,
					["serial"] = "Creature-0-4504-229-31332-9096-0000B0E418",
					["monster"] = true,
				}, -- [3]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.050319,
					["damage_from"] = {
						["狂爪火鳞龙人"] = true,
						["多彩龙人"] = true,
					},
					["targets"] = {
						["狂爪龙人"] = 2858,
						["黑手老兵"] = 2595,
						["黑手精英"] = 1926,
						["黑手驭龙者"] = 4955,
						["狂爪火鳞龙人"] = 738,
						["黑老鼠"] = 222,
						["多彩龙人"] = 11662,
						["多彩雏龙"] = 6785,
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 31741.050319,
					["damage_taken"] = 1843.050319,
					["dps_started"] = false,
					["total"] = 31741.050319,
					["delay"] = 0,
					["on_hold"] = false,
					["nome"] = "遂于而安",
					["spells"] = {
						["_ActorTable"] = {
							["神圣新星"] = {
								["c_amt"] = 25,
								["b_amt"] = 0,
								["c_dmg"] = 7881,
								["g_amt"] = 0,
								["n_max"] = 223,
								["targets"] = {
									["狂爪龙人"] = 2858,
									["黑手老兵"] = 2595,
									["狂爪火鳞龙人"] = 738,
									["黑手驭龙者"] = 4955,
									["黑手精英"] = 1926,
									["黑老鼠"] = 222,
									["多彩龙人"] = 11662,
									["多彩雏龙"] = 6785,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 23860,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 143,
								["total"] = 31741,
								["c_max"] = 332,
								["id"] = "神圣新星",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 114,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 4,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["end_time"] = 1588652858,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652712,
					["serial"] = "Player-4920-01DC68C3",
					["classe"] = "PRIEST",
				}, -- [4]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.076779,
					["damage_from"] = {
						["狂爪火鳞龙人"] = true,
						["黑手老兵"] = true,
						["多彩龙人"] = true,
						["黑手驭龙者"] = true,
					},
					["targets"] = {
						["狂爪龙人"] = 7883,
						["大酋长雷德·黑手 <盖斯>"] = 4834,
						["黑手驭龙者"] = 14060,
						["狂爪火鳞龙人"] = 3530,
						["多彩雏龙"] = 16844,
						["黑手老兵"] = 9798,
						["黑手精英"] = 3810,
						["多彩龙人"] = 21568,
						["蟑螂"] = 578,
						["盖斯"] = 6047,
					},
					["pets"] = {
					},
					["damage_taken"] = 12614.076779,
					["tipo"] = 1,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 88952.076779,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 88952.076779,
					["nome"] = "窈窕淑",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["点燃"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 474,
								["targets"] = {
									["多彩雏龙"] = 407,
									["黑手老兵"] = 922,
									["黑手驭龙者"] = 948,
									["多彩龙人"] = 572,
									["狂爪火鳞龙人"] = 192,
									["盖斯"] = 850,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 3891,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 3891,
								["c_max"] = 0,
								["id"] = "点燃",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 20,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["烈焰风暴"] = {
								["c_amt"] = 9,
								["b_amt"] = 0,
								["c_dmg"] = 4374,
								["g_amt"] = 0,
								["n_max"] = 544,
								["targets"] = {
									["狂爪龙人"] = 1336,
									["黑手老兵"] = 2711,
									["黑手驭龙者"] = 4119,
									["狂爪火鳞龙人"] = 770,
									["黑手精英"] = 765,
									["多彩龙人"] = 5516,
									["多彩雏龙"] = 6518,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 17361,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 112,
								["total"] = 21735,
								["c_max"] = 782,
								["id"] = "烈焰风暴",
								["r_dmg"] = 7844,
								["r_amt"] = 29,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 103,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["狂爪龙人"] = 0,
									["大酋长雷德·黑手"] = 0,
									["盖斯"] = 0,
									["多彩雏龙"] = 0,
									["多彩龙人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 0,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "冲击",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["RESIST"] = 4,
								["a_dmg"] = 0,
								["IMMUNE"] = 2,
							},
							["魔爆术"] = {
								["c_amt"] = 14,
								["b_amt"] = 0,
								["c_dmg"] = 5050,
								["g_amt"] = 0,
								["n_max"] = 296,
								["targets"] = {
									["狂爪龙人"] = 3584,
									["黑手老兵"] = 4153,
									["黑手驭龙者"] = 5923,
									["狂爪火鳞龙人"] = 863,
									["黑手精英"] = 2454,
									["多彩龙人"] = 6899,
									["多彩雏龙"] = 3877,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 22703,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 127,
								["total"] = 27753,
								["c_max"] = 440,
								["id"] = "魔爆术",
								["r_dmg"] = 10202,
								["r_amt"] = 68,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 111,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冲击波"] = {
								["c_amt"] = 5,
								["b_amt"] = 0,
								["c_dmg"] = 4348,
								["g_amt"] = 0,
								["n_max"] = 618,
								["targets"] = {
									["狂爪龙人"] = 0,
									["黑手老兵"] = 2012,
									["黑手精英"] = 591,
									["黑手驭龙者"] = 3070,
									["狂爪火鳞龙人"] = 0,
									["多彩雏龙"] = 6042,
									["蟑螂"] = 578,
									["多彩龙人"] = 3529,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 11474,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 36,
								["total"] = 15822,
								["c_max"] = 903,
								["id"] = "冲击波",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 20,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 11,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火球术"] = {
								["c_amt"] = 4,
								["b_amt"] = 0,
								["c_dmg"] = 1728,
								["g_amt"] = 0,
								["n_max"] = 972,
								["targets"] = {
									["狂爪龙人"] = 2815,
									["大酋长雷德·黑手 <盖斯>"] = 4834,
									["多彩龙人"] = 3817,
									["盖斯"] = 5197,
									["狂爪火鳞龙人"] = 1227,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 16162,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 69,
								["total"] = 17890,
								["c_max"] = 680,
								["id"] = "火球术",
								["r_dmg"] = 12679,
								["r_amt"] = 32,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 64,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 478,
								["g_amt"] = 0,
								["n_max"] = 439,
								["targets"] = {
									["狂爪龙人"] = 148,
									["狂爪火鳞龙人"] = 478,
									["多彩龙人"] = 1235,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1383,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 1861,
								["c_max"] = 478,
								["id"] = "火焰冲击",
								["r_dmg"] = 1861,
								["r_amt"] = 6,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["on_hold"] = false,
					["end_time"] = 1588652858,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652566,
					["serial"] = "Player-4920-01DC60BC",
					["friendlyfire_total"] = 0,
				}, -- [5]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.069999,
					["damage_from"] = {
						["多彩雏龙"] = true,
						["黑手老兵"] = true,
						["黑手驭龙者"] = true,
						["狂爪火鳞龙人"] = true,
						["狂爪龙人"] = true,
						["多彩龙人"] = true,
					},
					["targets"] = {
						["狂爪龙人"] = 10265,
						["大酋长雷德·黑手 <盖斯>"] = 3466,
						["黑手驭龙者"] = 12462,
						["狂爪火鳞龙人"] = 3235,
						["多彩雏龙"] = 15975,
						["黑手老兵"] = 4085,
						["黑手精英"] = 2974,
						["多彩龙人"] = 19913,
						["盖斯"] = 5795,
					},
					["pets"] = {
					},
					["damage_taken"] = 11145.069999,
					["tipo"] = 1,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 78170.069999,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 78170.069999,
					["nome"] = "妖怪你别里跑",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["点燃"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 396,
								["targets"] = {
									["狂爪龙人"] = 792,
									["黑手驭龙者"] = 274,
									["多彩龙人"] = 1354,
									["多彩雏龙"] = 177,
									["狂爪火鳞龙人"] = 140,
									["盖斯"] = 174,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2911,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 2911,
								["c_max"] = 0,
								["id"] = "点燃",
								["r_dmg"] = 174,
								["r_amt"] = 2,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 18,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火球术"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 1879,
								["g_amt"] = 0,
								["n_max"] = 868,
								["targets"] = {
									["狂爪龙人"] = 2140,
									["大酋长雷德·黑手 <盖斯>"] = 3466,
									["狂爪火鳞龙人"] = 1529,
									["多彩龙人"] = 4647,
									["黑手精英"] = 791,
									["盖斯"] = 5621,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 16315,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 71,
								["total"] = 18194,
								["c_max"] = 671,
								["id"] = "火球术",
								["r_dmg"] = 12770,
								["r_amt"] = 36,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 67,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰冻"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["多彩龙人"] = 0,
									["多彩雏龙"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰冻",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["多彩雏龙"] = 0,
									["狂爪龙人"] = 0,
									["大酋长雷德·黑手"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "冲击",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["RESIST"] = 2,
								["a_dmg"] = 0,
								["IMMUNE"] = 1,
							},
							["魔爆术"] = {
								["c_amt"] = 14,
								["b_amt"] = 0,
								["c_dmg"] = 4287,
								["g_amt"] = 0,
								["n_max"] = 284,
								["targets"] = {
									["狂爪龙人"] = 3822,
									["黑手老兵"] = 4085,
									["黑手驭龙者"] = 5768,
									["狂爪火鳞龙人"] = 814,
									["黑手精英"] = 2183,
									["多彩龙人"] = 7368,
									["多彩雏龙"] = 4539,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 24292,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 135,
								["total"] = 28579,
								["c_max"] = 420,
								["id"] = "魔爆术",
								["r_dmg"] = 10530,
								["r_amt"] = 71,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 120,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冲击波"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1687,
								["g_amt"] = 0,
								["n_max"] = 609,
								["targets"] = {
									["多彩雏龙"] = 4159,
									["黑手驭龙者"] = 2751,
									["狂爪火鳞龙人"] = 0,
									["多彩龙人"] = 1743,
									["狂爪龙人"] = 1437,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8403,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 31,
								["total"] = 10090,
								["c_max"] = 853,
								["id"] = "冲击波",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 15,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 14,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["烈焰风暴"] = {
								["c_amt"] = 12,
								["b_amt"] = 0,
								["c_dmg"] = 5447,
								["g_amt"] = 0,
								["n_max"] = 518,
								["targets"] = {
									["多彩雏龙"] = 7100,
									["黑手驭龙者"] = 3669,
									["狂爪火鳞龙人"] = 752,
									["多彩龙人"] = 4801,
									["狂爪龙人"] = 1343,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 12218,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 97,
								["total"] = 17665,
								["c_max"] = 725,
								["id"] = "烈焰风暴",
								["r_dmg"] = 8066,
								["r_amt"] = 29,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 84,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 423,
								["targets"] = {
									["狂爪龙人"] = 731,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 731,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 731,
								["c_max"] = 0,
								["id"] = "火焰冲击",
								["r_dmg"] = 731,
								["r_amt"] = 2,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["on_hold"] = false,
					["end_time"] = 1588652858,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652566,
					["serial"] = "Player-4920-01DC6F5E",
					["friendlyfire_total"] = 0,
				}, -- [6]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.078413,
					["damage_from"] = {
						["多彩雏龙"] = true,
						["黑手驭龙者"] = true,
						["狂爪火鳞龙人"] = true,
						["多彩龙人"] = true,
						["黑手精英"] = true,
					},
					["targets"] = {
						["狂爪龙人"] = 10275,
						["大酋长雷德·黑手 <盖斯>"] = 4728,
						["黑手驭龙者"] = 12855,
						["狂爪火鳞龙人"] = 4187,
						["多彩雏龙"] = 15478,
						["黑手老兵"] = 8075,
						["黑手精英"] = 4101,
						["多彩龙人"] = 18315,
						["盖斯"] = 5469,
					},
					["pets"] = {
					},
					["damage_taken"] = 9988.078413,
					["tipo"] = 1,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 83483.078413,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 83483.078413,
					["nome"] = "妩媚飒飒",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["点燃"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 249,
								["targets"] = {
									["狂爪龙人"] = 783,
									["黑手驭龙者"] = 292,
									["多彩龙人"] = 963,
									["多彩雏龙"] = 152,
									["黑手精英"] = 274,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2464,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 18,
								["total"] = 2464,
								["c_max"] = 0,
								["id"] = "点燃",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 18,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 21,
								["b_amt"] = 0,
								["c_dmg"] = 6229,
								["g_amt"] = 0,
								["n_max"] = 287,
								["targets"] = {
									["狂爪龙人"] = 4019,
									["黑手老兵"] = 3726,
									["黑手驭龙者"] = 6237,
									["狂爪火鳞龙人"] = 829,
									["黑手精英"] = 2221,
									["多彩龙人"] = 7253,
									["多彩雏龙"] = 4864,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 22920,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 135,
								["total"] = 29149,
								["c_max"] = 431,
								["id"] = "魔爆术",
								["r_dmg"] = 11282,
								["r_amt"] = 74,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 113,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰冻"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["多彩龙人"] = 0,
									["黑手驭龙者"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰冻",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["多彩雏龙"] = 0,
									["多彩龙人"] = 0,
									["大酋长雷德·黑手"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 0,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "冲击",
								["r_dmg"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["RESIST"] = 2,
								["a_dmg"] = 0,
								["IMMUNE"] = 1,
							},
							["火球术"] = {
								["c_amt"] = 6,
								["b_amt"] = 0,
								["c_dmg"] = 4640,
								["g_amt"] = 0,
								["n_max"] = 922,
								["targets"] = {
									["狂爪龙人"] = 2833,
									["大酋长雷德·黑手 <盖斯>"] = 4728,
									["大酋长雷德·黑手"] = 0,
									["多彩龙人"] = 3016,
									["盖斯"] = 5469,
									["狂爪火鳞龙人"] = 1504,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 12910,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 67,
								["total"] = 17550,
								["c_max"] = 1176,
								["id"] = "火球术",
								["r_dmg"] = 10835,
								["r_amt"] = 29,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 59,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冲击波"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 616,
								["targets"] = {
									["狂爪龙人"] = 530,
									["黑手老兵"] = 1782,
									["黑手驭龙者"] = 2313,
									["狂爪火鳞龙人"] = 594,
									["黑手精英"] = 535,
									["多彩雏龙"] = 4523,
									["多彩龙人"] = 1117,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 11394,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["total"] = 11394,
								["c_max"] = 0,
								["id"] = "冲击波",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 20,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["RESIST"] = 10,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["烈焰风暴"] = {
								["c_amt"] = 12,
								["b_amt"] = 0,
								["c_dmg"] = 6282,
								["g_amt"] = 0,
								["n_max"] = 525,
								["targets"] = {
									["狂爪龙人"] = 1690,
									["黑手老兵"] = 2567,
									["黑手驭龙者"] = 4013,
									["狂爪火鳞龙人"] = 967,
									["黑手精英"] = 1071,
									["多彩龙人"] = 4683,
									["多彩雏龙"] = 5939,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 14648,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 111,
								["total"] = 20930,
								["c_max"] = 742,
								["id"] = "烈焰风暴",
								["r_dmg"] = 6791,
								["r_amt"] = 26,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 99,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 3,
								["b_amt"] = 0,
								["c_dmg"] = 850,
								["g_amt"] = 0,
								["n_max"] = 433,
								["targets"] = {
									["狂爪龙人"] = 420,
									["狂爪火鳞龙人"] = 293,
									["多彩龙人"] = 1283,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1146,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 1996,
								["c_max"] = 413,
								["id"] = "火焰冲击",
								["r_dmg"] = 1996,
								["r_amt"] = 6,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["on_hold"] = false,
					["end_time"] = 1588652858,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652557,
					["serial"] = "Player-4920-01DC6F13",
					["friendlyfire_total"] = 0,
				}, -- [7]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.012181,
					["damage_from"] = {
						["狂爪火鳞龙人"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["damage_taken"] = 1941.012181,
					["classe"] = "DRUID",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.012181,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1588652858,
					["delay"] = 0,
					["total"] = 0.012181,
					["nome"] = "李大宝",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["on_hold"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652855,
					["serial"] = "Player-4920-01DC173C",
					["friendlyfire_total"] = 0,
				}, -- [8]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.014898,
					["damage_from"] = {
						["狂爪火鳞龙人"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["damage_taken"] = 1380.014898,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.014898,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1588652858,
					["delay"] = 0,
					["total"] = 0.014898,
					["nome"] = "吴建业",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["on_hold"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652855,
					["serial"] = "Player-4920-01DC12D1",
					["friendlyfire_total"] = 0,
				}, -- [9]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.013804,
					["damage_from"] = {
						["狂爪火鳞龙人"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["damage_taken"] = 571.013804,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.013804,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1588652858,
					["delay"] = 0,
					["total"] = 0.013804,
					["nome"] = "花姐",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1588652855,
					["serial"] = "Player-4920-01D0BF72",
					["friendlyfire_total"] = 0,
				}, -- [10]
				{
					["flag_original"] = 1297,
					["totalabsorbed"] = 0.071552,
					["damage_from"] = {
						["狂爪火鳞龙人"] = true,
						["黑手老兵"] = true,
					},
					["targets"] = {
						["盖斯"] = 12220,
						["传令官基尔图诺斯"] = 0,
						["多彩雏龙"] = 3970,
						["詹迪斯·巴罗夫"] = 0,
						["枯木剥皮者"] = 0,
						["滚烫的雏龙"] = 0,
						["血骨傀儡"] = 0,
						["火烟食人魔法师"] = 0,
						["山脊巡行者"] = 0,
						["狂爪龙人"] = 8248,
						["邪恶的枭兽"] = 0,
						["密林"] = 0,
						["黑手驭龙者"] = 1627,
						["狂爪火鳞龙人"] = 7463,
						["多彩龙人"] = 36100,
						["黑手精英"] = 1620,
						["复活的构造体"] = 0,
						["莱斯·霜语"] = 0,
						["黑手老兵"] = 2446,
						["枯木血虫"] = 0,
						["大酋长雷德·黑手 <盖斯>"] = 14719,
						["漫步者维瑟哈特"] = 0,
						["沙德拉"] = 0,
						["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
						["枯木巢穴守卫"] = 0,
					},
					["delay"] = 0,
					["pets"] = {
						"狼 <啪啪>", -- [1]
					},
					["nome"] = "啪啪",
					["total"] = 88413.071552,
					["classe"] = "HUNTER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 86989.071552,
					["damage_taken"] = 1267.071552,
					["dps_started"] = false,
					["end_time"] = 1588652858,
					["on_hold"] = false,
					["tipo"] = 1,
					["boss_fight_component"] = true,
					["spec"] = 254,
					["grupo"] = true,
					["friendlyfire"] = {
					},
					["spells"] = {
						["_ActorTable"] = {
							["毒蛇钉刺"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 101,
								["targets"] = {
									["盖斯"] = 1164,
									["传令官基尔图诺斯"] = 0,
									["黑手精英"] = 101,
									["血骨傀儡"] = 0,
									["复活的构造体"] = 0,
									["邪恶的枭兽"] = 0,
									["沙德拉"] = 0,
									["狂爪火鳞龙人"] = 706,
									["詹迪斯·巴罗夫"] = 0,
									["狂爪龙人"] = 505,
									["黑手老兵"] = 101,
									["密林"] = 0,
									["多彩龙人"] = 2807,
									["漫步者维瑟哈特"] = 0,
									["大酋长雷德·黑手 <盖斯>"] = 1111,
									["莱斯·霜语"] = 0,
									["枯木巢穴守卫"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6495,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 71,
								["total"] = 6495,
								["c_max"] = 0,
								["id"] = "毒蛇钉刺",
								["r_dmg"] = 1547,
								["r_amt"] = 22,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 71,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["瞄准射击"] = {
								["c_amt"] = 3,
								["b_amt"] = 1,
								["c_dmg"] = 5132,
								["g_amt"] = 0,
								["n_max"] = 811,
								["targets"] = {
									["狂爪龙人"] = 1392,
									["沙德拉"] = 0,
									["盖斯"] = 2108,
									["传令官基尔图诺斯"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["大酋长雷德·黑手 <盖斯>"] = 4069,
									["莱斯·霜语"] = 0,
									["多彩龙人"] = 8363,
									["狂爪火鳞龙人"] = 1518,
									["漫步者维瑟哈特"] = 0,
									["血骨傀儡"] = 0,
									["复活的构造体"] = 0,
									["枯木巢穴守卫"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 12318,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 20,
								["total"] = 17450,
								["c_max"] = 1800,
								["id"] = "瞄准射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 681,
								["n_amt"] = 17,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Autoshot"] = {
								["c_amt"] = 24,
								["b_amt"] = 2,
								["c_dmg"] = 18792,
								["g_amt"] = 0,
								["n_max"] = 416,
								["targets"] = {
									["盖斯"] = 7997,
									["传令官基尔图诺斯"] = 0,
									["黑手精英"] = 923,
									["血骨傀儡"] = 0,
									["复活的构造体"] = 0,
									["邪恶的枭兽"] = 0,
									["大酋长雷德·黑手 <盖斯>"] = 8072,
									["狂爪火鳞龙人"] = 2676,
									["詹迪斯·巴罗夫"] = 0,
									["狂爪龙人"] = 3477,
									["黑手老兵"] = 1462,
									["沙德拉"] = 0,
									["多彩龙人"] = 16593,
									["漫步者维瑟哈特"] = 0,
									["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
									["莱斯·霜语"] = 0,
									["枯木巢穴守卫"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 22408,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 91,
								["total"] = 41200,
								["c_max"] = 888,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 565,
								["n_amt"] = 67,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["奥术射击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 470,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["狂爪龙人"] = 470,
									["沙德拉"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 470,
								["c_max"] = 470,
								["id"] = "奥术射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 1,
								["n_max"] = 0,
								["targets"] = {
									["枯木剥皮者"] = 0,
									["狂爪火鳞龙人"] = 33,
									["火烟食人魔法师"] = 0,
									["滚烫的雏龙"] = 0,
									["传令官基尔图诺斯"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 33,
								["counter"] = 4,
								["total"] = 33,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["MISS"] = 2,
								["a_amt"] = 0,
							},
							["震荡射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["多彩龙人"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "震荡射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["IMMUNE"] = 1,
							},
							["多重射击"] = {
								["c_amt"] = 8,
								["b_amt"] = 0,
								["c_dmg"] = 7908,
								["g_amt"] = 0,
								["n_max"] = 527,
								["targets"] = {
									["狂爪龙人"] = 1779,
									["詹迪斯·巴罗夫"] = 0,
									["大酋长雷德·黑手 <盖斯>"] = 1467,
									["黑手驭龙者"] = 1627,
									["狂爪火鳞龙人"] = 1448,
									["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
									["传令官基尔图诺斯"] = 0,
									["复活的构造体"] = 0,
									["多彩雏龙"] = 3970,
									["黑手老兵"] = 883,
									["黑手精英"] = 435,
									["盖斯"] = 951,
									["多彩龙人"] = 8337,
									["血骨傀儡"] = 0,
									["沙德拉"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 12989,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 37,
								["total"] = 20897,
								["c_max"] = 1185,
								["id"] = "多重射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 29,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["摔绊"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 34,
								["targets"] = {
									["狂爪火鳞龙人"] = 34,
									["火烟食人魔法师"] = 0,
									["滚烫的雏龙"] = 0,
									["枯木剥皮者"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 34,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 34,
								["c_max"] = 0,
								["id"] = "摔绊",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["驱散射击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 410,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["狂爪火鳞龙人"] = 410,
									["血骨傀儡"] = 0,
									["沙德拉"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 410,
								["c_max"] = 410,
								["id"] = "驱散射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["猛禽一击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["山脊巡行者"] = 0,
									["枯木剥皮者"] = 0,
									["狂爪火鳞龙人"] = 0,
									["传令官基尔图诺斯"] = 0,
									["滚烫的雏龙"] = 0,
									["火烟食人魔法师"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "猛禽一击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["DODGE"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1588652560,
					["serial"] = "Player-4920-01D0E17B",
					["friendlyfire_total"] = 0,
				}, -- [11]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.016743,
					["damage_from"] = {
						["黑手精英"] = true,
						["黑手老兵"] = true,
						["狂爪火鳞龙人"] = true,
					},
					["targets"] = {
						["狂爪火鳞龙人"] = 638,
						["狂爪龙人"] = 625,
						["黑手精英"] = 161,
					},
					["pets"] = {
					},
					["damage_taken"] = 4731.016743,
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1424.016743,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1588652912,
					["delay"] = 0,
					["ownerName"] = "啪啪",
					["nome"] = "狼 <啪啪>",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 3,
								["n_max"] = 100,
								["targets"] = {
									["狂爪火鳞龙人"] = 568,
									["狂爪龙人"] = 561,
									["黑手精英"] = 99,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1071,
								["n_min"] = 0,
								["g_dmg"] = 157,
								["counter"] = 22,
								["total"] = 1228,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 17,
								["a_dmg"] = 0,
								["DODGE"] = 2,
							},
							["撕咬"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 70,
								["targets"] = {
									["狂爪火鳞龙人"] = 70,
									["狂爪龙人"] = 64,
									["黑手精英"] = 62,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 196,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 196,
								["c_max"] = 0,
								["id"] = "撕咬",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire_total"] = 0,
					["tipo"] = 1,
					["total"] = 1424.016743,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1588652868,
					["serial"] = "Pet-0-4504-0-58-9696-0200BA6F1B",
					["on_hold"] = false,
				}, -- [12]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.008533,
					["damage_from"] = {
						["妩媚飒飒"] = true,
						["啪啪"] = true,
						["遂于而安"] = true,
						["窈窕淑"] = true,
						["妖怪你别里跑"] = true,
					},
					["targets"] = {
						["啪啪"] = 415,
						["窈窕淑"] = 3947,
						["妖怪你别里跑"] = 86,
						["狼 <啪啪>"] = 2304,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_taken"] = 26999.008533,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 6752.008533,
					["delay"] = 0,
					["monster"] = true,
					["end_time"] = 1588653080,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "黑手老兵",
					["spells"] = {
						["_ActorTable"] = {
							["盾击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 29,
								["targets"] = {
									["妖怪你别里跑"] = 86,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 86,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 86,
								["c_max"] = 0,
								["id"] = "盾击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 3,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 468,
								["targets"] = {
									["窈窕淑"] = 468,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 468,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 468,
								["c_max"] = 0,
								["id"] = "打击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["盾牌冲锋"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 144,
								["targets"] = {
									["啪啪"] = 415,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 415,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 415,
								["c_max"] = 0,
								["id"] = "盾牌冲锋",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 1419,
								["g_amt"] = 0,
								["n_max"] = 468,
								["targets"] = {
									["窈窕淑"] = 3479,
									["狼"] = 0,
									["狼 <啪啪>"] = 2304,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 4364,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 5783,
								["c_max"] = 867,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 13,
								["a_dmg"] = 0,
								["DODGE"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["total"] = 6752.008533,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1588653063,
					["serial"] = "Creature-0-4504-229-31332-9819-0007B0E417",
					["fight_component"] = true,
				}, -- [13]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.011463,
					["damage_from"] = {
						["狼 <啪啪>"] = true,
						["妩媚飒飒"] = true,
						["啪啪"] = true,
						["遂于而安"] = true,
						["窈窕淑"] = true,
						["妖怪你别里跑"] = true,
						["无常十号"] = true,
					},
					["targets"] = {
						["无常十号"] = 231,
						["妩媚飒飒"] = 2425,
						["狼 <啪啪>"] = 972,
					},
					["pets"] = {
					},
					["dps_started"] = false,
					["damage_taken"] = 15446.011463,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 3628.011463,
					["delay"] = 0,
					["monster"] = true,
					["end_time"] = 1588653080,
					["friendlyfire_total"] = 0,
					["on_hold"] = false,
					["nome"] = "黑手精英",
					["spells"] = {
						["_ActorTable"] = {
							["打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 756,
								["targets"] = {
									["妩媚飒飒"] = 756,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 756,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 756,
								["c_max"] = 0,
								["id"] = "打击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 647,
								["targets"] = {
									["无常十号"] = 231,
									["妩媚飒飒"] = 1669,
									["狼 <啪啪>"] = 972,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2872,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 8,
								["total"] = 2872,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["b_dmg"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_amt"] = 0,
								["n_amt"] = 6,
								["MISS"] = 1,
								["DODGE"] = 1,
							},
							["反手一击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "反手一击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["total"] = 3628.011463,
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1588653052,
					["serial"] = "Creature-0-4504-229-31332-10317-0000B0E417",
					["fight_component"] = true,
				}, -- [14]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.003106,
					["damage_from"] = {
						["窈窕淑"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.003106,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["end_time"] = 1588653080,
					["delay"] = 0,
					["damage_taken"] = 578.003106,
					["nome"] = "蟑螂",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["total"] = 0.003106,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1588653077,
					["serial"] = "Creature-0-4504-229-31332-4076-000030E41A",
					["dps_started"] = false,
				}, -- [15]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.007553,
					["damage_from"] = {
						["遂于而安"] = true,
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.007553,
					["friendlyfire_total"] = 0,
					["fight_component"] = true,
					["end_time"] = 1588653080,
					["delay"] = 0,
					["damage_taken"] = 222.007553,
					["nome"] = "黑老鼠",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["on_hold"] = false,
					["total"] = 0.007553,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["last_event"] = 0,
					["last_dps"] = 0,
					["start_time"] = 1588653077,
					["serial"] = "Creature-0-4504-229-31332-2110-000030E417",
					["dps_started"] = false,
				}, -- [16]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.039483,
					["damage_from"] = {
						["妩媚飒飒"] = true,
						["啪啪"] = true,
						["遂于而安"] = true,
						["窈窕淑"] = true,
						["妖怪你别里跑"] = true,
					},
					["targets"] = {
						["无常十号"] = 4307,
						["妩媚飒飒"] = 233,
						["妖怪你别里跑"] = 1145,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 5685.039483,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 5685.039483,
					["classe"] = "UNKNOW",
					["friendlyfire"] = {
					},
					["nome"] = "多彩雏龙",
					["spells"] = {
						["_ActorTable"] = {
							["闪电箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 355,
								["targets"] = {
									["无常十号"] = 1257,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1257,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1257,
								["c_max"] = 0,
								["id"] = "闪电箭",
								["r_dmg"] = 294,
								["r_amt"] = 1,
								["c_min"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 4,
								["m_amt"] = 0,
								["successful_casted"] = 5,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 320,
								["targets"] = {
									["妖怪你别里跑"] = 320,
									["无常十号"] = 1064,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1384,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 1384,
								["c_max"] = 0,
								["id"] = "寒冰箭",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 5,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 248,
								["g_amt"] = 0,
								["n_max"] = 233,
								["targets"] = {
									["妖怪你别里跑"] = 825,
									["窈窕淑"] = 0,
									["妩媚飒飒"] = 233,
									["无常十号"] = 1986,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2796,
								["DODGE"] = 3,
								["n_min"] = 0,
								["a_amt"] = 0,
								["counter"] = 33,
								["r_amt"] = 0,
								["total"] = 3044,
								["c_max"] = 248,
								["b_dmg"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["BLOCK"] = 3,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 21,
								["MISS"] = 4,
								["g_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["fight_component"] = true,
					["end_time"] = 1588653175,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 59052.039483,
					["start_time"] = 1588653128,
					["serial"] = "Creature-0-4504-229-31332-10442-0000B0E417",
					["monster"] = true,
				}, -- [17]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.034988,
					["damage_from"] = {
						["妩媚飒飒"] = true,
						["啪啪"] = true,
						["遂于而安"] = true,
						["无常十号"] = true,
						["妖怪你别里跑"] = true,
						["窈窕淑"] = true,
					},
					["targets"] = {
						["妩媚飒飒"] = 3137,
						["遂于而安"] = 439,
						["无常十号"] = 7048,
						["妖怪你别里跑"] = 2855,
						["窈窕淑"] = 4027,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 17506.034988,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 17506.034988,
					["classe"] = "UNKNOW",
					["friendlyfire"] = {
					},
					["nome"] = "多彩龙人",
					["spells"] = {
						["_ActorTable"] = {
							["顺劈斩"] = {
								["c_amt"] = 0,
								["b_amt"] = 5,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 466,
								["targets"] = {
									["妩媚飒飒"] = 3137,
									["遂于而安"] = 439,
									["无常十号"] = 851,
									["妖怪你别里跑"] = 2855,
									["窈窕淑"] = 1218,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 8500,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 32,
								["total"] = 8500,
								["r_amt"] = 0,
								["c_max"] = 0,
								["MISS"] = 2,
								["id"] = "顺劈斩",
								["r_dmg"] = 0,
								["b_dmg"] = 309,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["m_amt"] = 0,
								["successful_casted"] = 12,
								["a_dmg"] = 0,
								["n_amt"] = 27,
								["a_amt"] = 0,
								["DODGE"] = 1,
							},
							["!Melee"] = {
								["c_amt"] = 2,
								["b_amt"] = 12,
								["c_dmg"] = 461,
								["g_amt"] = 0,
								["n_max"] = 371,
								["targets"] = {
									["无常十号"] = 5388,
									["窈窕淑"] = 2217,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 7144,
								["DODGE"] = 8,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 81,
								["r_amt"] = 0,
								["total"] = 7605,
								["c_max"] = 240,
								["b_dmg"] = 423,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 10,
								["BLOCK"] = 4,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 52,
								["a_amt"] = 0,
								["MISS"] = 5,
							},
							["打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 3,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 592,
								["targets"] = {
									["无常十号"] = 809,
									["窈窕淑"] = 592,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1401,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 1401,
								["c_max"] = 0,
								["id"] = "打击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 7,
								["b_dmg"] = 326,
								["n_amt"] = 6,
								["a_dmg"] = 0,
								["a_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["fight_component"] = true,
					["end_time"] = 1588653175,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 122102.034988,
					["start_time"] = 1588653023,
					["serial"] = "Creature-0-4504-229-31332-10447-000030E417",
					["monster"] = true,
				}, -- [18]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.035303,
					["damage_from"] = {
						["妩媚飒飒"] = true,
						["啪啪"] = true,
						["遂于而安"] = true,
						["窈窕淑"] = true,
						["妖怪你别里跑"] = true,
					},
					["targets"] = {
						["妖怪你别里跑"] = 878,
						["窈窕淑"] = 2249,
						["妩媚飒飒"] = 1727,
						["无常十号"] = 1436,
					},
					["pets"] = {
					},
					["fight_component"] = true,
					["last_dps"] = 0,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 6290.035303,
					["delay"] = 0,
					["dps_started"] = false,
					["total"] = 6290.035303,
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["nome"] = "黑手驭龙者",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 4,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 377,
								["targets"] = {
									["妖怪你别里跑"] = 878,
									["窈窕淑"] = 2249,
									["妩媚飒飒"] = 1727,
									["无常十号"] = 1436,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 6290,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 30,
								["total"] = 6290,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 280,
								["n_amt"] = 26,
								["DODGE"] = 2,
								["a_amt"] = 0,
							},
							["治疗龙类"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗龙类",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["classe"] = "UNKNOW",
					["end_time"] = 1588653324,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 45959.035303,
					["start_time"] = 1588653260,
					["serial"] = "Creature-0-4504-229-31332-10742-000030ECEF",
					["monster"] = true,
				}, -- [19]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.011536,
					["damage_from"] = {
						["妩媚飒飒"] = true,
						["啪啪"] = true,
						["无常十号"] = true,
						["妖怪你别里跑"] = true,
						["窈窕淑"] = true,
					},
					["targets"] = {
						["无常十号"] = 12461,
					},
					["pets"] = {
						"大酋长雷德·黑手 <盖斯>", -- [1]
					},
					["monster"] = true,
					["nome"] = "盖斯",
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 7235.011536,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1588653785,
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 4,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 248,
								["targets"] = {
									["无常十号"] = 2581,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2581,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 22,
								["total"] = 2581,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 2,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 511,
								["n_amt"] = 13,
								["DODGE"] = 7,
								["a_amt"] = 0,
							},
							["召唤雷德·黑手"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "召唤雷德·黑手",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["冰冻术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 742,
								["targets"] = {
									["无常十号"] = 1974,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1974,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 1974,
								["c_max"] = 0,
								["id"] = "冰冻术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 6,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["击退"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["无常十号"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 0,
								["c_max"] = 0,
								["r_amt"] = 0,
								["id"] = "击退",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["DODGE"] = 1,
								["a_amt"] = 0,
							},
							["火息术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1116,
								["targets"] = {
									["无常十号"] = 1953,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1953,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 1953,
								["c_max"] = 0,
								["id"] = "火息术",
								["r_dmg"] = 837,
								["r_amt"] = 1,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 2,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["腐蚀酸液吐息"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 415,
								["targets"] = {
									["无常十号"] = 727,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 727,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 7,
								["total"] = 727,
								["c_max"] = 0,
								["id"] = "腐蚀酸液吐息",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 7,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["total"] = 12461.011536,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 32402.011536,
					["start_time"] = 1588653688,
					["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
					["last_dps"] = 0,
				}, -- [20]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.013759,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["monster"] = true,
					["nome"] = "维克多·奈法里奥斯",
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.013759,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1588653785,
					["friendlyfire"] = {
					},
					["on_hold"] = false,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["多彩混乱"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "多彩混乱",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["total"] = 0.013759,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 0.013759,
					["start_time"] = 1588653782,
					["serial"] = "Creature-0-4504-229-31332-10162-000030E418",
					["last_dps"] = 0,
				}, -- [21]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.009449,
					["damage_from"] = {
						["妩媚飒飒"] = true,
						["啪啪"] = true,
						["无常十号"] = true,
						["妖怪你别里跑"] = true,
						["窈窕淑"] = true,
					},
					["targets"] = {
						["无常十号"] = 5226,
					},
					["delay"] = 0,
					["pets"] = {
					},
					["nome"] = "大酋长雷德·黑手 <盖斯>",
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 5226.009449,
					["last_dps"] = 0,
					["dps_started"] = false,
					["end_time"] = 1588653785,
					["friendlyfire"] = {
					},
					["ownerName"] = "盖斯",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["致死打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 1041,
								["targets"] = {
									["无常十号"] = 1041,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1041,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 1041,
								["c_max"] = 0,
								["id"] = "致死打击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["顺劈斩"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["无常十号"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "顺劈斩",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 1,
								["m_amt"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["a_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 4,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 412,
								["targets"] = {
									["无常十号"] = 2830,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 2830,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 21,
								["total"] = 2830,
								["r_amt"] = 0,
								["c_max"] = 0,
								["DODGE"] = 5,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["b_dmg"] = 912,
								["c_min"] = 0,
								["m_crit"] = 0,
								["PARRY"] = 4,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["a_dmg"] = 0,
								["n_amt"] = 11,
								["MISS"] = 1,
								["a_amt"] = 0,
							},
							["旋风斩"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "旋风斩",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 4,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["旋风斩效果"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 675,
								["targets"] = {
									["无常十号"] = 1355,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1355,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 4,
								["total"] = 1355,
								["c_max"] = 0,
								["id"] = "旋风斩效果",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 3,
								["a_dmg"] = 0,
								["DODGE"] = 1,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["total"] = 5226.009449,
					["monster"] = true,
					["custom"] = 0,
					["last_event"] = 0,
					["damage_taken"] = 32451.009449,
					["start_time"] = 1588653726,
					["serial"] = "Creature-0-4504-229-31332-10429-000030EEA0",
					["classe"] = "UNKNOW",
				}, -- [22]
				{
					["flag_original"] = 66888,
					["totalabsorbed"] = 0.006762,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["enemy"] = true,
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNGROUPPLAYER",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006762,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["serial"] = "Player-4920-01D13EB0",
					["last_dps"] = 0,
					["nome"] = "密林",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.006762,
					["on_hold"] = false,
					["total"] = 0.006762,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [23]
				{
					["flag_original"] = -2147483648,
					["totalabsorbed"] = 0.003969,
					["damage_from"] = {
					},
					["targets"] = {
						["首席传送师"] = 0,
						["余人"] = 0,
						["Sanji"] = 0,
						["一个小白"] = 0,
						["风王"] = 0,
						["五十度灰"] = 0,
						["阿斯托尔福"] = 0,
						["太昊"] = 0,
						["殺戮機器"] = 0,
						["笨笨牛"] = 0,
						["七级糊涂"] = 0,
						["青山不老丶"] = 0,
						["佳佳大宝贝"] = 0,
						["鲸落"] = 0,
						["胸大都是奶"] = 0,
						["柳大炮"] = 0,
						["给莫肌"] = 0,
						["毁己"] = 0,
						["出逃指南"] = 0,
						["托尼帕克"] = 0,
						["二营长"] = 0,
						["Xjilly"] = 0,
						["归壹"] = 0,
						["Noyaa"] = 0,
						["Comic"] = 0,
						["零零大"] = 0,
						["暗影长择"] = 0,
						["蒙娜丽斌"] = 0,
						["高贵的甜甜圈"] = 0,
						["雪中菲"] = 0,
						["偷芯的苹果"] = 0,
						["托尔"] = 0,
						["匪地主"] = 0,
						["馬爷"] = 0,
						["猛牛酸酸乳"] = 0,
						["大丈夫萌大奶"] = 0,
						["霸气香香包"] = 0,
						["萨尓霸罢"] = 0,
						["Thirdeye"] = 0,
						["鸡爷"] = 0,
						["山城亦雾都"] = 0,
						["揉揉"] = 0,
						["Mmint"] = 0,
						["Squanchy"] = 0,
						["抓过你的奶"] = 0,
						["Ybbabo"] = 0,
						["加尔摩"] = 0,
						["隐藏的心"] = 0,
						["杜尔伯特"] = 0,
						["白露时节"] = 0,
						["年迈的军师"] = 0,
						["夏雨"] = 0,
						["野外小卖店"] = 0,
						["小西几小脑斧"] = 0,
						["秋风兮"] = 0,
						["啪啪"] = 0,
						["Spicymaster"] = 0,
						["绿光制造者"] = 0,
						["狮子座丶伍月"] = 0,
						["笨吖头"] = 0,
						["抓你当狗"] = 0,
						["哎呀"] = 0,
						["雪落"] = 0,
						["玛拉卡斯"] = 0,
						["Underattack"] = 0,
						["老友记"] = 0,
						["六九号技师"] = 0,
						["隐龟人"] = 0,
						["小丶肉饼"] = 0,
						["奶牛豆豆"] = 0,
						["恶魔狂想曲"] = 0,
						["啤酒花生乳瓜"] = 0,
						["胡萝卜丶"] = 0,
						["Dalex"] = 0,
						["王政骁"] = 0,
						["风龙之子"] = 0,
						["猫沙利文"] = 0,
						["疯紫"] = 0,
						["风皇"] = 0,
						["逆苍天"] = 0,
						["银狐坏少奶"] = 0,
						["叨叨不喝酒"] = 0,
						["神之二传"] = 0,
						["熊心壮痣"] = 0,
						["小霸霸"] = 0,
						["Walks"] = 0,
						["风母"] = 0,
						["疯疯"] = 0,
						["Owxue"] = 0,
						["暴风归来"] = 0,
						["一大群法師"] = 0,
						["Paimon"] = 0,
						["老实得很"] = 0,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.003969,
					["fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["serial"] = "",
					["last_dps"] = 0,
					["nome"] = "环境伤害 (高处坠落)",
					["spells"] = {
						["_ActorTable"] = {
							["Falling"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["首席传送师"] = 0,
									["余人"] = 0,
									["Sanji"] = 0,
									["一个小白"] = 0,
									["风王"] = 0,
									["五十度灰"] = 0,
									["阿斯托尔福"] = 0,
									["太昊"] = 0,
									["殺戮機器"] = 0,
									["笨笨牛"] = 0,
									["七级糊涂"] = 0,
									["青山不老丶"] = 0,
									["佳佳大宝贝"] = 0,
									["鲸落"] = 0,
									["胸大都是奶"] = 0,
									["柳大炮"] = 0,
									["给莫肌"] = 0,
									["毁己"] = 0,
									["出逃指南"] = 0,
									["托尼帕克"] = 0,
									["二营长"] = 0,
									["Xjilly"] = 0,
									["归壹"] = 0,
									["Noyaa"] = 0,
									["Comic"] = 0,
									["零零大"] = 0,
									["暗影长择"] = 0,
									["蒙娜丽斌"] = 0,
									["高贵的甜甜圈"] = 0,
									["雪中菲"] = 0,
									["偷芯的苹果"] = 0,
									["托尔"] = 0,
									["匪地主"] = 0,
									["馬爷"] = 0,
									["猛牛酸酸乳"] = 0,
									["大丈夫萌大奶"] = 0,
									["霸气香香包"] = 0,
									["萨尓霸罢"] = 0,
									["Thirdeye"] = 0,
									["鸡爷"] = 0,
									["山城亦雾都"] = 0,
									["揉揉"] = 0,
									["Mmint"] = 0,
									["Squanchy"] = 0,
									["抓过你的奶"] = 0,
									["Ybbabo"] = 0,
									["加尔摩"] = 0,
									["隐藏的心"] = 0,
									["杜尔伯特"] = 0,
									["白露时节"] = 0,
									["年迈的军师"] = 0,
									["夏雨"] = 0,
									["野外小卖店"] = 0,
									["小西几小脑斧"] = 0,
									["秋风兮"] = 0,
									["啪啪"] = 0,
									["Spicymaster"] = 0,
									["绿光制造者"] = 0,
									["狮子座丶伍月"] = 0,
									["笨吖头"] = 0,
									["抓你当狗"] = 0,
									["哎呀"] = 0,
									["雪落"] = 0,
									["玛拉卡斯"] = 0,
									["Underattack"] = 0,
									["老友记"] = 0,
									["六九号技师"] = 0,
									["隐龟人"] = 0,
									["小丶肉饼"] = 0,
									["奶牛豆豆"] = 0,
									["恶魔狂想曲"] = 0,
									["啤酒花生乳瓜"] = 0,
									["胡萝卜丶"] = 0,
									["Dalex"] = 0,
									["王政骁"] = 0,
									["风龙之子"] = 0,
									["猫沙利文"] = 0,
									["疯紫"] = 0,
									["风皇"] = 0,
									["逆苍天"] = 0,
									["银狐坏少奶"] = 0,
									["叨叨不喝酒"] = 0,
									["神之二传"] = 0,
									["熊心壮痣"] = 0,
									["小霸霸"] = 0,
									["Walks"] = 0,
									["风母"] = 0,
									["疯疯"] = 0,
									["Owxue"] = 0,
									["暴风归来"] = 0,
									["一大群法師"] = 0,
									["Paimon"] = 0,
									["老实得很"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "Falling",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["damage_taken"] = 0.003969,
					["total"] = 0.003969,
					["friendlyfire"] = {
					},
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [24]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.008243,
					["damage_from"] = {
					},
					["targets"] = {
						["机总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008243,
					["serial"] = "Creature-0-4504-0-187-2651-0000303D7E",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.008243,
					["nome"] = "枯木剥皮者",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
									["机总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["毒药"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "毒药",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.008243,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [25]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.006603,
					["damage_from"] = {
					},
					["targets"] = {
						["啪啪"] = 0,
						["机总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006603,
					["serial"] = "Creature-0-4504-0-187-2707-0000303B77",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.006603,
					["nome"] = "沙德拉",
					["spells"] = {
						["_ActorTable"] = {
							["毒药"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
									["机总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "毒药",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["啪啪"] = 0,
									["机总"] = 0,
									["机总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["减速毒药"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "减速毒药",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.006603,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [26]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.006048,
					["damage_from"] = {
					},
					["targets"] = {
						["机总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006048,
					["serial"] = "Creature-0-4504-0-187-2686-00002E96CD",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.006048,
					["nome"] = "枯木巢穴守卫",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
									["机总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["毒药"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "毒药",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.006048,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [27]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.005689,
					["damage_from"] = {
					},
					["targets"] = {
						["机总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005689,
					["serial"] = "Creature-0-4504-0-187-8218-00002FF0BF",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.005689,
					["nome"] = "漫步者维瑟哈特",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
									["机总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.005689,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [28]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.004895,
					["damage_from"] = {
					},
					["targets"] = {
						["机总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004895,
					["serial"] = "Creature-0-4504-0-187-2927-000030389E",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.004895,
					["nome"] = "邪恶的枭兽",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["机总"] = 0,
									["机总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.004895,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [29]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.008598,
					["damage_from"] = {
					},
					["targets"] = {
						["复活的构造体"] = 0,
						["詹迪斯·巴罗夫"] = 0,
						["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
						["传令官基尔图诺斯"] = 0,
						["血骨傀儡"] = 0,
						["通灵魔"] = 0,
						["莱斯·霜语"] = 0,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["last_event"] = 0,
					["classe"] = "ROGUE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.008598,
					["serial"] = "Player-4920-01F19A55",
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["friendlyfire"] = {
						["朴不成"] = {
							["spells"] = {
								["风怒图腾"] = 0,
							},
							["total"] = 0,
						},
					},
					["nome"] = "朴不成",
					["spells"] = {
						["_ActorTable"] = {
							["脚踢"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["詹迪斯·巴罗夫"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "脚踢",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["背刺"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["血骨傀儡"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "背刺",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["通灵魔"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["肾击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "肾击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["火舌攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["传令官基尔图诺斯"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火舌攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["刺骨"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["传令官基尔图诺斯"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "刺骨",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["灼热武器"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["血骨傀儡"] = 0,
									["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "灼热武器",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["邪恶攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["血骨傀儡"] = 0,
									["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "邪恶攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["total"] = 0.008598,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.008598,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [30]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.002629,
					["damage_from"] = {
					},
					["targets"] = {
						["啪啪"] = 0,
						["朴不成"] = 0,
						["像只猴的你"] = 0,
						["琼琼宝贝"] = 0,
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002629,
					["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
					["dps_started"] = false,
					["total"] = 0.002629,
					["last_dps"] = 0,
					["damage_taken"] = 0.002629,
					["nome"] = "莱斯·霜语",
					["spells"] = {
						["_ActorTable"] = {
							["冰冻"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["朴不成"] = 0,
									["像只猴的你"] = 0,
									["鲁总"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰冻",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["恐惧术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "恐惧术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["连发寒冰箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["琼琼宝贝"] = 0,
									["像只猴的你"] = 0,
									["鲁总 <啪啪>"] = 0,
									["啪啪"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "连发寒冰箭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["击退"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["朴不成"] = 0,
									["像只猴的你"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "击退",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["冰冻新星"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰冻新星",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["朴不成"] = 0,
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["monster"] = true,
				}, -- [31]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.00655,
					["damage_from"] = {
					},
					["targets"] = {
						["复活的构造体"] = 0,
						["老鼠"] = 0,
						["詹迪斯·巴罗夫"] = 0,
						["传令官基尔图诺斯"] = 0,
						["血骨傀儡"] = 0,
						["莱斯·霜语"] = 0,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["last_event"] = 0,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.00655,
					["serial"] = "Player-4920-01ECB17B",
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["friendlyfire"] = {
					},
					["nome"] = "幽魂无双",
					["spells"] = {
						["_ActorTable"] = {
							["点燃"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "点燃",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["灼烧"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["血骨傀儡"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "灼烧",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["传令官基尔图诺斯"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冲击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["魔爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["老鼠"] = 0,
									["詹迪斯·巴罗夫"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "魔爆术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["炎爆术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["血骨傀儡"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "炎爆术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["火球术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火球术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["火焰冲击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火焰冲击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["total"] = 0.00655,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.00655,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [32]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.00236,
					["damage_from"] = {
					},
					["targets"] = {
						["复活的构造体"] = 0,
						["詹迪斯·巴罗夫"] = 0,
						["血骨傀儡"] = 0,
						["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
						["传令官基尔图诺斯"] = 0,
						["莱斯·霜语"] = 0,
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["last_event"] = 0,
					["classe"] = "WARRIOR",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.00236,
					["serial"] = "Player-4920-01D50132",
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["friendlyfire"] = {
						["像只猴的你"] = {
							["spells"] = {
								["风怒图腾"] = 0,
							},
							["total"] = 0,
						},
					},
					["nome"] = "像只猴的你",
					["spells"] = {
						["_ActorTable"] = {
							["嗜血"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "嗜血",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["火舌攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["血骨傀儡"] = 0,
									["传令官基尔图诺斯"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火舌攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["重伤"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "重伤",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["暗影箭"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["血骨傀儡"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "暗影箭",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Autoshot"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["詹迪斯·巴罗夫"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫的幻象"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["拦截昏迷"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["血骨傀儡"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "拦截昏迷",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["英勇打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "英勇打击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["复仇"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["传令官基尔图诺斯"] = 0,
									["血骨傀儡"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "复仇",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["盾击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "盾击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["惩戒痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["血骨傀儡"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "惩戒痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["total"] = 0.00236,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.00236,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [33]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.005562,
					["damage_from"] = {
					},
					["targets"] = {
						["复活的构造体"] = 0,
						["山脊巡行者"] = 0,
						["詹迪斯·巴罗夫"] = 0,
						["滚烫的雏龙"] = 0,
						["火烟食人魔法师"] = 0,
						["传令官基尔图诺斯"] = 0,
						["莱斯·霜语"] = 0,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005562,
					["damage_taken"] = 0.005562,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["山脊巡行者"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["滚烫的雏龙"] = 0,
									["火烟食人魔法师"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["爪击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
									["山脊巡行者"] = 0,
									["詹迪斯·巴罗夫"] = 0,
									["滚烫的雏龙"] = 0,
									["火烟食人魔法师"] = 0,
									["传令官基尔图诺斯"] = 0,
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "爪击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 0.005562,
					["nome"] = "鲁总 <啪啪>",
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [34]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.002997,
					["damage_from"] = {
					},
					["targets"] = {
						["詹迪斯·巴罗夫"] = 0,
						["血骨傀儡"] = 0,
						["老鼠"] = 0,
						["莱斯·霜语"] = 0,
					},
					["serial"] = "Player-4920-01D6B7EB",
					["pets"] = {
					},
					["spec"] = 264,
					["on_hold"] = false,
					["classe"] = "SHAMAN",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002997,
					["boss_fight_component"] = true,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["friendlyfire"] = {
					},
					["last_event"] = 0,
					["nome"] = "琼琼宝贝",
					["spells"] = {
						["_ActorTable"] = {
							["烈焰震击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "烈焰震击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["血骨傀儡"] = 0,
									["老鼠"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["冰霜震击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["莱斯·霜语"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰霜震击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["total"] = 0.002997,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.002997,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [35]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.004661,
					["damage_from"] = {
					},
					["targets"] = {
						["朴不成"] = 0,
						["像只猴的你"] = 0,
						["琼琼宝贝"] = 0,
					},
					["pets"] = {
					},
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.004661,
					["serial"] = "Creature-0-4889-289-12207-11622-0000300FDF",
					["dps_started"] = false,
					["total"] = 0.004661,
					["last_dps"] = 0,
					["damage_taken"] = 0.004661,
					["nome"] = "血骨傀儡",
					["spells"] = {
						["_ActorTable"] = {
							["打击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["琼琼宝贝"] = 0,
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "打击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["击退"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "击退",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["琼琼宝贝"] = 0,
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["战争践踏"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["朴不成"] = 0,
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "战争践踏",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["monster"] = true,
				}, -- [36]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.001584,
					["damage_from"] = {
					},
					["targets"] = {
						["朴不成"] = 0,
						["像只猴的你"] = 0,
						["复活的构造体"] = 0,
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001584,
					["serial"] = "Creature-0-4889-289-12207-10488-0003300FDF",
					["dps_started"] = false,
					["total"] = 0.001584,
					["last_dps"] = 0,
					["damage_taken"] = 0.001584,
					["nome"] = "复活的构造体",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["横扫攻击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["朴不成"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "横扫攻击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["圆弧斩"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "圆弧斩",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["痛击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["复活的构造体"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "痛击",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["狂怒"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "狂怒",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["monster"] = true,
				}, -- [37]
				{
					["flag_original"] = 16657,
					["totalabsorbed"] = 0.005422,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.005422,
					["damage_taken"] = 0.005422,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["serial"] = "GameObject-0-4889-289-12207-164877-0000302007",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["冰冻陷阱效果"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["血骨傀儡"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "冰冻陷阱效果",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 0.005422,
					["nome"] = "冰冻陷阱 III",
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [38]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.003356,
					["damage_from"] = {
					},
					["targets"] = {
						["像只猴的你"] = 0,
						["幽魂无双"] = 0,
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.003356,
					["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
					["dps_started"] = false,
					["total"] = 0.003356,
					["last_dps"] = 0,
					["damage_taken"] = 0.003356,
					["nome"] = "传令官基尔图诺斯",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["缴械"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "缴械",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["拍翼"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "拍翼",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["飞扑"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
									["幽魂无双"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "飞扑",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["刺穿护甲"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "刺穿护甲",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["基尔图诺斯变形"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "基尔图诺斯变形",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["monster"] = true,
				}, -- [39]
				{
					["flag_original"] = 2632,
					["totalabsorbed"] = 0.002525,
					["damage_from"] = {
					},
					["targets"] = {
						["朴不成"] = 0,
						["像只猴的你"] = 0,
						["琼琼宝贝"] = 0,
					},
					["pets"] = {
					},
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002525,
					["serial"] = "Creature-0-4889-289-12207-10503-0000300FDF",
					["dps_started"] = false,
					["total"] = 0.002525,
					["last_dps"] = 0,
					["damage_taken"] = 0.002525,
					["nome"] = "詹迪斯·巴罗夫",
					["spells"] = {
						["_ActorTable"] = {
							["召唤幻象"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "召唤幻象",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
							["放逐术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "放逐术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["monster"] = true,
				}, -- [40]
				{
					["flag_original"] = 8776,
					["totalabsorbed"] = 0.006548,
					["damage_from"] = {
					},
					["targets"] = {
						["朴不成"] = 0,
						["琼琼宝贝"] = 0,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006548,
					["damage_taken"] = 0.006548,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["serial"] = "Creature-0-4889-289-12207-11439-0007301CAB",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["朴不成"] = 0,
									["琼琼宝贝"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 0.006548,
					["nome"] = "詹迪斯·巴罗夫的幻象 <詹迪斯·巴罗夫>",
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [41]
				{
					["flag_original"] = 2600,
					["totalabsorbed"] = 0.002428,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002428,
					["damage_taken"] = 0.002428,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["serial"] = "Creature-0-4889-289-12207-4075-0007B00FE0",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 0.002428,
					["nome"] = "老鼠",
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [42]
				{
					["flag_original"] = 8466,
					["totalabsorbed"] = 0.007751,
					["damage_from"] = {
					},
					["targets"] = {
						["詹迪斯·巴罗夫"] = 0,
					},
					["pets"] = {
					},
					["last_event"] = 0,
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.007751,
					["damage_taken"] = 0.007751,
					["dps_started"] = false,
					["end_time"] = 1588769236,
					["serial"] = "Creature-0-4889-289-12207-7845-0000301CB1",
					["last_dps"] = 0,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["火焰新星"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["詹迪斯·巴罗夫"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火焰新星",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["total"] = 0.007751,
					["nome"] = "火焰新星图腾 V <琼琼宝贝>",
					["custom"] = 0,
					["tipo"] = 1,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["friendlyfire_total"] = 0,
				}, -- [43]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.003367,
					["damage_from"] = {
					},
					["targets"] = {
						["啪啪"] = 0,
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.003367,
					["serial"] = "Creature-0-4504-0-4491-2731-00002FE6DF",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.003367,
					["nome"] = "山脊巡行者",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["啪啪"] = 0,
									["鲁总"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.003367,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [44]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.001041,
					["damage_from"] = {
					},
					["targets"] = {
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.001041,
					["serial"] = "Creature-0-4504-0-4491-2720-00003000A4",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.001041,
					["nome"] = "火烟食人魔法师",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["鲁总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.001041,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [45]
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.003263,
					["damage_from"] = {
					},
					["targets"] = {
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.003263,
					["serial"] = "Creature-0-4504-0-4491-2725-00002FFB6B",
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 0.003263,
					["nome"] = "滚烫的雏龙",
					["spells"] = {
						["_ActorTable"] = {
							["火球术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["鲁总"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "火球术",
								["r_dmg"] = 0,
								["a_dmg"] = 0,
								["m_crit"] = 0,
								["a_amt"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["r_amt"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_event"] = 0,
					["on_hold"] = false,
					["total"] = 0.003263,
					["custom"] = 0,
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["start_time"] = 1588769233,
					["delay"] = 0,
					["dps_started"] = false,
				}, -- [46]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.002813,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "DRUID",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.002813,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1588852916,
					["serial"] = "Player-4920-01F83CA4",
					["total"] = 0.002813,
					["nome"] = "熊心壮痣",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.002813,
					["start_time"] = 1588852913,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [47]
				{
					["flag_original"] = 1298,
					["totalabsorbed"] = 0.006485,
					["damage_from"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["on_hold"] = false,
					["classe"] = "MAGE",
					["raid_targets"] = {
					},
					["total_without_pet"] = 0.006485,
					["friendlyfire"] = {
					},
					["dps_started"] = false,
					["end_time"] = 1588852916,
					["serial"] = "Player-4920-01FC29F8",
					["total"] = 0.006485,
					["nome"] = "夏雨",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 2,
					},
					["grupo"] = true,
					["last_event"] = 0,
					["friendlyfire_total"] = 0,
					["custom"] = 0,
					["tipo"] = 1,
					["damage_taken"] = 0.006485,
					["start_time"] = 1588852913,
					["delay"] = 0,
					["last_dps"] = 0,
				}, -- [48]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
						["妩媚飒飒"] = 0,
						["遂于而安"] = 0,
						["窈窕淑"] = 0,
						["妖怪你别里跑"] = 0,
						["无常十号"] = 0,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 190585.059169,
					["total_without_pet"] = 63284.059169,
					["total"] = 63284.059169,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01DC68C3",
					["totalabsorb"] = 0.059169,
					["last_hps"] = 0,
					["targets"] = {
						["妩媚飒飒"] = 14169,
						["遂于而安"] = 4412,
						["窈窕淑"] = 16287,
						["妖怪你别里跑"] = 15611,
						["无常十号"] = 0,
					},
					["totalover_without_pet"] = 0.059169,
					["healing_taken"] = 1843.059169,
					["fight_component"] = true,
					["end_time"] = 1588652858,
					["classe"] = "PRIEST",
					["nome"] = "遂于而安",
					["spells"] = {
						["_ActorTable"] = {
							["神圣新星"] = {
								["c_amt"] = 69,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["妩媚飒飒"] = 24715,
									["遂于而安"] = 30528,
									["窈窕淑"] = 19562,
									["妖怪你别里跑"] = 23360,
									["无常十号"] = 21035,
								},
								["n_max"] = 442,
								["targets"] = {
									["妩媚飒飒"] = 6973,
									["遂于而安"] = 957,
									["窈窕淑"] = 10897,
									["妖怪你别里跑"] = 7838,
									["无常十号"] = 9507,
								},
								["n_min"] = 0,
								["counter"] = 340,
								["overheal"] = 119200,
								["total"] = 36172,
								["c_max"] = 639,
								["id"] = "神圣新星",
								["targets_absorbs"] = {
								},
								["c_curado"] = 6513,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 271,
								["n_curado"] = 29659,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
							["快速治疗"] = {
								["c_amt"] = 2,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["遂于而安"] = 6723,
									["无常十号"] = 3469,
								},
								["n_max"] = 1280,
								["targets"] = {
									["遂于而安"] = 344,
									["无常十号"] = 10422,
								},
								["n_min"] = 0,
								["counter"] = 18,
								["overheal"] = 10192,
								["total"] = 10766,
								["c_max"] = 949,
								["id"] = "快速治疗",
								["targets_absorbs"] = {
								},
								["c_curado"] = 949,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 16,
								["n_curado"] = 9817,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
							["治疗祷言"] = {
								["c_amt"] = 18,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["妩媚飒飒"] = 14199,
									["遂于而安"] = 14669,
									["窈窕淑"] = 15909,
									["妖怪你别里跑"] = 13208,
									["无常十号"] = 3208,
								},
								["n_max"] = 1220,
								["targets"] = {
									["妩媚飒飒"] = 1477,
									["遂于而安"] = 542,
									["窈窕淑"] = 957,
									["妖怪你别里跑"] = 1442,
									["无常十号"] = 11928,
								},
								["n_min"] = 0,
								["counter"] = 55,
								["overheal"] = 61193,
								["total"] = 16346,
								["c_max"] = 1782,
								["id"] = "治疗祷言",
								["targets_absorbs"] = {
								},
								["c_curado"] = 6787,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 37,
								["n_curado"] = 9559,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["healing_from"] = {
						["遂于而安"] = true,
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.059169,
					["start_time"] = 1588652645,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [1]
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.057606,
					["total_without_pet"] = 0.057606,
					["total"] = 0.057606,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01DC6F5E",
					["totalabsorb"] = 0.057606,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.057606,
					["healing_taken"] = 9280.057606,
					["fight_component"] = true,
					["end_time"] = 1588652858,
					["classe"] = "MAGE",
					["nome"] = "妖怪你别里跑",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["healing_from"] = {
						["遂于而安"] = true,
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.057606,
					["start_time"] = 1588652855,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [2]
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.066303,
					["total_without_pet"] = 0.066303,
					["total"] = 0.066303,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01DC6F13",
					["totalabsorb"] = 0.066303,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.066303,
					["healing_taken"] = 8450.066303,
					["fight_component"] = true,
					["end_time"] = 1588652858,
					["classe"] = "MAGE",
					["nome"] = "妩媚飒飒",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["healing_from"] = {
						["遂于而安"] = true,
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.066303,
					["start_time"] = 1588652855,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [3]
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.049634,
					["total_without_pet"] = 0.049634,
					["total"] = 0.049634,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01DC60BC",
					["totalabsorb"] = 0.049634,
					["last_hps"] = 0,
					["targets"] = {
					},
					["totalover_without_pet"] = 0.049634,
					["healing_taken"] = 11854.049634,
					["fight_component"] = true,
					["end_time"] = 1588652858,
					["classe"] = "MAGE",
					["nome"] = "窈窕淑",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["healing_from"] = {
						["遂于而安"] = true,
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.049634,
					["start_time"] = 1588652855,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [4]
				{
					["flag_original"] = 1300,
					["targets_overheal"] = {
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.064547,
					["total_without_pet"] = 295.064547,
					["total"] = 295.064547,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-020A7239",
					["totalabsorb"] = 0.064547,
					["last_hps"] = 0,
					["targets"] = {
						["无常十号"] = 0,
					},
					["totalover_without_pet"] = 0.064547,
					["healing_taken"] = 32152.064547,
					["fight_component"] = true,
					["end_time"] = 1588652858,
					["classe"] = "WARRIOR",
					["nome"] = "无常十号",
					["spells"] = {
						["_ActorTable"] = {
							["神圣力量"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 116,
								["targets"] = {
									["无常十号"] = 295,
								},
								["n_min"] = 0,
								["counter"] = 3,
								["overheal"] = 0,
								["total"] = 295,
								["c_max"] = 0,
								["id"] = "神圣力量",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["m_healed"] = 0,
								["c_min"] = 0,
								["totaldenied"] = 0,
								["n_amt"] = 3,
								["n_curado"] = 295,
								["m_amt"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["healing_from"] = {
						["遂于而安"] = true,
						["无常十号"] = true,
					},
					["boss_fight_component"] = true,
					["custom"] = 0,
					["tipo"] = 2,
					["totaldenied"] = 0.064547,
					["start_time"] = 1588652851,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [5]
				{
					["flag_original"] = 1297,
					["totalabsorb"] = 0.00547,
					["last_hps"] = 0,
					["targets_overheal"] = {
					},
					["targets"] = {
						["机总 <啪啪>"] = 0,
					},
					["serial"] = "Player-4920-01D0E17B",
					["pets"] = {
					},
					["totalover_without_pet"] = 0.00547,
					["healing_from"] = {
					},
					["classe"] = "HUNTER",
					["totalover"] = 0.00547,
					["total_without_pet"] = 0.00547,
					["iniciar_hps"] = false,
					["start_time"] = 1588769233,
					["heal_enemy_amt"] = 0,
					["total"] = 0.00547,
					["healing_taken"] = 0.00547,
					["end_time"] = 1588769236,
					["nome"] = "啪啪",
					["spec"] = 254,
					["grupo"] = true,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["spells"] = {
						["_ActorTable"] = {
							["治疗宠物"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 0,
								["targets"] = {
									["机总 <啪啪>"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗宠物",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["custom"] = 0,
					["tipo"] = 2,
					["on_hold"] = false,
					["totaldenied"] = 0.00547,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [6]
				{
					["flag_original"] = 4369,
					["totalabsorb"] = 0.006848,
					["last_hps"] = 0,
					["targets_overheal"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["totalover_without_pet"] = 0.006848,
					["healing_from"] = {
					},
					["classe"] = "PET",
					["totalover"] = 0.006848,
					["total_without_pet"] = 0.006848,
					["total"] = 0.006848,
					["iniciar_hps"] = false,
					["fight_component"] = true,
					["end_time"] = 1588769236,
					["healing_taken"] = 0.006848,
					["serial"] = "Pet-0-4504-0-173-4511-0100A60D85",
					["nome"] = "机总 <啪啪>",
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["targets_absorbs"] = {
					},
					["heal_enemy_amt"] = 0,
					["heal_enemy"] = {
					},
					["totaldenied"] = 0.006848,
					["custom"] = 0,
					["tipo"] = 2,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [7]
				{
					["flag_original"] = 1298,
					["targets_overheal"] = {
						["啪啪"] = 0,
						["朴不成"] = 0,
						["像只猴的你"] = 0,
						["琼琼宝贝"] = 0,
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["iniciar_hps"] = false,
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.005573,
					["total_without_pet"] = 0.005573,
					["total"] = 0.005573,
					["targets_absorbs"] = {
					},
					["heal_enemy"] = {
					},
					["on_hold"] = false,
					["serial"] = "Player-4920-01D6B7EB",
					["totalabsorb"] = 0.005573,
					["last_hps"] = 0,
					["targets"] = {
						["琼琼宝贝"] = 0,
						["啪啪"] = 0,
						["朴不成"] = 0,
						["幽魂无双"] = 0,
						["像只猴的你"] = 0,
						["鲁总 <啪啪>"] = 0,
					},
					["totalover_without_pet"] = 0.005573,
					["healing_taken"] = 0.005573,
					["end_time"] = 1588769236,
					["boss_fight_component"] = true,
					["healing_from"] = {
					},
					["nome"] = "琼琼宝贝",
					["spells"] = {
						["_ActorTable"] = {
							["次级治疗波"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 0,
								["targets"] = {
									["朴不成"] = 0,
									["像只猴的你"] = 0,
									["幽魂无双"] = 0,
									["琼琼宝贝"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "次级治疗波",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							["治疗链"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["啪啪"] = 0,
									["朴不成"] = 0,
									["像只猴的你"] = 0,
									["琼琼宝贝"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["啪啪"] = 0,
									["朴不成"] = 0,
									["像只猴的你"] = 0,
									["琼琼宝贝"] = 0,
									["鲁总 <啪啪>"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗链",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
							["治疗波"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
								},
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗波",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["grupo"] = true,
					["tipo"] = 2,
					["start_time"] = 1588769233,
					["custom"] = 0,
					["last_event"] = 0,
					["classe"] = "SHAMAN",
					["totaldenied"] = 0.005573,
					["delay"] = 0,
					["spec"] = 264,
				}, -- [8]
				{
					["flag_original"] = 4369,
					["totalabsorb"] = 0.006057,
					["last_hps"] = 0,
					["targets_overheal"] = {
					},
					["targets"] = {
					},
					["pets"] = {
					},
					["totalover_without_pet"] = 0.006057,
					["healing_from"] = {
					},
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.006057,
					["total_without_pet"] = 0.006057,
					["total"] = 0.006057,
					["iniciar_hps"] = false,
					["healing_taken"] = 0.006057,
					["end_time"] = 1588769236,
					["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
					["nome"] = "鲁总 <啪啪>",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["last_event"] = 0,
					["classe"] = "PET",
					["heal_enemy"] = {
					},
					["targets_absorbs"] = {
					},
					["custom"] = 0,
					["tipo"] = 2,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["totaldenied"] = 0.006057,
				}, -- [9]
				{
					["flag_original"] = 1298,
					["totalabsorb"] = 0.003186,
					["last_hps"] = 0,
					["targets_overheal"] = {
					},
					["targets"] = {
					},
					["healing_taken"] = 0.003186,
					["pets"] = {
					},
					["totalover_without_pet"] = 0.003186,
					["healing_from"] = {
					},
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.003186,
					["total_without_pet"] = 0.003186,
					["iniciar_hps"] = false,
					["start_time"] = 1588769233,
					["classe"] = "ROGUE",
					["total"] = 0.003186,
					["end_time"] = 1588769236,
					["nome"] = "朴不成",
					["boss_fight_component"] = true,
					["targets_absorbs"] = {
					},
					["grupo"] = true,
					["serial"] = "Player-4920-01F19A55",
					["heal_enemy"] = {
					},
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["custom"] = 0,
					["tipo"] = 2,
					["on_hold"] = false,
					["totaldenied"] = 0.003186,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [10]
				{
					["flag_original"] = 1298,
					["totalabsorb"] = 0.004129,
					["last_hps"] = 0,
					["targets_overheal"] = {
						["像只猴的你"] = 0,
					},
					["targets"] = {
						["像只猴的你"] = 0,
					},
					["healing_taken"] = 0.004129,
					["pets"] = {
					},
					["totalover_without_pet"] = 0.004129,
					["healing_from"] = {
					},
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.004129,
					["total_without_pet"] = 0.004129,
					["iniciar_hps"] = false,
					["start_time"] = 1588769233,
					["classe"] = "WARRIOR",
					["total"] = 0.004129,
					["end_time"] = 1588769236,
					["nome"] = "像只猴的你",
					["boss_fight_component"] = true,
					["targets_absorbs"] = {
					},
					["grupo"] = true,
					["serial"] = "Player-4920-01D50132",
					["heal_enemy"] = {
					},
					["spells"] = {
						["_ActorTable"] = {
							["嗜血"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["像只猴的你"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "嗜血",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["custom"] = 0,
					["tipo"] = 2,
					["on_hold"] = false,
					["totaldenied"] = 0.004129,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [11]
				{
					["flag_original"] = 8466,
					["totalabsorb"] = 0.005529,
					["last_hps"] = 0,
					["targets_overheal"] = {
						["治疗之泉图腾 IV <琼琼宝贝>"] = 0,
						["啪啪"] = 0,
						["朴不成"] = 0,
						["幽魂无双"] = 0,
						["鲁总 <啪啪>"] = 0,
						["琼琼宝贝"] = 0,
					},
					["targets"] = {
						["朴不成"] = 0,
						["像只猴的你"] = 0,
						["幽魂无双"] = 0,
						["鲁总 <啪啪>"] = 0,
					},
					["pets"] = {
					},
					["totalover_without_pet"] = 0.005529,
					["healing_from"] = {
					},
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.005529,
					["total_without_pet"] = 0.005529,
					["total"] = 0.005529,
					["iniciar_hps"] = false,
					["healing_taken"] = 0.005529,
					["end_time"] = 1588769236,
					["serial"] = "Creature-0-4889-289-12207-3908-0000301D68",
					["nome"] = "治疗之泉图腾 IV <琼琼宝贝>",
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["治疗之泉"] = {
								["c_amt"] = 0,
								["totalabsorb"] = 0,
								["targets_overheal"] = {
									["治疗之泉图腾 IV <琼琼宝贝>"] = 0,
									["啪啪"] = 0,
									["朴不成"] = 0,
									["幽魂无双"] = 0,
									["鲁总 <啪啪>"] = 0,
									["琼琼宝贝"] = 0,
								},
								["n_max"] = 0,
								["targets"] = {
									["治疗之泉图腾 IV <琼琼宝贝>"] = 0,
									["鲁总 <啪啪>"] = 0,
									["啪啪"] = 0,
									["朴不成"] = 0,
									["幽魂无双"] = 0,
									["像只猴的你"] = 0,
									["琼琼宝贝"] = 0,
								},
								["n_min"] = 0,
								["counter"] = 0,
								["overheal"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗之泉",
								["targets_absorbs"] = {
								},
								["c_curado"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["n_curado"] = 0,
								["n_amt"] = 0,
								["totaldenied"] = 0,
								["m_healed"] = 0,
								["absorbed"] = 0,
							},
						},
						["tipo"] = 3,
					},
					["last_event"] = 0,
					["classe"] = "PET",
					["heal_enemy"] = {
					},
					["targets_absorbs"] = {
					},
					["custom"] = 0,
					["tipo"] = 2,
					["on_hold"] = false,
					["start_time"] = 1588769233,
					["delay"] = 0,
					["totaldenied"] = 0.005529,
				}, -- [12]
				{
					["flag_original"] = 1298,
					["totalabsorb"] = 0.00692,
					["last_hps"] = 0,
					["targets_overheal"] = {
					},
					["targets"] = {
					},
					["healing_taken"] = 0.00692,
					["pets"] = {
					},
					["totalover_without_pet"] = 0.00692,
					["healing_from"] = {
					},
					["heal_enemy_amt"] = 0,
					["totalover"] = 0.00692,
					["total_without_pet"] = 0.00692,
					["iniciar_hps"] = false,
					["start_time"] = 1588769233,
					["classe"] = "MAGE",
					["total"] = 0.00692,
					["end_time"] = 1588769236,
					["nome"] = "幽魂无双",
					["boss_fight_component"] = true,
					["targets_absorbs"] = {
					},
					["grupo"] = true,
					["serial"] = "Player-4920-01ECB17B",
					["heal_enemy"] = {
					},
					["spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 3,
					},
					["custom"] = 0,
					["tipo"] = 2,
					["on_hold"] = false,
					["totaldenied"] = 0.00692,
					["delay"] = 0,
					["last_event"] = 0,
				}, -- [13]
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
				{
					["flag_original"] = 1300,
					["resource"] = 0.107169,
					["targets"] = {
						["无常十号"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "WARRIOR",
					["totalover"] = 0.00131,
					["fight_component"] = true,
					["alternatepower"] = 0.071949,
					["nome"] = "无常十号",
					["spells"] = {
						["_ActorTable"] = {
							["力量"] = {
								["total"] = 44,
								["id"] = "力量",
								["totalover"] = 0,
								["targets"] = {
									["无常十号"] = 0,
								},
								["counter"] = 44,
							},
							["盾牌专精"] = {
								["total"] = 48,
								["id"] = "盾牌专精",
								["totalover"] = 0,
								["targets"] = {
									["无常十号"] = 0,
								},
								["counter"] = 48,
							},
							["怒不可遏"] = {
								["total"] = 14,
								["id"] = "怒不可遏",
								["totalover"] = 0,
								["targets"] = {
									["无常十号"] = 0,
								},
								["counter"] = 14,
							},
							["血性狂暴"] = {
								["total"] = 170,
								["id"] = "血性狂暴",
								["totalover"] = 0,
								["targets"] = {
									["无常十号"] = 0,
								},
								["counter"] = 100,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["boss_fight_component"] = true,
					["tipo"] = 3,
					["last_event"] = 0,
					["total"] = 276.071949,
					["passiveover"] = 0.00131,
					["serial"] = "Player-4920-020A7239",
					["received"] = 276.071949,
				}, -- [1]
				{
					["flag_original"] = 1300,
					["resource"] = 0.078627,
					["targets"] = {
						["妖怪你别里跑"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["totalover"] = 0.002279,
					["fight_component"] = true,
					["alternatepower"] = 0.051232,
					["nome"] = "妖怪你别里跑",
					["spells"] = {
						["_ActorTable"] = {
							["元素大师"] = {
								["total"] = 2895,
								["id"] = "元素大师",
								["totalover"] = 0,
								["targets"] = {
									["妖怪你别里跑"] = 0,
								},
								["counter"] = 12,
							},
							["补充法力"] = {
								["total"] = 1053,
								["id"] = "补充法力",
								["totalover"] = 0,
								["targets"] = {
									["妖怪你别里跑"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["boss_fight_component"] = true,
					["tipo"] = 3,
					["last_event"] = 0,
					["total"] = 3948.051232,
					["passiveover"] = 0.002279,
					["serial"] = "Player-4920-01DC6F5E",
					["received"] = 3948.051232,
				}, -- [2]
				{
					["flag_original"] = 1300,
					["resource"] = 0.080843,
					["targets"] = {
						["妩媚飒飒"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["totalover"] = 0.0084,
					["fight_component"] = true,
					["alternatepower"] = 0.061308,
					["nome"] = "妩媚飒飒",
					["spells"] = {
						["_ActorTable"] = {
							["元素大师"] = {
								["total"] = 3689,
								["id"] = "元素大师",
								["totalover"] = 0,
								["targets"] = {
									["妩媚飒飒"] = 0,
								},
								["counter"] = 18,
							},
							["补充法力"] = {
								["total"] = 1143,
								["id"] = "补充法力",
								["totalover"] = 0,
								["targets"] = {
									["妩媚飒飒"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["boss_fight_component"] = true,
					["tipo"] = 3,
					["last_event"] = 0,
					["total"] = 4832.061308,
					["passiveover"] = 0.0084,
					["serial"] = "Player-4920-01DC6F13",
					["received"] = 4832.061308,
				}, -- [3]
				{
					["flag_original"] = 1300,
					["resource"] = 0.065641,
					["targets"] = {
						["窈窕淑"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["totalover"] = 0.002663,
					["fight_component"] = true,
					["alternatepower"] = 0.060041,
					["nome"] = "窈窕淑",
					["spells"] = {
						["_ActorTable"] = {
							["元素大师"] = {
								["total"] = 2684,
								["id"] = "元素大师",
								["totalover"] = 0,
								["targets"] = {
									["窈窕淑"] = 0,
								},
								["counter"] = 13,
							},
							["补充法力"] = {
								["total"] = 1087,
								["id"] = "补充法力",
								["totalover"] = 0,
								["targets"] = {
									["窈窕淑"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["boss_fight_component"] = true,
					["tipo"] = 3,
					["last_event"] = 0,
					["total"] = 3771.060041,
					["passiveover"] = 0.002663,
					["serial"] = "Player-4920-01DC60BC",
					["received"] = 3771.060041,
				}, -- [4]
				{
					["received"] = 847.006884,
					["resource"] = 0.119309,
					["targets"] = {
						["啪啪"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "HUNTER",
					["passiveover"] = 0.00235,
					["total"] = 847.006884,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["恢复法力"] = {
								["total"] = 847,
								["id"] = "恢复法力",
								["totalover"] = 0,
								["targets"] = {
									["啪啪"] = 0,
								},
								["counter"] = 1,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["totalover"] = 0.00235,
					["spec"] = 254,
					["last_event"] = 0,
					["tipo"] = 3,
					["alternatepower"] = 0.006884,
					["flag_original"] = 1297,
					["serial"] = "Player-4920-01D0E17B",
					["nome"] = "啪啪",
				}, -- [5]
				{
					["received"] = 0.00548,
					["resource"] = 0.10491,
					["targets"] = {
						["琼琼宝贝"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "SHAMAN",
					["passiveover"] = 0.00548,
					["total"] = 0.00548,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["法力澎湃"] = {
								["total"] = 0,
								["id"] = "法力澎湃",
								["totalover"] = 0,
								["targets"] = {
									["琼琼宝贝"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["nome"] = "琼琼宝贝",
					["alternatepower"] = 0.00548,
					["spec"] = 264,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D6B7EB",
					["totalover"] = 0.00548,
				}, -- [6]
				{
					["received"] = 0.007072,
					["resource"] = 0.082162,
					["targets"] = {
						["幽魂无双"] = 0,
						["啪啪"] = 0,
						["琼琼宝贝"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "PET",
					["passiveover"] = 0.007072,
					["total"] = 0.007072,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["法力之泉"] = {
								["total"] = 0,
								["id"] = "法力之泉",
								["totalover"] = 0,
								["targets"] = {
									["幽魂无双"] = 0,
									["啪啪"] = 0,
									["琼琼宝贝"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["nome"] = "法力之泉图腾 IV <琼琼宝贝>",
					["alternatepower"] = 0.007072,
					["tipo"] = 3,
					["flag_original"] = 8466,
					["last_event"] = 0,
					["serial"] = "Creature-0-4889-289-12207-7416-00003021A0",
					["totalover"] = 0.007072,
				}, -- [7]
				{
					["received"] = 0.007816,
					["resource"] = 0.102606,
					["targets"] = {
						["幽魂无双"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 0,
					["classe"] = "MAGE",
					["passiveover"] = 0.007816,
					["total"] = 0.007816,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["元素大师"] = {
								["total"] = 0,
								["id"] = "元素大师",
								["totalover"] = 0,
								["targets"] = {
									["幽魂无双"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["nome"] = "幽魂无双",
					["alternatepower"] = 0.007816,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["last_event"] = 0,
					["serial"] = "Player-4920-01ECB17B",
					["totalover"] = 0.007816,
				}, -- [8]
				{
					["received"] = 0.003206,
					["resource"] = 0.152061,
					["targets"] = {
						["像只猴的你"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 1,
					["classe"] = "WARRIOR",
					["passiveover"] = 0.003206,
					["total"] = 0.003206,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["怒不可遏"] = {
								["total"] = 0,
								["id"] = "怒不可遏",
								["totalover"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["counter"] = 0,
							},
							["血性狂暴"] = {
								["total"] = 0,
								["id"] = "血性狂暴",
								["totalover"] = 0,
								["targets"] = {
									["像只猴的你"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["nome"] = "像只猴的你",
					["alternatepower"] = 0.003206,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["last_event"] = 0,
					["serial"] = "Player-4920-01D50132",
					["totalover"] = 0.003206,
				}, -- [9]
				{
					["received"] = 0.00858,
					["resource"] = 0.07672,
					["targets"] = {
						["朴不成"] = 0,
					},
					["pets"] = {
					},
					["powertype"] = 3,
					["classe"] = "ROGUE",
					["passiveover"] = 0.00858,
					["total"] = 0.00858,
					["boss_fight_component"] = true,
					["spells"] = {
						["_ActorTable"] = {
							["无情打击效果"] = {
								["total"] = 0,
								["id"] = "无情打击效果",
								["totalover"] = 0,
								["targets"] = {
									["朴不成"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 7,
					},
					["grupo"] = true,
					["nome"] = "朴不成",
					["alternatepower"] = 0.00858,
					["tipo"] = 3,
					["flag_original"] = 1298,
					["last_event"] = 0,
					["serial"] = "Player-4920-01F19A55",
					["totalover"] = 0.00858,
				}, -- [10]
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["嘲讽"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 11,
								["id"] = "嘲讽",
								["uptime"] = 33,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["挫志怒吼"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 35,
								["id"] = "挫志怒吼",
								["uptime"] = 153,
								["targets"] = {
								},
								["refreshamt"] = 12,
							},
							["破甲攻击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 6,
								["id"] = "破甲攻击",
								["uptime"] = 73,
								["targets"] = {
								},
								["refreshamt"] = 2,
							},
							["挑战怒吼"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = "挑战怒吼",
								["uptime"] = 6,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["战争践踏"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = "战争践踏",
								["uptime"] = 2,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["dispell"] = 1.003684,
					["buff_uptime"] = 810,
					["classe"] = "WARRIOR",
					["pets"] = {
					},
					["dispell_oque"] = {
						["多彩混乱"] = 1,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							["盾牌猛击"] = {
								["targets"] = {
									["盖斯"] = 1,
								},
								["id"] = "盾牌猛击",
								["dispell_oque"] = {
									["多彩混乱"] = 1,
								},
								["dispell"] = 1,
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 267,
					["dispell_targets"] = {
						["盖斯"] = 1,
					},
					["boss_fight_component"] = true,
					["grupo"] = true,
					["spell_cast"] = {
						["英勇打击"] = 4,
						["盾牌猛击"] = 38,
						["防御姿态"] = 2,
						["战争践踏"] = 1,
						["盾墙"] = 1,
						["嘲讽"] = 12,
						["挑战怒吼"] = 1,
						["挫志怒吼"] = 15,
						["破甲攻击"] = 10,
						["复仇"] = 27,
						["狂暴姿态"] = 2,
						["血性狂暴"] = 5,
					},
					["nome"] = "无常十号",
					["tipo"] = 4,
					["last_event"] = 0,
					["debuff_uptime_targets"] = {
					},
					["buff_uptime_targets"] = {
					},
					["serial"] = "Player-4920-020A7239",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["意志之力"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "意志之力",
								["uptime"] = 10,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["盾墙"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "盾墙",
								["uptime"] = 15,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["防御姿态"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = 2,
								["uptime"] = 0,
								["id"] = "防御姿态",
								["appliedamt"] = 2,
								["targets"] = {
								},
								["actived_at"] = 3177306378,
							},
							["敏捷"] = {
								["counter"] = 0,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = "敏捷",
								["uptime"] = 272,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["血性狂暴"] = {
								["counter"] = 0,
								["activedamt"] = 12,
								["appliedamt"] = 12,
								["id"] = "血性狂暴",
								["uptime"] = 89,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["精神错乱"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "精神错乱",
								["uptime"] = 376,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["神圣力量"] = {
								["counter"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = "神圣力量",
								["uptime"] = 32,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["狂暴姿态"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 1588652978,
								["id"] = "狂暴姿态",
								["uptime"] = 1,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["伊森哈德之怒"] = {
								["counter"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = "伊森哈德之怒",
								["uptime"] = 15,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
				}, -- [1]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["烈焰风暴"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 38,
								["id"] = "烈焰风暴",
								["uptime"] = 80,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冲击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 4,
								["id"] = "冲击",
								["uptime"] = 7,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["火球术"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 12,
								["id"] = "火球术",
								["uptime"] = 99,
								["targets"] = {
								},
								["refreshamt"] = 20,
							},
							["冲击波"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 8,
								["id"] = "冲击波",
								["uptime"] = 11,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["点燃"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 11,
								["id"] = "点燃",
								["uptime"] = 35,
								["targets"] = {
								},
								["refreshamt"] = 7,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 0,
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["进食"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177305721,
								["id"] = "进食",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["喝水"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177305721,
								["id"] = "喝水",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 232,
					["boss_fight_component"] = true,
					["grupo"] = true,
					["spell_cast"] = {
						["烈焰风暴"] = 10,
						["火焰冲击"] = 6,
						["火球术"] = 34,
						["冲击波"] = 10,
						["魔爆术"] = 64,
						["补充法力"] = 1,
					},
					["pets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["nome"] = "窈窕淑",
					["tipo"] = 4,
					["serial"] = "Player-4920-01DC60BC",
					["buff_uptime_targets"] = {
					},
				}, -- [2]
				{
					["flag_original"] = 1300,
					["dispell"] = 1.00671,
					["pets"] = {
					},
					["classe"] = "PRIEST",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["喝水"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177305721,
								["id"] = "喝水",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["心灵专注"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "心灵专注",
								["uptime"] = 17,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["灵感"] = {
								["counter"] = 0,
								["activedamt"] = 3,
								["appliedamt"] = 3,
								["id"] = "灵感",
								["uptime"] = 45,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["dispell_spells"] = {
						["_ActorTable"] = {
							["驱散魔法"] = {
								["targets"] = {
									["无常十号"] = 1,
								},
								["id"] = "驱散魔法",
								["dispell_oque"] = {
									["冰冻术"] = 1,
								},
								["dispell"] = 1,
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["dispell_oque"] = {
						["冰冻术"] = 1,
					},
					["boss_fight_component"] = true,
					["grupo"] = true,
					["spell_cast"] = {
						["心灵专注"] = 1,
						["治疗祷言"] = 11,
						["驱散魔法"] = 1,
						["快速治疗"] = 18,
						["神圣新星"] = 68,
					},
					["buff_uptime"] = 62,
					["tipo"] = 4,
					["last_event"] = 0,
					["nome"] = "遂于而安",
					["dispell_targets"] = {
						["无常十号"] = 1,
					},
					["serial"] = "Player-4920-01DC68C3",
					["buff_uptime_targets"] = {
					},
				}, -- [3]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["烈焰风暴"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 42,
								["id"] = "烈焰风暴",
								["uptime"] = 78,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冲击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 6,
								["id"] = "冲击",
								["uptime"] = 10,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["火球术"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 11,
								["id"] = "火球术",
								["uptime"] = 96,
								["targets"] = {
								},
								["refreshamt"] = 20,
							},
							["冲击波"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 10,
								["id"] = "冲击波",
								["uptime"] = 13,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰冻"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 9,
								["id"] = "冰冻",
								["uptime"] = 45,
								["targets"] = {
								},
								["refreshamt"] = 3,
							},
							["点燃"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 14,
								["id"] = "点燃",
								["uptime"] = 40,
								["targets"] = {
								},
								["refreshamt"] = 3,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 752,
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["进食"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177305721,
								["id"] = "进食",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["喝水"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177305721,
								["id"] = "喝水",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["奥术光辉"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "奥术光辉",
								["uptime"] = 376,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰甲术"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "冰甲术",
								["uptime"] = 376,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 282,
					["boss_fight_component"] = true,
					["grupo"] = true,
					["spell_cast"] = {
						["烈焰风暴"] = 10,
						["火焰冲击"] = 6,
						["火球术"] = 35,
						["冲击波"] = 9,
						["魔爆术"] = 65,
						["补充法力"] = 1,
					},
					["pets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["nome"] = "妩媚飒飒",
					["tipo"] = 4,
					["serial"] = "Player-4920-01DC6F13",
					["buff_uptime_targets"] = {
					},
				}, -- [4]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["冰冻"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 15,
								["id"] = "冰冻",
								["uptime"] = 41,
								["targets"] = {
								},
								["refreshamt"] = 5,
							},
							["冲击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 6,
								["id"] = "冲击",
								["uptime"] = 10,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["火球术"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 14,
								["id"] = "火球术",
								["uptime"] = 103,
								["targets"] = {
								},
								["refreshamt"] = 19,
							},
							["冲击波"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 7,
								["id"] = "冲击波",
								["uptime"] = 24,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["烈焰风暴"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 35,
								["id"] = "烈焰风暴",
								["uptime"] = 70,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["点燃"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 12,
								["id"] = "点燃",
								["uptime"] = 36,
								["targets"] = {
								},
								["refreshamt"] = 7,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 376,
					["classe"] = "MAGE",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["喝水"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177305721,
								["id"] = "喝水",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["进食"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177305721,
								["id"] = "进食",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["冰甲术"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "冰甲术",
								["uptime"] = 376,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["fight_component"] = true,
					["debuff_uptime"] = 284,
					["boss_fight_component"] = true,
					["grupo"] = true,
					["spell_cast"] = {
						["烈焰风暴"] = 9,
						["火焰冲击"] = 2,
						["火球术"] = 35,
						["冲击波"] = 9,
						["魔爆术"] = 66,
						["补充法力"] = 1,
					},
					["pets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["nome"] = "妖怪你别里跑",
					["tipo"] = 4,
					["serial"] = "Player-4920-01DC6F5E",
					["buff_uptime_targets"] = {
					},
				}, -- [5]
				{
					["flag_original"] = 1300,
					["nome"] = "花姐",
					["grupo"] = true,
					["buff_uptime_targets"] = {
					},
					["pets"] = {
					},
					["classe"] = "ROGUE",
					["buff_uptime"] = 648,
					["tipo"] = 4,
					["last_event"] = 0,
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["精神错乱"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "精神错乱",
								["uptime"] = 376,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["潜行"] = {
								["counter"] = 0,
								["activedamt"] = 9,
								["appliedamt"] = 9,
								["id"] = "潜行",
								["uptime"] = 272,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Player-4920-01D0BF72",
					["boss_fight_component"] = true,
				}, -- [6]
				{
					["flag_original"] = 1300,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["毒蛇钉刺"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 22,
								["id"] = "毒蛇钉刺",
								["uptime"] = 240,
								["targets"] = {
								},
								["refreshamt"] = 1,
							},
							["冰霜陷阱光环"] = {
								["counter"] = 0,
								["appliedamt"] = 1,
								["activedamt"] = -8,
								["actived_at"] = 3177306965,
								["id"] = "冰霜陷阱光环",
								["uptime"] = 13,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["眩晕"] = {
								["id"] = "眩晕",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["摔绊"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = "摔绊",
								["uptime"] = 7,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["强化摔绊"] = {
								["id"] = "强化摔绊",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["震荡射击"] = {
								["id"] = "震荡射击",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["破甲虚弱"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 2,
								["id"] = "破甲虚弱",
								["uptime"] = 12,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["猎人印记"] = {
								["counter"] = 0,
								["refreshamt"] = 0,
								["activedamt"] = -2,
								["uptime"] = 213,
								["id"] = "猎人印记",
								["appliedamt"] = 9,
								["targets"] = {
								},
								["actived_at"] = 3177306991,
							},
							["驱散射击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = "驱散射击",
								["uptime"] = 1,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["生命的恩赐"] = {
								["id"] = "生命的恩赐",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 833,
					["classe"] = "HUNTER",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["猎豹守护"] = {
								["id"] = "猎豹守护",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["喝水"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 3177306659,
								["id"] = "喝水",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["强击光环"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "强击光环",
								["uptime"] = 376,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["强效敏捷"] = {
								["id"] = "强效敏捷",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["狂暴"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "狂暴",
								["uptime"] = 10,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["急速射击"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "急速射击",
								["uptime"] = 15,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["野性守护"] = {
								["id"] = "野性守护",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["快速射击"] = {
								["counter"] = 0,
								["activedamt"] = 5,
								["appliedamt"] = 5,
								["id"] = "快速射击",
								["uptime"] = 48,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["雄鹰守护"] = {
								["counter"] = 0,
								["activedamt"] = 13,
								["appliedamt"] = 13,
								["id"] = "雄鹰守护",
								["uptime"] = 376,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["狂怒之嚎"] = {
								["counter"] = 0,
								["appliedamt"] = 2,
								["activedamt"] = 2,
								["actived_at"] = 1588652985,
								["id"] = "狂怒之嚎",
								["uptime"] = 8,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["绿色骸骨战马"] = {
								["id"] = "绿色骸骨战马",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 486,
					["boss_fight_component"] = true,
					["spec"] = 254,
					["grupo"] = true,
					["spell_cast"] = {
						["自动射击"] = 94,
						["瞄准射击"] = 20,
						["强击光环"] = 0,
						["狂暴"] = 1,
						["震荡射击"] = 1,
						["猎人印记"] = 8,
						["多重射击"] = 24,
						["猎豹守护"] = 0,
						["摔绊"] = 1,
						["驱散射击"] = 1,
						["铁皮手雷"] = 0,
						["治疗宠物"] = 0,
						["冰冻陷阱"] = 0,
						["冰霜陷阱"] = 0,
						["奥术射击"] = 1,
						["急速射击"] = 1,
						["猛禽一击"] = 1,
						["毒蛇钉刺"] = 23,
						["雄鹰守护"] = 0,
						["恢复法力"] = 1,
						["生命的恩赐"] = 0,
					},
					["debuff_uptime_targets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["pets"] = {
						"狼 <啪啪>", -- [1]
					},
					["nome"] = "啪啪",
					["serial"] = "Player-4920-01D0E17B",
					["buff_uptime_targets"] = {
					},
				}, -- [7]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "狂爪火鳞龙人",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-4504-229-31332-10083-0000B0E418",
					["spell_cast"] = {
						["火焰新星"] = 2,
						["烈焰风暴"] = 2,
						["连珠火球"] = 2,
					},
				}, -- [8]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "狂爪龙人",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-4504-229-31332-9096-0000B0E418",
					["spell_cast"] = {
						["凝视"] = 2,
						["破甲攻击"] = 6,
						["打击"] = 2,
						["痛击"] = 5,
						["狂怒"] = 3,
					},
				}, -- [9]
				{
					["flag_original"] = 4369,
					["ownerName"] = "啪啪",
					["nome"] = "狼 <啪啪>",
					["spell_cast"] = {
						["低吼"] = 6,
						["撕咬"] = 3,
						["狂怒之嚎"] = 4,
						["突进"] = 2,
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["classe"] = "PET",
					["serial"] = "Pet-0-4504-0-58-9696-0200BA6F1B",
					["pets"] = {
					},
				}, -- [10]
				{
					["flag_original"] = 2632,
					["last_event"] = 0,
					["fight_component"] = true,
					["interrupt"] = 1.001195,
					["interrupt_targets"] = {
						["妖怪你别里跑"] = 1,
					},
					["monster"] = true,
					["nome"] = "黑手老兵",
					["spell_cast"] = {
						["打击"] = 1,
						["盾击"] = 3,
						["盾牌冲锋"] = 1,
					},
					["tipo"] = 4,
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["盾击"] = {
								["id"] = "盾击",
								["counter"] = 1,
								["targets"] = {
									["妖怪你别里跑"] = 1,
								},
								["interrompeu_oque"] = {
									["烈焰风暴"] = 1,
								},
							},
						},
						["tipo"] = 9,
					},
					["serial"] = "Creature-0-4504-229-31332-9819-000730E417",
					["interrompeu_oque"] = {
						["烈焰风暴"] = 1,
					},
				}, -- [11]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "黑手精英",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-4504-229-31332-10317-0000B0E417",
					["spell_cast"] = {
						["打击"] = 1,
						["反手一击"] = 1,
					},
				}, -- [12]
				{
					["fight_component"] = true,
					["classe"] = "UNKNOW",
					["nome"] = "多彩龙人",
					["spell_cast"] = {
						["打击"] = 7,
						["顺劈斩"] = 12,
					},
					["last_event"] = 0,
					["monster"] = true,
					["tipo"] = 4,
					["pets"] = {
					},
					["serial"] = "Creature-0-4504-229-31332-10447-000030E417",
					["flag_original"] = 68168,
				}, -- [13]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "多彩雏龙",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-4504-229-31332-10442-000130E417",
					["spell_cast"] = {
						["闪电箭"] = 5,
						["寒冰箭"] = 5,
					},
				}, -- [14]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "黑手驭龙者",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-4504-229-31332-10742-000030ED78",
					["spell_cast"] = {
						["治疗龙类"] = 2,
					},
				}, -- [15]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "盖斯",
					["pets"] = {
						"大酋长雷德·黑手 <盖斯>", -- [1]
						"致死打击 <盖斯>", -- [2]
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 68168,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
					["spell_cast"] = {
						["腐蚀酸液吐息"] = 1,
						["冰冻术"] = 2,
						["击退"] = 2,
						["火息术"] = 2,
						["召唤雷德·黑手"] = 1,
					},
				}, -- [16]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "维克多·奈法里奥斯",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 2632,
					["tipo"] = 4,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4504-229-31332-10162-000030E418",
					["spell_cast"] = {
						["多彩混乱"] = 1,
					},
				}, -- [17]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 14,
					["spellschool"] = 16,
					["nome"] = "冰冻术",
					["debuff_uptime_targets"] = {
						["无常十号"] = {
							["uptime"] = 14,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["damage_twin"] = "盖斯",
					["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
					["damage_spellid"] = "冰冻术",
					["boss_fight_component"] = true,
				}, -- [18]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 30,
					["spellschool"] = 8,
					["nome"] = "腐蚀酸液吐息",
					["debuff_uptime_targets"] = {
						["无常十号"] = {
							["uptime"] = 30,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["damage_twin"] = "盖斯",
					["serial"] = "Creature-0-4504-229-31332-10339-000030EE70",
					["damage_spellid"] = "腐蚀酸液吐息",
					["boss_fight_component"] = true,
				}, -- [19]
				{
					["flag_original"] = 68168,
					["classe"] = "UNKNOW",
					["ownerName"] = "盖斯",
					["boss_fight_component"] = true,
					["pets"] = {
					},
					["tipo"] = 4,
					["monster"] = true,
					["last_event"] = 0,
					["spell_cast"] = {
						["致死打击"] = 1,
						["顺劈斩"] = 1,
						["旋风斩"] = 4,
					},
					["serial"] = "Creature-0-4504-229-31332-10429-000030EEA0",
					["nome"] = "大酋长雷德·黑手 <盖斯>",
				}, -- [20]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 5,
					["spellschool"] = 1,
					["ownerName"] = "盖斯",
					["nome"] = "致死打击 <盖斯>",
					["tipo"] = 4,
					["serial"] = "Creature-0-4504-229-31332-10429-000030EEA0",
					["last_event"] = 0,
					["damage_twin"] = "大酋长雷德·黑手",
					["boss_fight_component"] = true,
					["damage_spellid"] = "致死打击",
					["debuff_uptime_targets"] = {
						["无常十号"] = {
							["uptime"] = 5,
							["refreshamt"] = 0,
							["activedamt"] = 0,
							["actived"] = false,
							["appliedamt"] = 0,
						},
					},
				}, -- [21]
				{
					["flag_original"] = 1047,
					["pets"] = {
					},
					["classe"] = "ROGUE",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["脚踢"] = {
								["id"] = "脚踢",
								["interrompeu_oque"] = {
								},
								["targets"] = {
									["詹迪斯·巴罗夫"] = 0,
									["莱斯·霜语"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["剑刃乱舞"] = {
								["id"] = "剑刃乱舞",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冲动"] = {
								["id"] = "冲动",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["切割"] = {
								["id"] = "切割",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["风怒图腾"] = {
								["id"] = "风怒图腾",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["疾跑"] = {
								["id"] = "疾跑",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["闪避"] = {
								["id"] = "闪避",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["interrompeu_oque"] = {
					},
					["interrupt"] = 0,
					["interrupt_targets"] = {
						["詹迪斯·巴罗夫"] = 0,
						["莱斯·霜语"] = 0,
					},
					["grupo"] = true,
					["spell_cast"] = {
						["脚踢"] = 0,
						["背刺"] = 0,
						["邪恶攻击"] = 0,
						["剑刃乱舞"] = 0,
						["冲动"] = 0,
						["切割"] = 0,
						["肾击"] = 0,
						["刺骨"] = 0,
						["疾跑"] = 0,
						["闪避"] = 0,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 0,
					["tipo"] = 4,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Player-4920-01F19A55",
					["nome"] = "朴不成",
				}, -- [22]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["嘲讽"] = {
								["id"] = "嘲讽",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["挫志怒吼"] = {
								["id"] = "挫志怒吼",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["破甲攻击"] = {
								["id"] = "破甲攻击",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["重伤"] = {
								["id"] = "重伤",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["惩戒痛击"] = {
								["id"] = "惩戒痛击",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["拦截昏迷"] = {
								["id"] = "拦截昏迷",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "WARRIOR",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["乱舞"] = {
								["id"] = "乱舞",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["嗜血"] = {
								["id"] = "嗜血",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["盾牌格挡"] = {
								["id"] = "盾牌格挡",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["赞扎之魂"] = {
								["id"] = "赞扎之魂",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["战斗怒吼"] = {
								["id"] = "战斗怒吼",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["狂怒"] = {
								["id"] = "狂怒",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["战斗姿态"] = {
								["id"] = "战斗姿态",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["防御姿态"] = {
								["id"] = "防御姿态",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["风怒图腾"] = {
								["id"] = "风怒图腾",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["神圣力量"] = {
								["id"] = "神圣力量",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["狂暴姿态"] = {
								["id"] = "狂暴姿态",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["血性狂暴"] = {
								["id"] = "血性狂暴",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 0,
					["boss_fight_component"] = true,
					["grupo"] = true,
					["spell_cast"] = {
						["战斗姿态"] = 0,
						["嗜血"] = 0,
						["盾击"] = 0,
						["破甲攻击"] = 0,
						["盾牌格挡"] = 0,
						["防御姿态"] = 0,
						["惩戒痛击"] = 0,
						["战斗怒吼"] = 0,
						["拦截"] = 0,
						["嘲讽"] = 0,
						["挫志怒吼"] = 0,
						["英勇打击"] = 0,
						["复仇"] = 0,
						["狂暴姿态"] = 0,
						["血性狂暴"] = 0,
					},
					["buff_uptime"] = 0,
					["nome"] = "像只猴的你",
					["tipo"] = 4,
					["debuff_uptime_targets"] = {
					},
					["buff_uptime_targets"] = {
					},
					["serial"] = "Player-4920-01D50132",
					["last_event"] = 0,
				}, -- [23]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["烈焰震击"] = {
								["id"] = "烈焰震击",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime"] = 0,
					["classe"] = "SHAMAN",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["银色黎明委任徽章"] = {
								["id"] = "银色黎明委任徽章",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["冰霜抗性"] = {
								["id"] = "冰霜抗性",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["治疗之泉"] = {
								["id"] = "治疗之泉",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["大地之力"] = {
								["id"] = "大地之力",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["风之优雅"] = {
								["id"] = "风之优雅",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["石肤术"] = {
								["id"] = "石肤术",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["法力之泉"] = {
								["id"] = "法力之泉",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 0,
					["boss_fight_component"] = true,
					["spec"] = 264,
					["grupo"] = true,
					["spell_cast"] = {
						["大地之力图腾"] = 0,
						["石肤图腾"] = 0,
						["抗寒图腾"] = 0,
						["烈焰震击"] = 0,
						["次级治疗波"] = 0,
						["治疗波"] = 0,
						["冰霜震击"] = 0,
						["火焰新星图腾"] = 0,
						["灼热图腾"] = 0,
						["风之优雅图腾"] = 0,
						["治疗链"] = 0,
					},
					["debuff_uptime_targets"] = {
					},
					["tipo"] = 4,
					["last_event"] = 0,
					["buff_uptime_targets"] = {
					},
					["nome"] = "琼琼宝贝",
					["serial"] = "Player-4920-01D6B7EB",
					["pets"] = {
					},
				}, -- [24]
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["冲击"] = {
								["id"] = "冲击",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["火球术"] = {
								["id"] = "火球术",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["侦测魔法"] = {
								["id"] = "侦测魔法",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["炎爆术"] = {
								["id"] = "炎爆术",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["点燃"] = {
								["id"] = "点燃",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "MAGE",
					["interrupt_spells"] = {
						["_ActorTable"] = {
							["法术反制"] = {
								["id"] = "法术反制",
								["interrompeu_oque"] = {
								},
								["targets"] = {
									["莱斯·霜语"] = 0,
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["节能施法"] = {
								["id"] = "节能施法",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["喝水"] = {
								["id"] = "喝水",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["奥术智慧"] = {
								["id"] = "奥术智慧",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["奥术光辉"] = {
								["id"] = "奥术光辉",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["法力护盾"] = {
								["id"] = "法力护盾",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["魔甲术"] = {
								["id"] = "魔甲术",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["银色黎明委任徽章"] = {
								["id"] = "银色黎明委任徽章",
								["targets"] = {
								},
								["counter"] = 0,
							},
							["燃烧"] = {
								["id"] = "燃烧",
								["targets"] = {
								},
								["counter"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["interrompeu_oque"] = {
					},
					["debuff_uptime"] = 0,
					["nome"] = "幽魂无双",
					["debuff_uptime_targets"] = {
					},
					["interrupt_targets"] = {
						["莱斯·霜语"] = 0,
					},
					["grupo"] = true,
					["spell_cast"] = {
						["魔爆术"] = 0,
						["法力护盾"] = 0,
						["侦测魔法"] = 0,
						["法术反制"] = 0,
						["火球术"] = 0,
						["灼烧"] = 0,
						["炎爆术"] = 0,
						["火焰冲击"] = 0,
					},
					["buff_uptime_targets"] = {
					},
					["buff_uptime"] = 0,
					["tipo"] = 4,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Player-4920-01ECB17B",
					["interrupt"] = 0,
				}, -- [25]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 16,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "冰冻",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "莱斯·霜语",
					["damage_spellid"] = "冰冻",
					["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
					["last_event"] = 0,
				}, -- [26]
				{
					["flag_original"] = 4369,
					["nome"] = "鲁总 <啪啪>",
					["last_event"] = 0,
					["pets"] = {
					},
					["spell_cast"] = {
						["爪击"] = 0,
						["低吼"] = 0,
						["突进"] = 0,
					},
					["tipo"] = 4,
					["classe"] = "PET",
					["serial"] = "Pet-0-4889-289-12207-10737-0100AE9C78",
					["boss_fight_component"] = true,
				}, -- [27]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "莱斯·霜语",
					["pets"] = {
					},
					["spell_cast"] = {
						["冰冻新星"] = 0,
						["击退"] = 0,
						["连发寒冰箭"] = 0,
						["恐惧术"] = 0,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
					["classe"] = "UNKNOW",
				}, -- [28]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 32,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "恐惧术",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "莱斯·霜语",
					["damage_spellid"] = "恐惧术",
					["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
					["last_event"] = 0,
				}, -- [29]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 16,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "冰冻新星",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "莱斯·霜语",
					["damage_spellid"] = "冰冻新星",
					["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
					["last_event"] = 0,
				}, -- [30]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 16,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "连发寒冰箭",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "莱斯·霜语",
					["damage_spellid"] = "连发寒冰箭",
					["serial"] = "Creature-0-4889-289-12207-10508-0000300FDF",
					["last_event"] = 0,
				}, -- [31]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "血骨傀儡",
					["pets"] = {
					},
					["spell_cast"] = {
						["打击"] = 0,
						["击退"] = 0,
						["战争践踏"] = 0,
					},
					["flag_original"] = 2632,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4889-289-12207-11622-0000300FDF",
					["classe"] = "UNKNOW",
				}, -- [32]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "复活的构造体",
					["pets"] = {
					},
					["spell_cast"] = {
						["横扫攻击"] = 0,
						["圆弧斩"] = 0,
						["痛击"] = 0,
						["狂怒"] = 0,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4889-289-12207-10488-0003300FDF",
					["classe"] = "UNKNOW",
				}, -- [33]
				{
					["flag_original"] = 2632,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 1,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "战争践踏",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "血骨傀儡",
					["damage_spellid"] = "战争践踏",
					["serial"] = "Creature-0-4889-289-12207-11622-0000300FDF",
					["last_event"] = 0,
				}, -- [34]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "传令官基尔图诺斯",
					["pets"] = {
					},
					["spell_cast"] = {
						["基尔图诺斯变形"] = 0,
						["缴械"] = 0,
						["拍翼"] = 0,
						["刺穿护甲"] = 0,
						["飞扑"] = 0,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
					["classe"] = "UNKNOW",
				}, -- [35]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 1,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "缴械",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "传令官基尔图诺斯",
					["damage_spellid"] = "缴械",
					["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
					["last_event"] = 0,
				}, -- [36]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 1,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "飞扑",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "传令官基尔图诺斯",
					["damage_spellid"] = "飞扑",
					["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
					["last_event"] = 0,
				}, -- [37]
				{
					["flag_original"] = 68168,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
						},
						["tipo"] = 9,
					},
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["boss_debuff"] = true,
					["monster"] = true,
					["debuff_uptime"] = 0,
					["spellschool"] = 1,
					["debuff_uptime_targets"] = {
					},
					["nome"] = "刺穿护甲",
					["boss_fight_component"] = true,
					["tipo"] = 4,
					["damage_twin"] = "传令官基尔图诺斯",
					["damage_spellid"] = "刺穿护甲",
					["serial"] = "Creature-0-4889-289-12207-10506-0000301D5B",
					["last_event"] = 0,
				}, -- [38]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "詹迪斯·巴罗夫",
					["pets"] = {
					},
					["spell_cast"] = {
						["召唤幻象"] = 0,
						["放逐术"] = 0,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["boss_fight_component"] = true,
					["serial"] = "Creature-0-4889-289-12207-10503-0000300FDF",
					["classe"] = "UNKNOW",
				}, -- [39]
				{
					["monster"] = true,
					["tipo"] = 4,
					["nome"] = "滚烫的雏龙",
					["pets"] = {
					},
					["spell_cast"] = {
						["火球术"] = 0,
					},
					["flag_original"] = 68168,
					["last_event"] = 0,
					["fight_component"] = true,
					["serial"] = "Creature-0-4504-0-4491-2725-00002FFB6B",
					["classe"] = "UNKNOW",
				}, -- [40]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1588652776,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["segments_added"] = {
			{
				["elapsed"] = 94.0079999999143,
				["type"] = 6,
				["name"] = "维克多·奈法里奥斯",
				["clock"] = "12:41:31",
			}, -- [1]
			{
				["elapsed"] = 29.0039999999572,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:39:38",
			}, -- [2]
			{
				["elapsed"] = 21.9990000000689,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:38:26",
			}, -- [3]
			{
				["elapsed"] = 22.0009999999311,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:37:16",
			}, -- [4]
			{
				["elapsed"] = 22.0010000001639,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:36:14",
			}, -- [5]
			{
				["elapsed"] = 25.0060000000522,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:34:59",
			}, -- [6]
			{
				["elapsed"] = 22,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:33:45",
			}, -- [7]
			{
				["elapsed"] = 22.0009999999311,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:32:33",
			}, -- [8]
			{
				["elapsed"] = 13.0110000001732,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:31:59",
			}, -- [9]
			{
				["elapsed"] = 25.0030000000261,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:30:55",
			}, -- [10]
			{
				["elapsed"] = 32.0079999999143,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:29:16",
			}, -- [11]
			{
				["elapsed"] = 24.0060000000522,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:28:08",
			}, -- [12]
			{
				["elapsed"] = 23.00400000019,
				["type"] = 5,
				["name"] = "垃圾清理",
				["clock"] = "12:27:15",
			}, -- [13]
		},
		["combat_counter"] = 673,
		["totals"] = {
			486605.477589, -- [1]
			63579.269304, -- [2]
			{
				276.065446, -- [1]
				[0] = 13398.151223,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 1.001195,
				["debuff_uptime"] = 0,
				["dispell"] = 2.010394,
				["cooldowns_defensive"] = 0,
			}, -- [4]
			["voidzone_damage"] = 0,
			["frags_total"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "12:27:15",
		["end_time"] = 1615517.436,
		["cleu_timeline"] = {
		},
		["totals_grupo"] = {
			400454.423402, -- [1]
			63579.269304, -- [2]
			{
				276.070639, -- [1]
				[0] = 13398.163773,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["dispell"] = 2.010394,
				["cooldowns_defensive"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
		},
		["hasSaved"] = true,
		["spells_cast_timeline"] = {
		},
		["data_fim"] = "12:43:05",
		["overall_enemy_name"] = "-- x -- x --",
		["CombatSkillCache"] = {
		},
		["frags"] = {
		},
		["start_time"] = 1615142.384,
		["TimeData"] = {
		},
		["cleu_events"] = {
			["n"] = 1,
		},
	},
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -169.955718994141,
					["x"] = 745.313110351563,
					["w"] = 309.999969482422,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = -1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				5, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -347.95573425293,
					["x"] = 745.313110351563,
					["w"] = 309.999969482422,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["character_data"] = {
		["logons"] = 59,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["announce_cooldowns"] = {
		["enabled"] = false,
		["ignored_cooldowns"] = {
		},
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
	},
}
