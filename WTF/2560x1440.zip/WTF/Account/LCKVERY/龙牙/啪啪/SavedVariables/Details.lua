
_detalhes_database = {
	["savedbuffs"] = {
	},
	["mythic_dungeon_id"] = 0,
	["tabela_historico"] = {
		["tabelas"] = {
			{
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 68168,
							["totalabsorbed"] = 0.006293,
							["damage_from"] = {
								["啪啪"] = true,
								["狼 <啪啪>"] = true,
							},
							["targets"] = {
								["狼 <啪啪>"] = 423,
								["啪啪"] = 1215,
							},
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["friendlyfire"] = {
							},
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1638.006293,
							["delay"] = 0,
							["fight_component"] = true,
							["total"] = 1638.006293,
							["monster"] = true,
							["damage_taken"] = 8876.006293,
							["nome"] = "哈卡莱神谕者",
							["spells"] = {
								["_ActorTable"] = {
									["闪电链"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["啪啪"] = 0,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "闪电链",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_amt"] = 0,
										["m_crit"] = 0,
										["n_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["RESIST"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["地震术"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 574,
										["targets"] = {
											["啪啪"] = 574,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 574,
										["n_min"] = 574,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 574,
										["c_max"] = 0,
										["id"] = "地震术",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
									["!Melee"] = {
										["c_amt"] = 0,
										["b_amt"] = 1,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 233,
										["targets"] = {
											["狼 <啪啪>"] = 423,
											["啪啪"] = 641,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 1064,
										["n_min"] = 195,
										["g_dmg"] = 0,
										["counter"] = 6,
										["total"] = 1064,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 204,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 5,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
									["治疗波"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 0,
										["total"] = 0,
										["c_max"] = 0,
										["id"] = "治疗波",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 1,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_amt"] = 0,
										["a_dmg"] = 0,
									},
								},
								["tipo"] = 2,
							},
							["last_event"] = 1593181212,
							["last_dps"] = 0,
							["end_time"] = 1593181213,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1593181188,
							["serial"] = "Creature-0-4505-0-208-11346-00007602FC",
							["dps_started"] = false,
						}, -- [1]
						{
							["flag_original"] = 1300,
							["totalabsorbed"] = 0.005248,
							["damage_from"] = {
								["哈卡莱神谕者"] = true,
								["环境伤害 (高处坠落)"] = true,
							},
							["targets"] = {
								["哈卡莱神谕者"] = 8876,
							},
							["pets"] = {
								"狼 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["last_event"] = 1593181212,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 7602.005248,
							["delay"] = 0,
							["dps_started"] = false,
							["total"] = 8876.005248,
							["spells"] = {
								["_ActorTable"] = {
									["!Autoshot"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 826,
										["g_amt"] = 0,
										["n_max"] = 356,
										["targets"] = {
											["哈卡莱神谕者"] = 1525,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 699,
										["n_min"] = 343,
										["g_dmg"] = 0,
										["counter"] = 3,
										["total"] = 1525,
										["c_max"] = 826,
										["id"] = "!Autoshot",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 826,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["!Melee"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 318,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["哈卡莱神谕者"] = 318,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 318,
										["c_max"] = 318,
										["r_amt"] = 0,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 318,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 0,
										["spellschool"] = 1,
										["MISS"] = 1,
									},
									["毒蛇钉刺"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 100,
										["targets"] = {
											["哈卡莱神谕者"] = 500,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 500,
										["n_min"] = 100,
										["g_dmg"] = 0,
										["counter"] = 5,
										["total"] = 500,
										["c_max"] = 0,
										["id"] = "毒蛇钉刺",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 5,
										["a_dmg"] = 0,
										["spellschool"] = 8,
									},
									["瞄准射击"] = {
										["c_amt"] = 1,
										["b_amt"] = 0,
										["c_dmg"] = 1905,
										["g_amt"] = 0,
										["n_max"] = 779,
										["targets"] = {
											["哈卡莱神谕者"] = 2684,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 779,
										["n_min"] = 779,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2684,
										["c_max"] = 1905,
										["id"] = "瞄准射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1905,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["多重射击"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 2379,
										["g_amt"] = 0,
										["n_max"] = 0,
										["targets"] = {
											["哈卡莱神谕者"] = 2379,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 0,
										["n_min"] = 0,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 2379,
										["c_max"] = 1231,
										["id"] = "多重射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 1148,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 0,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["驱散射击"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 162,
										["targets"] = {
											["哈卡莱神谕者"] = 162,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 162,
										["n_min"] = 162,
										["g_dmg"] = 0,
										["counter"] = 1,
										["total"] = 162,
										["c_max"] = 0,
										["id"] = "驱散射击",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 1,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["摔绊"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 34,
										["targets"] = {
											["哈卡莱神谕者"] = 34,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 34,
										["n_min"] = 34,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 34,
										["c_max"] = 0,
										["r_amt"] = 0,
										["id"] = "摔绊",
										["r_dmg"] = 0,
										["a_dmg"] = 0,
										["b_dmg"] = 0,
										["m_crit"] = 0,
										["m_amt"] = 0,
										["c_min"] = 0,
										["successful_casted"] = 0,
										["a_amt"] = 0,
										["n_amt"] = 1,
										["spellschool"] = 1,
										["DODGE"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["damage_taken"] = 2250.005248,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["end_time"] = 1593181213,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["friendlyfire"] = {
							},
							["start_time"] = 1593181188,
							["serial"] = "Player-4920-01D0E17B",
							["on_hold"] = false,
						}, -- [2]
						{
							["flag_original"] = 4369,
							["totalabsorbed"] = 0.003069,
							["damage_from"] = {
								["哈卡莱神谕者"] = true,
							},
							["targets"] = {
								["哈卡莱神谕者"] = 1274,
							},
							["pets"] = {
							},
							["damage_taken"] = 423.003069,
							["friendlyfire_total"] = 0,
							["raid_targets"] = {
							},
							["total_without_pet"] = 1274.003069,
							["friendlyfire"] = {
							},
							["dps_started"] = false,
							["total"] = 1274.003069,
							["delay"] = 0,
							["ownerName"] = "啪啪",
							["nome"] = "狼 <啪啪>",
							["spells"] = {
								["_ActorTable"] = {
									["!Melee"] = {
										["c_amt"] = 2,
										["b_amt"] = 0,
										["c_dmg"] = 236,
										["g_amt"] = 0,
										["n_max"] = 105,
										["targets"] = {
											["哈卡莱神谕者"] = 1120,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 884,
										["n_min"] = 56,
										["g_dmg"] = 0,
										["counter"] = 16,
										["total"] = 1120,
										["c_max"] = 122,
										["id"] = "!Melee",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 114,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 14,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
									["撕咬"] = {
										["c_amt"] = 0,
										["b_amt"] = 0,
										["c_dmg"] = 0,
										["g_amt"] = 0,
										["n_max"] = 79,
										["targets"] = {
											["哈卡莱神谕者"] = 154,
										},
										["m_dmg"] = 0,
										["n_dmg"] = 154,
										["n_min"] = 75,
										["g_dmg"] = 0,
										["counter"] = 2,
										["total"] = 154,
										["c_max"] = 0,
										["id"] = "撕咬",
										["r_dmg"] = 0,
										["r_amt"] = 0,
										["a_amt"] = 0,
										["m_crit"] = 0,
										["c_min"] = 0,
										["m_amt"] = 0,
										["successful_casted"] = 0,
										["b_dmg"] = 0,
										["n_amt"] = 2,
										["a_dmg"] = 0,
										["spellschool"] = 1,
									},
								},
								["tipo"] = 2,
							},
							["end_time"] = 1593181213,
							["last_event"] = 1593181212,
							["last_dps"] = 0,
							["custom"] = 0,
							["tipo"] = 1,
							["on_hold"] = false,
							["start_time"] = 1593181189,
							["serial"] = "Pet-0-4515-309-21098-9696-0200BA6F1B",
							["classe"] = "PET",
						}, -- [3]
					},
				}, -- [1]
				{
					["tipo"] = 3,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [2]
				{
					["tipo"] = 7,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [3]
				{
					["tipo"] = 9,
					["combatId"] = 10,
					["_ActorTable"] = {
						{
							["flag_original"] = 1047,
							["debuff_uptime_spells"] = {
								["_ActorTable"] = {
									["毒蛇钉刺"] = {
										["activedamt"] = -1,
										["id"] = "毒蛇钉刺",
										["targets"] = {
										},
										["actived_at"] = 1593181202,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									["猎人印记"] = {
										["activedamt"] = -1,
										["id"] = "猎人印记",
										["targets"] = {
										},
										["actived_at"] = 1593181212,
										["uptime"] = 0,
										["counter"] = 0,
										["refreshamt"] = 0,
										["actived"] = false,
										["appliedamt"] = 0,
									},
									["驱散射击"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "驱散射击",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
									["摔绊"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "摔绊",
										["uptime"] = 9,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["pets"] = {
								"狼 <啪啪>", -- [1]
							},
							["classe"] = "HUNTER",
							["buff_uptime_spells"] = {
								["_ActorTable"] = {
									["狂怒之嚎"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 0,
										["refreshamt"] = 0,
										["id"] = "狂怒之嚎",
										["uptime"] = 0,
										["targets"] = {
										},
										["appliedamt"] = 0,
									},
									["强击光环"] = {
										["counter"] = 0,
										["actived"] = false,
										["activedamt"] = 1,
										["refreshamt"] = 0,
										["id"] = "强击光环",
										["uptime"] = 25,
										["targets"] = {
										},
										["appliedamt"] = 1,
									},
								},
								["tipo"] = 9,
							},
							["debuff_uptime"] = 9,
							["nome"] = "啪啪",
							["spec"] = 254,
							["grupo"] = true,
							["spell_cast"] = {
								["摔绊"] = 2,
								["多重射击"] = 2,
								["自动射击"] = 2,
								["驱散射击"] = 1,
								["瞄准射击"] = 2,
							},
							["tipo"] = 4,
							["last_event"] = 1593181213,
							["buff_uptime_targets"] = {
							},
							["debuff_uptime_targets"] = {
							},
							["serial"] = "Player-4920-01D0E17B",
							["buff_uptime"] = 25,
						}, -- [1]
						{
							["flag_original"] = 4369,
							["ownerName"] = "啪啪",
							["nome"] = "狼 <啪啪>",
							["pets"] = {
							},
							["spell_cast"] = {
								["低吼"] = 3,
								["撕咬"] = 2,
							},
							["last_event"] = 0,
							["tipo"] = 4,
							["serial"] = "Pet-0-4515-309-21098-9696-0200BA6F1B",
							["classe"] = "PET",
						}, -- [2]
						{
							["flag_original"] = 68168,
							["last_event"] = 0,
							["nome"] = "哈卡莱神谕者",
							["pets"] = {
							},
							["classe"] = "UNKNOW",
							["spell_cast"] = {
								["治疗波"] = 1,
								["闪电链"] = 1,
								["地震术"] = 1,
							},
							["tipo"] = 4,
							["monster"] = true,
							["serial"] = "Creature-0-4505-0-208-11346-00007602FC",
							["fight_component"] = true,
						}, -- [3]
					},
				}, -- [4]
				{
					["tipo"] = 2,
					["combatId"] = 10,
					["_ActorTable"] = {
					},
				}, -- [5]
				["raid_roster"] = {
					["啪啪"] = true,
				},
				["tempo_start"] = 1593181188,
				["last_events_tables"] = {
				},
				["alternate_power"] = {
				},
				["cleu_events"] = {
					["n"] = 1,
				},
				["playing_solo"] = true,
				["totals"] = {
					10513.73872, -- [1]
					-0.007051, -- [2]
					{
						-0.0231679999999947, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = -0.00115599999999993,
						["cooldowns_defensive"] = 0,
					}, -- [4]
					["voidzone_damage"] = 0,
					["frags_total"] = 0,
				},
				["totals_grupo"] = {
					7602, -- [1]
					0, -- [2]
					{
						0, -- [1]
						[0] = 0,
						["alternatepower"] = 0,
						[6] = 0,
						[3] = 0,
					}, -- [3]
					{
						["buff_uptime"] = 0,
						["ress"] = 0,
						["dead"] = 0,
						["cc_break"] = 0,
						["interrupt"] = 0,
						["debuff_uptime"] = 0,
						["dispell"] = 0,
						["cooldowns_defensive"] = 0,
					}, -- [4]
				},
				["frags_need_refresh"] = true,
				["instance_type"] = "none",
				["hasSaved"] = true,
				["data_fim"] = "22:20:14",
				["cleu_timeline"] = {
				},
				["enemy"] = "哈卡莱神谕者",
				["TotalElapsedCombatTime"] = 103894.128,
				["CombatEndedAt"] = 103894.128,
				["aura_timeline"] = {
				},
				["__call"] = {
				},
				["data_inicio"] = "22:19:48",
				["end_time"] = 103894.128,
				["combat_id"] = 10,
				["PhaseData"] = {
					{
						1, -- [1]
						1, -- [2]
					}, -- [1]
					["damage"] = {
						{
							["啪啪"] = 8876.005248,
						}, -- [1]
					},
					["heal_section"] = {
					},
					["heal"] = {
						{
						}, -- [1]
					},
					["damage_section"] = {
					},
				},
				["overall_added"] = true,
				["frags"] = {
					["哈卡莱神谕者"] = 1,
				},
				["TimeData"] = {
				},
				["combat_counter"] = 2003,
				["CombatSkillCache"] = {
				},
				["player_last_events"] = {
					["啪啪"] = {
						{
							true, -- [1]
							"Falling", -- [2]
							788, -- [3]
							1593181495.494, -- [4]
							5850, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [1]
						{
							true, -- [1]
							"Falling", -- [2]
							95, -- [3]
							1593182325.928, -- [4]
							5526, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [2]
						{
							true, -- [1]
							"Falling", -- [2]
							152, -- [3]
							1593182338.934, -- [4]
							5526, -- [5]
							"环境伤害 (高处坠落)", -- [6]
							nil, -- [7]
							3, -- [8]
							false, -- [9]
							-1, -- [10]
						}, -- [3]
						{
						}, -- [4]
						{
						}, -- [5]
						{
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						{
						}, -- [9]
						{
						}, -- [10]
						{
						}, -- [11]
						{
						}, -- [12]
						{
						}, -- [13]
						{
						}, -- [14]
						{
						}, -- [15]
						{
						}, -- [16]
						{
						}, -- [17]
						{
						}, -- [18]
						{
						}, -- [19]
						{
						}, -- [20]
						{
						}, -- [21]
						{
						}, -- [22]
						{
						}, -- [23]
						{
						}, -- [24]
						{
						}, -- [25]
						{
						}, -- [26]
						{
						}, -- [27]
						{
						}, -- [28]
						{
						}, -- [29]
						{
						}, -- [30]
						{
						}, -- [31]
						{
						}, -- [32]
						["n"] = 4,
					},
				},
				["start_time"] = 103868.591,
				["contra"] = "哈卡莱神谕者",
				["spells_cast_timeline"] = {
				},
			}, -- [1]
		},
	},
	["last_version"] = "v1.13.4.209",
	["SoloTablesSaved"] = {
		["Mode"] = 1,
	},
	["tabela_instancias"] = {
	},
	["on_death_menu"] = true,
	["nick_tag_cache"] = {
		["last_version"] = 11,
		["nextreset"] = 1594349558,
		["火焰冰激凌"] = {
			"火焰冰激凌", -- [1]
			"Interface\\EncounterJournal\\UI-EJ-BOSS-Grand Magus Telestra", -- [2]
			{
				0, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			}, -- [3]
			"Interface\\PetBattles\\Weather-Sunlight", -- [4]
			{
				0.1772721, -- [1]
				0.953125, -- [2]
				1, -- [3]
				0, -- [4]
			}, -- [5]
			{
				1, -- [1]
				1, -- [2]
				1, -- [3]
			}, -- [6]
			3, -- [7]
		},
		["啪啪"] = {
			"啪啪", -- [1]
			"Interface\\EncounterJournal\\UI-EJ-BOSS-Vazruden", -- [2]
			{
				0, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			}, -- [3]
			"Interface\\PetBattles\\Weather-ArcaneStorm", -- [4]
			{
				0.129609375, -- [1]
				1, -- [2]
				1, -- [3]
				0, -- [4]
			}, -- [5]
			{
				1, -- [1]
				1, -- [2]
				1, -- [3]
			}, -- [6]
			3, -- [7]
		},
	},
	["last_instance_id"] = 309,
	["announce_interrupts"] = {
		["enabled"] = false,
		["whisper"] = "",
		["channel"] = "SAY",
		["custom"] = "",
		["next"] = "",
	},
	["last_instance_time"] = 1593181091,
	["active_profile"] = "龙哥-龙牙",
	["mythic_dungeon_currentsaved"] = {
		["dungeon_name"] = "",
		["started"] = false,
		["segment_id"] = 0,
		["ej_id"] = 0,
		["started_at"] = 0,
		["run_id"] = 0,
		["level"] = 0,
		["dungeon_zone_id"] = 0,
		["previous_boss_killed_at"] = 0,
	},
	["ignore_nicktag"] = false,
	["plugin_database"] = {
		["DETAILS_PLUGIN_TINY_THREAT"] = {
			["enabled"] = true,
			["animate"] = true,
			["author"] = "Details! Team",
			["playercolor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["openedfromcommand"] = true,
			["updatespeed"] = 0.2,
			["dividebyhundred"] = true,
			["showamount"] = true,
			["useplayercolor"] = true,
			["useclasscolors"] = true,
		},
	},
	["last_day"] = "09",
	["cached_talents"] = {
		["Player-4920-01D0E17B"] = {
			{
				136076, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [1]
			{
				136080, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [2]
			{
				132150, -- [1]
				0, -- [2]
				2, -- [3]
				1, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [3]
			{
				132159, -- [1]
				0, -- [2]
				2, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [4]
			{
				134355, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				3, -- [7]
			}, -- [5]
			{
				132163, -- [1]
				0, -- [2]
				2, -- [3]
				4, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [6]
			{
				132242, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [7]
			{
				132120, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				1, -- [7]
			}, -- [8]
			{
				132091, -- [1]
				0, -- [2]
				3, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [9]
			{
				132179, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [10]
			{
				134297, -- [1]
				0, -- [2]
				4, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [11]
			{
				132121, -- [1]
				0, -- [2]
				5, -- [3]
				1, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [12]
			{
				132111, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				1, -- [7]
			}, -- [13]
			{
				136006, -- [1]
				0, -- [2]
				5, -- [3]
				4, -- [4]
				1, -- [5]
				nil, -- [6]
				2, -- [7]
			}, -- [14]
			{
				134296, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				1, -- [5]
				nil, -- [6]
				5, -- [7]
			}, -- [15]
			{
				132127, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				1, -- [5]
				nil, -- [6]
				1, -- [7]
			}, -- [16]
			{
				135860, -- [1]
				0, -- [2]
				1, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [17]
			{
				135865, -- [1]
				5, -- [2]
				1, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [18]
			{
				132212, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [19]
			{
				132312, -- [1]
				5, -- [2]
				2, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [20]
			{
				135130, -- [1]
				1, -- [2]
				3, -- [3]
				1, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [21]
			{
				132218, -- [1]
				0, -- [2]
				3, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [22]
			{
				132327, -- [1]
				3, -- [2]
				3, -- [3]
				4, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [23]
			{
				132204, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [24]
			{
				132271, -- [1]
				5, -- [2]
				4, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [25]
			{
				132153, -- [1]
				1, -- [2]
				5, -- [3]
				1, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [26]
			{
				132330, -- [1]
				3, -- [2]
				5, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [27]
			{
				132169, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				3, -- [7]
			}, -- [28]
			{
				135615, -- [1]
				5, -- [2]
				6, -- [3]
				3, -- [4]
				2, -- [5]
				254, -- [6]
				5, -- [7]
			}, -- [29]
			{
				132329, -- [1]
				1, -- [2]
				7, -- [3]
				2, -- [4]
				2, -- [5]
				254, -- [6]
				1, -- [7]
			}, -- [30]
			{
				134154, -- [1]
				3, -- [2]
				1, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [31]
			{
				135942, -- [1]
				3, -- [2]
				1, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [32]
			{
				132269, -- [1]
				0, -- [2]
				1, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [33]
			{
				136100, -- [1]
				5, -- [2]
				2, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [34]
			{
				132277, -- [1]
				2, -- [2]
				2, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [35]
			{
				132309, -- [1]
				0, -- [2]
				2, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [36]
			{
				136106, -- [1]
				0, -- [2]
				3, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [37]
			{
				136223, -- [1]
				4, -- [2]
				3, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [38]
			{
				132369, -- [1]
				1, -- [2]
				3, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [39]
			{
				132149, -- [1]
				0, -- [2]
				4, -- [3]
				1, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [40]
			{
				132219, -- [1]
				0, -- [2]
				4, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [41]
			{
				132293, -- [1]
				2, -- [2]
				4, -- [3]
				4, -- [4]
				3, -- [5]
				255, -- [6]
				2, -- [7]
			}, -- [42]
			{
				135881, -- [1]
				0, -- [2]
				5, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				3, -- [7]
			}, -- [43]
			{
				132336, -- [1]
				0, -- [2]
				5, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [44]
			{
				136047, -- [1]
				0, -- [2]
				6, -- [3]
				3, -- [4]
				3, -- [5]
				255, -- [6]
				5, -- [7]
			}, -- [45]
			{
				135125, -- [1]
				0, -- [2]
				7, -- [3]
				2, -- [4]
				3, -- [5]
				255, -- [6]
				1, -- [7]
			}, -- [46]
		},
	},
	["last_encounter"] = "血领主曼多基尔",
	["announce_prepots"] = {
		["enabled"] = true,
		["channel"] = "SELF",
		["reverse"] = false,
	},
	["benchmark_db"] = {
		["frame"] = {
		},
	},
	["character_data"] = {
		["logons"] = 194,
	},
	["combat_id"] = 10,
	["savedStyles"] = {
	},
	["local_instances_config"] = {
		{
			["segment"] = 0,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["last_raid_plugin"] = "DETAILS_PLUGIN_TINY_THREAT",
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 4,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -169.955718994141,
					["x"] = 745.313110351563,
					["w"] = 309.999969482422,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [1]
		{
			["segment"] = -1,
			["sub_attribute"] = 1,
			["horizontalSnap"] = false,
			["verticalSnap"] = false,
			["is_open"] = false,
			["isLocked"] = true,
			["sub_atributo_last"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				5, -- [4]
				1, -- [5]
			},
			["snap"] = {
			},
			["mode"] = 2,
			["attribute"] = 1,
			["pos"] = {
				["normal"] = {
					["y"] = -347.95573425293,
					["x"] = 745.313110351563,
					["w"] = 309.999969482422,
					["h"] = 158,
				},
				["solo"] = {
					["y"] = 2,
					["x"] = 1,
					["w"] = 300,
					["h"] = 200,
				},
			},
		}, -- [2]
	},
	["force_font_outline"] = "",
	["announce_deaths"] = {
		["enabled"] = false,
		["last_hits"] = 1,
		["only_first"] = 5,
		["where"] = 1,
	},
	["tabela_overall"] = {
		{
			["tipo"] = 2,
			["_ActorTable"] = {
				{
					["flag_original"] = 68168,
					["totalabsorbed"] = 0.007368,
					["damage_from"] = {
						["狼 <啪啪>"] = true,
						["啪啪"] = true,
					},
					["targets"] = {
						["啪啪"] = 1215,
						["狼 <啪啪>"] = 423,
					},
					["pets"] = {
					},
					["monster"] = true,
					["last_dps"] = 0,
					["classe"] = "UNKNOW",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1638.007368,
					["delay"] = 0,
					["fight_component"] = true,
					["end_time"] = 1593181214,
					["friendlyfire_total"] = 0,
					["damage_taken"] = 8876.007368,
					["nome"] = "哈卡莱神谕者",
					["spells"] = {
						["_ActorTable"] = {
							["治疗波"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 0,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "治疗波",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["闪电链"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["啪啪"] = 0,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 0,
								["c_max"] = 0,
								["id"] = "闪电链",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_amt"] = 0,
								["m_crit"] = 0,
								["n_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["RESIST"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Melee"] = {
								["c_amt"] = 0,
								["b_amt"] = 1,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 233,
								["targets"] = {
									["啪啪"] = 641,
									["狼 <啪啪>"] = 423,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 1064,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 6,
								["total"] = 1064,
								["c_max"] = 0,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 204,
								["n_amt"] = 5,
								["a_dmg"] = 0,
								["DODGE"] = 1,
							},
							["地震术"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 574,
								["targets"] = {
									["啪啪"] = 574,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 574,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 574,
								["c_max"] = 0,
								["id"] = "地震术",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 1,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["tipo"] = 1,
					["friendlyfire"] = {
					},
					["total"] = 1638.007368,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1593181186,
					["serial"] = "Creature-0-4505-0-208-11346-00007602FC",
					["dps_started"] = false,
				}, -- [1]
				{
					["flag_original"] = 1300,
					["totalabsorbed"] = 0.006992,
					["damage_from"] = {
						["哈卡莱神谕者"] = true,
					},
					["targets"] = {
						["哈卡莱神谕者"] = 8876,
					},
					["pets"] = {
						"狼 <啪啪>", -- [1]
					},
					["damage_taken"] = 1215.006992,
					["tipo"] = 1,
					["friendlyfire_total"] = 0,
					["raid_targets"] = {
					},
					["total_without_pet"] = 7602.006992,
					["delay"] = 0,
					["dps_started"] = false,
					["end_time"] = 1593181214,
					["spells"] = {
						["_ActorTable"] = {
							["摔绊"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 34,
								["targets"] = {
									["哈卡莱神谕者"] = 34,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 34,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 34,
								["c_max"] = 0,
								["id"] = "摔绊",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_dmg"] = 0,
								["DODGE"] = 1,
							},
							["!Melee"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 318,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["哈卡莱神谕者"] = 318,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 318,
								["c_max"] = 318,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["a_amt"] = 0,
								["m_crit"] = 0,
								["c_min"] = 0,
								["m_amt"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_dmg"] = 0,
								["MISS"] = 1,
							},
							["毒蛇钉刺"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 100,
								["targets"] = {
									["哈卡莱神谕者"] = 500,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 500,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 5,
								["total"] = 500,
								["c_max"] = 0,
								["id"] = "毒蛇钉刺",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 5,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["驱散射击"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 162,
								["targets"] = {
									["哈卡莱神谕者"] = 162,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 162,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 1,
								["total"] = 162,
								["c_max"] = 0,
								["id"] = "驱散射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["多重射击"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 2379,
								["g_amt"] = 0,
								["n_max"] = 0,
								["targets"] = {
									["哈卡莱神谕者"] = 2379,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 0,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 2379,
								["c_max"] = 1231,
								["id"] = "多重射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 0,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["!Autoshot"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 826,
								["g_amt"] = 0,
								["n_max"] = 356,
								["targets"] = {
									["哈卡莱神谕者"] = 1525,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 699,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 3,
								["total"] = 1525,
								["c_max"] = 826,
								["id"] = "!Autoshot",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["瞄准射击"] = {
								["c_amt"] = 1,
								["b_amt"] = 0,
								["c_dmg"] = 1905,
								["g_amt"] = 0,
								["n_max"] = 779,
								["targets"] = {
									["哈卡莱神谕者"] = 2684,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 779,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 2684,
								["c_max"] = 1905,
								["id"] = "瞄准射击",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 1,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["last_dps"] = 0,
					["nome"] = "啪啪",
					["spec"] = 254,
					["grupo"] = true,
					["total"] = 8876.006992,
					["on_hold"] = false,
					["custom"] = 0,
					["last_event"] = 0,
					["friendlyfire"] = {
					},
					["start_time"] = 1593181186,
					["serial"] = "Player-4920-01D0E17B",
					["classe"] = "HUNTER",
				}, -- [2]
				{
					["flag_original"] = 4369,
					["totalabsorbed"] = 0.009845,
					["damage_from"] = {
						["哈卡莱神谕者"] = true,
					},
					["targets"] = {
						["哈卡莱神谕者"] = 1274,
					},
					["pets"] = {
					},
					["last_dps"] = 0,
					["classe"] = "PET",
					["raid_targets"] = {
					},
					["total_without_pet"] = 1274.009845,
					["damage_taken"] = 423.009845,
					["dps_started"] = false,
					["total"] = 1274.009845,
					["delay"] = 0,
					["ownerName"] = "啪啪",
					["nome"] = "狼 <啪啪>",
					["spells"] = {
						["_ActorTable"] = {
							["!Melee"] = {
								["c_amt"] = 2,
								["b_amt"] = 0,
								["c_dmg"] = 236,
								["g_amt"] = 0,
								["n_max"] = 105,
								["targets"] = {
									["哈卡莱神谕者"] = 1120,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 884,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 16,
								["total"] = 1120,
								["c_max"] = 122,
								["id"] = "!Melee",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 14,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
							["撕咬"] = {
								["c_amt"] = 0,
								["b_amt"] = 0,
								["c_dmg"] = 0,
								["g_amt"] = 0,
								["n_max"] = 79,
								["targets"] = {
									["哈卡莱神谕者"] = 154,
								},
								["m_dmg"] = 0,
								["n_dmg"] = 154,
								["n_min"] = 0,
								["g_dmg"] = 0,
								["counter"] = 2,
								["total"] = 154,
								["c_max"] = 0,
								["id"] = "撕咬",
								["r_dmg"] = 0,
								["r_amt"] = 0,
								["m_crit"] = 0,
								["m_amt"] = 0,
								["c_min"] = 0,
								["successful_casted"] = 0,
								["b_dmg"] = 0,
								["n_amt"] = 2,
								["a_amt"] = 0,
								["a_dmg"] = 0,
							},
						},
						["tipo"] = 2,
					},
					["friendlyfire"] = {
					},
					["tipo"] = 1,
					["end_time"] = 1593181214,
					["custom"] = 0,
					["last_event"] = 0,
					["on_hold"] = false,
					["start_time"] = 1593181187,
					["serial"] = "Pet-0-4515-309-21098-9696-0200BA6F1B",
					["friendlyfire_total"] = 0,
				}, -- [3]
			},
		}, -- [1]
		{
			["tipo"] = 3,
			["_ActorTable"] = {
			},
		}, -- [2]
		{
			["tipo"] = 7,
			["_ActorTable"] = {
			},
		}, -- [3]
		{
			["tipo"] = 9,
			["_ActorTable"] = {
				{
					["flag_original"] = 1047,
					["debuff_uptime_spells"] = {
						["_ActorTable"] = {
							["摔绊"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = "摔绊",
								["uptime"] = 9,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["猎人印记"] = {
								["counter"] = 0,
								["appliedamt"] = 0,
								["activedamt"] = -1,
								["actived_at"] = 1593181212,
								["id"] = "猎人印记",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["驱散射击"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 1,
								["id"] = "驱散射击",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["毒蛇钉刺"] = {
								["counter"] = 0,
								["appliedamt"] = 0,
								["activedamt"] = -1,
								["actived_at"] = 1593181202,
								["id"] = "毒蛇钉刺",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["pets"] = {
						"狼 <啪啪>", -- [1]
					},
					["classe"] = "HUNTER",
					["buff_uptime_spells"] = {
						["_ActorTable"] = {
							["狂怒之嚎"] = {
								["counter"] = 0,
								["activedamt"] = 0,
								["appliedamt"] = 0,
								["id"] = "狂怒之嚎",
								["uptime"] = 0,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
							["强击光环"] = {
								["counter"] = 0,
								["activedamt"] = 1,
								["appliedamt"] = 1,
								["id"] = "强击光环",
								["uptime"] = 25,
								["targets"] = {
								},
								["refreshamt"] = 0,
							},
						},
						["tipo"] = 9,
					},
					["debuff_uptime"] = 9,
					["nome"] = "啪啪",
					["spec"] = 254,
					["grupo"] = true,
					["spell_cast"] = {
						["摔绊"] = 2,
						["瞄准射击"] = 2,
						["自动射击"] = 2,
						["多重射击"] = 2,
						["驱散射击"] = 1,
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["buff_uptime_targets"] = {
					},
					["debuff_uptime_targets"] = {
					},
					["serial"] = "Player-4920-01D0E17B",
					["buff_uptime"] = 25,
				}, -- [1]
				{
					["flag_original"] = 4369,
					["ownerName"] = "啪啪",
					["nome"] = "狼 <啪啪>",
					["pets"] = {
					},
					["last_event"] = 0,
					["tipo"] = 4,
					["classe"] = "PET",
					["serial"] = "Pet-0-4515-309-21098-9696-0200BA6F1B",
					["spell_cast"] = {
						["低吼"] = 3,
						["撕咬"] = 2,
					},
				}, -- [2]
				{
					["monster"] = true,
					["last_event"] = 0,
					["nome"] = "哈卡莱神谕者",
					["pets"] = {
					},
					["classe"] = "UNKNOW",
					["flag_original"] = 68168,
					["tipo"] = 4,
					["fight_component"] = true,
					["serial"] = "Creature-0-4505-0-208-11346-00007602FC",
					["spell_cast"] = {
						["治疗波"] = 1,
						["地震术"] = 1,
						["闪电链"] = 1,
					},
				}, -- [3]
			},
		}, -- [4]
		{
			["tipo"] = 2,
			["_ActorTable"] = {
			},
		}, -- [5]
		["raid_roster"] = {
		},
		["tempo_start"] = 1593181188,
		["last_events_tables"] = {
		},
		["alternate_power"] = {
		},
		["segments_added"] = {
			{
				["elapsed"] = 25.5369999999966,
				["type"] = 0,
				["name"] = "哈卡莱神谕者",
				["clock"] = "22:19:48",
			}, -- [1]
		},
		["combat_counter"] = 2002,
		["totals"] = {
			11788.01461, -- [1]
			-0.008328, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
			["voidzone_damage"] = 0,
			["frags_total"] = 0,
		},
		["player_last_events"] = {
		},
		["frags_need_refresh"] = false,
		["aura_timeline"] = {
		},
		["__call"] = {
		},
		["data_inicio"] = "22:19:48",
		["end_time"] = 103894.128,
		["cleu_timeline"] = {
		},
		["totals_grupo"] = {
			8876.005248, -- [1]
			0, -- [2]
			{
				0, -- [1]
				[0] = 0,
				["alternatepower"] = 0,
				[6] = 0,
				[3] = 0,
			}, -- [3]
			{
				["buff_uptime"] = 0,
				["ress"] = 0,
				["dead"] = 0,
				["cc_break"] = 0,
				["interrupt"] = 0,
				["debuff_uptime"] = 0,
				["dispell"] = 0,
				["cooldowns_defensive"] = 0,
			}, -- [4]
		},
		["overall_refreshed"] = true,
		["PhaseData"] = {
			{
				1, -- [1]
				1, -- [2]
			}, -- [1]
			["damage"] = {
			},
			["heal_section"] = {
			},
			["heal"] = {
			},
			["damage_section"] = {
			},
		},
		["hasSaved"] = true,
		["spells_cast_timeline"] = {
		},
		["data_fim"] = "22:20:14",
		["overall_enemy_name"] = "哈卡莱神谕者",
		["CombatSkillCache"] = {
		},
		["frags"] = {
		},
		["start_time"] = 103868.591,
		["TimeData"] = {
		},
		["cleu_events"] = {
			["n"] = 1,
		},
	},
	["combat_counter"] = 2010,
	["announce_firsthit"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["last_realversion"] = 142,
	["announce_cooldowns"] = {
		["ignored_cooldowns"] = {
		},
		["enabled"] = false,
		["custom"] = "",
		["channel"] = "RAID",
	},
	["rank_window"] = {
		["last_difficulty"] = 15,
		["last_raid"] = "",
	},
	["announce_damagerecord"] = {
		["enabled"] = true,
		["channel"] = "SELF",
	},
	["cached_specs"] = {
		["Player-4920-01D0E17B"] = 254,
	},
}
