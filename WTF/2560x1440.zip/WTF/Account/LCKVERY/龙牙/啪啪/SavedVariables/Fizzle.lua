
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["啪啪 - 龙牙"] = "啪啪 - 龙牙",
	},
	["profiles"] = {
		["啪啪 - 龙牙"] = {
		},
	},
}
