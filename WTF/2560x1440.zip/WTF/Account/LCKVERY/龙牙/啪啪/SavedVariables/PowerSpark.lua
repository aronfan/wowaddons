
PowerSparkDB = {
	["default"] = {
		["timer"] = 813579.037,
	},
}
