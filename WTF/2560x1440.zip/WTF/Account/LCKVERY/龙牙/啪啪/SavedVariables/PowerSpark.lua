
PowerSparkDB = {
	["default"] = {
		["timer"] = 660963.399,
	},
}
