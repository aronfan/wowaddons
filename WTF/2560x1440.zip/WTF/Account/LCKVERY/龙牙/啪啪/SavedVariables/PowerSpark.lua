
PowerSparkDB = {
	["default"] = {
		["timer"] = 681657.16,
	},
}
