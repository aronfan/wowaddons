
PowerSparkDB = {
	["default"] = {
		["timer"] = 1816478.787,
	},
}
