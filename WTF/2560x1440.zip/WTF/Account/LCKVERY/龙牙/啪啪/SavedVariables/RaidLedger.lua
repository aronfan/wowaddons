
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1589535711,
			["items"] = {
				{
					["beneficiary"] = "Chinav",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16799::::::::60:::::::|h[奥术师护腕]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "通用墨水",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18806::::::::60:::::::|h[熔火胫甲]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "通用墨水",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:17107::::::::60:::::::|h[龙血斗篷]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "通用墨水",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18817::::::::60:::::::|h[毁灭王冠]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "通用墨水",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16946::::::::60:::::::|h[无尽风暴护腿]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "通用墨水",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13075::::::::60:::::::|h[魔翼护腿]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "通用墨水",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13144::::::::60:::::::|h[平静腰带]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "通用墨水",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16901::::::::60:::::::|h[怒风腿甲]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18821::::::::60:::::::|h[迅击戒指]|h|r",
						["count"] = 1,
					},
				}, -- [9]
				{
					["beneficiary"] = "无双上將潘凤",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:17067::::::::60:::::::|h[上古角石魔典]|h|r",
						["count"] = 1,
					},
				}, -- [10]
				{
					["beneficiary"] = "请勿打脸",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16914::::::::60:::::::|h[灵风头冠]|h|r",
						["count"] = 1,
					},
				}, -- [11]
				{
					["beneficiary"] = "壹克拉的眼泪",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16908::::::::60:::::::|h[血牙头巾]|h|r",
						["count"] = 1,
					},
				}, -- [12]
				{
					["beneficiary"] = "丶阿拉蕾",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18422::::::::60:::::::|h[奥妮克希亚的头颅]|h|r",
						["count"] = 1,
					},
				}, -- [13]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [14]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19712::::::::60:::::::|h[紫色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [15]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [16]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [17]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [18]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [19]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19929::::::::60:::::::|h[淡血手套]|h|r",
						["count"] = 1,
					},
				}, -- [20]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19712::::::::60:::::::|h[紫色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [21]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [22]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [23]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19899::::::::60:::::::|h[仪式护腿]|h|r",
						["count"] = 1,
					},
				}, -- [24]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19722::::::::60:::::::|h[原始哈卡莱徽章]|h|r",
						["count"] = 1,
					},
				}, -- [25]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22711::::::::60:::::::|h[哈卡莱崇拜者披风]|h|r",
						["count"] = 1,
					},
				}, -- [26]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [27]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [28]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [29]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [30]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22637::::::::60:::::::|h[原始哈卡莱神像]|h|r",
						["count"] = 1,
					},
				}, -- [31]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19722::::::::60:::::::|h[原始哈卡莱徽章]|h|r",
						["count"] = 1,
					},
				}, -- [32]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19866::::::::60:::::::|h[哈卡莱战刃]|h|r",
						["count"] = 1,
					},
				}, -- [33]
				{
					["beneficiary"] = "微小澜",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19870::::::::60:::::::|h[哈卡莱血披风]|h|r",
						["count"] = 1,
					},
				}, -- [34]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
