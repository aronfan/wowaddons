
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1590821982,
			["items"] = {
				{
					["beneficiary"] = "易天萌牛",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:17067::::::::60:::::::|h[上古角石魔典]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "易天萌牛",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16914::::::::60:::::::|h[灵风头冠]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "易天萌牛",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16963::::::::60:::::::|h[愤怒头盔]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "易天萌牛",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13077::::::::60:::::::|h[乌瑟尔的腰带]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "易天萌牛",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13144::::::::60:::::::|h[平静腰带]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "易天萌牛",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:18422::::::::60:::::::|h[奥妮克希亚的头颅]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "易天萌牛",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:17413::::::::60:::::::|h[圣典：坚韧祷言]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:16674::::::::60:::1::::|h[野兽追猎者外套]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "无常十号",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:13098::::::::60:::1::::|h[痛苦指环]|h|r",
						["count"] = 1,
					},
				}, -- [9]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
