
ExAE_Config = {
	["阿雅@Enigma"] = {
		["CurrentSetId"] = 0,
	},
}
