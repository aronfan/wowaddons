
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["阿雅 - 龙牙"] = "阿雅 - 龙牙",
	},
	["profiles"] = {
		["阿雅 - 龙牙"] = {
		},
	},
}
