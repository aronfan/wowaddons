
FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["龙哥 - 龙牙"] = "龙哥 - 龙牙",
	},
	["profiles"] = {
		["龙哥 - 龙牙"] = {
		},
	},
}
