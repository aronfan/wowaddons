
GearMenuConfiguration = {
	["enableDragAndDrop"] = true,
	["addonVersion"] = "v1.3.0",
	["showKeyBindings"] = true,
	["enableTooltips"] = true,
	["slots"] = {
		1, -- [1]
		99, -- [2]
		3, -- [3]
		15, -- [4]
		99, -- [5]
		10, -- [6]
		8, -- [7]
		99, -- [8]
		99, -- [9]
		99, -- [10]
		99, -- [11]
		13, -- [12]
		14, -- [13]
		99, -- [14]
		16, -- [15]
		17, -- [16]
		99, -- [17]
	},
	["lockGearBar"] = true,
	["enableFastpress"] = false,
	["slotSize"] = 40,
	["showCooldowns"] = true,
	["frames"] = {
		["GM_GearBar"] = {
			["posX"] = -92.3993225097656,
			["posY"] = 35.444522857666,
			["point"] = "BOTTOMRIGHT",
			["relativePoint"] = "BOTTOMRIGHT",
		},
	},
	["enableSimpleTooltips"] = true,
	["quickChangeRules"] = {
	},
	["filterItemQuality"] = 0,
}
