
GearMenuConfiguration = {
	["enableDragAndDrop"] = true,
	["addonVersion"] = "v1.3.0",
	["showKeyBindings"] = true,
	["enableTooltips"] = true,
	["slots"] = {
		1, -- [1]
		99, -- [2]
		15, -- [3]
		5, -- [4]
		6, -- [5]
		99, -- [6]
		8, -- [7]
		99, -- [8]
		99, -- [9]
		99, -- [10]
		99, -- [11]
		13, -- [12]
		14, -- [13]
		99, -- [14]
		16, -- [15]
		17, -- [16]
		99, -- [17]
	},
	["lockGearBar"] = true,
	["enableFastpress"] = false,
	["slotSize"] = 40,
	["showCooldowns"] = true,
	["filterItemQuality"] = 0,
	["enableSimpleTooltips"] = true,
	["quickChangeRules"] = {
	},
	["frames"] = {
		["GM_GearBar"] = {
			["relativePoint"] = "BOTTOMRIGHT",
			["point"] = "BOTTOMRIGHT",
			["posY"] = 35.444522857666,
			["posX"] = -92.3993225097656,
		},
	},
}
