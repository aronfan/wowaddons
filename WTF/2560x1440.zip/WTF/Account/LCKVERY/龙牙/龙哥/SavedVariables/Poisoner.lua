
POISONER_CONFIG = {
	["TooltipType"] = "full",
	["Buttons"] = {
		["FreeButton"] = {
			["Active"] = 1,
			["Scale"] = 1,
			["Position"] = {
				["RelativeTo"] = "UIParent",
				["XPos"] = 267.088897705078,
				["RelativePoint"] = "BOTTOM",
				["Anchor"] = "BOTTOM",
				["YPos"] = 42.5777778625488,
			},
			["Alpha"] = 1,
			["Lock"] = 0,
		},
		["QuickButton"] = {
			["Scale"] = 1,
			["Position"] = {
				["RelativeTo"] = "UIParent",
				["XPos"] = 0,
				["RelativePoint"] = "CENTER",
				["Anchor"] = "CENTER",
				["YPos"] = 0,
			},
			["Alpha"] = 1,
			["Lock"] = 1,
		},
		["LDBIcon"] = {
			["hide"] = "true",
		},
	},
	["Preset"] = {
		["Normal"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
		["CTRL"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
		["Overwrite"] = 0,
		["ALT"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
		["SHIFT"] = {
			["Mainhand"] = 1,
			["Offhand"] = 1,
		},
	},
	["StartedOnce"] = 1,
	["Menu"] = {
		["Spacing"] = 0,
		["Scale"] = 1,
		["Position"] = "right",
		["Parent"] = "Poisoner_FreeButton",
		["AutoHide"] = {
			["inCombat"] = 0,
			["Time"] = 10,
			["Active"] = 0,
		},
		["ShowOnMouseover"] = 0,
		["Sorting"] = {
			"IP", -- [1]
			"DP", -- [2]
			"WP", -- [3]
			"MP", -- [4]
			"CP", -- [5]
			"SS", -- [6]
			"WS", -- [7]
		},
	},
	["PrintClickedPoison"] = 1,
	["Timer"] = {
		["Active"] = 1,
		["Scale"] = 1,
		["WarningThreshold"] = 2,
		["Alpha"] = 1,
		["Output"] = {
			["Aura"] = 1,
			["ErrorFrame"] = 1,
			["Audio"] = 1,
			["Chat"] = 1,
		},
		["IgnoreWhileFishing"] = 0,
		["Position"] = {
			["RelativeTo"] = "UIParent",
			["XPos"] = 0,
			["RelativePoint"] = "CENTER",
			["Anchor"] = "CENTER",
			["YPos"] = 100,
			["OnlyInstanced"] = 0,
		},
		["OnlyInstanced"] = 0,
		["Lock"] = 1,
		["Weapon"] = {
			["MainHand"] = 1,
			["OffHand"] = 1,
		},
	},
	["Poisons"] = {
		[2863] = {
			["Name"] = "粗制磨刀石",
			["Texture"] = 135249,
		},
		[3239] = {
			["Name"] = "劣质平衡石",
			["Texture"] = 135255,
		},
		[3241] = {
			["Name"] = "重平衡石",
			["Texture"] = 135257,
		},
		[8926] = {
			["Name"] = "速效毒药 IV",
			["Texture"] = 132273,
		},
		[6951] = {
			["Name"] = "麻痹毒药 II",
			["Texture"] = 136066,
		},
		[20844] = {
			["Name"] = "致命毒药 V",
			["Texture"] = 132290,
		},
		[3776] = {
			["Name"] = "致残毒药 II",
			["Texture"] = 134799,
		},
		[8927] = {
			["Name"] = "速效毒药 V",
			["Texture"] = 132273,
		},
		[6947] = {
			["Name"] = "速效毒药",
			["Texture"] = 132273,
		},
		[2893] = {
			["Name"] = "致命毒药 II",
			["Texture"] = 132290,
		},
		[8984] = {
			["Name"] = "致命毒药 III",
			["Texture"] = 132290,
		},
		[8928] = {
			["Name"] = "速效毒药 VI",
			["Texture"] = 132273,
		},
		[10920] = {
			["Name"] = "致伤毒药 II",
			["Texture"] = 132274,
		},
		[12404] = {
			["Name"] = "致密磨刀石",
			["Texture"] = 135252,
		},
		[2862] = {
			["Name"] = "劣质磨刀石",
			["Texture"] = 135248,
		},
		[12643] = {
			["Name"] = "致密平衡石",
			["Texture"] = 135259,
		},
		[10921] = {
			["Name"] = "致伤毒药 III",
			["Texture"] = 132274,
		},
		[7964] = {
			["Name"] = "坚固的磨刀石",
			["Texture"] = 135251,
		},
		[18262] = {
			["Name"] = "元素磨刀石",
			["Texture"] = 135228,
		},
		[6949] = {
			["Name"] = "速效毒药 II",
			["Texture"] = 132273,
		},
		[10922] = {
			["Name"] = "致伤毒药 IV",
			["Texture"] = 132274,
		},
		[3775] = {
			["Name"] = "致残毒药",
			["Texture"] = 134799,
		},
		[8985] = {
			["Name"] = "致命毒药 IV",
			["Texture"] = 132290,
		},
		[5237] = {
			["Name"] = "麻痹毒药",
			["Texture"] = 136066,
		},
		[10918] = {
			["Name"] = "致伤毒药",
			["Texture"] = 132274,
		},
		[7965] = {
			["Name"] = "坚固的平衡石",
			["Texture"] = 135258,
		},
		[9186] = {
			["Name"] = "麻痹毒药 III",
			["Texture"] = 136066,
		},
		[6950] = {
			["Name"] = "速效毒药 III",
			["Texture"] = 132273,
		},
		[3240] = {
			["Name"] = "粗制平衡石",
			["Texture"] = 135256,
		},
		[2892] = {
			["Name"] = "致命毒药",
			["Texture"] = 132290,
		},
		[2871] = {
			["Name"] = "重磨刀石",
			["Texture"] = 135250,
		},
	},
	["Enabled"] = 1,
	["Buy"] = {
		["MP"] = 0,
		["WP"] = 0,
		["DP"] = 0,
		["Active"] = 1,
		["Check"] = 1,
		["Prompt"] = 0,
		["CP"] = 0,
		["IP"] = 0,
	},
}
