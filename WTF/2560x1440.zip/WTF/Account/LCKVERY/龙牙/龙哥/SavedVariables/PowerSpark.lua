
PowerSparkDB = {
	["default"] = {
		["timer"] = 616106.877,
	},
}
