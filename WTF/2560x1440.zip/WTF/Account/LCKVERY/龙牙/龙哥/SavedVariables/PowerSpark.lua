
PowerSparkDB = {
	["default"] = {
		["timer"] = 735319.517,
	},
}
