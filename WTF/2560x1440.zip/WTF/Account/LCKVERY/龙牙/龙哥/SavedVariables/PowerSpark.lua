
PowerSparkDB = {
	["default"] = {
		["timer"] = 599456.453,
	},
}
