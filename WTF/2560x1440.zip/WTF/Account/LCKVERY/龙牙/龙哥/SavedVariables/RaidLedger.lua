
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1589977319,
			["items"] = {
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19915::::::::60:::::::|h[祖利安防御者]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22718::::::::60:::::::|h[浴血面具]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19717::::::::60:::::::|h[原始哈卡莱护臂]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19905::::::::60:::::::|h[赞吉尔指环]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19716::::::::60:::::::|h[原始哈卡莱护腕]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22716::::::::60:::::::|h[无尽潜能腰带]|h|r",
						["count"] = 1,
					},
				}, -- [9]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [10]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [11]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22712::::::::60:::::::|h[部族之力]|h|r",
						["count"] = 1,
					},
				}, -- [12]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19719::::::::60:::::::|h[原始哈卡莱束带]|h|r",
						["count"] = 1,
					},
				}, -- [13]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19871::::::::60:::::::|h[保护之符]|h|r",
						["count"] = 1,
					},
				}, -- [14]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [15]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [16]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [17]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19873::::::::60:::::::|h[督军的红色指环]|h|r",
						["count"] = 1,
					},
				}, -- [18]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19867::::::::60:::::::|h[血领主庇护者]|h|r",
						["count"] = 1,
					},
				}, -- [19]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19719::::::::60:::::::|h[原始哈卡莱束带]|h|r",
						["count"] = 1,
					},
				}, -- [20]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:22722::::::::60:::::::|h[古拉巴什狂暴者徽记]|h|r",
						["count"] = 1,
					},
				}, -- [21]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19901::::::::60:::::::|h[祖利安切割者]|h|r",
						["count"] = 1,
					},
				}, -- [22]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19720::::::::60:::::::|h[原始哈卡莱腰带]|h|r",
						["count"] = 1,
					},
				}, -- [23]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [24]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19901::::::::60:::::::|h[祖利安切割者]|h|r",
						["count"] = 1,
					},
				}, -- [25]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19910::::::::60:::::::|h[娅尔罗之握]|h|r",
						["count"] = 1,
					},
				}, -- [26]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22712::::::::60:::::::|h[部族之力]|h|r",
						["count"] = 1,
					},
				}, -- [27]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19719::::::::60:::::::|h[原始哈卡莱束带]|h|r",
						["count"] = 1,
					},
				}, -- [28]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [29]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [30]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19885::::::::60:::::::|h[金度的邪眼]|h|r",
						["count"] = 1,
					},
				}, -- [31]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19721::::::::60:::::::|h[原始哈卡莱披肩]|h|r",
						["count"] = 1,
					},
				}, -- [32]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22637::::::::60:::::::|h[原始哈卡莱神像]|h|r",
						["count"] = 1,
					},
				}, -- [33]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19929::::::::60:::::::|h[淡血手套]|h|r",
						["count"] = 1,
					},
				}, -- [34]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [35]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [36]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [37]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [38]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [39]
				{
					["beneficiary"] = "目中无壬",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [40]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19802::::::::60:::::::|h[哈卡之心]|h|r",
						["count"] = 1,
					},
				}, -- [41]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19857::::::::60:::::::|h[吞噬披风]|h|r",
						["count"] = 1,
					},
				}, -- [42]
				{
					["beneficiary"] = "恋战鱼兒",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19859::::::::60:::::::|h[无面者之牙]|h|r",
						["count"] = 1,
					},
				}, -- [43]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
