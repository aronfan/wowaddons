
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1593003731,
			["items"] = {
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19920::::::::60:::::::|h[首领指环]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22711::::::::60:::::::|h[哈卡莱崇拜者披风]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19712::::::::60:::::::|h[紫色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19905::::::::60:::::::|h[赞吉尔指环]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19722::::::::60:::::::|h[原始哈卡莱徽章]|h|r",
						["count"] = 1,
					},
				}, -- [6]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22714::::::::60:::::::|h[祭祀护手]|h|r",
						["count"] = 1,
					},
				}, -- [7]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [8]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [9]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [10]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [11]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:20032::::::::60:::::::|h[仪祭海袍]|h|r",
						["count"] = 1,
					},
				}, -- [12]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:22721::::::::60:::::::|h[惩戒指环]|h|r",
						["count"] = 1,
					},
				}, -- [13]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19719::::::::60:::::::|h[原始哈卡莱束带]|h|r",
						["count"] = 1,
					},
				}, -- [14]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [15]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [16]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [17]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19967::::::::60:::::::|h[心智凋零者]|h|r",
						["count"] = 1,
					},
				}, -- [18]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19712::::::::60:::::::|h[紫色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [19]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [20]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:22721::::::::60:::::::|h[惩戒指环]|h|r",
						["count"] = 1,
					},
				}, -- [21]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19896::::::::60:::::::|h[塞卡尔之握]|h|r",
						["count"] = 1,
					},
				}, -- [22]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19721::::::::60:::::::|h[原始哈卡莱披肩]|h|r",
						["count"] = 1,
					},
				}, -- [23]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [24]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [25]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [26]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [27]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [28]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19909::::::::60:::::::|h[娅尔罗的意志]|h|r",
						["count"] = 1,
					},
				}, -- [29]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22716::::::::60:::::::|h[无尽潜能腰带]|h|r",
						["count"] = 1,
					},
				}, -- [30]
				{
					["beneficiary"] = "芭拉小魔仙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19720::::::::60:::::::|h[原始哈卡莱腰带]|h|r",
						["count"] = 1,
					},
				}, -- [31]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [32]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [33]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [34]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [35]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [36]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [37]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19865::::::::60:::::::|h[哈卡莱战刃]|h|r",
						["count"] = 1,
					},
				}, -- [38]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19857::::::::60:::::::|h[吞噬披风]|h|r",
						["count"] = 1,
					},
				}, -- [39]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [40]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [41]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19710::::::::60:::::::|h[橙色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [42]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19712::::::::60:::::::|h[紫色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [43]
				{
					["beneficiary"] = "Aaf",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19727::::::::60:::::::|h[血镰刀]|h|r",
						["count"] = 1,
					},
				}, -- [44]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19727::::::::60:::::::|h[血镰刀]|h|r",
						["count"] = 1,
					},
				}, -- [45]
				{
					["beneficiary"] = "忽悠人的先祖",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22637::::::::60:::::::|h[原始哈卡莱神像]|h|r",
						["count"] = 1,
					},
				}, -- [46]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [47]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [48]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [49]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [50]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [51]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19719::::::::60:::::::|h[原始哈卡莱束带]|h|r",
						["count"] = 1,
					},
				}, -- [52]
				{
					["beneficiary"] = "颤抖吧娇花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19887::::::::60:::::::|h[血污腿甲]|h|r",
						["count"] = 1,
					},
				}, -- [53]
				{
					["beneficiary"] = "小雨同学",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19894::::::::60:::::::|h[浸血护手]|h|r",
						["count"] = 1,
					},
				}, -- [54]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [55]
				{
					["beneficiary"] = "我很迷人",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:18335::::::::60:::::::|h[原始黑钻石]|h|r",
						["count"] = 1,
					},
				}, -- [56]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [57]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [58]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19712::::::::60:::::::|h[紫色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [59]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19714::::::::60:::::::|h[银色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [60]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19884::::::::60:::::::|h[金度的裁决]|h|r",
						["count"] = 1,
					},
				}, -- [61]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19894::::::::60:::::::|h[浸血护手]|h|r",
						["count"] = 1,
					},
				}, -- [62]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22637::::::::60:::::::|h[原始哈卡莱神像]|h|r",
						["count"] = 1,
					},
				}, -- [63]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [64]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [65]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [66]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19922::::::::60:::::::|h[娅尔罗的巫毒棒]|h|r",
						["count"] = 1,
					},
				}, -- [67]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22715::::::::60:::::::|h[被折磨者的手套]|h|r",
						["count"] = 1,
					},
				}, -- [68]
				{
					["beneficiary"] = "专偷骨头的贼",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19727::::::::60:::::::|h[血镰刀]|h|r",
						["count"] = 1,
					},
				}, -- [69]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19898::::::::60:::::::|h[巨魔族长徽记]|h|r",
						["count"] = 1,
					},
				}, -- [70]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19711::::::::60:::::::|h[绿色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [71]
				{
					["beneficiary"] = "你",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19898::::::::60:::::::|h[巨魔族长徽记]|h|r",
						["count"] = 1,
					},
				}, -- [72]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19713::::::::60:::::::|h[青铜哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [73]
				{
					["beneficiary"] = "紫电麒麟",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [74]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:20032::::::::60:::::::|h[仪祭海袍]|h|r",
						["count"] = 1,
					},
				}, -- [75]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22713::::::::60:::::::|h[祖利安典礼权杖]|h|r",
						["count"] = 1,
					},
				}, -- [76]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19708::::::::60:::::::|h[蓝色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [77]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22637::::::::60:::::::|h[原始哈卡莱神像]|h|r",
						["count"] = 1,
					},
				}, -- [78]
				{
					["beneficiary"] = "坦克花花",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:20038::::::::60:::::::|h[曼多基尔之刺]|h|r",
						["count"] = 1,
					},
				}, -- [79]
				{
					["beneficiary"] = "虎牙丶丫丫",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19867::::::::60:::::::|h[血领主庇护者]|h|r",
						["count"] = 1,
					},
				}, -- [80]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19709::::::::60:::::::|h[黄色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [81]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19707::::::::60:::::::|h[红色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [82]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22715::::::::60:::::::|h[被折磨者的手套]|h|r",
						["count"] = 1,
					},
				}, -- [83]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19906::::::::60:::::::|h[浴血软鞋]|h|r",
						["count"] = 1,
					},
				}, -- [84]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:19715::::::::60:::::::|h[金色哈卡莱宝石]|h|r",
						["count"] = 1,
					},
				}, -- [85]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:22714::::::::60:::::::|h[祭祀护手]|h|r",
						["count"] = 1,
					},
				}, -- [86]
				{
					["beneficiary"] = "梅利奥达灬斯",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19865::::::::60:::::::|h[哈卡莱战刃]|h|r",
						["count"] = 1,
					},
				}, -- [87]
				{
					["beneficiary"] = "紫电麒麟",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19864::::::::60:::::::|h[血之召唤者]|h|r",
						["count"] = 1,
					},
				}, -- [88]
				{
					["beneficiary"] = "紫电麒麟",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19802::::::::60:::::::|h[哈卡之心]|h|r",
						["count"] = 1,
					},
				}, -- [89]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [90]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [91]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [92]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [93]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [94]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [95]
				{
					["beneficiary"] = "心有琳熙",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cff0070dd|Hitem:14344::::::::60:::::::|h[大块魔光碎片]|h|r",
						["count"] = 1,
					},
				}, -- [96]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
