
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1588343067,
			["items"] = {
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
