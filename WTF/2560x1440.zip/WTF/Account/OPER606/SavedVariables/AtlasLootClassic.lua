
AtlasLootClassicDB = {
	["global"] = {
		["__addonrevision"] = 1050001,
	},
	["profileKeys"] = {
		["刚哥 - 龙牙"] = "刚哥 - 龙牙",
	},
	["profiles"] = {
		["刚哥 - 龙牙"] = {
			["minimap"] = {
				["minimapPos"] = 188.055956825386,
			},
		},
	},
}
