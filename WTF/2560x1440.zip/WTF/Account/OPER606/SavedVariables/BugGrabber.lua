
BugGrabberDB = {
	["lastSanitation"] = 3,
	["session"] = 5,
	["errors"] = {
		{
			["message"] = "...face\\AddOns\\Questie\\Modules\\Network\\QuestieComms.lua:448: attempt to concatenate local 'patch' (a nil value)",
			["time"] = "2020/05/08 20:23:51",
			["stack"] = "...face\\AddOns\\Questie\\Modules\\Network\\QuestieComms.lua:448: in function `CreatePacket'\n...face\\AddOns\\Questie\\Modules\\Network\\QuestieComms.lua:223: in function <...face\\AddOns\\Questie\\Modules\\Network\\QuestieComms.lua:218>\n[C]: ?\n...sic\\Libs\\CallbackHandler-1.0\\CallbackHandler-1.0-7.lua:29: in function <...sic\\Libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:25>\n...sic\\Libs\\CallbackHandler-1.0\\CallbackHandler-1.0-7.lua:64: in function `SendMessage'\n...rface\\AddOns\\Questie\\Modules\\QuestieEventHandler.lua:341: in function <...rface\\AddOns\\Questie\\Modules\\QuestieEventHandler.lua:333>\nInterface\\SharedXML\\C_TimerAugment.lua:16: in function <Interface\\SharedXML\\C_TimerAugment.lua:14>",
			["session"] = 2,
			["counter"] = 3,
		}, -- [1]
	},
}
