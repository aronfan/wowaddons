
EasyFramesDB = {
	["profileKeys"] = {
		["刚哥 - 龙牙"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
