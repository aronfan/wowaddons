
NugCastDB = {
	["nameplateCastbars"] = false,
}
