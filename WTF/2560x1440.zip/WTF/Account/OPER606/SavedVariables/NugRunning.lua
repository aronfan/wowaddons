
NRunDB_Global = {
	["charspec"] = {
	},
}
NugRunningConfigCustom = {
	["HUNTER"] = {
	},
}
