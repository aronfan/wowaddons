
Postal3ClassicDB = {
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"刚哥|龙牙|Horde|60|HUNTER", -- [1]
			},
		},
	},
	["profileKeys"] = {
		["刚哥 - 龙牙"] = "刚哥 - 龙牙",
	},
	["profiles"] = {
		["刚哥 - 龙牙"] = {
		},
	},
}
