
SpyDB = {
	["kosData"] = {
		["龙牙"] = {
			["Horde"] = {
				["刚哥"] = {
				},
			},
		},
	},
	["removeKOSData"] = {
		["龙牙"] = {
			["Horde"] = {
			},
		},
	},
	["profileKeys"] = {
		["刚哥 - 龙牙"] = "刚哥 - 龙牙",
	},
	["profiles"] = {
		["刚哥 - 龙牙"] = {
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["AppendUnitNameCheck"] = true,
			["MainWindowVis"] = false,
			["AppendUnitKoSCheck"] = true,
		},
	},
}
