
StatusBars2_SettingsDB = {
	["database"] = {
		["刚哥-龙牙"] = {
			["font"] = 1,
			["groups"] = {
				{
				}, -- [1]
				{
				}, -- [2]
				{
				}, -- [3]
				{
				}, -- [4]
			},
			["position"] = {
				["y"] = 0,
				["x"] = 0,
			},
			["locked"] = true,
			["textDisplayOption"] = 1,
			["bars"] = {
				["focusPower"] = {
					["enabled"] = "Auto",
					["percentDisplayOption"] = "Right",
					["index"] = 2,
					["group"] = 3,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["flash"] = false,
				},
				["targetPower"] = {
					["enabled"] = "Auto",
					["showSpell"] = true,
					["index"] = 2,
					["group"] = 2,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["percentDisplayOption"] = "Right",
				},
				["playerHealth"] = {
					["enabled"] = "Auto",
					["percentDisplayOption"] = "Right",
					["index"] = 1,
					["group"] = 1,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["flash"] = true,
				},
				["playerAura"] = {
					["enabled"] = "Auto",
					["index"] = 7,
					["flashThreshold"] = 0.4,
					["group"] = 1,
					["showDebuffs"] = true,
					["layoutType"] = "AutoLayout",
					["showBuffs"] = true,
				},
				["petAura"] = {
					["enabled"] = "Auto",
					["index"] = 7,
					["flashThreshold"] = 0.4,
					["group"] = 4,
					["showDebuffs"] = true,
					["layoutType"] = "AutoLayout",
					["showBuffs"] = true,
				},
				["petPower"] = {
					["enabled"] = "Auto",
					["percentDisplayOption"] = "Right",
					["index"] = 2,
					["group"] = 4,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["flash"] = false,
				},
				["targetAura"] = {
					["enabled"] = "Auto",
					["index"] = 7,
					["flashThreshold"] = 0.4,
					["group"] = 2,
					["showDebuffs"] = true,
					["layoutType"] = "AutoLayout",
					["showBuffs"] = true,
				},
				["petHealth"] = {
					["enabled"] = "Auto",
					["percentDisplayOption"] = "Right",
					["index"] = 1,
					["group"] = 4,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["flash"] = true,
				},
				["playerPower"] = {
					["enabled"] = "Auto",
					["percentDisplayOption"] = "Right",
					["index"] = 2,
					["group"] = 1,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["flash"] = true,
				},
				["targetHealth"] = {
					["enabled"] = "Auto",
					["percentDisplayOption"] = "Right",
					["index"] = 1,
					["group"] = 2,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["flash"] = false,
				},
				["focusHealth"] = {
					["enabled"] = "Auto",
					["percentDisplayOption"] = "Right",
					["index"] = 1,
					["group"] = 3,
					["flashThreshold"] = 0.4,
					["layoutType"] = "AutoLayout",
					["flash"] = false,
				},
				["focusAura"] = {
					["enabled"] = "Auto",
					["index"] = 7,
					["flashThreshold"] = 0.4,
					["group"] = 3,
					["showDebuffs"] = true,
					["layoutType"] = "AutoLayout",
					["showBuffs"] = true,
				},
			},
			["fade"] = true,
		},
	},
	["SaveDataVersion"] = 1.4,
}
