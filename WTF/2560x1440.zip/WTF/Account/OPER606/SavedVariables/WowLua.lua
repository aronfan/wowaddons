
WowLua_DB = {
	["currentPage"] = 1,
	["fontSize"] = 14,
	["pages"] = {
		{
			["untitled"] = true,
			["name"] = "Untitled 1",
			["content"] = "",
		}, -- [1]
	},
	["untitled"] = 2,
}
