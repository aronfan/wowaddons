
bloodOfHerosDB = {
	["auto"] = 1,
}
