
CharacterStatsClassicCharacterDB = {
	["selectedRightStatsCategory"] = 3,
	["selectedLeftStatsCategory"] = 1,
}
