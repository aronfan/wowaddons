
ExAE_Config = {
	["刚哥@Enigma"] = {
		["CurrentSetId"] = 0,
	},
}
