
NRunDB_Char = {
}
