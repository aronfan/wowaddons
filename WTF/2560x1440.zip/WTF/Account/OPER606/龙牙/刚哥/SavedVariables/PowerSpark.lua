
PowerSparkDB = {
	["default"] = {
		["timer"] = 1905122.117,
	},
}
