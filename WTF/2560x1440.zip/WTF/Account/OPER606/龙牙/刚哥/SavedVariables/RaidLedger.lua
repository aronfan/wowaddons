
RaidLedgerDatabase = {
	["ledgers"] = {
		{
			["time"] = 1588940627,
			["items"] = {
				{
					["beneficiary"] = "冷月的独白",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19370::::::::60:::::::|h[黑翼衬肩]|h|r",
						["count"] = 1,
					},
				}, -- [1]
				{
					["beneficiary"] = "冷月的独白",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16904::::::::60:::::::|h[怒风护腕]|h|r",
						["count"] = 1,
					},
				}, -- [2]
				{
					["beneficiary"] = "冷月的独白",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16918::::::::60:::::::|h[灵风束腕]|h|r",
						["count"] = 1,
					},
				}, -- [3]
				{
					["beneficiary"] = "冷月的独白",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16818::::::::60:::::::|h[灵风腰带]|h|r",
						["count"] = 1,
					},
				}, -- [4]
				{
					["beneficiary"] = "冷月的独白",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:16818::::::::60:::::::|h[灵风腰带]|h|r",
						["count"] = 1,
					},
				}, -- [5]
				{
					["beneficiary"] = "冷月的独白",
					["type"] = "CREDIT",
					["costtype"] = "GOLD",
					["cost"] = 0,
					["costcache"] = 0,
					["detail"] = {
						["type"] = "ITEM",
						["item"] = "|cffa335ee|Hitem:19346::::::::60:::::::|h[龙牙之刃]|h|r",
						["count"] = 1,
					},
				}, -- [6]
			},
		}, -- [1]
	},
	["config"] = {
		["autoaddloot"] = 1,
		["filterlevel"] = 3,
		["debittemplates"] = {
		},
	},
	["current"] = 1,
}
