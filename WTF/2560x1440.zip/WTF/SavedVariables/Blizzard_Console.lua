
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Total: 27d 1h 24m 53s", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Level: 19d 9h 33m 12s", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18034, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21365, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 18037, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9415, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9408, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9406, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9316, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21618, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9318, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 21626, effect aura: 85, which is wrong", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 23264, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 13, which is wrong", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9416, effect aura: 135, which is wrong", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Proficiency in item class 2 set to 0x0000000480", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Proficiency in item class 2 set to 0x0000008480", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Proficiency in item class 4 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Proficiency in item class 2 set to 0x000000c480", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Proficiency in item class 2 set to 0x000008c480", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Proficiency in item class 4 set to 0x0000000003", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Proficiency in item class 2 set to 0x000008c480", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Proficiency in item class 4 set to 0x0000000003", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Weather changed to 0, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Time set to 5/31/2020 (Sun) 21:26", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Water detail changed to 2", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Ripple detail changed to 1", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"Sunshafts quality changed to 2", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"WorldPoolUsage must be stream, dynamic or static.", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"CVar 'worldPoolUsage' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Projected textures enabled.", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Shadow mode changed to 3 - 3 band dynamic shadows, 2048", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Shadow texture size changed to 2048.", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"SSAO mode set to 4", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"SSAO distance value set to 100.000000", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"SSAO blur set to 2", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"Terrain mip level changed to 0.", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"MSAA set to 2 color samples, 2 coverage samples", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"Component texture lod changed to 0", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"Component texture lod changed to 0", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"FFX: Anti Aliasing Mode disabled", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"FFX: Color correction enabled", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"[IBN_Login] Joining realmsubRegion=\"45-101-89\" realmAddress=\"45-1-44\"", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Proficiency in item class 2 set to 0x000000018d", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Proficiency in item class 2 set to 0x000000058d", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Proficiency in item class 2 set to 0x000000058f", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Proficiency in item class 2 set to 0x000000858f", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Proficiency in item class 2 set to 0x000001858f", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Proficiency in item class 4 set to 0x0000000001", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Proficiency in item class 2 set to 0x000001c58f", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Proficiency in item class 2 set to 0x000005c58f", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Proficiency in item class 2 set to 0x000005c5cf", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"Proficiency in item class 2 set to 0x000015c5cf", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"Proficiency in item class 4 set to 0x0000000009", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"Proficiency in item class 4 set to 0x000000000d", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"Proficiency in item class 4 set to 0x000000000f", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"Proficiency in item class 2 set to 0x000015e5cf", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"Proficiency in item class 2 set to 0x000015e5cf", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Proficiency in item class 4 set to 0x000000000f", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Weather changed to 0, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Time set to 5/31/2020 (Sun) 21:28", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Total: 21d 20h 5m 46s", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Level: 14d 14h 10m 0s", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Weather changed to 0, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Weather changed to 0, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Time played:", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"Total: 21d 20h 15m 51s", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Level: 14d 14h 20m 5s", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 99, which is wrong", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"CGast - CGItemStatsSummary::ParseSpellRec is being called for spellID: 9335, effect aura: 124, which is wrong", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Weather changed to 0, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"DBCache::CancelCallback ignored", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 300,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
